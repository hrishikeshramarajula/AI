// 🎯 Task Decomposition and Planning Engine
// This component breaks down complex tasks into manageable steps and creates execution plans

export interface TaskPlan {
  id: string;
  goal: string;
  description: string;
  tasks: Task[];
  dependencies: DependencyGraph;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  estimatedDuration: number;
  riskAssessment: RiskAssessment;
  resourceRequirements: ResourceRequirements;
  successCriteria: string[];
}

export interface Task {
  id: string;
  name: string;
  description: string;
  type: 'analysis' | 'development' | 'testing' | 'deployment' | 'cleanup' | 'verification';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  estimatedTime: number;
  dependencies: string[];
  requiredResources: string[];
  expectedOutput: string;
  failureHandling: FailureHandling;
  status: 'pending' | 'in_progress' | 'completed' | 'failed' | 'skipped';
}

export interface DependencyGraph {
  nodes: DependencyNode[];
  edges: DependencyEdge[];
  criticalPath: string[];
}

export interface DependencyNode {
  id: string;
  task: Task;
  position: { x: number; y: number };
  level: number;
}

export interface DependencyEdge {
  from: string;
  to: string;
  type: 'strong' | 'weak' | 'optional';
  description: string;
}

export interface RiskAssessment {
  overallRisk: 'low' | 'medium' | 'high' | 'critical';
  risks: Risk[];
  mitigationStrategies: MitigationStrategy[];
}

export interface Risk {
  id: string;
  description: string;
  probability: 'low' | 'medium' | 'high';
  impact: 'low' | 'medium' | 'high' | 'critical';
  category: 'technical' | 'operational' | 'resource' | 'external';
  affectedTasks: string[];
}

export interface MitigationStrategy {
  riskId: string;
  strategy: string;
  effectiveness: 'low' | 'medium' | 'high';
  cost: 'low' | 'medium' | 'high';
}

export interface ResourceRequirements {
  computational: ComputationalResources;
  human: HumanResources;
  time: TimeResources;
  tools: ToolResources;
}

export interface ComputationalResources {
  cpu: string;
  memory: string;
  storage: string;
  network: string;
}

export interface HumanResources {
  developers: number;
  testers: number;
  designers: number;
  managers: number;
}

export interface TimeResources {
  estimatedTotal: number;
  buffer: number;
  milestones: Milestone[];
}

export interface Milestone {
  id: string;
  name: string;
  deadline: number;
  dependencies: string[];
}

export interface ToolResources {
  required: string[];
  optional: string[];
  versions: { [key: string]: string };
}

export interface FailureHandling {
  retryStrategy: 'immediate' | 'delayed' | 'manual';
  maxRetries: number;
  fallbackTasks: string[];
  escalationProcedures: string[];
}

export class TaskPlanner {
  private taskTemplates: TaskTemplate[];
  private planningStrategies: PlanningStrategy[];
  private initialized: boolean = false;

  constructor() {
    this.taskTemplates = this.initializeTaskTemplates();
    this.planningStrategies = this.initializePlanningStrategies();
  }

  public async initialize(): Promise<void> {
    this.initialized = true;
    console.log('🎯 Task Planner initialized successfully');
  }

  // 🎯 Main planning method - creates comprehensive task plans
  public async createPlan(nluResult: any, context?: any): Promise<TaskPlan> {
    console.log('🎯 Creating task plan for intent:', nluResult.intent);

    try {
      // Step 1: Goal Analysis
      console.log('📋 Analyzing goal...');
      const goalAnalysis = await this.analyzeGoal(nluResult, context);
      console.log(`✅ Goal analyzed - Complexity: ${goalAnalysis.complexity}`);

      // Step 2: Task Decomposition
      console.log('🔨 Decomposing tasks...');
      const decomposedTasks = await this.decomposeTasks(goalAnalysis, nluResult);
      console.log(`✅ Tasks decomposed - ${decomposedTasks.length} tasks identified`);

      // Step 3: Dependency Analysis
      console.log('🔗 Analyzing dependencies...');
      const dependencyGraph = await this.analyzeDependencies(decomposedTasks);
      console.log(`✅ Dependencies analyzed - ${dependencyGraph.edges.length} dependencies found`);

      // Step 4: Priority Assignment
      console.log('⚡ Assigning priorities...');
      const prioritizedTasks = await this.assignPriorities(decomposedTasks, nluResult);
      console.log(`✅ Priorities assigned`);

      // Step 5: Risk Assessment
      console.log('⚠️ Assessing risks...');
      const riskAssessment = await this.assessRisks(prioritizedTasks, context);
      console.log(`✅ Risk assessment complete - Overall risk: ${riskAssessment.overallRisk}`);

      // Step 6: Resource Planning
      console.log('📦 Planning resources...');
      const resourceRequirements = await this.planResources(prioritizedTasks, context);
      console.log(`✅ Resource planning complete`);

      // Step 7: Success Criteria Definition
      console.log('🎯 Defining success criteria...');
      const successCriteria = await this.defineSuccessCriteria(goalAnalysis, nluResult);
      console.log(`✅ Success criteria defined - ${successCriteria.length} criteria`);

      // Step 8: Critical Path Analysis
      console.log('🛤️ Analyzing critical path...');
      const criticalPath = await this.analyzeCriticalPath(dependencyGraph, prioritizedTasks);
      console.log(`✅ Critical path analyzed - ${criticalPath.length} critical tasks`);

      // Step 9: Plan Optimization
      console.log('⚡ Optimizing plan...');
      const optimizedTasks = await this.optimizePlan(prioritizedTasks, dependencyGraph, resourceRequirements);
      console.log(`✅ Plan optimized`);

      // Create final task plan
      const taskPlan: TaskPlan = {
        id: this.generateId(),
        goal: goalAnalysis.goal,
        description: goalAnalysis.description,
        tasks: optimizedTasks,
        dependencies: {
          ...dependencyGraph,
          criticalPath
        },
        priority: this.determineOverallPriority(nluResult, riskAssessment),
        estimatedDuration: this.calculateTotalDuration(optimizedTasks),
        riskAssessment,
        resourceRequirements,
        successCriteria
      };

      console.log('🎉 Task plan created successfully');
      return taskPlan;

    } catch (error) {
      console.error('❌ Task planning failed:', error);
      throw error;
    }
  }

  // 📊 Goal Analysis - understand what needs to be achieved
  private async analyzeGoal(nluResult: any, context?: any): Promise<any> {
    const intent = nluResult.intent;
    const entities = nluResult.entities;
    const semanticAnalysis = nluResult.semanticAnalysis;

    // Extract goal from NLU results
    const goal = this.extractGoalFromIntent(intent, entities, semanticAnalysis);
    const description = this.generateGoalDescription(goal, entities);
    const complexity = this.assessGoalComplexity(intent, entities, semanticAnalysis);
    const scope = this.defineGoalScope(goal, entities, context);

    return {
      goal,
      description,
      complexity,
      scope,
      constraints: this.identifyConstraints(context),
      assumptions: this.identifyAssumptions(entities, context)
    };
  }

  // 🔨 Task Decomposition - break down into manageable tasks
  private async decomposeTasks(goalAnalysis: any, nluResult: any): Promise<Task[]> {
    const tasks: Task[] = [];
    const intent = nluResult.intent;
    const entities = nluResult.entities;

    // Use task templates based on intent
    const relevantTemplates = this.taskTemplates.filter(template => 
      template.applicableIntents.includes(intent)
    );

    for (const template of relevantTemplates) {
      const templateTasks = await this.instantiateTemplate(template, goalAnalysis, entities);
      tasks.push(...templateTasks);
    }

    // Add custom tasks based on entities
    const customTasks = await this.generateCustomTasks(goalAnalysis, entities);
    tasks.push(...customTasks);

    return tasks;
  }

  // 🔗 Dependency Analysis - understand task relationships
  private async analyzeDependencies(tasks: Task[]): Promise<DependencyGraph> {
    const nodes: DependencyNode[] = [];
    const edges: DependencyEdge[] = [];

    // Create nodes
    for (const task of tasks) {
      nodes.push({
        id: task.id,
        task,
        position: this.calculateTaskPosition(task, tasks),
        level: this.calculateTaskLevel(task, tasks)
      });
    }

    // Create edges based on dependencies
    for (const task of tasks) {
      for (const dependencyId of task.dependencies) {
        edges.push({
          from: dependencyId,
          to: task.id,
          type: this.determineDependencyType(task, dependencyId, tasks),
          description: this.generateDependencyDescription(task, dependencyId, tasks)
        });
      }
    }

    return {
      nodes,
      edges
    };
  }

  // ⚡ Priority Assignment - assign priorities to tasks
  private async assignPriorities(tasks: Task[], nluResult: any): Promise<Task[]> {
    const basePriority = this.mapUrgencyToPriority(nluResult.urgency);
    
    return tasks.map(task => ({
      ...task,
      priority: this.calculateTaskPriority(task, basePriority, tasks)
    }));
  }

  // ⚠️ Risk Assessment - identify and assess risks
  private async assessRisks(tasks: Task[], context?: any): Promise<RiskAssessment> {
    const risks: Risk[] = [];
    const mitigationStrategies: MitigationStrategy[] = [];

    // Analyze each task for risks
    for (const task of tasks) {
      const taskRisks = await this.identifyTaskRisks(task, context);
      risks.push(...taskRisks);
    }

    // Generate mitigation strategies
    for (const risk of risks) {
      const strategy = await this.generateMitigationStrategy(risk);
      mitigationStrategies.push(strategy);
    }

    // Calculate overall risk
    const overallRisk = this.calculateOverallRisk(risks);

    return {
      overallRisk,
      risks,
      mitigationStrategies
    };
  }

  // 📦 Resource Planning - plan required resources
  private async planResources(tasks: Task[], context?: any): Promise<ResourceRequirements> {
    const computational = await this.estimateComputationalResources(tasks);
    const human = await this.estimateHumanResources(tasks);
    const time = await this.estimateTimeResources(tasks);
    const tools = await this.identifyRequiredTools(tasks);

    return {
      computational,
      human,
      time,
      tools
    };
  }

  // 🎯 Success Criteria Definition - define what success looks like
  private async defineSuccessCriteria(goalAnalysis: any, nluResult: any): Promise<string[]> {
    const criteria: string[] = [];

    // Basic success criteria
    criteria.push('All tasks completed successfully');
    criteria.push('No critical errors encountered');
    criteria.push('Resource usage within limits');

    // Intent-specific criteria
    switch (nluResult.intent) {
      case 'file_cleanup':
        criteria.push('Only relevant files retained');
        criteria.push('No broken dependencies');
        criteria.push('Application functionality preserved');
        break;
      case 'code_generation':
        criteria.push('Generated code compiles successfully');
        criteria.push('Code follows best practices');
        criteria.push('All requirements implemented');
        break;
      case 'ai_agent_request':
        criteria.push('AI agent functionality working');
        criteria.push('All brain components operational');
        criteria.push('Learning capabilities active');
        break;
    }

    // Context-specific criteria
    if (nluResult.urgency === 'urgent') {
      criteria.push('Completed within urgent timeframe');
    }

    return criteria;
  }

  // 🛤️ Critical Path Analysis - identify critical path
  private async analyzeCriticalPath(dependencyGraph: DependencyGraph, tasks: Task[]): Promise<string[]> {
    // Simplified critical path analysis
    const criticalPath: string[] = [];
    const visited = new Set<string>();

    // Find tasks with no dependencies (starting points)
    const startTasks = dependencyGraph.nodes.filter(node => 
      !dependencyGraph.edges.some(edge => edge.to === node.id)
    );

    // Traverse from start tasks
    for (const startTask of startTasks) {
      const path = await this.findCriticalPath(startTask.id, dependencyGraph, tasks, visited);
      criticalPath.push(...path);
    }

    return [...new Set(criticalPath)]; // Remove duplicates
  }

  // ⚡ Plan Optimization - optimize the task plan
  private async optimizePlan(
    tasks: Task[], 
    dependencyGraph: DependencyGraph, 
    resources: ResourceRequirements
  ): Promise<Task[]> {
    // Clone tasks to avoid modifying original
    const optimizedTasks = tasks.map(task => ({ ...task }));

    // Optimize task ordering
    const orderedTasks = this.optimizeTaskOrder(optimizedTasks, dependencyGraph);
    
    // Optimize resource allocation
    const resourceOptimizedTasks = this.optimizeResourceAllocation(orderedTasks, resources);
    
    // Optimize for parallel execution
    const parallelOptimizedTasks = this.optimizeForParallelExecution(resourceOptimizedTasks, dependencyGraph);

    return parallelOptimizedTasks;
  }

  // 🔮 Predict next actions based on patterns
  public async predictNextActions(patterns: any[], context: any): Promise<string[]> {
    const predictions: string[] = [];

    // Analyze patterns to predict likely next actions
    for (const pattern of patterns) {
      if (pattern.type === 'file_operation') {
        predictions.push('File verification and testing');
        predictions.push('Dependency analysis');
      }
      if (pattern.type === 'development') {
        predictions.push('Code review and optimization');
        predictions.push('Integration testing');
      }
      if (pattern.type === 'ai_interaction') {
        predictions.push('AI agent training and improvement');
        predictions.push('Performance monitoring');
      }
    }

    return [...new Set(predictions)]; // Remove duplicates
  }

  // 📊 Get planner status
  public getStatus(): any {
    return {
      initialized: this.initialized,
      templatesCount: this.taskTemplates.length,
      strategiesCount: this.planningStrategies.length
    };
  }

  public async shutdown(): Promise<void> {
    console.log('🛑 Shutting down Task Planner...');
  }

  // Helper methods
  private initializeTaskTemplates(): TaskTemplate[] {
    return [
      {
        name: 'file_cleanup_template',
        applicableIntents: ['file_cleanup'],
        tasks: [
          {
            name: 'Analyze current file structure',
            type: 'analysis',
            estimatedTime: 5,
            requiredResources: ['file_system', 'analysis_tools']
          },
          {
            name: 'Identify file dependencies',
            type: 'analysis',
            estimatedTime: 10,
            dependencies: ['Analyze current file structure'],
            requiredResources: ['dependency_analyzer']
          },
          {
            name: 'Mark files for deletion',
            type: 'cleanup',
            estimatedTime: 5,
            dependencies: ['Identify file dependencies'],
            requiredResources: ['file_system']
          },
          {
            name: 'Delete marked files',
            type: 'cleanup',
            estimatedTime: 3,
            dependencies: ['Mark files for deletion'],
            requiredResources: ['file_system']
          },
          {
            name: 'Verify system integrity',
            type: 'verification',
            estimatedTime: 8,
            dependencies: ['Delete marked files'],
            requiredResources: ['testing_framework']
          }
        ]
      },
      {
        name: 'ai_agent_development_template',
        applicableIntents: ['ai_agent_request', 'code_generation'],
        tasks: [
          {
            name: 'Design AI agent architecture',
            type: 'development',
            estimatedTime: 30,
            requiredResources: ['architecture_tools', 'design_tools']
          },
          {
            name: 'Implement NLU components',
            type: 'development',
            estimatedTime: 45,
            dependencies: ['Design AI agent architecture'],
            requiredResources: ['nlu_framework', 'development_tools']
          },
          {
            name: 'Implement task planning engine',
            type: 'development',
            estimatedTime: 40,
            dependencies: ['Design AI agent architecture'],
            requiredResources: ['planning_framework', 'development_tools']
          },
          {
            name: 'Implement execution engine',
            type: 'development',
            estimatedTime: 50,
            dependencies: ['Implement task planning engine'],
            requiredResources: ['execution_framework', 'development_tools']
          },
          {
            name: 'Implement verification system',
            type: 'development',
            estimatedTime: 35,
            dependencies: ['Implement execution engine'],
            requiredResources: ['testing_framework', 'development_tools']
          },
          {
            name: 'Implement learning engine',
            type: 'development',
            estimatedTime: 40,
            dependencies: ['Implement verification system'],
            requiredResources: ['ml_framework', 'development_tools']
          },
          {
            name: 'Integrate all components',
            type: 'development',
            estimatedTime: 25,
            dependencies: ['Implement learning engine'],
            requiredResources: ['integration_tools']
          },
          {
            name: 'Test AI agent functionality',
            type: 'testing',
            estimatedTime: 30,
            dependencies: ['Integrate all components'],
            requiredResources: ['testing_framework', 'test_data']
          },
          {
            name: 'Optimize performance',
            type: 'development',
            estimatedTime: 20,
            dependencies: ['Test AI agent functionality'],
            requiredResources: ['profiling_tools', 'optimization_tools']
          }
        ]
      }
    ];
  }

  private initializePlanningStrategies(): PlanningStrategy[] {
    return [
      {
        name: 'sequential_strategy',
        description: 'Execute tasks one after another',
        applicableFor: ['simple', 'low_dependency'],
        efficiency: 0.7
      },
      {
        name: 'parallel_strategy',
        description: 'Execute independent tasks in parallel',
        applicableFor: ['complex', 'high_dependency'],
        efficiency: 0.9
      },
      {
        name: 'adaptive_strategy',
        description: 'Adapt execution based on progress',
        applicableFor: ['complex', 'uncertain'],
        efficiency: 0.85
      }
    ];
  }

  private extractGoalFromIntent(intent: string, entities: any[], semanticAnalysis: any): string {
    switch (intent) {
      case 'file_cleanup':
        return 'Clean up project files keeping only autonomous agent related files';
      case 'code_generation':
        return 'Generate AI agent brain system with comprehensive capabilities';
      case 'ai_agent_request':
        return 'Implement intelligent autonomous agent with NLU, planning, execution, and learning';
      default:
        return 'Execute requested task efficiently';
    }
  }

  private generateGoalDescription(goal: string, entities: any[]): string {
    return `Goal: ${goal}. This involves processing ${entities.length} entities to achieve the desired outcome.`;
  }

  private assessGoalComplexity(intent: string, entities: any[], semanticAnalysis: any): 'simple' | 'medium' | 'complex' {
    if (entities.length > 5 || semanticAnalysis.complexity > 0.7) return 'complex';
    if (entities.length > 2 || semanticAnalysis.complexity > 0.4) return 'medium';
    return 'simple';
  }

  private defineGoalScope(goal: string, entities: any[], context?: any): any {
    return {
      inScope: entities.map(e => e.type),
      outOfScope: ['external_systems', 'third_party_integrations'],
      boundaries: this.identifyBoundaries(entities)
    };
  }

  private identifyConstraints(context?: any): string[] {
    return ['time_constraints', 'resource_limits', 'quality_requirements'];
  }

  private identifyBoundaries(entities: any[]): any {
    return {
      technical: ['system_components', 'ai_modules', 'core_functionality'],
      business: ['user_requirements', 'business_logic', 'domain_constraints'],
      data: ['input_data', 'output_data', 'processing_limits'],
      external: ['third_party_apis', 'external_systems', 'user_interfaces']
    };
  }

  private identifyAssumptions(entities: any[], context?: any): string[] {
    return ['all_dependencies_available', 'sufficient_resources', 'clear_requirements'];
  }

  private async instantiateTemplate(template: TaskTemplate, goalAnalysis: any, entities: any[]): Promise<Task[]> {
    const tasks: Task[] = [];

    for (const templateTask of template.tasks) {
      const task: Task = {
        id: this.generateId(),
        name: templateTask.name,
        description: this.generateTaskDescription(templateTask, goalAnalysis),
        type: templateTask.type,
        priority: 'medium',
        estimatedTime: templateTask.estimatedTime,
        dependencies: templateTask.dependencies || [],
        requiredResources: templateTask.requiredResources,
        expectedOutput: this.generateExpectedOutput(templateTask),
        failureHandling: {
          retryStrategy: 'delayed',
          maxRetries: 3,
          fallbackTasks: [],
          escalationProcedures: ['notify_admin', 'log_error']
        },
        status: 'pending'
      };

      tasks.push(task);
    }

    return tasks;
  }

  private async generateCustomTasks(goalAnalysis: any, entities: any[]): Promise<Task[]> {
    const tasks: Task[] = [];

    // Generate entity-specific tasks
    for (const entity of entities) {
      if (entity.type === 'target_files') {
        tasks.push({
          id: this.generateId(),
          name: `Process ${entity.value} files`,
          description: `Handle processing of ${entity.value} related files`,
          type: 'development',
          priority: 'medium',
          estimatedTime: 15,
          dependencies: [],
          requiredResources: ['file_system', 'processing_tools'],
          expectedOutput: `Processed ${entity.value} files`,
          failureHandling: {
            retryStrategy: 'immediate',
            maxRetries: 2,
            fallbackTasks: [],
            escalationProcedures: ['log_error']
          },
          status: 'pending'
        });
      }
    }

    return tasks;
  }

  private generateTaskDescription(templateTask: any, goalAnalysis: any): string {
    return `${templateTask.name} - Part of ${goalAnalysis.goal}`;
  }

  private generateExpectedOutput(templateTask: any): string {
    return `Completed ${templateTask.name} successfully`;
  }

  private calculateTaskPosition(task: Task, tasks: Task[]): { x: number; y: number } {
    const index = tasks.findIndex(t => t.id === task.id);
    return {
      x: (index % 3) * 200,
      y: Math.floor(index / 3) * 100
    };
  }

  private calculateTaskLevel(task: Task, tasks: Task[]): number {
    if (task.dependencies.length === 0) return 0;
    
    let maxLevel = 0;
    for (const depId of task.dependencies) {
      const depTask = tasks.find(t => t.id === depId);
      if (depTask) {
        const depLevel = this.calculateTaskLevel(depTask, tasks);
        maxLevel = Math.max(maxLevel, depLevel + 1);
      }
    }
    
    return maxLevel;
  }

  private determineDependencyType(task: Task, dependencyId: string, tasks: Task[]): 'strong' | 'weak' | 'optional' {
    const depTask = tasks.find(t => t.id === dependencyId);
    if (!depTask) return 'weak';
    
    // Strong dependency if the task directly uses output of dependency
    if (task.requiredResources.some(r => depTask.expectedOutput.includes(r))) {
      return 'strong';
    }
    
    return 'weak';
  }

  private generateDependencyDescription(task: Task, dependencyId: string, tasks: Task[]): string {
    const depTask = tasks.find(t => t.id === dependencyId);
    return `${task.name} depends on ${depTask?.name || dependencyId}`;
  }

  private mapUrgencyToPriority(urgency: string): 'low' | 'medium' | 'high' | 'urgent' {
    switch (urgency) {
      case 'urgent': return 'urgent';
      case 'high': return 'high';
      case 'medium': return 'medium';
      default: return 'low';
    }
  }

  private calculateTaskPriority(task: Task, basePriority: string, tasks: Task[]): 'low' | 'medium' | 'high' | 'urgent' {
    // Validate task object
    if (!task || !task.type) {
      console.warn('⚠️ Invalid task object in calculateTaskPriority:', task);
      return basePriority as 'low' | 'medium' | 'high' | 'urgent';
    }

    // Calculate priority based on task type, dependencies, and base priority
    if (task.type === 'verification' || task.type === 'testing') {
      return basePriority === 'urgent' ? 'urgent' : 'high';
    }
    
    if (task.dependencies.length > 2) {
      return basePriority === 'low' ? 'medium' : basePriority;
    }
    
    return basePriority;
  }

  private async identifyTaskRisks(task: Task, context?: any): Promise<Risk[]> {
    const risks: Risk[] = [];

    // Validate task object
    if (!task || !task.type) {
      console.warn('⚠️ Invalid task object in identifyTaskRisks:', task);
      return risks;
    }

    // Common risks based on task type
    switch (task.type) {
      case 'development':
        risks.push({
          id: this.generateId(),
          description: 'Code compilation errors',
          probability: 'medium',
          impact: 'high',
          category: 'technical',
          affectedTasks: [task.id]
        });
        break;
      case 'testing':
        risks.push({
          id: this.generateId(),
          description: 'Test failures',
          probability: 'medium',
          impact: 'medium',
          category: 'technical',
          affectedTasks: [task.id]
        });
        break;
      case 'cleanup':
        risks.push({
          id: this.generateId(),
          description: 'Accidental deletion of important files',
          probability: 'low',
          impact: 'critical',
          category: 'operational',
          affectedTasks: [task.id]
        });
        break;
    }

    return risks;
  }

  private async generateMitigationStrategy(risk: Risk): Promise<MitigationStrategy> {
    const strategies = {
      'Code compilation errors': {
        strategy: 'Implement code linting and pre-commit checks',
        effectiveness: 'high',
        cost: 'low'
      },
      'Test failures': {
        strategy: 'Implement comprehensive test suite and CI/CD',
        effectiveness: 'high',
        cost: 'medium'
      },
      'Accidental deletion of important files': {
        strategy: 'Implement backup system and confirmation prompts',
        effectiveness: 'high',
        cost: 'low'
      }
    };

    const defaultStrategy = {
      strategy: 'Monitor and manual intervention',
      effectiveness: 'medium',
      cost: 'medium'
    };

    const strategy = strategies[risk.description] || defaultStrategy;

    return {
      riskId: risk.id,
      ...strategy
    };
  }

  private calculateOverallRisk(risks: Risk[]): 'low' | 'medium' | 'high' | 'critical' {
    const highImpactRisks = risks.filter(r => r.impact === 'high' || r.impact === 'critical');
    const highProbabilityRisks = risks.filter(r => r.probability === 'high');
    
    if (highImpactRisks.length > 2 || highProbabilityRisks.length > 3) return 'critical';
    if (highImpactRisks.length > 0 || highProbabilityRisks.length > 1) return 'high';
    if (risks.length > 3) return 'medium';
    return 'low';
  }

  private async estimateComputationalResources(tasks: Task[]): Promise<ComputationalResources> {
    const totalComplexity = tasks.reduce((sum, task) => sum + task.estimatedTime, 0);
    
    return {
      cpu: `${Math.ceil(totalComplexity / 10)} cores`,
      memory: `${Math.ceil(totalComplexity / 5)} GB`,
      storage: `${Math.ceil(totalComplexity / 20)} GB`,
      network: 'Standard'
    };
  }

  private async estimateHumanResources(tasks: Task[]): Promise<HumanResources> {
    const devTasks = tasks.filter(t => t.type === 'development').length;
    const testTasks = tasks.filter(t => t.type === 'testing').length;
    
    return {
      developers: Math.ceil(devTasks / 3),
      testers: Math.ceil(testTasks / 5),
      designers: 1,
      managers: 1
    };
  }

  private async estimateTimeResources(tasks: Task[]): Promise<TimeResources> {
    const estimatedTotal = tasks.reduce((sum, task) => sum + task.estimatedTime, 0);
    const buffer = Math.ceil(estimatedTotal * 0.2); // 20% buffer
    
    return {
      estimatedTotal,
      buffer,
      milestones: this.generateMilestones(tasks)
    };
  }

  private generateMilestones(tasks: Task[]): Milestone[] {
    const milestones: Milestone[] = [];
    const phases = this.groupTasksByPhase(tasks);
    
    let cumulativeTime = 0;
    for (const [phaseName, phaseTasks] of Object.entries(phases)) {
      cumulativeTime += phaseTasks.reduce((sum, task) => sum + task.estimatedTime, 0);
      
      milestones.push({
        id: this.generateId(),
        name: `${phaseName} Phase Complete`,
        deadline: cumulativeTime,
        dependencies: phaseTasks.map(t => t.id)
      });
    }
    
    return milestones;
  }

  private groupTasksByPhase(tasks: Task[]): { [key: string]: Task[] } {
    const phases: { [key: string]: Task[] } = {};
    
    for (const task of tasks) {
      // Validate task object
      if (!task || !task.type) {
        console.warn('⚠️ Invalid task object in phase organization:', task);
        continue;
      }
      
      if (!phases[task.type]) {
        phases[task.type] = [];
      }
      phases[task.type].push(task);
    }
    
    return phases;
  }

  private async identifyRequiredTools(tasks: Task[]): Promise<ToolResources> {
    const requiredTools = new Set<string>();
    const optionalTools = new Set<string>();
    const versions: { [key: string]: string } = {};
    
    for (const task of tasks) {
      for (const resource of task.requiredResources) {
        requiredTools.add(resource);
      }
    }
    
    // Add common tools
    requiredTools.add('node.js');
    requiredTools.add('typescript');
    requiredTools.add('next.js');
    
    optionalTools.add('docker');
    optionalTools.add('kubernetes');
    
    versions['node.js'] = '18.x';
    versions['typescript'] = '5.x';
    versions['next.js'] = '15.x';
    
    return {
      required: Array.from(requiredTools),
      optional: Array.from(optionalTools),
      versions
    };
  }

  private async findCriticalPath(
    taskId: string, 
    dependencyGraph: DependencyGraph, 
    tasks: Task[], 
    visited: Set<string>
  ): Promise<string[]> {
    if (visited.has(taskId)) return [];
    visited.add(taskId);
    
    const path = [taskId];
    const outgoingEdges = dependencyGraph.edges.filter(edge => edge.from === taskId);
    
    for (const edge of outgoingEdges) {
      if (edge.type === 'strong') {
        const subPath = await this.findCriticalPath(edge.to, dependencyGraph, tasks, visited);
        path.push(...subPath);
      }
    }
    
    return path;
  }

  private optimizeTaskOrder(tasks: Task[], dependencyGraph: DependencyGraph): Task[] {
    // Topological sort based on dependencies
    const ordered: Task[] = [];
    const remaining = [...tasks];
    const resolved = new Set<string>();
    
    while (remaining.length > 0) {
      // Find tasks with all dependencies resolved
      const readyTasks = remaining.filter(task => 
        task.dependencies.every(dep => resolved.has(dep))
      );
      
      if (readyTasks.length === 0) {
        // Circular dependency, break with remaining tasks
        ordered.push(...remaining);
        break;
      }
      
      // Add ready tasks to ordered list
      ordered.push(...readyTasks);
      readyTasks.forEach(task => {
        resolved.add(task.id);
        remaining.splice(remaining.indexOf(task), 1);
      });
    }
    
    return ordered;
  }

  private optimizeResourceAllocation(tasks: Task[], resources: ResourceRequirements): Task[] {
    // Simple resource allocation optimization
    return tasks.map(task => ({
      ...task,
      // Adjust estimated time based on available resources
      estimatedTime: Math.ceil(task.estimatedTime * this.getResourceEfficiencyFactor(task, resources))
    }));
  }

  private getResourceEfficiencyFactor(task: Task, resources: ResourceRequirements): number {
    // Simple efficiency calculation
    const resourceCount = task.requiredResources.length;
    if (resourceCount > 3) return 1.2; // More resources needed, more time
    if (resourceCount > 1) return 1.1;
    return 1.0;
  }

  private optimizeForParallelExecution(tasks: Task[], dependencyGraph: DependencyGraph): Task[] {
    // Identify tasks that can be executed in parallel
    const parallelGroups: Task[][] = [];
    const remaining = [...tasks];
    const resolved = new Set<string>();
    
    while (remaining.length > 0) {
      const currentGroup = remaining.filter(task => 
        task.dependencies.every(dep => resolved.has(dep))
      );
      
      parallelGroups.push(currentGroup);
      currentGroup.forEach(task => {
        resolved.add(task.id);
        remaining.splice(remaining.indexOf(task), 1);
      });
    }
    
    // Flatten groups while maintaining parallel execution possibility
    return tasks; // For now, return as-is - parallel execution would be handled by execution engine
  }

  private determineOverallPriority(nluResult: any, riskAssessment: RiskAssessment): 'low' | 'medium' | 'high' | 'urgent' {
    const urgencyPriority = this.mapUrgencyToPriority(nluResult.urgency);
    const riskPriority = this.mapRiskToPriority(riskAssessment.overallRisk);
    
    // Return the higher priority
    if (urgencyPriority === 'urgent' || riskPriority === 'critical') return 'urgent';
    if (urgencyPriority === 'high' || riskPriority === 'high') return 'high';
    if (urgencyPriority === 'medium' || riskPriority === 'medium') return 'medium';
    return 'low';
  }

  private mapRiskToPriority(risk: string): 'low' | 'medium' | 'high' | 'urgent' {
    switch (risk) {
      case 'critical': return 'urgent';
      case 'high': return 'high';
      case 'medium': return 'medium';
      default: return 'low';
    }
  }

  private calculateTotalDuration(tasks: Task[]): number {
    return tasks.reduce((sum, task) => sum + task.estimatedTime, 0);
  }

  private generateId(): string {
    return Math.random().toString(36).substr(2, 9);
  }
}

// Supporting interfaces
interface TaskTemplate {
  name: string;
  applicableIntents: string[];
  tasks: TemplateTask[];
}

interface TemplateTask {
  name: string;
  type: 'analysis' | 'development' | 'testing' | 'deployment' | 'cleanup' | 'verification';
  estimatedTime: number;
  dependencies?: string[];
  requiredResources: string[];
}

interface PlanningStrategy {
  name: string;
  description: string;
  applicableFor: string[];
  efficiency: number;
}