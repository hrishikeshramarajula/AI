import { NextRequest, NextResponse } from 'next/server';
import { DeepResearchLogger, PerformanceMonitor, ErrorTracker } from '@/lib/monitoring';

export async function GET(request: NextRequest) {
  try {
    const logger = DeepResearchLogger.getInstance();
    const monitoringId = `monitoring_${Date.now()}`;
    
    logger.info('Monitoring', 'Starting resource monitoring', { monitoringId });

    // Get system and process metrics
    const memoryUsage = process.memoryUsage();
    const cpuUsage = process.cpuUsage();
    const uptime = process.uptime();
    
    // Calculate memory usage percentages
    const memoryStats = {
      rss: {
        used: memoryUsage.rss,
        used_mb: Math.round(memoryUsage.rss / 1024 / 1024),
        percentage: Math.round((memoryUsage.rss / (4 * 1024 * 1024 * 1024)) * 100) // Assuming 4GB system memory
      },
      heap: {
        used: memoryUsage.heapUsed,
        used_mb: Math.round(memoryUsage.heapUsed / 1024 / 1024),
        total: memoryUsage.heapTotal,
        total_mb: Math.round(memoryUsage.heapTotal / 1024 / 1024),
        percentage: Math.round((memoryUsage.heapUsed / memoryUsage.heapTotal) * 100)
      },
      external: {
        used: memoryUsage.external,
        used_mb: Math.round(memoryUsage.external / 1024 / 1024)
      }
    };

    // Get performance metrics
    const activeTimers = PerformanceMonitor.getActiveTimers();
    const recentLogs = logger.getRecentLogs(20);
    const errorLogs = logger.getErrorLogs();
    const allErrors = ErrorTracker.getErrors();

    // Calculate error rates
    const errorRate = recentLogs.length > 0 ? 
      (recentLogs.filter(log => log.level === 'error').length / recentLogs.length) * 100 : 0;

    // Calculate response time metrics (if available)
    const responseTimeMetrics = calculateResponseTimeMetrics(recentLogs);

    // System health assessment
    const systemHealth = assessSystemHealth(memoryStats, errorRate, activeTimers.length, allErrors.length);

    // Generate recommendations
    const recommendations = generateRecommendations(memoryStats, errorRate, activeTimers, allErrors);

    const monitoringData = {
      timestamp: new Date().toISOString(),
      monitoring_id: monitoringId,
      system: {
        uptime: uptime,
        uptime_formatted: formatUptime(uptime),
        platform: process.platform,
        arch: process.arch,
        node_version: process.version,
        environment: process.env.NODE_ENV || 'development'
      },
      memory: memoryStats,
      cpu: {
        user: cpuUsage.user,
        system: cpuUsage.system,
        user_formatted: formatCpuTime(cpuUsage.user),
        system_formatted: formatCpuTime(cpuUsage.system)
      },
      performance: {
        active_timers: activeTimers.length,
        active_timer_names: activeTimers,
        response_time_metrics: responseTimeMetrics
      },
      logging: {
        total_logs: recentLogs.length,
        recent_errors: errorLogs.length,
        error_rate: `${errorRate.toFixed(2)}%`,
        log_levels: countLogLevels(recentLogs),
        top_components: getTopComponents(recentLogs)
      },
      errors: {
        total_errors: allErrors.length,
        unhandled_errors: allErrors.filter(e => !e.handled).length,
        error_by_component: getErrorsByComponent(allErrors),
        recent_errors: allErrors.slice(-5).map(error => ({
          timestamp: error.timestamp.toISOString(),
          component: error.component,
          error: error.error.message,
          handled: error.handled
        }))
      },
      health: systemHealth,
      recommendations: recommendations,
      alerts: generateAlerts(memoryStats, errorRate, activeTimers.length)
    };

    logger.info('Monitoring', 'Resource monitoring completed', { 
      monitoringId, 
      memory_usage_mb: memoryStats.heap.used_mb,
      error_rate: errorRate.toFixed(2),
      system_health: systemHealth.status 
    });

    return NextResponse.json(monitoringData, {
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      }
    });

  } catch (error) {
    console.error('Resource monitoring endpoint failed:', error);
    
    return NextResponse.json({
      error: 'Resource monitoring failed',
      message: (error as Error).message,
      timestamp: new Date().toISOString()
    }, { 
      status: 500,
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      }
    });
  }
}

// Helper functions
function formatUptime(seconds: number): string {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  
  if (days > 0) {
    return `${days}d ${hours}h ${minutes}m ${secs}s`;
  } else if (hours > 0) {
    return `${hours}h ${minutes}m ${secs}s`;
  } else if (minutes > 0) {
    return `${minutes}m ${secs}s`;
  } else {
    return `${secs}s`;
  }
}

function formatCpuTime(microseconds: number): string {
  const milliseconds = microseconds / 1000;
  const seconds = milliseconds / 1000;
  
  if (seconds >= 1) {
    return `${seconds.toFixed(2)}s`;
  } else if (milliseconds >= 1) {
    return `${milliseconds.toFixed(2)}ms`;
  } else {
    return `${microseconds}μs`;
  }
}

function calculateResponseTimeMetrics(logs: any[]) {
  const performanceLogs = logs.filter(log => 
    log.component === 'Performance' && log.message?.includes('completed in')
  );
  
  if (performanceLogs.length === 0) {
    return {
      average: 0,
      min: 0,
      max: 0,
      count: 0
    };
  }
  
  const durations = performanceLogs.map(log => {
    const match = log.message.match(/completed in ([\d.]+)ms/);
    return match ? parseFloat(match[1]) : 0;
  }).filter(d => d > 0);
  
  if (durations.length === 0) {
    return {
      average: 0,
      min: 0,
      max: 0,
      count: 0
    };
  }
  
  return {
    average: durations.reduce((a, b) => a + b, 0) / durations.length,
    min: Math.min(...durations),
    max: Math.max(...durations),
    count: durations.length
  };
}

function assessSystemHealth(memoryStats: any, errorRate: number, activeTimers: number, totalErrors: number) {
  let score = 100;
  let issues = [];
  
  // Memory health (40% of score)
  if (memoryStats.heap.percentage > 80) {
    score -= 20;
    issues.push('High memory usage');
  } else if (memoryStats.heap.percentage > 60) {
    score -= 10;
    issues.push('Moderate memory usage');
  }
  
  // Error rate (30% of score)
  if (errorRate > 10) {
    score -= 30;
    issues.push('High error rate');
  } else if (errorRate > 5) {
    score -= 15;
    issues.push('Moderate error rate');
  }
  
  // Active timers (20% of score)
  if (activeTimers > 10) {
    score -= 10;
    issues.push('Many active timers');
  } else if (activeTimers > 5) {
    score -= 5;
    issues.push('Several active timers');
  }
  
  // Total errors (10% of score)
  if (totalErrors > 20) {
    score -= 10;
    issues.push('Many errors logged');
  } else if (totalErrors > 10) {
    score -= 5;
    issues.push('Several errors logged');
  }
  
  let status = 'excellent';
  if (score < 70) status = 'poor';
  else if (score < 80) status = 'fair';
  else if (score < 90) status = 'good';
  
  return {
    score: Math.max(0, score),
    status,
    issues
  };
}

function generateRecommendations(memoryStats: any, errorRate: number, activeTimers: any[], allErrors: any[]) {
  const recommendations = [];
  
  // Memory recommendations
  if (memoryStats.heap.percentage > 80) {
    recommendations.push({
      priority: 'high',
      category: 'memory',
      title: 'High Memory Usage Detected',
      description: 'Memory usage is above 80%. Consider optimizing memory usage or restarting the service.',
      action: 'Monitor memory leaks and optimize code'
    });
  }
  
  // Error rate recommendations
  if (errorRate > 10) {
    recommendations.push({
      priority: 'high',
      category: 'errors',
      title: 'High Error Rate',
      description: 'Error rate is above 10%. Review recent errors and address underlying issues.',
      action: 'Check error logs and fix recurring issues'
    });
  }
  
  // Timer recommendations
  if (activeTimers.length > 10) {
    recommendations.push({
      priority: 'medium',
      category: 'performance',
      title: 'Many Active Timers',
      description: 'Multiple performance timers are active. Check for timer leaks.',
      action: 'Review timer management in code'
    });
  }
  
  // Component-specific recommendations
  const errorByComponent = getErrorsByComponent(allErrors);
  const topErrorComponent = Object.entries(errorByComponent)
    .sort(([,a], [,b]) => (b as number) - (a as number))[0];
  
  if (topErrorComponent && (topErrorComponent[1] as number) > 5) {
    recommendations.push({
      priority: 'medium',
      category: 'component',
      title: `High Error Rate in ${topErrorComponent[0]}`,
      description: `Component ${topErrorComponent[0]} has ${(topErrorComponent[1] as number)} errors.`,
      action: `Review and fix issues in ${topErrorComponent[0]} component`
    });
  }
  
  return recommendations;
}

function generateAlerts(memoryStats: any, errorRate: number, activeTimers: number) {
  const alerts = [];
  
  if (memoryStats.heap.percentage > 90) {
    alerts.push({
      level: 'critical',
      type: 'memory',
      message: 'Critical memory usage detected'
    });
  } else if (memoryStats.heap.percentage > 80) {
    alerts.push({
      level: 'warning',
      type: 'memory',
      message: 'High memory usage detected'
    });
  }
  
  if (errorRate > 15) {
    alerts.push({
      level: 'critical',
      type: 'errors',
      message: 'Critical error rate detected'
    });
  } else if (errorRate > 10) {
    alerts.push({
      level: 'warning',
      type: 'errors',
      message: 'High error rate detected'
    });
  }
  
  if (activeTimers > 15) {
    alerts.push({
      level: 'warning',
      type: 'performance',
      message: 'Too many active timers detected'
    });
  }
  
  return alerts;
}

function countLogLevels(logs: any[]) {
  const levels = { info: 0, warn: 0, error: 0, debug: 0 };
  logs.forEach(log => {
    if (levels.hasOwnProperty(log.level)) {
      levels[log.level as keyof typeof levels]++;
    }
  });
  return levels;
}

function getTopComponents(logs: any[]) {
  const componentCount: Record<string, number> = {};
  logs.forEach(log => {
    componentCount[log.component] = (componentCount[log.component] || 0) + 1;
  });
  
  return Object.entries(componentCount)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 5)
    .map(([component, count]) => ({ component, count }));
}

function getErrorsByComponent(errors: any[]) {
  const errorCount: Record<string, number> = {};
  errors.forEach(error => {
    errorCount[error.component] = (errorCount[error.component] || 0) + 1;
  });
  return errorCount;
}