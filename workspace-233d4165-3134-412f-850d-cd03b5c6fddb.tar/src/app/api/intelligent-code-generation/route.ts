import { NextRequest, NextResponse } from 'next/server';
import { getZAIInstance } from '@/lib/zaiHelper';

// Enhanced code generation with intelligent features
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { 
      description, 
      language = 'typescript', 
      constraints = [], 
      context = '',
      useTemplate = true,
      forceAI = false,
      complexity = 'intermediate'
    } = body;

    if (!description) {
      return NextResponse.json(
        { error: 'Description is required' },
        { status: 400 }
      );
    }

    console.log('🤖 Intelligent Code Generation Request:', {
      description,
      language,
      constraints,
      context,
      useTemplate,
      forceAI,
      complexity
    });

    // Initialize ZAI SDK
    const zai = await getZAIInstance();

    // Create intelligent prompt based on parameters
    const intelligentPrompt = createIntelligentPrompt({
      description,
      language,
      constraints,
      context,
      complexity,
      useTemplate
    });

    console.log('🎯 Generated Intelligent Prompt:', intelligentPrompt);

    // Generate code using AI
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: `You are an expert software developer specializing in ${language} code generation. 
          
          Your capabilities include:
          - Writing clean, efficient, and well-documented code
          - Following best practices and design patterns
          - Adding appropriate error handling
          - Including necessary imports and dependencies
          - Providing clear comments and documentation
          - Adapting to different complexity levels
          - Understanding context and constraints
          
          Always respond with code only, no explanations unless specifically requested.`
        },
        {
          role: 'user',
          content: intelligentPrompt
        }
      ],
      temperature: 0.2,
      max_tokens: 2000
    });

    const generatedCode = completion.choices[0]?.message?.content || '';
    
    // Post-process the generated code
    const processedCode = postProcessCode(generatedCode, language);
    
    // Extract dependencies from the code
    const dependencies = extractDependencies(processedCode, language);
    
    // Generate code analysis
    const analysis = await analyzeCode(processedCode, language, zai);

    console.log('✅ Code Generation Complete:', {
      language,
      dependenciesCount: dependencies.length,
      codeLength: processedCode.length,
      analysis
    });

    return NextResponse.json({
      success: true,
      code: processedCode,
      language,
      dependencies,
      analysis,
      metadata: {
        generatedAt: new Date().toISOString(),
        complexity,
        constraintsApplied: constraints.length,
        contextUsed: context.length > 0
      }
    });

  } catch (error: any) {
    console.error('❌ Intelligent Code Generation Error:', error);
    
    return NextResponse.json(
      { 
        error: 'Failed to generate code',
        details: error.message,
        fallbackCode: generateFallbackCode(body.language || 'typescript', body.description || '')
      },
      { status: 500 }
    );
  }
}

// Create intelligent prompt based on parameters
function createIntelligentPrompt(params: {
  description: string;
  language: string;
  constraints: string[];
  context: string;
  complexity: string;
  useTemplate: boolean;
}): string {
  const { description, language, constraints, context, complexity, useTemplate } = params;
  
  let prompt = `Generate ${language} code for: ${description}\n\n`;
  
  if (context) {
    prompt += `Context: ${context}\n\n`;
  }
  
  if (constraints.length > 0) {
    prompt += `Constraints:\n`;
    constraints.forEach((constraint, index) => {
      prompt += `${index + 1}. ${constraint}\n`;
    });
    prompt += '\n';
  }
  
  prompt += `Complexity Level: ${complexity}\n\n`;
  
  if (useTemplate) {
    prompt += `Please follow these guidelines:\n`;
    prompt += `- Use modern ${language} syntax and best practices\n`;
    prompt += `- Include proper error handling\n`;
    prompt += `- Add necessary imports/dependencies\n`;
    prompt += `- Include clear comments and documentation\n`;
    prompt += `- Make the code reusable and maintainable\n`;
    
    if (complexity === 'beginner') {
      prompt += `- Keep the code simple and easy to understand\n`;
    } else if (complexity === 'advanced') {
      prompt += `- Use advanced patterns and optimizations\n`;
      prompt += `- Consider edge cases and robustness\n`;
    }
  }
  
  prompt += `\nGenerate only the code, no explanations.`;
  
  return prompt;
}

// Post-process generated code
function postProcessCode(code: string, language: string): string {
  let processedCode = code.trim();
  
  // Remove markdown code block markers if present
  processedCode = processedCode.replace(/^```[\w-]*\n/, '').replace(/```$/, '');
  
  // Language-specific processing
  switch (language.toLowerCase()) {
    case 'typescript':
    case 'javascript':
      // Ensure proper import statements
      if (!processedCode.includes('import ') && processedCode.includes('React')) {
        processedCode = `import React from 'react';\n\n${processedCode}`;
      }
      break;
      
    case 'python':
      // Ensure proper Python structure
      if (!processedCode.startsWith('def ') && !processedCode.startsWith('class ') && !processedCode.startsWith('import ')) {
        processedCode = `def main():\n    # Your implementation here\n    pass\n\nif __name__ == "__main__":\n    main()`;
      }
      break;
      
    case 'java':
      // Ensure proper Java class structure
      if (!processedCode.includes('class ')) {
        processedCode = `public class GeneratedCode {\n    ${processedCode}\n}`;
      }
      break;
  }
  
  return processedCode;
}

// Extract dependencies from code
function extractDependencies(code: string, language: string): string[] {
  const dependencies: string[] = [];
  
  switch (language.toLowerCase()) {
    case 'typescript':
    case 'javascript':
      // Extract import statements
      const importMatches = code.match(/import\s+.*?from\s+['"]([^'"]+)['"]/g);
      if (importMatches) {
        importMatches.forEach(match => {
          const dependency = match.match(/from\s+['"]([^'"]+)['"]/)?.[1];
          if (dependency && !dependency.startsWith('.')) {
            dependencies.push(dependency);
          }
        });
      }
      
      // Extract require statements
      const requireMatches = code.match(/require\s*\(\s*['"]([^'"]+)['"]\s*\)/g);
      if (requireMatches) {
        requireMatches.forEach(match => {
          const dependency = match.match(/require\s*\(\s*['"]([^'"]+)['"]\s*\)/)?.[1];
          if (dependency && !dependency.startsWith('.')) {
            dependencies.push(dependency);
          }
        });
      }
      break;
      
    case 'python':
      // Extract import statements
      const pythonImports = code.match(/(?:import\s+(\w+)|from\s+(\w+)\s+import)/g);
      if (pythonImports) {
        pythonImports.forEach(match => {
          const dependency = match.match(/(?:import\s+(\w+)|from\s+(\w+)\s+import)/)?.[1] || 
                           match.match(/from\s+(\w+)\s+import/)?.[1];
          if (dependency && !['os', 'sys', 'json', 'time', 'datetime'].includes(dependency)) {
            dependencies.push(dependency);
          }
        });
      }
      break;
      
    case 'java':
      // Extract import statements
      const javaImports = code.match(/import\s+([\w\.]+);/g);
      if (javaImports) {
        javaImports.forEach(match => {
          const dependency = match.match(/import\s+([\w\.]+);/)?.[1];
          if (dependency && !dependency.startsWith('java.')) {
            dependencies.push(dependency);
          }
        });
      }
      break;
  }
  
  return [...new Set(dependencies)]; // Remove duplicates
}

// Analyze generated code
async function analyzeCode(code: string, language: string, zai: any): Promise<any> {
  try {
    const analysisPrompt = `Analyze this ${language} code and provide a brief assessment:

${code}

Please provide:
1. Code quality assessment (1-10)
2. Potential issues or improvements
3. Suggested use cases
4. Complexity level`;

    const analysis = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a code analysis expert. Provide concise, helpful code analysis.'
        },
        {
          role: 'user',
          content: analysisPrompt
        }
      ],
      temperature: 0.3,
      max_tokens: 500
    });

    const analysisText = analysis.choices[0]?.message?.content || '';
    
    // Parse analysis into structured format
    return {
      summary: analysisText,
      quality: extractQualityScore(analysisText),
      issues: extractIssues(analysisText),
      suggestions: extractSuggestions(analysisText)
    };
  } catch (error) {
    console.error('Code analysis failed:', error);
    return {
      summary: 'Analysis unavailable',
      quality: 7,
      issues: [],
      suggestions: []
    };
  }
}

// Helper functions for analysis parsing
function extractQualityScore(analysis: string): number {
  const scoreMatch = analysis.match(/(\d+)\/10/i);
  return scoreMatch ? parseInt(scoreMatch[1]) : 7;
}

function extractIssues(analysis: string): string[] {
  const issues: string[] = [];
  const issuePatterns = [
    /potential (issue|problem|improvement):\s*(.+)/gi,
    /issue:\s*(.+)/gi,
    /improvement:\s*(.+)/gi
  ];
  
  issuePatterns.forEach(pattern => {
    let match;
    while ((match = pattern.exec(analysis)) !== null) {
      issues.push(match[2] || match[1]);
    }
  });
  
  return issues;
}

function extractSuggestions(analysis: string): string[] {
  const suggestions: string[] = [];
  const suggestionPatterns = [
    /suggestion:\s*(.+)/gi,
    /recommend:\s*(.+)/gi,
    /use case:\s*(.+)/gi
  ];
  
  suggestionPatterns.forEach(pattern => {
    let match;
    while ((match = pattern.exec(analysis)) !== null) {
      suggestions.push(match[1]);
    }
  });
  
  return suggestions;
}

// Generate fallback code
function generateFallbackCode(language: string, description: string): string {
  const timestamp = new Date().toISOString();
  
  switch (language.toLowerCase()) {
    case 'typescript':
      return `// Generated for: ${description}
// Generated at: ${timestamp}
// This is a fallback template - customize as needed

interface GeneratedInterface {
  // Define your interface here
}

export function generatedFunction(): GeneratedInterface {
  // Your implementation here
  return {} as GeneratedInterface;
}

export default generatedFunction;`;

    case 'javascript':
      return `// Generated for: ${description}
// Generated at: ${timestamp}
// This is a fallback template - customize as needed

function generatedFunction() {
  // Your implementation here
  return {};
}

module.exports = generatedFunction;`;

    case 'python':
      return `# Generated for: ${description}
# Generated at: ${timestamp}
# This is a fallback template - customize as needed

def generated_function():
    # Your implementation here
    pass

if __name__ == "__main__":
    generated_function()`;

    case 'java':
      return `// Generated for: ${description}
// Generated at: ${timestamp}
// This is a fallback template - customize as needed

public class GeneratedClass {
    public void generatedMethod() {
        // Your implementation here
    }
    
    public static void main(String[] args) {
        GeneratedClass instance = new GeneratedClass();
        instance.generatedMethod();
    }
}`;

    default:
      return `// Generated for: ${description}
// Generated at: ${timestamp}
// Language: ${language}
// This is a fallback template - customize as needed

// Your code here`;
  }
}