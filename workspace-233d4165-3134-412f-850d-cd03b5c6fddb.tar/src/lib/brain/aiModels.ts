export interface AIModel {
  id: string;
  name: string;
  provider: string;
  description: string;
  apiModel?: string;
  intelligence?: string;
  contextLength?: string;
  inputCredits?: string;
  outputCredits?: string;
  specialty?: 'chat' | 'image' | 'code' | 'fullstack' | 'deep-research' | 'autonomous-agent';
  capabilities?: string[];
  maxTokens?: number;
  temperature?: number;
  topP?: number;
  frequencyPenalty?: number;
  presencePenalty?: number;
}

export const AI_MODELS: AIModel[] = [
  // OpenAI Models
  {
    id: 'gpt-4o',
    name: 'GPT-4O',
    provider: 'openai',
    description: 'Most advanced model, optimized for complex tasks',
    apiModel: 'gpt-4o',
    intelligence: 'Very High',
    contextLength: '128K',
    inputCredits: '5',
    outputCredits: '15',
    specialty: 'autonomous-agent',
    capabilities: ['reasoning', 'coding', 'creative', 'analysis'],
    maxTokens: 4096,
    temperature: 0.7,
    topP: 0.9,
  },
  {
    id: 'gpt-4-turbo',
    name: 'GPT-4 Turbo',
    provider: 'openai',
    description: 'High performance model with large context window',
    apiModel: 'gpt-4-turbo',
    intelligence: 'High',
    contextLength: '128K',
    inputCredits: '10',
    outputCredits: '30',
    specialty: 'deep-research',
    capabilities: ['research', 'analysis', 'coding', 'writing'],
    maxTokens: 4096,
    temperature: 0.7,
    topP: 0.9,
  },
  {
    id: 'gpt-4',
    name: 'GPT-4',
    provider: 'openai',
    description: 'Powerful model for complex reasoning tasks',
    apiModel: 'gpt-4',
    intelligence: 'High',
    contextLength: '8K',
    inputCredits: '30',
    outputCredits: '60',
    specialty: 'chat',
    capabilities: ['reasoning', 'coding', 'analysis'],
    maxTokens: 8192,
    temperature: 0.7,
    topP: 0.9,
  },

  // Anthropic Models
  {
    id: 'claude-3-opus',
    name: 'Claude 3 Opus',
    provider: 'anthropic',
    description: 'Most capable model for complex tasks',
    apiModel: 'claude-3-opus-20240229',
    intelligence: 'Very High',
    contextLength: '200K',
    inputCredits: '15',
    outputCredits: '75',
    specialty: 'autonomous-agent',
    capabilities: ['reasoning', 'coding', 'creative', 'analysis'],
    maxTokens: 4096,
    temperature: 0.7,
    topP: 0.9,
  },
  {
    id: 'claude-3-sonnet',
    name: 'Claude 3 Sonnet',
    provider: 'anthropic',
    description: 'Balance of intelligence and speed',
    apiModel: 'claude-3-sonnet-20240229',
    intelligence: 'High',
    contextLength: '200K',
    inputCredits: '3',
    outputCredits: '15',
    specialty: 'chat',
    capabilities: ['reasoning', 'coding', 'creative'],
    maxTokens: 4096,
    temperature: 0.7,
    topP: 0.9,
  },

  // Google Models
  {
    id: 'gemini-1.5-pro',
    name: 'Gemini 1.5 Pro',
    provider: 'google',
    description: 'Advanced model with very large context window',
    apiModel: 'gemini-1.5-pro-latest',
    intelligence: 'Very High',
    contextLength: '1M',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'deep-research',
    capabilities: ['research', 'analysis', 'coding', 'multimodal'],
    maxTokens: 8192,
    temperature: 0.7,
    topP: 0.9,
  },
  {
    id: 'gemini-pro',
    name: 'Gemini Pro',
    provider: 'google',
    description: 'Capable model for various tasks',
    apiModel: 'gemini-pro',
    intelligence: 'High',
    contextLength: '32K',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'chat',
    capabilities: ['reasoning', 'coding', 'creative'],
    maxTokens: 8192,
    temperature: 0.7,
    topP: 0.9,
  },

  // OpenRouter Models
  {
    id: 'mixtral-8x7b',
    name: 'Mixtral 8x7B',
    provider: 'openrouter',
    description: 'High-quality open-source model',
    apiModel: 'mistralai/mixtral-8x7b-instruct',
    intelligence: 'High',
    contextLength: '32K',
    inputCredits: '0.5',
    outputCredits: '1.5',
    specialty: 'code',
    capabilities: ['coding', 'reasoning', 'creative'],
    maxTokens: 4096,
    temperature: 0.7,
    topP: 0.9,
  },
  {
    id: 'llama-3-70b',
    name: 'Llama 3 70B',
    provider: 'openrouter',
    description: 'Latest open-source model',
    apiModel: 'meta-llama/llama-3-70b-instruct',
    intelligence: 'High',
    contextLength: '8K',
    inputCredits: '0.9',
    outputCredits: '2.7',
    specialty: 'chat',
    capabilities: ['reasoning', 'coding', 'creative'],
    maxTokens: 4096,
    temperature: 0.7,
    topP: 0.9,
  },
];

// Specialized models for specific tasks
export const SPECIALIZED_MODELS = {
  code: [
    'gpt-4o',
    'gpt-4-turbo',
    'claude-3-opus',
    'mixtral-8x7b',
  ],
  creative: [
    'gpt-4o',
    'claude-3-opus',
    'claude-3-sonnet',
    'gpt-4',
  ],
  analysis: [
    'gpt-4-turbo',
    'claude-3-opus',
    'gemini-1.5-pro',
    'gpt-4o',
  ],
  research: [
    'gemini-1.5-pro',
    'gpt-4-turbo',
    'claude-3-opus',
  ],
  autonomous: [
    'gpt-4o',
    'claude-3-opus',
    'gpt-4-turbo',
  ],
  chat: [
    'gpt-4o',
    'claude-3-sonnet',
    'gemini-pro',
    'llama-3-70b',
  ],
};

// Helper functions
export function getModelById(id: string): AIModel | undefined {
  return AI_MODELS.find(model => model.id === id);
}

export function getModelsByProvider(provider: string): AIModel[] {
  return AI_MODELS.filter(model => model.provider === provider);
}

export function getModelsBySpecialty(specialty: string): AIModel[] {
  return AI_MODELS.filter(model => model.specialty === specialty);
}

export function getBestModelForTask(taskType: string): AIModel {
  const specializedModels = SPECIALIZED_MODELS[taskType as keyof typeof SPECIALIZED_MODELS];
  if (specializedModels && specializedModels.length > 0) {
    const modelId = specializedModels[0];
    const model = getModelById(modelId);
    if (model) return model;
  }
  
  // Default to GPT-4O if no specialized model found
  return getModelById('gpt-4o') || AI_MODELS[0];
}

export function getModelConfiguration(modelId: string): Partial<AIModel> {
  const model = getModelById(modelId);
  if (!model) return {};
  
  return {
    maxTokens: model.maxTokens,
    temperature: model.temperature,
    topP: model.topP,
    frequencyPenalty: model.frequencyPenalty,
    presencePenalty: model.presencePenalty,
  };
}