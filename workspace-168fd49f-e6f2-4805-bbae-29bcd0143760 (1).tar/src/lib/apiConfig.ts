// API Configuration for all AI services
export const API_CONFIG = {
  // OpenRouter (Primary)
  OPENROUTER_API_KEY: "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",
  OPENROUTER_BASE_URL: "https://openrouter.ai/api/v1",
  
  // Gemini (Backup)
  GEMINI_API_KEY: "AIzaSyDFT_vQAudEHVo2EmSEjhysOtwmP8HYr4I",
  GEMINI_BASE_URL: "https://generativelanguage.googleapis.com/v1beta",
  
  // OpenAI (Emergency)
  OPENAI_API_KEY: "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",
  OPENAI_BASE_URL: "https://api.openai.com/v1",
  
  // Model mappings for different services
  MODELS: {
    // OpenRouter Models
    OPENROUTER: {
      "gpt-4o": "openai/gpt-4o",
      "gpt-4-turbo": "openai/gpt-4-turbo",
      "gpt-4": "openai/gpt-4",
      "claude-3-opus": "anthropic/claude-3-opus",
      "claude-3-sonnet": "anthropic/claude-3-sonnet",
      "mixtral-8x7b": "mistralai/mixtral-8x7b-instruct",
      "llama-3-70b": "meta-llama/llama-3-70b-instruct",
      "gemini-pro": "google/gemini-pro",
      "gemini-1.5-pro": "google/gemini-1.5-pro",
      "glm-4.5": "glm-4-5"  // Added for deep research models
    },
    
    // Gemini Models
    GEMINI: {
      "gemini-pro": "gemini-pro",
      "gemini-1.5-pro": "gemini-1.5-pro",
      "gemini-1.5-flash": "gemini-1.5-flash",
      "glm-4.5": "gemini-1.5-pro"  // Fallback mapping
    },
    
    // OpenAI Models
    OPENAI: {
      "gpt-4o": "gpt-4o",
      "gpt-4-turbo": "gpt-4-turbo",
      "gpt-4": "gpt-4",
      "gpt-3.5-turbo": "gpt-3.5-turbo",
      "claude-3-opus": "gpt-4o",  // Fallback mapping
      "glm-4.5": "gpt-4o"  // Fallback mapping
    }
  },
  
  // Provider priorities for fallback
  PROVIDER_PRIORITY: ["openrouter", "gemini", "openai"],
  
  // Default models for different modes
  DEFAULT_MODELS: {
    "autonomous-agent": "gpt-4o",
    "chat": "gpt-4o", 
    "code": "gpt-4o",
    "image": "dall-e-3",
    "fullstack": "gpt-4o",
    "deep-research": "gpt-4o"
  }
};

// Helper function to get API headers for different providers
export const getApiHeaders = (provider: string) => {
  switch (provider) {
    case "openrouter":
      return {
        "Authorization": `Bearer ${API_CONFIG.OPENROUTER_API_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "http://localhost:3000",
        "X-Title": "AI Agent Platform"
      };
    case "gemini":
      return {
        "Content-Type": "application/json"
      };
    case "openai":
      return {
        "Authorization": `Bearer ${API_CONFIG.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      };
    default:
      return {
        "Content-Type": "application/json"
      };
  }
};

// Helper function to get API URL for different providers
export const getApiUrl = (provider: string, endpoint: string) => {
  switch (provider) {
    case "openrouter":
      return `${API_CONFIG.OPENROUTER_BASE_URL}/${endpoint}`;
    case "gemini":
      return `${API_CONFIG.GEMINI_BASE_URL}/${endpoint}`;
    case "openai":
      return `${API_CONFIG.OPENAI_BASE_URL}/${endpoint}`;
    default:
      return endpoint;
  }
};

// Helper function to map model name to provider-specific model ID
export const getModelId = (modelName: string, provider: string) => {
  const providerModels = API_CONFIG.MODELS[provider.toUpperCase() as keyof typeof API_CONFIG.MODELS];
  if (providerModels && providerModels[modelName as keyof typeof providerModels]) {
    return providerModels[modelName as keyof typeof providerModels];
  }
  return modelName;
};