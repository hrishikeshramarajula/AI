// Utility functions for API routes to ensure proper JSON responses
import { NextResponse } from 'next/server';

export interface APIResponse {
  success: boolean;
  response?: string;
  error?: string;
  data?: any;
}

/**
 * Creates a standardized JSON response
 */
export function createJSONResponse(data: APIResponse, status: number = 200): NextResponse {
  return NextResponse.json(data, { status });
}

/**
 * Creates a success response
 */
export function createSuccessResponse(response: string, additionalData?: any): NextResponse {
  return createJSONResponse({
    success: true,
    response,
    ...additionalData
  });
}

/**
 * Creates an error response
 */
export function createErrorResponse(error: string, status: number = 500): NextResponse {
  return createJSONResponse({
    success: false,
    error
  }, status);
}

/**
 * Wraps an async function with error handling to ensure JSON responses
 */
export async function withErrorHandling(fn: () => Promise<NextResponse>): Promise<NextResponse> {
  try {
    return await fn();
  } catch (error: any) {
    console.error('API Error:', error);
    
    // Ensure we always return JSON, never HTML
    return createErrorResponse(
      error.message || 'Internal server error',
      error.status || 500
    );
  }
}

/**
 * Validates required fields in request body
 */
export function validateRequiredFields(body: any, fields: string[]): { valid: boolean; error?: string } {
  for (const field of fields) {
    if (!body[field]) {
      return {
        valid: false,
        error: `${field} is required`
      };
    }
  }
  return { valid: true };
}

/**
 * Safely parses JSON from request body
 */
export async function safeParseJSON(request: Request): Promise<any> {
  try {
    return await request.json();
  } catch (error) {
    throw new Error('Invalid JSON in request body');
  }
}