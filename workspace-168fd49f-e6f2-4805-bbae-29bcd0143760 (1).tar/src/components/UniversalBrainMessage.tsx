// 🌟 Universal Brain-Enhanced Message Component
// Displays brain processing results for ANY mode (chat, image, code, fullstack, deep-research, autonomous-agent)

'use client';

import React, { useState } from 'react';
import { 
  Brain, 
  ChevronDown, 
  ChevronRight, 
  Clock, 
  Target, 
  BookOpen, 
  Zap,
  Eye,
  EyeOff,
  Download,
  Share2,
  CheckCircle,
  AlertCircle,
  TrendingUp,
  Code,
  Image as ImageIcon,
  Layers,
  Search,
  Bot,
  MessageSquare
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';

interface UniversalBrainProcessingData {
  mode: string;
  actualAnswer: string;
  textAnalysis: {
    primaryIntent: string;
    confidence: number;
    domain: string;
    complexity: number;
    emotionalContext: string;
    entitiesFound: number;
  };
  goalDecomposition: {
    subGoalsGenerated: number;
    executionApproach: string;
    estimatedDuration: number;
    riskLevel: string;
    modeSpecificGoals: string[];
  };
  knowledgeRetrieval: {
    knowledgeItems: number;
    strategies: number;
    recommendations: number;
    modeSpecificKnowledge: string[];
  };
  processingMetadata: {
    totalProcessingTime: number;
    confidence: number;
    brainCapabilities: string[];
    mode: string;
    processingDepth: string;
  };
  originalResponse: any;
}

interface UniversalBrainMessageProps {
  content: string;
  brainProcessing?: UniversalBrainProcessingData;
  model?: string;
  timestamp?: string;
  isUser?: boolean;
  mode?: string;
}

export default function UniversalBrainMessage({ 
  content, 
  brainProcessing, 
  model = '🤖 AI Assistant',
  timestamp,
  isUser = false,
  mode = 'chat'
}: UniversalBrainMessageProps) {
  const [showDetails, setShowDetails] = useState(false);
  const [showFullAnalysis, setShowFullAnalysis] = useState(false);

  if (isUser) {
    return (
      <div className="flex justify-end mb-4">
        <div className="max-w-[80%]">
          <div className="bg-blue-600 text-white p-4 rounded-lg rounded-br-none">
            <p className="text-sm">{content}</p>
          </div>
          {timestamp && (
            <p className="text-xs text-gray-500 mt-1 text-right">{timestamp}</p>
          )}
        </div>
      </div>
    );
  }

  // Get mode-specific icon and color
  const getModeInfo = (mode: string) => {
    const modeMap: Record<string, { icon: React.ReactNode, color: string, label: string }> = {
      'chat': { 
        icon: <MessageSquare className="w-4 h-4" />, 
        color: 'blue',
        label: '💬 Chat'
      },
      'image': { 
        icon: <ImageIcon className="w-4 h-4" />, 
        color: 'purple',
        label: '🎨 Image Generation'
      },
      'code': { 
        icon: <Code className="w-4 h-4" />, 
        color: 'green',
        label: '💻 Code Generation'
      },
      'fullstack': { 
        icon: <Layers className="w-4 h-4" />, 
        color: 'orange',
        label: '🚀 Fullstack Development'
      },
      'deep-research': { 
        icon: <Search className="w-4 h-4" />, 
        color: 'red',
        label: '🔬 Deep Research'
      },
      'autonomous-agent': { 
        icon: <Bot className="w-4 h-4" />, 
        color: 'indigo',
        label: '🤖 Autonomous Agent'
      }
    };

    return modeMap[mode] || modeMap['chat'];
  };

  const modeInfo = getModeInfo(mode);
  const colorClasses = {
    blue: 'border-blue-500 bg-blue-50',
    purple: 'border-purple-500 bg-purple-50',
    green: 'border-green-500 bg-green-50',
    orange: 'border-orange-500 bg-orange-50',
    red: 'border-red-500 bg-red-50',
    indigo: 'border-indigo-500 bg-indigo-50'
  };

  return (
    <div className="flex justify-start mb-6">
      <div className="max-w-[90%]">
        {/* Mode Header */}
        <div className="flex items-center gap-2 mb-2">
          <span className="font-semibold text-gray-700">{model}</span>
          <Badge variant="secondary" className={`bg-${modeInfo.color}-100 text-${modeInfo.color}-800`}>
            {modeInfo.icon}
            {modeInfo.label}
          </Badge>
          {brainProcessing && (
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              <Brain className="w-3 h-3 mr-1" />
              Brain Enhanced
            </Badge>
          )}
          {timestamp && (
            <span className="text-xs text-gray-500">{timestamp}</span>
          )}
        </div>

        {/* Main Response Card */}
        <Card className={`border-l-4 border-l-${modeInfo.color}-500 ${colorClasses[modeInfo.color as keyof typeof colorClasses]}`}>
          <CardContent className="p-4">
            {/* Brain Processing Indicator - Simplified */}
            {brainProcessing && (
              <div className="mb-4 p-3 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg border border-green-200">
                <div className="flex items-center gap-2 mb-2">
                  <Brain className="w-5 h-5 text-green-600" />
                  <Badge variant="outline" className="text-xs">
                    {modeInfo.label}
                  </Badge>
                  <Badge variant="secondary" className="bg-green-100 text-green-800">
                    Brain Enhanced
                  </Badge>
                </div>
              </div>
            )}

            {/* Mode-Specific Response */}
            <div className="mb-4">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="font-semibold text-gray-700">
                  {mode === 'image' && '🎨 Image Generation Response'}
                  {mode === 'code' && '💻 Code Generation Response'}
                  {mode === 'fullstack' && '🚀 Fullstack Development Response'}
                  {mode === 'deep-research' && '🔬 Deep Research Response'}
                  {mode === 'autonomous-agent' && '🤖 Autonomous Agent Response'}
                  {mode === 'chat' && '💬 AI Response'}
                </span>
              </div>
              <div className="prose prose-sm max-w-none">
                <div className="whitespace-pre-wrap text-gray-800 leading-relaxed">
                  {brainProcessing?.actualAnswer || content}
                </div>
              </div>
              
              {/* Image Display */}
              {mode === 'image' && brainProcessing?.originalResponse?.imageData && (
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <div className="text-xs font-medium mb-2 text-gray-600">🎨 Generated Image:</div>
                  <div className="mt-2">
                    <img 
                      src={`data:image/png;base64,${brainProcessing.originalResponse.imageData}`} 
                      alt={brainProcessing.originalResponse.imagePrompt || "Generated image"}
                      className="max-w-full h-auto rounded-lg border border-gray-200 shadow-sm"
                    />
                    {brainProcessing.originalResponse.imagePrompt && (
                      <div className="text-xs text-gray-500 mt-2 italic">
                        💭 Prompt: "{brainProcessing.originalResponse.imagePrompt}"
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Universal Brain Processing Details (Collapsible) */}
            {brainProcessing && (
              <>
                <div className="flex items-center justify-between mb-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowDetails(!showDetails)}
                    className="flex items-center gap-2"
                  >
                    {showDetails ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    {showDetails ? 'Hide Brain Analysis' : 'Show Universal Brain Analysis'}
                  </Button>
                  
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" className="text-xs">
                      <Download className="w-3 h-3 mr-1" />
                      Save
                    </Button>
                    <Button variant="ghost" size="sm" className="text-xs">
                      <Share2 className="w-3 h-3 mr-1" />
                      Share
                    </Button>
                  </div>
                </div>

                {showDetails && (
                  <div className="border-t pt-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      {/* Text Analysis */}
                      <Card className="bg-blue-50 border-blue-200">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm flex items-center gap-2">
                            <Target className="w-4 h-4 text-blue-600" />
                            🔍 Universal Text Analysis
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-3">
                          <div className="space-y-2 text-xs">
                            <div className="flex justify-between">
                              <span>Primary Intent:</span>
                              <span className="font-medium">{brainProcessing.textAnalysis?.primaryIntent || 'N/A'}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Confidence:</span>
                              <span className="font-medium">{(brainProcessing.textAnalysis?.confidence || 0 * 100).toFixed(0)}%</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Domain:</span>
                              <span className="font-medium">{brainProcessing.textAnalysis?.domain || 'N/A'}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Complexity:</span>
                              <span className="font-medium">{brainProcessing.textAnalysis?.complexity?.toFixed(2) || '0.00'}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Emotional Context:</span>
                              <span className="font-medium">{brainProcessing.textAnalysis?.emotionalContext || 'N/A'}</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      {/* Goal Decomposition */}
                      <Card className="bg-purple-50 border-purple-200">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm flex items-center gap-2">
                            <Zap className="w-4 h-4 text-purple-600" />
                            🎯 Universal Goal Decomposition
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-3">
                          <div className="space-y-2 text-xs">
                            <div className="flex justify-between">
                              <span>Sub-Goals:</span>
                              <span className="font-medium">{brainProcessing.goalDecomposition?.subGoalsGenerated || 0}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Approach:</span>
                              <span className="font-medium">{brainProcessing.goalDecomposition?.executionApproach || 'N/A'}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Duration:</span>
                              <span className="font-medium">{brainProcessing.goalDecomposition?.estimatedDuration || 0}s</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Risk Level:</span>
                              <span className="font-medium">{brainProcessing.goalDecomposition?.riskLevel || 'N/A'}</span>
                            </div>
                          </div>
                          
                          {/* Mode-Specific Goals */}
                          {brainProcessing.goalDecomposition?.modeSpecificGoals && brainProcessing.goalDecomposition.modeSpecificGoals.length > 0 && (
                            <div className="mt-2 pt-2 border-t border-purple-200">
                              <div className="font-medium text-xs text-purple-800 mb-1">Mode-Specific Goals:</div>
                              {brainProcessing.goalDecomposition.modeSpecificGoals.slice(0, 3).map((goal, index) => (
                                <div key={index} className="text-xs text-purple-700">• {goal}</div>
                              ))}
                            </div>
                          )}
                        </CardContent>
                      </Card>

                      {/* Knowledge Retrieval */}
                      <Card className="bg-orange-50 border-orange-200">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm flex items-center gap-2">
                            <BookOpen className="w-4 h-4 text-orange-600" />
                            🧚 Universal Knowledge
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-3">
                          <div className="space-y-2 text-xs">
                            <div className="flex justify-between">
                              <span>Knowledge Items:</span>
                              <span className="font-medium">{brainProcessing.knowledgeRetrieval?.knowledgeItems || 0}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Strategies:</span>
                              <span className="font-medium">{brainProcessing.knowledgeRetrieval?.strategies || 0}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Recommendations:</span>
                              <span className="font-medium">{brainProcessing.knowledgeRetrieval?.recommendations || 0}</span>
                            </div>
                          </div>
                          
                          {/* Mode-Specific Knowledge */}
                          {brainProcessing.knowledgeRetrieval?.modeSpecificKnowledge && brainProcessing.knowledgeRetrieval.modeSpecificKnowledge.length > 0 && (
                            <div className="mt-2 pt-2 border-t border-orange-200">
                              <div className="font-medium text-xs text-orange-800 mb-1">Mode-Specific Knowledge:</div>
                              {brainProcessing.knowledgeRetrieval.modeSpecificKnowledge.slice(0, 3).map((knowledge, index) => (
                                <div key={index} className="text-xs text-orange-700">• {knowledge}</div>
                              ))}
                            </div>
                          )}
                        </CardContent>
                      </Card>

                      {/* Processing Performance */}
                      <Card className="bg-green-50 border-green-200">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm flex items-center gap-2">
                            <TrendingUp className="w-4 h-4 text-green-600" />
                            📊 Universal Performance
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-3">
                          <div className="space-y-2 text-xs">
                            <div className="flex justify-between">
                              <span>Total Time:</span>
                              <span className="font-medium">{brainProcessing.processingMetadata?.totalProcessingTime || 0}ms</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Confidence:</span>
                              <span className="font-medium">{(brainProcessing.processingMetadata?.confidence || 0 * 100).toFixed(0)}%</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Capabilities:</span>
                              <span className="font-medium">{brainProcessing.processingMetadata?.brainCapabilities?.length || 0}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Processing Depth:</span>
                              <span className="font-medium">{brainProcessing.processingMetadata?.processingDepth || 'N/A'}</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    {/* Universal Brain Capabilities */}
                    <div className="mb-4">
                      <div className="text-sm font-semibold mb-2">🌟 Universal Brain Capabilities Utilized:</div>
                      <div className="flex flex-wrap gap-1">
                        {brainProcessing.processingMetadata?.brainCapabilities && brainProcessing.processingMetadata.brainCapabilities.map((capability, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {capability.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}