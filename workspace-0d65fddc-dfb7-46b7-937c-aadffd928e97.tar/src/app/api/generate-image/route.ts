import { NextRequest } from 'next/server';
import { createSuccessResponse, createErrorResponse, withErrorHandling } from '@/lib/apiUtils';
import ZAI from 'z-ai-web-dev-sdk';
import * as fs from 'fs/promises';
import * as path from 'path';
import * as crypto from 'crypto';

export async function POST(request: NextRequest) {
  return withErrorHandling(async () => {
    try {
      const body = await request.json();
      const { prompt, provider = 'auto', model = 'auto', size = '1024x1024', optimize = true, saveToFile = false } = body;

      if (!prompt) {
        return createErrorResponse('Prompt is required', 400);
      }

      console.log('🎨 Generating image with prompt:', prompt);
      console.log('📋 Configuration:', { provider, model, size, optimize, saveToFile });

      // Initialize ZAI SDK
      const zai = await ZAI.create();

      // Generate image
      const response = await zai.images.generations.create({
        prompt: prompt,
        size: size as any
      });

      console.log('✅ Image generated successfully');

      // Extract image data
      const imageData = response.data[0]?.base64;
      
      if (!imageData) {
        throw new Error('No image data received from AI service');
      }

      // If saveToFile is true, save the image
      let filePath = '';
      if (saveToFile) {
        // Generate unique filename
        const timestamp = Date.now();
        const hash = crypto.createHash('md5').update(prompt).digest('hex').substring(0, 8);
        const fileName = `generated-${timestamp}-${hash}.png`;
        filePath = path.join(process.cwd(), 'public', 'generated-images', fileName);
        
        // Ensure directory exists
        await fs.mkdir(path.dirname(filePath), { recursive: true });
        
        // Save image
        const buffer = Buffer.from(imageData, 'base64');
        await fs.writeFile(filePath, buffer);
        
        console.log('💾 Image saved to:', filePath);
      }

      return createSuccessResponse({
        imageData,
        imageUrl: filePath ? `/generated-images/${path.basename(filePath)}` : null,
        provider: provider,
        model: model,
        metadata: {
          size,
          optimized: optimize,
          savedToFile: saveToFile,
          filePath
        }
      });

    } catch (error: any) {
      console.error('❌ Image generation error:', error);
      
      // Return a more user-friendly error message
      let errorMessage = 'Image generation failed';
      let errorDetails = error.message || 'Unknown error occurred';
      
      if (error.message?.includes('API key')) {
        errorMessage = 'API key configuration error';
        errorDetails = 'Please check your AI service API keys';
      } else if (error.message?.includes('quota')) {
        errorMessage = 'API quota exceeded';
        errorDetails = 'Please check your API usage limits';
      } else if (error.message?.includes('timeout')) {
        errorMessage = 'Request timeout';
        errorDetails = 'The image generation request took too long';
      }
      
      return createErrorResponse({
        message: errorMessage,
        details: errorDetails,
        suggestion: 'Please try again with a different prompt or check your API configuration'
      }, 500);
    }
  });
}