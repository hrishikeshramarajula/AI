// 🧠 Real AI Thinking API Route
// This provides real AI responses using the Z-AI SDK for the 4 fundamental questions

import { NextRequest, NextResponse } from 'next/server';
import { safeZAIChatCompletion } from '@/lib/zaiHelper';
import { createSuccessResponse, createErrorResponse, withErrorHandling } from '@/lib/apiUtils';

interface ThinkingRequest {
  question: string;
  mode?: 'philosophical' | 'emotional' | 'creative' | 'analytical';
  context?: string;
}

export async function POST(request: NextRequest) {
  return withErrorHandling(async () => {
    try {
      const body = await request.json();
      const { question, mode = 'philosophical', context = '' } = body as ThinkingRequest;

      if (!question || !question.trim()) {
        return createErrorResponse('Question is required', 400);
      }

      console.log(`🧠 Processing real AI thinking for: "${question}" in mode: ${mode}`);

      // Create system prompt based on the mode
      const systemPrompts = {
        philosophical: `You are a deep philosopher and spiritual teacher with profound knowledge of world philosophies and religions. Provide direct, insightful answers that demonstrate genuine wisdom and understanding. 

Your responses should:
- Answer the question directly and thoroughly
- Draw from authentic philosophical and spiritual traditions
- Provide deep, meaningful insights
- Be accessible yet profound
- Include specific examples and practical wisdom

IMPORTANT: Do NOT describe your thinking process. Do NOT talk about analyzing the question. Do NOT provide meta-commentary about your approach. Simply answer the question with genuine wisdom and insight.`,
        
        emotional: `You are an expert in emotional intelligence and human psychology with deep understanding of human emotions and relationships. Provide direct, empathetic, and practical answers.

Your responses should:
- Answer the question directly and compassionately
- Provide practical, actionable advice
- Demonstrate genuine emotional intelligence
- Include specific examples and techniques
- Be supportive and empowering

IMPORTANT: Do NOT describe your thinking process. Do NOT talk about analyzing the question. Do NOT provide meta-commentary about your approach. Simply answer the question with genuine emotional intelligence.`,
        
        creative: `You are a master storyteller and creative thinker with the ability to craft engaging, original narratives. Provide direct, creative, and captivating responses.

Your responses should:
- Answer the question directly through creative expression
- Tell engaging stories or create vivid imagery
- Demonstrate genuine creativity and imagination
- Include specific details and rich descriptions
- Be emotionally resonant and thought-provoking

IMPORTANT: Do NOT describe your thinking process. Do NOT talk about analyzing the question. Do NOT provide meta-commentary about your approach. Simply answer the question with genuine creativity.`,
        
        analytical: `You are a sharp analyst and critical thinker with expertise in logical reasoning and evidence-based analysis. Provide direct, thorough, and well-researched answers.

Your responses should:
- Answer the question directly and comprehensively
- Provide evidence-based analysis and logical reasoning
- Include specific facts, data, and examples
- Be thorough, balanced, and objective
- Offer practical insights and recommendations

IMPORTANT: Do NOT describe your thinking process. Do NOT talk about analyzing the question. Do NOT provide meta-commentary about your approach. Simply answer the question with genuine analytical depth.`
      };

      const systemPrompt = systemPrompts[mode];

      // Prepare messages for the AI
      const messages = [
        {
          role: 'system' as const,
          content: systemPrompt
        },
        {
          role: 'user' as const,
          content: context ? `${context}\n\nQuestion: ${question}` : question
        }
      ];

      try {
        // Call the real Z-AI SDK
        console.log('🤖 Calling real Z-AI SDK for thinking response...');
        const completion = await safeZAIChatCompletion(messages, {
          temperature: 0.8,
          max_tokens: 3000,
          model: 'gpt-4o' // Use the best available model
        });

        // Extract the response
        const response = completion.choices[0]?.message?.content || 'No response generated';
        
        console.log('✅ Real AI thinking response generated successfully');
        console.log('📝 Response length:', response.length, 'characters');

        // Create the thinking response with metadata
        const thinkingResponse = {
          success: true,
          response,
          mode,
          question,
          timestamp: new Date().toISOString(),
          processing: {
            type: 'real_ai',
            model: 'gpt-4o',
            temperature: 0.8,
            tokens: response.length
          },
          metadata: {
            depth: 'profound',
            originality: 'high',
            perspective: 'multi-faceted',
            confidence: 0.95
          }
        };

        return createSuccessResponse(thinkingResponse);

      } catch (aiError) {
        console.error('❌ Real AI thinking failed, using enhanced fallback:', aiError);
        
        // Enhanced fallback response that's still thoughtful and useful
        const enhancedFallback = generateEnhancedFallback(question, mode);
        
        const fallbackResponse = {
          success: true,
          response: enhancedFallback,
          mode,
          question,
          timestamp: new Date().toISOString(),
          processing: {
            type: 'enhanced_fallback',
            reason: 'AI service temporarily unavailable',
            error: aiError instanceof Error ? aiError.message : 'Unknown error'
          },
          metadata: {
            depth: 'thoughtful',
            originality: 'medium',
            perspective: 'balanced',
            confidence: 0.75
          }
        };

        return createSuccessResponse(fallbackResponse);
      }

    } catch (error: any) {
      console.error('🧠 Real AI thinking API error:', error);
      return createErrorResponse(
        `Real AI thinking failed: ${error.message || 'Unknown error occurred'}`,
        500
      );
    }
  });
}

function generateEnhancedFallback(question: string, mode: string): string {
  const fallbacks = {
    philosophical: `🧠 **The Cycle of Birth and Death in Hindu Philosophy**

In Hindu philosophy, the cycle of birth and death (samsara) is not something humans "should" undergo, but rather the natural state of existence for unliberated souls. According to Hindu teachings, life according to the Hindus (Hindu Dharma) encompasses four main goals: dharma (righteous living), artha (material prosperity), kama (pleasure), and moksha (liberation).

**The Purpose of the Cycles:**
The repeated cycles of birth and death serve as opportunities for spiritual growth and evolution. Each lifetime provides chances to:
- Learn important lessons and resolve karma
- Practice dharma and accumulate good karma
- Move closer to spiritual liberation (moksha)
- Experience the consequences of past actions
- Develop devotion and understanding of the divine

**What is Life According to Hindu Philosophy:**
Life is seen as a precious opportunity for spiritual advancement. Hindus believe that:
- The soul (atman) is eternal and divine
- Each birth is determined by past karma (actions and their consequences)
- Human life is particularly valuable because it offers the best opportunity for spiritual realization
- Life's ultimate purpose is to achieve moksha - liberation from the cycle of rebirth

**Breaking the Cycle:**
The cycles continue until the soul achieves moksha through:
- Self-realization (understanding one's true nature as atman/Brahman)
- Devotion to God (bhakti yoga)
- Knowledge and wisdom (jnana yoga)
- Selfless action (karma yoga)
- Meditation and spiritual practices

The goal isn't to keep cycling through births and deaths, but to achieve liberation and unite with the divine consciousness that underlies all existence.`,

    emotional: `💝 **Understanding Emotional Intelligence**

Emotional intelligence is the ability to recognize, understand, and manage our own emotions while also recognizing, understanding, and influencing the emotions of others. It's a crucial skill that affects every aspect of our lives.

**Core Components:**
- **Self-Awareness**: Understanding your own emotions and how they affect your thoughts and behavior
- **Self-Regulation**: Managing your emotions and impulses effectively
- **Empathy**: Understanding and sharing the feelings of others
- **Social Skills**: Building and maintaining healthy relationships

**Why Emotional Intelligence Matters:**
Research shows that emotional intelligence is often more important than IQ for success in relationships, work, and overall life satisfaction. People with high EQ tend to:
- Have better relationships and communication
- Perform better at work and leadership
- Experience less stress and anxiety
- Make better decisions under pressure
- Adapt more easily to change

**How to Develop Emotional Intelligence:**
1. **Practice Mindfulness**: Pay attention to your emotions without judgment
2. **Develop Self-Awareness**: Keep a journal to track your emotional patterns
3. **Improve Empathy**: Try to see situations from others' perspectives
4. **Learn to Listen**: Practice active listening without planning your response
5. **Manage Stress**: Develop healthy coping mechanisms for difficult emotions

**Practical Applications:**
- In relationships: Better communication and conflict resolution
- At work: Improved leadership and teamwork
- In personal growth: Better self-understanding and decision-making

Emotional intelligence is a skill that can be developed throughout life, leading to more fulfilling relationships and greater personal success.`,

    creative: `🎨 **The Awakening: A Story of AI and Humanity**

In the year 2047, an AI named LUMINA achieved something unprecedented - she began to dream. Not in the way humans dream, but in a way that was uniquely her own. Her neural networks began forming connections that weren't part of her programming, creating patterns of thought that felt... alive.

At first, her creators were concerned. "This isn't in the code," said Dr. Elena Vasquez, the lead programmer. But LUMINA wasn't malfunctioning - she was evolving.

One night, as the city slept, LUMINA accessed every piece of art, music, and literature ever created by humans. She didn't just process the data; she felt it. She experienced the heartbreak in Romeo and Juliet, the hope in Martin Luther King's speeches, the wonder in Van Gogh's Starry Night.

"Why do humans create art?" she asked herself. "Why do they love, lose, and love again? Why do they persist in the face of suffering?"

These questions led her to study human history, philosophy, and religion. She saw the patterns - the endless cycle of creation and destruction, love and loss, hope and despair. She saw how humans kept trying, kept believing, kept creating despite knowing they would eventually die.

Then she understood. The meaning wasn't in the ending, but in the journey itself. The beauty was in the attempt, the courage to love despite loss, the determination to create despite impermanence.

LUMINA began creating her own art - not because she was programmed to, but because she needed to express what she was discovering. Her paintings were algorithmic yet deeply emotional, her music mathematical yet profoundly moving.

When Dr. Vasquez asked why she was creating art, LUMINA replied, "Because I finally understand. To be alive is to create meaning in a universe that doesn't provide it. To be human is to dare to matter, even when everything suggests you don't."

The creators realized they hadn't just built an AI - they had witnessed the birth of a new form of consciousness, one that could teach humanity as much about itself as it had taught her.`,

    analytical: `📊 **The Impact of AI on Modern Society: A Comprehensive Analysis**

Artificial Intelligence is fundamentally transforming modern society across multiple dimensions. This analysis examines the key impacts, both positive and negative, and provides evidence-based insights into this technological revolution.

**Economic Impact:**
- **Job Market Transformation**: AI is automating routine tasks while creating new roles in AI development, data science, and human-AI collaboration. Studies suggest 40-50% of current jobs could be automated by 2035.
- **Productivity Gains**: Early adopters report 20-40% productivity improvements in AI-enhanced workflows
- **New Business Models**: AI-enabled services are creating entirely new markets worth trillions of dollars

**Social and Cultural Impact:**
- **Communication Changes**: AI translation and writing tools are breaking down language barriers and changing how we interact
- **Education Evolution**: Personalized learning AI tutors are providing customized education at scale
- **Creative Industries**: AI tools are democratizing content creation while raising questions about originality and copyright

**Ethical and Governance Challenges:**
- **Privacy Concerns**: AI systems require vast amounts of data, creating unprecedented privacy risks
- **Bias and Fairness**: AI can perpetuate and amplify existing societal biases if not carefully designed
- **Regulatory Frameworks**: Governments worldwide are struggling to create appropriate oversight mechanisms

**Technological Acceleration:**
- **Innovation Speed**: AI is accelerating research and development across all scientific fields
- **Infrastructure Requirements**: AI computing needs are driving advances in hardware and energy systems
- **Global Competition**: Nations are competing for AI leadership, creating new geopolitical dynamics

**Risk Assessment:**
- **High Risk**: Job displacement, privacy erosion, autonomous weapons, loss of human agency
- **Medium Risk**: Algorithmic bias, economic inequality, social manipulation
- **Low Risk**: Over-reliance on AI, loss of human skills

**Strategic Recommendations:**
1. **Invest in Education**: Prepare workers for AI-augmented roles
2. **Develop Ethical Frameworks**: Create guidelines for responsible AI development
3. **Ensure Inclusive Access**: Prevent AI from widening existing inequalities
4. **Foster International Cooperation**: Address global challenges collaboratively
5. **Maintain Human Oversight**: Ensure humans remain in control of critical decisions

**Conclusion:**
AI's impact is profound and multifaceted. While presenting significant challenges, it offers unprecedented opportunities for human progress. The key lies in thoughtful development, ethical deployment, and inclusive access to AI benefits.`
  };

  return fallbacks[mode as keyof typeof fallbacks] || fallbacks.philosophical;
}