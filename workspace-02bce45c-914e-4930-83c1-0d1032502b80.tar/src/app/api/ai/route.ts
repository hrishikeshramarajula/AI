import { NextRequest } from 'next/server';
import { performWebSearch } from '@/lib/search';
import { AIMessage, AIResponse } from '@/types/ai';
import { 
  createSuccessResponse, 
  createErrorResponse, 
  withErrorHandling,
  validateRequiredFields 
} from '@/lib/apiUtils';
import { API_CONFIG, getApiHeaders, getApiUrl, getModelId } from '@/lib/apiConfig';

async function callRealAI(messages: AIMessage[], model: string, searchType: string) {
  console.log('🤖 Calling real AI APIs...');
  console.log('📋 Model:', model);
  console.log('🎯 Search Type:', searchType);
  
  // Try providers in order of priority
  for (const provider of API_CONFIG.PROVIDER_PRIORITY) {
    try {
      console.log(`🔄 Trying provider: ${provider}`);
      
      let apiModel = model;
      let apiUrl = '';
      let headers = getApiHeaders(provider);
      let requestBody: any = {};
      
      // Map display model names to API-specific model IDs
      if (model.includes('GPT-4O') || model.includes('gpt-4o')) {
        apiModel = 'gpt-4o';
      } else if (model.includes('GPT-4 Turbo') || model.includes('gpt-4-turbo')) {
        apiModel = 'gpt-4-turbo';
      } else if (model.includes('GPT-4') || model.includes('gpt-4')) {
        apiModel = 'gpt-4';
      } else if (model.includes('Claude 3 Opus') || model.includes('claude-3-opus')) {
        apiModel = 'claude-3-opus';
      } else if (model.includes('Claude 3 Sonnet') || model.includes('claude-3-sonnet')) {
        apiModel = 'claude-3-sonnet';
      } else if (model.includes('Gemini 1.5 Pro') || model.includes('gemini-1.5-pro')) {
        apiModel = 'gemini-1.5-pro';
      } else if (model.includes('Gemini Pro') || model.includes('gemini-pro')) {
        apiModel = 'gemini-pro';
      } else if (model.includes('Mixtral') || model.includes('mixtral')) {
        apiModel = 'mixtral-8x7b';
      } else if (model.includes('Llama 3') || model.includes('llama-3')) {
        apiModel = 'llama-3-70b';
      } else {
        // Default model based on provider
        switch (provider) {
          case 'openrouter':
            apiModel = 'openai/gpt-4o';
            break;
          case 'gemini':
            apiModel = 'gemini-1.5-pro';
            break;
          case 'openai':
            apiModel = 'gpt-4o';
            break;
        }
      }
      
      console.log('🔄 Using API model:', apiModel, 'with provider:', provider);
      
      // Prepare request based on provider
      switch (provider) {
        case 'openrouter':
        case 'openai':
          apiUrl = getApiUrl(provider, 'chat/completions');
          requestBody = {
            model: getModelId(apiModel, provider),
            messages: messages.map(msg => ({
              role: msg.role,
              content: msg.content
            })),
            temperature: 0.7,
            max_tokens: 2000,
            stream: false
          };
          break;
          
        case 'gemini':
          apiUrl = getApiUrl(provider, `models/${getModelId(apiModel, provider)}:generateContent?key=${API_CONFIG.GEMINI_API_KEY}`);
          const userMessage = messages.find(m => m.role === 'user');
          const systemMessage = messages.find(m => m.role === 'system');
          
          requestBody = {
            contents: [{
              role: 'user',
              parts: [{
                text: `${systemMessage ? systemMessage.content + '\n\n' : ''}${userMessage?.content || ''}`
              }]
            }],
            generationConfig: {
              temperature: 0.7,
              topK: 40,
              topP: 0.95,
              maxOutputTokens: 2000,
            }
          };
          break;
      }
      
      console.log('🌐 Making request to:', apiUrl);
      
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(requestBody)
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error(`❌ ${provider} API error:`, response.status, errorText);
        throw new Error(`${provider} API failed: ${errorText}`);
      }
      
      const data = await response.json();
      console.log(`✅ ${provider} API response received`);
      
      // Extract response content based on provider
      let content = '';
      switch (provider) {
        case 'openrouter':
        case 'openai':
          content = data.choices?.[0]?.message?.content || 'No response generated';
          break;
          
        case 'gemini':
          content = data.candidates?.[0]?.content?.parts?.[0]?.text || 'No response generated';
          break;
      }
      
      console.log('📝 Response length:', content.length, 'characters');
      console.log(`✅ Successfully used ${provider} provider`);
      
      return content;
      
    } catch (error) {
      console.error(`❌ ${provider} failed:`, error);
      // Continue to next provider
      continue;
    }
  }
  
  // If all providers failed, throw an error
  throw new Error('All AI providers failed');
}

export async function POST(request: NextRequest) {
  return withErrorHandling(async () => {
    try {
      const body = await request.json();
      
      // Validate required fields
      const validation = validateRequiredFields(body, ['message']);
      if (!validation.valid) {
        return createErrorResponse(validation.error!, 400);
      }

      const { message, model, searchType = 'chat' } = body;
      
      console.log(`Processing request: ${message} with model: ${model} and type: ${searchType}`);

      let response = '';
      let searchResults: any[] = [];
      let imageData: string | undefined;
      let imagePrompt: string | undefined;
      let usedProvider = '';

      // Handle different search types
      switch (searchType) {
        case 'search':
          // Perform web search first
          try {
            searchResults = await performWebSearch(message);
            console.log(`Web search completed with ${searchResults.length} results`);
          } catch (searchError) {
            console.warn('Web search failed, continuing without search results:', searchError);
            searchResults = [];
          }
          
          const searchContext = searchResults.map(result => 
            `Source: ${result.name}\nContent: ${result.snippet}`
          ).join('\n\n');

          const searchMessages: AIMessage[] = [
            {
              role: 'system',
              content: `You are an AI assistant that provides accurate, comprehensive answers based on search results and your knowledge. Use the search results to enhance your response.\n\nSearch Results:\n${searchContext}`
            },
            {
              role: 'user',
              content: message
            }
          ];

          try {
            response = await callRealAI(searchMessages, model, searchType);
            usedProvider = 'Real AI';
          } catch (providerError) {
            console.error('Real AI failed for search:', providerError);
            response = `🔍 **Web Search Mode**

I apologize, but I'm experiencing technical difficulties with search services. However, I can still help you with: "${message}"

**Search Results Found:** ${searchResults.length} sources

**What I can provide:**
• Summary of available search results
• General knowledge on the topic
• Guidance on where to find more information
• Basic explanations and concepts

**Available Search Results:**
${searchResults.slice(0, 3).map((result, index) => `${index + 1}. ${result.name} - ${result.snippet.substring(0, 100)}...`).join('\n')}

**Technical Status:** The AI services are experiencing issues. Please try again in a moment for enhanced search capabilities.`;
            usedProvider = 'partial';
          }
          break;

        case 'image':
          imagePrompt = message;
          
          try {
            // Actually call the image generation API
            console.log('🎨 Calling image generation API for:', message);
            
            const imageResponse = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000'}/api/generate-image`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                prompt: message,
                provider: 'auto',
                model: 'auto',
                size: '1024x1024',
                optimize: true,
                saveToFile: false
              }),
            });
            
            if (!imageResponse.ok) {
              const errorText = await imageResponse.text();
              console.error('Image generation API failed:', errorText);
              throw new Error(`Image generation failed: ${errorText}`);
            }
            
            const imageResult = await imageResponse.json();
            console.log('✅ Image generated successfully:', imageResult);
            
            imageData = imageResult.imageData;
            response = `🎨 **Image Generated Successfully!**

I've created an image based on your prompt: "${message}"

**Generation Details:**
- **Provider:** ${imageResult.provider}
- **Model:** ${imageResult.model}
- **Size:** ${imageResult.metadata?.size || '1024x1024'}
- **Optimized:** ${imageResult.metadata?.optimized ? 'Yes' : 'No'}

The image is displayed above. If you'd like to generate a different image or make adjustments, just let me know!`;
            usedProvider = imageResult.provider;
            
          } catch (imageError) {
            console.error('Image generation error:', imageError);
            response = `❌ **Image Generation Failed**

I apologize, but I encountered an issue while generating the image for: "${message}"

**Error Details:** ${imageError instanceof Error ? imageError.message : 'Unknown error'}

**Possible Solutions:**
• Try again in a few moments
• Check if the AI services are properly configured
• Try a different image model from the dropdown
• Simplify your image prompt

**Available Image Models:**
• 🎨 FLUX Dev (Hugging Face) - Highest quality
• ⚡ FLUX Schnell (Hugging Face) - Fast generation
• 🎭 SD 3 Medium (Hugging Face) - Balanced quality
• 🎨 DALL-E 3 (OpenAI) - Premium quality

Please try again or select a different image generation model.`;
            usedProvider = 'error';
          }
          break;

        case 'code':
          const codeMessages: AIMessage[] = [
            {
              role: 'system',
              content: 'You are an expert software developer and coding assistant. Provide clear, well-commented, production-ready code solutions with explanations and best practices.'
            },
            {
              role: 'user',
              content: message
            }
          ];

          try {
            response = await callRealAI(codeMessages, model, searchType);
            usedProvider = 'Real AI';
          } catch (providerError) {
            console.error('Real AI failed for code:', providerError);
            response = `💻 **Code Generation**

I apologize, but I'm experiencing technical difficulties with code generation. However, I can still help you with: "${message}"

**What I can provide:**
• Basic code structure and syntax
• Programming concepts and explanations
• Debugging tips and best practices
• Algorithm explanations

**For better results, try:**
• Being more specific about the programming language
• Including specific requirements or constraints
• Breaking down complex requests into smaller parts
• Providing context about your project structure

**Technical Status:** The AI services are experiencing issues. Please try again in a moment for full code generation capabilities.`;
            usedProvider = 'partial';
          }
          break;

        case 'analysis':
          const analysisMessages: AIMessage[] = [
            {
              role: 'system',
              content: 'You are an expert data analyst and researcher. Provide thorough, evidence-based analysis with clear insights, trends, and actionable recommendations.'
            },
            {
              role: 'user',
              content: message
            }
          ];

          try {
            response = await callRealAI(analysisMessages, model, searchType);
            usedProvider = 'Real AI';
          } catch (providerError) {
            console.error('Real AI failed for analysis:', providerError);
            response = `📊 **Analysis Mode**

I apologize, but I'm experiencing technical difficulties with analysis services. However, I can still provide insights on: "${message}"

**What I can offer:**
• General analytical frameworks and approaches
• Basic data interpretation concepts
• Research methodology suggestions
• Statistical analysis fundamentals

**For better analysis results, consider:**
• Providing more specific data or context
• Specifying the type of analysis you need
• Including relevant metrics or parameters
• Being clear about your analysis goals

**Technical Status:** The AI services are experiencing issues. Please try again in a moment for full analysis capabilities.`;
            usedProvider = 'partial';
          }
          break;

        default: // 'chat'
          const chatMessages: AIMessage[] = [
            {
              role: 'system',
              content: 'You are a helpful, knowledgeable, and friendly AI assistant. Provide accurate, detailed, and useful responses while maintaining a conversational tone.'
            },
            {
              role: 'user',
              content: message
            }
          ];

          try {
            response = await callRealAI(chatMessages, model, searchType);
            usedProvider = 'Real AI';
          } catch (providerError) {
            console.error('Real AI failed for chat:', providerError);
            response = `💬 **Chat Mode**

I apologize, but I'm experiencing technical difficulties with chat services. However, I'm still here to help you with: "${message}"

**What I can provide:**
• General information and knowledge
• Basic explanations and concepts
• Guidance on various topics
• Conversational support

**This could be due to:**
• Temporary AI service connectivity issues
• High demand on AI services
• Service initialization in progress

**Technical Status:** The AI services are experiencing issues. Please try again in a moment for full chat capabilities.`;
            usedProvider = 'partial';
          }
          break;
      }

      const aiResponse: AIResponse = {
        success: true,
        response: response + (usedProvider !== 'fallback' ? `\n\n*Powered by ${usedProvider}*` : ''),
        searchResults: searchResults.length > 0 ? searchResults : undefined,
        imageData,
        imagePrompt,
        model: `${model} (${usedProvider})`
      };

      return createSuccessResponse(aiResponse.response, aiResponse);
      
    } catch (error: any) {
      console.error('AI API error:', error);
      
      // Always return JSON, never HTML
      return createErrorResponse(
        `AI service failed: ${error.message || 'Unknown error occurred'}`,
        500
      );
    }
  });
}