import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

// Enhanced interfaces for schema-based prompting
interface SchemaPromptingRequest {
  prompt: string
  databaseSchema: {
    tables: Array<{
      name: string
      columns: Array<{
        name: string
        type: string
        constraints?: string[]
        nullable?: boolean
        default?: string
        primary?: boolean
        foreign?: {
          table: string
          column: string
        }
      }>
      indexes?: Array<{
        name: string
        columns: string[]
        unique?: boolean
      }>
    }>
    relationships?: Array<{
      from: string
      to: string
      type: 'one-to-one' | 'one-to-many' | 'many-to-many'
      foreignKey: string
    }>
  }
  queryType: 'select' | 'insert' | 'update' | 'delete' | 'create-table' | 'alter-table' | 'join-query' | 'aggregate-query'
  complexity?: 'simple' | 'medium' | 'complex'
  databaseType?: 'postgresql' | 'mysql' | 'sqlite' | 'mongodb'
  context?: {
    securityLevel?: 'basic' | 'standard' | 'high'
    performanceOptimized?: boolean
    includeValidation?: boolean
    constraints?: string[]
  }
}

interface SchemaPromptingResponse {
  success: boolean
  sessionId: string
  queryAnalysis?: {
    intent: string
    tablesInvolved: string[]
    columnsAccessed: string[]
    joinsRequired?: Array<{
      table1: string
      table2: string
      type: string
      condition: string
    }>
    whereClauses?: string[]
    orderBy?: string[]
    groupBy?: string[]
    securityConsiderations?: string[]
  }
  generatedQuery?: {
    sql: string
    parameters?: Array<{
      name: string
      type: string
      description: string
    }>
    explanation: string
    alternatives?: Array<{
      query: string
      explanation: string
      performance: string
    }>
    validationRules?: string[]
    performanceNotes?: string[]
  }
  testCases?: Array<{
    description: string
    input: any
    expectedOutput: any
    query: string
  }>
  metadata?: {
    processingTime: number
    confidence: number
    suggestions: string[]
    complexityScore: number
  }
  error?: string
}

// Database-specific syntax and patterns
const DATABASE_PATTERNS = {
  postgresql: {
    dataTypes: {
      string: 'VARCHAR',
      number: 'NUMERIC',
      integer: 'INTEGER',
      boolean: 'BOOLEAN',
      date: 'DATE',
      timestamp: 'TIMESTAMP',
      json: 'JSONB',
      uuid: 'UUID'
    },
    functions: {
      concat: '||',
      length: 'LENGTH',
      upper: 'UPPER',
      lower: 'LOWER',
      now: 'NOW()',
      uuid: 'gen_random_uuid()'
    },
    indexing: 'CREATE INDEX CONCURRENTLY',
    constraints: 'CONSTRAINT',
    sequences: ['SERIAL', 'BIGSERIAL']
  },
  mysql: {
    dataTypes: {
      string: 'VARCHAR',
      number: 'DECIMAL',
      integer: 'INT',
      boolean: 'BOOLEAN',
      date: 'DATE',
      timestamp: 'TIMESTAMP',
      json: 'JSON',
      uuid: 'UUID'
    },
    functions: {
      concat: 'CONCAT',
      length: 'CHAR_LENGTH',
      upper: 'UPPER',
      lower: 'LOWER',
      now: 'NOW()',
      uuid: 'UUID()'
    },
    indexing: 'CREATE INDEX',
    constraints: 'CONSTRAINT',
    sequences: 'AUTO_INCREMENT'
  },
  sqlite: {
    dataTypes: {
      string: 'TEXT',
      number: 'REAL',
      integer: 'INTEGER',
      boolean: 'INTEGER',
      date: 'TEXT',
      timestamp: 'TEXT',
      json: 'TEXT',
      uuid: 'TEXT'
    },
    functions: {
      concat: '||',
      length: 'LENGTH',
      upper: 'UPPER',
      lower: 'LOWER',
      now: 'datetime("now")',
      uuid: 'lower(hex(randomblob(16)))'
    },
    indexing: 'CREATE INDEX',
    constraints: 'CONSTRAINT',
    sequences: 'AUTOINCREMENT'
  }
}

// Security patterns for SQL injection prevention
const SECURITY_PATTERNS = {
  inputValidation: [
    'Always use parameterized queries',
    'Validate input data types and formats',
    'Sanitize user inputs before processing',
    'Use prepared statements with placeholders'
  ],
  queryConstruction: [
    'Never concatenate user input directly into SQL',
    'Use query builders or ORMs when possible',
    'Implement allow-lists for column and table names',
    'Escape all dynamic identifiers properly'
  ],
  accessControl: [
    'Implement row-level security when needed',
    'Use views to limit data exposure',
    'Apply column-level permissions',
    'Audit query access patterns'
  ],
  errorHandling: [
    'Never expose raw database errors to users',
    'Log query errors for debugging',
    'Implement graceful error handling',
    'Use generic error messages for users'
  ]
}

// Query optimization patterns
const OPTIMIZATION_PATTERNS = {
  indexing: [
    'Create indexes on frequently queried columns',
    'Use composite indexes for multi-column queries',
    'Consider partial indexes for filtered queries',
    'Monitor index usage and remove unused ones'
  ],
  queryStructure: [
    'SELECT only necessary columns',
    'Use LIMIT for large result sets',
    'Avoid SELECT * in production queries',
    'Use appropriate JOIN types'
  ],
  performance: [
    'Use EXISTS instead of IN for subqueries',
    'Avoid correlated subqueries when possible',
    'Use UNION ALL instead of UNION for disjoint sets',
    'Consider materialized views for complex queries'
  ]
}

class SchemaBasedAIGenerator {
  private zai: any
  private sessionId: string

  constructor() {
    this.sessionId = `schema_session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  }

  async initialize() {
    try {
      this.zai = await ZAI.create()
      return true
    } catch (error) {
      console.error('Failed to initialize ZAI:', error)
      return false
    }
  }

  // Analyze the user's query intent and requirements
  async analyzeQueryIntent(prompt: string, schema: any, queryType: string, context: any): Promise<any> {
    const analysisPrompt = `You are an expert database administrator and SQL query optimizer.
    
    Analyze the following query request based on the provided database schema:
    
    User Request: "${prompt}"
    Query Type: ${queryType}
    Database Schema: ${JSON.stringify(schema, null, 2)}
    Context: ${JSON.stringify(context)}
    
    Provide a comprehensive analysis of the query requirements:
    
    1. Query Intent: What is the user trying to accomplish?
    2. Tables Involved: Which tables need to be accessed?
    3. Columns Required: Which columns are needed for the result?
    4. Relationships: What joins or relationships are involved?
    5. Filtering: What WHERE conditions are needed?
    6. Sorting: What ORDER BY requirements exist?
    7. Aggregation: Are any GROUP BY or aggregate functions needed?
    8. Security: What security considerations should be applied?
    9. Performance: What performance optimizations should be considered?
    
    Respond with JSON:
    {
      "intent": "Detailed description of query intent",
      "tablesInvolved": ["table1", "table2"],
      "columnsAccessed": ["column1", "column2"],
      "joinsRequired": [
        {
          "table1": "users",
          "table2": "profiles",
          "type": "left",
          "condition": "users.id = profiles.user_id"
        }
      ],
      "whereClauses": ["users.active = true", "profiles.age >= 18"],
      "orderBy": ["users.created_at DESC"],
      "groupBy": ["users.department"],
      "securityConsiderations": [
        "Parameterize all user inputs",
        "Validate date ranges",
        "Implement row-level security"
      ],
      "complexityScore": 0.7,
      "suggestedOptimizations": [
        "Add index on users.active",
        "Consider composite index on profiles.age and profiles.user_id"
      ]
    }`

    try {
      const response = await this.zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an expert database administrator specializing in SQL query optimization and database design.'
          },
          {
            role: 'user',
            content: analysisPrompt
          }
        ],
        temperature: 0.3,
        max_tokens: 2000
      })

      const analysisText = response.choices[0]?.message?.content || '{}'
      return JSON.parse(analysisText)
    } catch (error) {
      console.error('Query analysis failed:', error)
      throw new Error('Failed to analyze query intent')
    }
  }

  // Generate SQL query based on schema and analysis
  async generateQuery(prompt: string, schema: any, analysis: any, queryType: string, context: any): Promise<any> {
    const dbType = context.databaseType || 'postgresql'
    const patterns = DATABASE_PATTERNS[dbType as keyof typeof DATABASE_PATTERNS]
    
    const queryPrompt = `You are an expert SQL developer specializing in ${dbType.toUpperCase()}.
    
    Generate a ${dbType.toUpperCase()} SQL query based on the following requirements:
    
    User Request: "${prompt}"
    Query Type: ${queryType}
    Database Schema: ${JSON.stringify(schema, null, 2)}
    Query Analysis: ${JSON.stringify(analysis)}
    Database Type: ${dbType}
    
    Database-Specific Patterns:
    - Data Types: ${Object.entries(patterns.dataTypes).map(([k, v]) => `${k}: ${v}`).join(', ')}
    - Functions: ${Object.entries(patterns.functions).map(([k, v]) => `${k}: ${v}`).join(', ')}
    
    Security Requirements:
    ${SECURITY_PATTERNS.inputValidation.join('\n')}
    ${SECURITY_PATTERNS.queryConstruction.join('\n')}
    
    Performance Considerations:
    ${OPTIMIZATION_PATTERNS.queryStructure.join('\n')}
    
    Generate a comprehensive SQL query that includes:
    
    1. Primary SQL Query:
       - Well-formatted, syntactically correct SQL
       - Proper parameterized placeholders ($1, $2, etc.)
       - Appropriate JOINs and WHERE clauses
       - Proper error handling considerations
       
    2. Query Parameters:
       - List of all parameters with types and descriptions
       - Validation rules for each parameter
       
    3. Explanation:
       - Detailed explanation of the query logic
       - Why certain approaches were chosen
       - How the query satisfies the requirements
       
    4. Alternative Approaches:
       - Different ways to write the same query
       - Performance implications of each alternative
       
    5. Validation Rules:
       - Input validation requirements
       - Business logic validation
       
    6. Performance Notes:
       - Indexing recommendations
       - Query optimization suggestions
       - Potential bottlenecks
    
    Respond with JSON:
    {
      "sql": "SELECT u.id, u.name, p.email FROM users u LEFT JOIN profiles p ON u.id = p.user_id WHERE u.active = $1 AND p.age >= $2 ORDER BY u.created_at DESC",
      "parameters": [
        {
          "name": "active_status",
          "type": "boolean",
          "description": "User active status filter"
        },
        {
          "name": "min_age",
          "type": "integer",
          "description": "Minimum age filter"
        }
      ],
      "explanation": "This query retrieves active users with their profile information, filtered by age and sorted by creation date.",
      "alternatives": [
        {
          "query": "Alternative SQL query",
          "explanation": "This alternative uses a different join approach",
          "performance": "Slightly faster for large datasets"
        }
      ],
      "validationRules": [
        "active_status must be boolean",
        "min_age must be positive integer"
      ],
      "performanceNotes": [
        "Consider adding index on users(active, created_at)",
        "Composite index on profiles(user_id, age) could improve performance"
      ]
    }`

    try {
      const response = await this.zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: `You are an expert SQL developer specializing in ${dbType.toUpperCase()} with deep knowledge of database optimization and security.`
          },
          {
            role: 'user',
            content: queryPrompt
          }
        ],
        temperature: 0.2,
        max_tokens: 3000
      })

      const queryText = response.choices[0]?.message?.content || '{}'
      return JSON.parse(queryText)
    } catch (error) {
      console.error('Query generation failed:', error)
      throw new Error('Failed to generate SQL query')
    }
  }

  // Generate test cases for the query
  async generateTestCases(query: string, analysis: any, schema: any): Promise<any> {
    const testPrompt = `You are an expert QA engineer specializing in database testing.
    
    Generate comprehensive test cases for the following SQL query:
    
    SQL Query: ${query}
    Query Analysis: ${JSON.stringify(analysis)}
    Database Schema: ${JSON.stringify(schema)}
    
    Generate test cases that cover:
    1. Happy path scenarios
    2. Edge cases and boundary conditions
    3. Error conditions and invalid inputs
    4. Performance considerations
    5. Data validation scenarios
    
    For each test case, provide:
    - Description of what is being tested
    - Test input data
    - Expected output or behavior
    - The SQL query to execute
    
    Respond with JSON:
    {
      "testCases": [
        {
          "description": "Test retrieving active users with valid age filter",
          "input": {
            "active_status": true,
            "min_age": 18
          },
          "expectedOutput": {
            "rowCount": "greater than 0",
            "columns": ["id", "name", "email"]
          },
          "query": "SELECT u.id, u.name, p.email FROM users u LEFT JOIN profiles p ON u.id = p.user_id WHERE u.active = true AND p.age >= 18"
        }
      ]
    }`

    try {
      const response = await this.zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an expert QA engineer specializing in database testing and test case generation.'
          },
          {
            role: 'user',
            content: testPrompt
          }
        ],
        temperature: 0.3,
        max_tokens: 2000
      })

      const testText = response.choices[0]?.message?.content || '{}'
      return JSON.parse(testText)
    } catch (error) {
      console.error('Test case generation failed:', error)
      return { testCases: [] }
    }
  }

  // Main schema-based generation orchestration
  async generateWithSchema(prompt: string, schema: any, queryType: string, context: any): Promise<SchemaPromptingResponse> {
    const startTime = Date.now()

    try {
      // Initialize AI
      if (!(await this.initialize())) {
        throw new Error('Failed to initialize AI service')
      }

      // Step 1: Analyze query intent
      const queryAnalysis = await this.analyzeQueryIntent(prompt, schema, queryType, context)

      // Step 2: Generate SQL query
      const generatedQuery = await this.generateQuery(prompt, schema, queryAnalysis, queryType, context)

      // Step 3: Generate test cases
      const testCases = await this.generateTestCases(generatedQuery.sql, queryAnalysis, schema)

      const processingTime = Date.now() - startTime

      return {
        success: true,
        sessionId: this.sessionId,
        queryAnalysis: {
          intent: queryAnalysis.intent,
          tablesInvolved: queryAnalysis.tablesInvolved,
          columnsAccessed: queryAnalysis.columnsAccessed,
          joinsRequired: queryAnalysis.joinsRequired,
          whereClauses: queryAnalysis.whereClauses,
          orderBy: queryAnalysis.orderBy,
          groupBy: queryAnalysis.groupBy,
          securityConsiderations: queryAnalysis.securityConsiderations
        },
        generatedQuery: generatedQuery,
        testCases: testCases.testCases,
        metadata: {
          processingTime: processingTime,
          confidence: 0.9,
          suggestions: [
            'Review the generated query for your specific requirements',
            'Test the query with realistic data volumes',
            'Consider implementing the suggested indexes',
            'Validate all input parameters thoroughly',
            'Monitor query performance in production'
          ],
          complexityScore: queryAnalysis.complexityScore || 0.5
        }
      }

    } catch (error) {
      return {
        success: false,
        sessionId: this.sessionId,
        error: error instanceof Error ? error.message : 'Unknown error occurred during generation'
      }
    }
  }
}

export async function POST(request: NextRequest) {
  try {
    const body: SchemaPromptingRequest = await request.json()
    const { prompt, databaseSchema, queryType, complexity, databaseType, context } = body

    if (!prompt || !databaseSchema || !queryType) {
      return NextResponse.json(
        { error: 'Prompt, database schema, and query type are required' },
        { status: 400 }
      )
    }

    // Validate database schema structure
    if (!databaseSchema.tables || !Array.isArray(databaseSchema.tables)) {
      return NextResponse.json(
        { error: 'Database schema must contain a tables array' },
        { status: 400 }
      )
    }

    const generator = new SchemaBasedAIGenerator()
    const result = await generator.generateWithSchema(prompt, databaseSchema, queryType, {
      complexity,
      databaseType,
      ...context
    })

    return NextResponse.json(result)
  } catch (error) {
    console.error('Schema-based generation error:', error)
    return NextResponse.json(
      { 
        error: 'Internal server error',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}

export async function GET() {
  return NextResponse.json({
    supportedQueryTypes: ['select', 'insert', 'update', 'delete', 'create-table', 'alter-table', 'join-query', 'aggregate-query'],
    supportedDatabases: Object.keys(DATABASE_PATTERNS),
    complexityLevels: ['simple', 'medium', 'complex'],
    securityLevels: ['basic', 'standard', 'high'],
    features: {
      queryAnalysis: 'Analyzes query intent and requirements',
      parameterizedQueries: 'Generates secure parameterized queries',
      testCases: 'Provides comprehensive test cases',
      optimization: 'Includes performance optimization suggestions',
      validation: 'Input validation and security rules'
    }
  })
}