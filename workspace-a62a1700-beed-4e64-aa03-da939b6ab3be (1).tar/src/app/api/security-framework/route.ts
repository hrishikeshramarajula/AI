import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

// Enhanced interfaces for security framework
interface SecurityFrameworkRequest {
  prompt: string
  code?: string
  type: 'webpage' | 'component' | 'backend' | 'database' | 'api' | 'full-stack'
  securityLevel: 'basic' | 'standard' | 'high' | 'enterprise'
  compliance?: 'gdpr' | 'hipaa' | 'pci-dss' | 'soc2' | 'none'
  context?: {
    industry?: string
    userRole?: 'public' | 'user' | 'admin' | 'system'
    dataType?: 'public' | 'sensitive' | 'confidential' | 'restricted'
    authentication?: 'none' | 'basic' | 'oauth' | 'jwt' | 'mfa'
  }
}

interface SecurityVulnerability {
  type: string
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info'
  description: string
  location?: string
  remediation: string
  cwe?: string
  owaspCategory?: string
}

interface SecurityValidation {
  isValid: boolean
  score: number
  vulnerabilities: SecurityVulnerability[]
  recommendations: string[]
  complianceStatus: {
    [key: string]: boolean
  }
}

interface SecurityGuidelines {
  inputValidation: string[]
  outputEncoding: string[]
  authentication: string[]
  authorization: string[]
  dataProtection: string[]
  errorHandling: string[]
  logging: string[]
}

interface SecurityFrameworkResponse {
  success: boolean
  sessionId: string
  securityAnalysis?: {
    riskLevel: 'low' | 'medium' | 'high' | 'critical'
    threatModel: string[]
    attackSurface: string[]
    dataClassification: string
  }
  securityGuidelines?: SecurityGuidelines
  secureCode?: {
    code: string
    explanation: string
    securityMeasures: string[]
    validationRules: string[]
  }
  securityValidation?: SecurityValidation
  complianceReport?: {
    framework: string
    status: 'compliant' | 'partial' | 'non-compliant'
    gaps: string[]
    recommendations: string[]
  }
  metadata?: {
    processingTime: number
    securityScore: number
    vulnerabilitiesFound: number
    recommendations: string[]
  }
  error?: string
}

// OWASP Top 10 Vulnerability Patterns
const OWASP_PATTERNS = {
  'A01:2021-Broken Access Control': {
    description: 'Access control is only effective if enforced in trusted server-side code',
    patterns: [
      'Missing authentication checks',
      'Hardcoded admin credentials',
      'Insecure direct object references',
      'Missing authorization on API endpoints'
    ],
    remediation: [
      'Implement proper authentication and authorization',
      'Use role-based access control (RBAC)',
      'Validate user permissions for every request',
      'Use secure session management'
    ]
  },
  'A02:2021-Cryptographic Failures': {
    description: 'Failures related to cryptography often result in sensitive data exposure',
    patterns: [
      'Weak password hashing',
      'Hardcoded secrets or keys',
      'Insufficient encryption',
      'Outdated cryptographic algorithms'
    ],
    remediation: [
      'Use strong, modern cryptographic algorithms',
      'Implement proper password hashing (bcrypt, Argon2)',
      'Never hardcode secrets or keys',
      'Use proper key management'
    ]
  },
  'A03:2021-Injection': {
    description: 'Injection flaws allow attackers to execute malicious code',
    patterns: [
      'SQL injection vulnerabilities',
      'Command injection',
      'LDAP injection',
      'NoSQL injection'
    ],
    remediation: [
      'Use parameterized queries or prepared statements',
      'Implement input validation and sanitization',
      'Use ORM frameworks',
      'Apply least privilege principle'
    ]
  },
  'A04:2021-Insecure Design': {
    description: 'Security is not considered during the design phase',
    patterns: [
      'Missing security requirements',
      'Insecure architecture decisions',
      'Lack of threat modeling',
      'Missing security controls'
    ],
    remediation: [
      'Conduct threat modeling',
      'Design security controls from the beginning',
      'Implement defense in depth',
      'Use secure design patterns'
    ]
  },
  'A05:2021-Security Misconfiguration': {
    description: 'Improper security configurations can lead to vulnerabilities',
    patterns: [
      'Default credentials',
      'Verbose error messages',
      'Unnecessary services enabled',
      'Missing security headers'
    ],
    remediation: [
      'Remove default credentials',
      'Implement proper error handling',
      'Disable unnecessary services',
      'Configure security headers'
    ]
  },
  'A06:2021-Vulnerable and Outdated Components': {
    description: 'Using vulnerable components can compromise security',
    patterns: [
      'Outdated dependencies',
      'Known vulnerabilities in components',
      'Lack of dependency management',
      'Using unsupported software'
    ],
    remediation: [
      'Regularly update dependencies',
      'Use dependency scanning tools',
      'Monitor vulnerability databases',
      'Have a patch management process'
    ]
  },
  'A07:2021-Identification and Authentication Failures': {
    description: 'Weak authentication and session management',
    patterns: [
      'Weak password policies',
      'Session fixation',
      'Missing multi-factor authentication',
      'Insecure password recovery'
    ],
    remediation: [
      'Implement strong password policies',
      'Use secure session management',
      'Implement multi-factor authentication',
      'Secure password recovery processes'
    ]
  },
  'A08:2021-Software and Data Integrity Failures': {
    description: 'Failures in protecting software and data integrity',
    patterns: [
      'Missing data validation',
      'Insecure file uploads',
      'Missing integrity checks',
      'Insecure deserialization'
    ],
    remediation: [
      'Implement comprehensive input validation',
      'Secure file upload processes',
      'Use digital signatures',
      'Validate data integrity'
    ]
  },
  'A09:2021-Security Logging and Monitoring Failures': {
    description: 'Insufficient logging and monitoring',
    patterns: [
      'Missing security logging',
      'No monitoring for attacks',
      'Insufficient audit trails',
      'Missing alerting'
    ],
    remediation: [
      'Implement comprehensive security logging',
      'Set up security monitoring',
      'Maintain audit trails',
      'Configure security alerts'
    ]
  },
  'A10:2021-Server-Side Request Forgery (SSRF)': {
    description: 'Server-side request forgery vulnerabilities',
    patterns: [
      'Unrestricted URL fetching',
      'SSRF in file uploads',
      'SSRF in webhooks',
      'SSRF in API calls'
    ],
    remediation: [
      'Validate and sanitize URLs',
      'Implement allow-lists for external requests',
      'Use secure HTTP libraries',
      'Monitor for SSRF attempts'
    ]
  }
}

// Security Guidelines by Security Level
const SECURITY_GUIDELINES = {
  basic: {
    inputValidation: [
      'Validate all user inputs',
      'Use basic type checking',
      'Sanitize HTML inputs',
      'Validate file types'
    ],
    outputEncoding: [
      'Encode HTML output',
      'Encode URL parameters',
      'Basic XSS prevention',
      'Encode JSON output'
    ],
    authentication: [
      'Basic password requirements',
      'Session management',
      'Basic login forms',
      'Password hashing'
    ],
    authorization: [
      'Basic role checks',
      'Simple permissions',
      'Resource ownership',
      'Basic access control'
    ],
    dataProtection: [
      'Basic data encryption',
      'Secure password storage',
      'Basic backup procedures',
      'Data access logging'
    ],
    errorHandling: [
      'Basic error messages',
      'Generic error pages',
      'Basic logging',
      'Exception handling'
    ],
    logging: [
      'Basic access logs',
      'Error logging',
      'User activity logs',
      'Security event logging'
    ]
  },
  standard: {
    inputValidation: [
      'Comprehensive input validation',
      'Schema validation',
      'File type and size validation',
      'Input sanitization',
      'Parameterized queries'
    ],
    outputEncoding: [
      'Context-aware output encoding',
      'Content Security Policy',
      'X-XSS-Protection header',
      'X-Content-Type-Options header'
    ],
    authentication: [
      'Strong password policies',
      'JWT implementation',
      'OAuth 2.0 integration',
      'Session timeout management'
    ],
    authorization: [
      'Role-based access control',
      'Attribute-based access control',
      'Permission inheritance',
      'Audit trails'
    ],
    dataProtection: [
      'AES-256 encryption',
      'TLS 1.3 implementation',
      'Data masking',
      'Secure key management'
    ],
    errorHandling: [
      'Secure error handling',
      'Custom error pages',
      'Detailed logging',
      'Error rate limiting'
    ],
    logging: [
      'Comprehensive audit logging',
      'Security event monitoring',
      'Real-time alerting',
      'Log aggregation'
    ]
  },
  high: {
    inputValidation: [
      'Advanced input validation',
      'Machine learning-based validation',
      'Behavioral analysis',
      'Real-time threat detection',
      'Advanced sanitization'
    ],
    outputEncoding: [
      'Advanced output encoding',
      'Strict CSP policies',
      'Security headers optimization',
      'Subresource integrity'
    ],
    authentication: [
      'Multi-factor authentication',
      'Biometric authentication',
      'Adaptive authentication',
      'Hardware security keys'
    ],
    authorization: [
      'Dynamic access control',
      'Context-aware authorization',
      'Real-time permission validation',
      'Advanced audit trails'
    ],
    dataProtection: [
      'End-to-end encryption',
      'Homomorphic encryption',
      'Advanced key rotation',
      'Data loss prevention'
    ],
    errorHandling: [
      'Advanced error handling',
      'Distributed tracing',
      'Circuit breakers',
      'Graceful degradation'
    ],
    logging: [
      'Advanced security monitoring',
      'SIEM integration',
      'Machine learning-based anomaly detection',
      'Forensic logging'
    ]
  },
  enterprise: {
    inputValidation: [
      'Enterprise-grade input validation',
      'Zero-trust validation',
      'Advanced threat intelligence',
      'Real-time behavioral analysis',
      'Comprehensive sanitization'
    ],
    outputEncoding: [
      'Enterprise output encoding',
      'Advanced CSP with nonce',
      'Security headers optimization',
      'Advanced integrity checks'
    ],
    authentication: [
      'Enterprise authentication',
      'Federated identity',
      'Advanced MFA',
      'Zero-trust authentication'
    ],
    authorization: [
      'Enterprise access control',
      'Zero-trust authorization',
      'Advanced policy enforcement',
      'Comprehensive audit trails'
    ],
    dataProtection: [
      'Enterprise data protection',
      'Advanced encryption',
      'Zero-knowledge proofs',
      'Enterprise DLP'
    ],
    errorHandling: [
      'Enterprise error handling',
      'Advanced resilience',
      'Enterprise monitoring',
      'Advanced recovery'
    ],
    logging: [
      'Enterprise logging',
      'Advanced SIEM',
      'Threat hunting',
      'Compliance reporting'
    ]
  }
}

// Compliance Frameworks
const COMPLIANCE_FRAMEWORKS = {
  gdpr: {
    name: 'GDPR',
    requirements: [
      'Data minimization',
      'User consent management',
      'Right to be forgotten',
      'Data portability',
      'Breach notification',
      'Privacy by design'
    ],
    validationRules: [
      'Implement data minimization principles',
      'Obtain explicit user consent',
      'Provide data access and deletion capabilities',
      'Implement data protection measures',
      'Report breaches within 72 hours'
    ]
  },
  hipaa: {
    name: 'HIPAA',
    requirements: [
      'PHI protection',
      'Access controls',
      'Audit trails',
      'Encryption',
      'Business associate agreements'
    ],
    validationRules: [
      'Protect protected health information',
      'Implement strict access controls',
      'Maintain comprehensive audit trails',
      'Encrypt PHI at rest and in transit',
      'Ensure BAA compliance'
    ]
  },
  'pci-dss': {
    name: 'PCI-DSS',
    requirements: [
      'Protect cardholder data',
      'Maintain vulnerability management',
      'Implement access controls',
      'Monitor networks',
      'Information security policy'
    ],
    validationRules: [
      'Never store full cardholder data',
      'Regular vulnerability scanning',
      'Strict access controls',
      'Network monitoring',
      'Comprehensive security policy'
    ]
  },
  soc2: {
    name: 'SOC 2',
    requirements: [
      'Security',
      'Availability',
      'Processing integrity',
      'Confidentiality',
      'Privacy'
    ],
    validationRules: [
      'Implement security controls',
      'Ensure high availability',
      'Maintain data integrity',
      'Protect confidential data',
      'Respect privacy requirements'
    ]
  }
}

class SecurityAIFramework {
  private zai: any
  private sessionId: string

  constructor() {
    this.sessionId = `security_session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  }

  async initialize() {
    try {
      this.zai = await ZAI.create()
      return true
    } catch (error) {
      console.error('Failed to initialize ZAI:', error)
      return false
    }
  }

  // Analyze security requirements and threat model
  async analyzeSecurityRequirements(prompt: string, type: string, securityLevel: string, context: any): Promise<any> {
    const analysisPrompt = `You are an expert security architect and penetration tester.
    
    Analyze the security requirements for the following application:
    
    User Request: "${prompt}"
    Application Type: ${type}
    Security Level: ${securityLevel}
    Context: ${JSON.stringify(context)}
    
    Provide a comprehensive security analysis:
    
    1. Risk Assessment:
       - Overall risk level (low, medium, high, critical)
       - Primary security threats
       - Attack surface analysis
       - Data classification requirements
       
    2. Threat Modeling:
       - Potential attack vectors
       - Threat actors and capabilities
       - Impact assessment
       - Likelihood assessment
       
    3. Security Requirements:
       - Authentication requirements
       - Authorization requirements
       - Data protection requirements
       - Logging and monitoring requirements
       
    4. OWASP Top 10 Considerations:
       - Which OWASP vulnerabilities are most relevant
       - Specific mitigations needed
       - Priority areas for security focus
    
    Respond with JSON:
    {
      "riskLevel": "high",
      "threatModel": [
        "SQL injection attacks",
        "Cross-site scripting (XSS)",
        "Authentication bypass",
        "Data breaches"
      ],
      "attackSurface": [
        "User input forms",
        "API endpoints",
        "Database queries",
        "File upload functionality"
      ],
      "dataClassification": "sensitive",
      "primaryThreats": [
        {
          "threat": "SQL Injection",
          "likelihood": "high",
          "impact": "critical",
          "mitigation": "Use parameterized queries"
        }
      ]
    }`

    try {
      const response = await this.zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an expert security architect specializing in threat modeling and risk assessment.'
          },
          {
            role: 'user',
            content: analysisPrompt
          }
        ],
        temperature: 0.3,
        max_tokens: 2000
      })

      const analysisText = response.choices[0]?.message?.content || '{}'
      return JSON.parse(analysisText)
    } catch (error) {
      console.error('Security analysis failed:', error)
      throw new Error('Failed to analyze security requirements')
    }
  }

  // Generate security guidelines
  async generateSecurityGuidelines(securityLevel: string, context: any): Promise<SecurityGuidelines> {
    const guidelines = SECURITY_GUIDELINES[securityLevel as keyof typeof SECURITY_GUIDELINES]
    
    // Enhance guidelines based on context
    const enhancedGuidelines = { ...guidelines }
    
    if (context.industry === 'healthcare') {
      enhancedGuidelines.dataProtection.push('HIPAA compliance measures')
      enhancedGuidelines.logging.push('PHI access logging')
    }
    
    if (context.dataType === 'confidential') {
      enhancedGuidelines.dataProtection.push('End-to-end encryption')
      enhancedGuidelines.authorization.push('Strict access controls')
    }
    
    return enhancedGuidelines
  }

  // Generate secure code with security measures
  async generateSecureCode(prompt: string, type: string, securityAnalysis: any, guidelines: SecurityGuidelines): Promise<any> {
    const codePrompt = `You are an expert secure software developer specializing in ${type} development.
    
    Generate secure code based on the following requirements:
    
    User Request: "${prompt}"
    Application Type: ${type}
    Security Analysis: ${JSON.stringify(securityAnalysis)}
    Security Guidelines: ${JSON.stringify(guidelines)}
    
    Generate secure code that includes:
    
    1. Secure Implementation:
       - Code that follows security best practices
       - Proper input validation and sanitization
       - Secure error handling
       - Authentication and authorization checks
       
    2. Security Measures:
       - Specific security controls implemented
       - OWASP mitigations applied
       - Security-focused code comments
       - Defense in depth measures
       
    3. Validation Rules:
       - Input validation rules
       - Business logic validation
       - Security validation checks
       
    4. Security Explanation:
       - Why certain security measures were chosen
       - How the code addresses specific threats
       - Security trade-offs considered
    
    Respond with JSON:
    {
      "code": "Secure implementation code with comments",
      "explanation": "Detailed explanation of security measures",
      "securityMeasures": [
        "Input validation implemented",
        "Parameterized queries used",
        "Authentication checks added"
      ],
      "validationRules": [
        "All inputs validated and sanitized",
        "Authentication required for sensitive operations"
      ]
    }`

    try {
      const response = await this.zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an expert secure software developer who writes production-ready, secure code following OWASP best practices.'
          },
          {
            role: 'user',
            content: codePrompt
          }
        ],
        temperature: 0.2,
        max_tokens: 4000
      })

      const codeText = response.choices[0]?.message?.content || '{}'
      return JSON.parse(codeText)
    } catch (error) {
      console.error('Secure code generation failed:', error)
      throw new Error('Failed to generate secure code')
    }
  }

  // Validate code for security vulnerabilities
  async validateSecurity(code: string, type: string, securityLevel: string): Promise<SecurityValidation> {
    const validationPrompt = `You are an expert security analyst and penetration tester.
    
    Analyze the following code for security vulnerabilities:
    
    Code: ${code}
    Application Type: ${type}
    Security Level: ${securityLevel}
    
    Perform comprehensive security validation:
    
    1. Vulnerability Detection:
       - Identify OWASP Top 10 vulnerabilities
       - Check for common security anti-patterns
       - Analyze potential security flaws
       
    2. Risk Assessment:
       - Severity scoring for each vulnerability
       - Likelihood and impact assessment
       - Overall security score calculation
       
    3. Compliance Validation:
       - Check against security requirements
       - Validate security best practices
       - Assess compliance level
       
    4. Recommendations:
       - Specific remediation steps
       - Security improvement suggestions
       - Priority recommendations
    
    Respond with JSON:
    {
      "isValid": false,
      "score": 0.7,
      "vulnerabilities": [
        {
          "type": "SQL Injection",
          "severity": "high",
          "description": "Potential SQL injection vulnerability",
          "location": "Line 15",
          "remediation": "Use parameterized queries",
          "cwe": "CWE-89",
          "owaspCategory": "A03:2021-Injection"
        }
      ],
      "recommendations": [
        "Implement input validation",
        "Use parameterized queries",
        "Add authentication checks"
      ],
      "complianceStatus": {
        "owaspTop10": false,
        "secureCoding": false
      }
    }`

    try {
      const response = await this.zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an expert security analyst specializing in vulnerability assessment and penetration testing.'
          },
          {
            role: 'user',
            content: validationPrompt
          }
        ],
        temperature: 0.3,
        max_tokens: 3000
      })

      const validationText = response.choices[0]?.message?.content || '{}'
      return JSON.parse(validationText)
    } catch (error) {
      console.error('Security validation failed:', error)
      return {
        isValid: false,
        score: 0.5,
        vulnerabilities: [],
        recommendations: ['Manual security review required'],
        complianceStatus: {}
      }
    }
  }

  // Generate compliance report
  async generateComplianceReport(compliance: string, validation: SecurityValidation): Promise<any> {
    if (!compliance || compliance === 'none') {
      return null
    }

    const framework = COMPLIANCE_FRAMEWORKS[compliance as keyof typeof COMPLIANCE_FRAMEWORKS]
    
    const compliancePrompt = `You are a compliance expert specializing in ${framework.name}.
    
    Generate a compliance report based on the security validation:
    
    Framework: ${framework.name}
    Requirements: ${JSON.stringify(framework.requirements)}
    Security Validation: ${JSON.stringify(validation)}
    
    Provide compliance assessment:
    
    1. Compliance Status:
       - Overall compliance level
       - Gaps analysis
       - Specific requirements met/not met
       
    2. Gap Analysis:
       - Specific compliance gaps
       - Severity of each gap
       - Impact on compliance
       
    3. Recommendations:
       - Specific steps to achieve compliance
       - Priority recommendations
       - Implementation guidance
    
    Respond with JSON:
    {
      "framework": "${framework.name}",
      "status": "partial",
      "gaps": [
        "Missing data encryption",
        "Insufficient audit trails"
      ],
      "recommendations": [
        "Implement encryption for sensitive data",
        "Enhance audit logging capabilities"
      ]
    }`

    try {
      const response = await this.zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: `You are a compliance expert specializing in ${framework.name} requirements and assessments.`
          },
          {
            role: 'user',
            content: compliancePrompt
          }
        ],
        temperature: 0.3,
        max_tokens: 2000
      })

      const complianceText = response.choices[0]?.message?.content || '{}'
      return JSON.parse(complianceText)
    } catch (error) {
      console.error('Compliance report generation failed:', error)
      return {
        framework: framework.name,
        status: 'non-compliant',
        gaps: ['Unable to assess compliance'],
        recommendations: ['Manual compliance review required']
      }
    }
  }

  // Main security framework orchestration
  async applySecurityFramework(prompt: string, type: string, securityLevel: string, compliance: string, context: any): Promise<SecurityFrameworkResponse> {
    const startTime = Date.now()

    try {
      // Initialize AI
      if (!(await this.initialize())) {
        throw new Error('Failed to initialize AI service')
      }

      // Step 1: Analyze security requirements
      const securityAnalysis = await this.analyzeSecurityRequirements(prompt, type, securityLevel, context)

      // Step 2: Generate security guidelines
      const securityGuidelines = await this.generateSecurityGuidelines(securityLevel, context)

      // Step 3: Generate secure code
      const secureCode = await this.generateSecureCode(prompt, type, securityAnalysis, securityGuidelines)

      // Step 4: Validate security
      const securityValidation = await this.validateSecurity(secureCode.code, type, securityLevel)

      // Step 5: Generate compliance report
      const complianceReport = await this.generateComplianceReport(compliance, securityValidation)

      const processingTime = Date.now() - startTime

      return {
        success: true,
        sessionId: this.sessionId,
        securityAnalysis: {
          riskLevel: securityAnalysis.riskLevel,
          threatModel: securityAnalysis.threatModel,
          attackSurface: securityAnalysis.attackSurface,
          dataClassification: securityAnalysis.dataClassification
        },
        securityGuidelines: securityGuidelines,
        secureCode: secureCode,
        securityValidation: securityValidation,
        complianceReport: complianceReport,
        metadata: {
          processingTime: processingTime,
          securityScore: securityValidation.score,
          vulnerabilitiesFound: securityValidation.vulnerabilities.length,
          recommendations: [
            'Review and address identified vulnerabilities',
            'Implement recommended security measures',
            'Conduct regular security assessments',
            'Stay updated on security best practices',
            'Consider security testing in CI/CD pipeline'
          ]
        }
      }

    } catch (error) {
      return {
        success: false,
        sessionId: this.sessionId,
        error: error instanceof Error ? error.message : 'Unknown error occurred during security analysis'
      }
    }
  }
}

export async function POST(request: NextRequest) {
  try {
    const body: SecurityFrameworkRequest = await request.json()
    const { prompt, code, type, securityLevel, compliance, context } = body

    if (!prompt || !type || !securityLevel) {
      return NextResponse.json(
        { error: 'Prompt, type, and security level are required' },
        { status: 400 }
      )
    }

    const generator = new SecurityAIFramework()
    const result = await generator.applySecurityFramework(prompt, type, securityLevel, compliance || 'none', {
      ...context
    })

    return NextResponse.json(result)
  } catch (error) {
    console.error('Security framework error:', error)
    return NextResponse.json(
      { 
        error: 'Internal server error',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}

export async function GET() {
  return NextResponse.json({
    supportedTypes: ['webpage', 'component', 'backend', 'database', 'api', 'full-stack'],
    securityLevels: Object.keys(SECURITY_GUIDELINES),
    complianceFrameworks: Object.keys(COMPLIANCE_FRAMEWORKS),
    owaspCategories: Object.keys(OWASP_PATTERNS),
    features: {
      threatModeling: 'Comprehensive threat modeling and risk assessment',
      secureCodeGeneration: 'Security-focused code generation with best practices',
      vulnerabilityScanning: 'Automated vulnerability detection and scoring',
      complianceValidation: 'Compliance checking against major frameworks',
      securityGuidelines: 'Context-aware security guidelines and recommendations'
    }
  })
}