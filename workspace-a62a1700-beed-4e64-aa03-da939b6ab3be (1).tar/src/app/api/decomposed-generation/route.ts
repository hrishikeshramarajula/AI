import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

// Enhanced interfaces for decomposed generation
interface DecomposedRequest {
  prompt: string
  type: 'full-stack-application' | 'webpage-with-backend' | 'dynamic-webapp'
  requirements?: {
    database?: boolean
    authentication?: boolean
    realtime?: boolean
    payment?: boolean
    api?: boolean
  }
  context?: string
  industry?: string
  targetAudience?: string
  brandPersonality?: string
}

interface GenerationStep {
  step: 'analysis' | 'database-schema' | 'backend-api' | 'frontend' | 'integration'
  status: 'pending' | 'in-progress' | 'completed' | 'error'
  output?: any
  error?: string
  timestamp: Date
}

interface DecomposedResponse {
  success: boolean
  sessionId: string
  steps: GenerationStep[]
  finalOutput?: {
    database?: {
      schema: string
      migrations: string[]
    }
    backend?: {
      api: string[]
      routes: string[]
      middleware: string[]
    }
    frontend?: {
      components: string[]
      pages: string[]
      styles: string[]
    }
    integration?: {
      configuration: string
      deployment: string
    }
  }
  explanation?: string
  error?: string
}

// Advanced Security Patterns for Generated Code
const SECURITY_PATTERNS = {
  authentication: {
    jwt: 'Use JSON Web Tokens with proper expiration and refresh token rotation',
    bcrypt: 'Always use bcrypt for password hashing with appropriate work factor',
    session: 'Implement secure session management with HTTP-only cookies'
  },
  validation: {
    input: 'Validate all user inputs using schema validation (Zod/Joi)',
    output: 'Sanitize all output data to prevent XSS attacks',
    sql: 'Use parameterized queries or ORM to prevent SQL injection'
  },
  headers: {
    csp: 'Implement Content Security Policy headers',
    cors: 'Configure CORS properly for your domain',
    security: 'Use security headers like X-Frame-Options, X-Content-Type-Options'
  },
  api: {
    rate: 'Implement rate limiting for API endpoints',
    auth: 'Use proper authentication middleware for protected routes',
    error: 'Handle errors gracefully without exposing sensitive information'
  }
}

// Role-Based Prompting Templates
const ROLE_PROMPTS = {
  databaseArchitect: `You are a Senior Database Architect with 15+ years of experience.
  Your expertise is in designing scalable, secure, and performant database schemas.
  Always follow normalization principles, consider indexing strategies, and design for future scalability.
  Focus on data integrity, security, and optimal query performance.`,
  
  backendEngineer: `You are a Senior Backend Engineer specializing in API design and microservices.
  Your expertise is in building secure, scalable, and maintainable backend systems.
  Always follow RESTful principles, implement proper error handling, and consider security best practices.
  Focus on clean code architecture, proper separation of concerns, and comprehensive testing.`,
  
  frontendArchitect: `You are a Senior Frontend Architect with expertise in modern React applications.
  Your expertise is in building responsive, accessible, and performant user interfaces.
  Always follow component-driven development, consider accessibility standards, and optimize for user experience.
  Focus on clean component architecture, proper state management, and cross-browser compatibility.`,
  
  securityExpert: `You are a Security Expert specializing in web application security.
  Your expertise is in identifying and mitigating security vulnerabilities in web applications.
  Always follow OWASP Top 10 guidelines, implement defense-in-depth, and consider security at every layer.
  Focus on secure coding practices, proper authentication/authorization, and data protection.`
}

// Few-Shot Examples for Consistency
const FEW_SHOT_EXAMPLES = {
  databaseSchema: `Example: User Management System
  Tables:
  - users (id, email, password_hash, created_at, updated_at)
  - profiles (user_id, first_name, last_name, avatar_url, bio)
  - sessions (id, user_id, token, expires_at, created_at)
  
  Relationships:
  - users has_one profiles
  - users has_many sessions
  
  Indexes:
  - users.email (unique)
  - sessions.token (unique)
  - sessions.user_id
  - profiles.user_id (unique)`,

  backendApi: `Example: User Authentication API
  POST /api/auth/register
  - Request: { email, password, firstName, lastName }
  - Response: { user: { id, email, profile }, token }
  - Validation: Email format, password strength, required fields
  
  POST /api/auth/login
  - Request: { email, password }
  - Response: { user, token }
  - Security: Rate limiting, secure password comparison
  
  GET /api/users/profile
  - Authentication: Required (JWT)
  - Response: { profile }
  - Authorization: User can only access own profile`,

  frontendComponent: `Example: User Profile Component
  import { useState, useEffect } from 'react'
  import { useAuth } from '@/hooks/useAuth'
  
  const UserProfile = () => {
    const { user } = useAuth()
    const [profile, setProfile] = useState(null)
    const [loading, setLoading] = useState(true)
    
    useEffect(() => {
      const fetchProfile = async () => {
        try {
          const response = await fetch('/api/users/profile')
          const data = await response.json()
          setProfile(data)
        } catch (error) {
          console.error('Failed to fetch profile:', error)
        } finally {
          setLoading(false)
        }
      }
      
      if (user) fetchProfile()
    }, [user])
    
    if (loading) return <div>Loading...</div>
    if (!profile) return <div>Profile not found</div>
    
    return (
      <div className="profile-container">
        <img src={profile.avatar_url} alt={profile.first_name} />
        <h1>{profile.first_name} {profile.last_name}</h1>
        <p>{profile.bio}</p>
      </div>
    )
  }`
}

class DecomposedAIGenerator {
  private zai: any
  private sessionId: string

  constructor() {
    this.sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  }

  async initialize() {
    try {
      this.zai = await ZAI.create()
      return true
    } catch (error) {
      console.error('Failed to initialize ZAI:', error)
      return false
    }
  }

  // Step 1: Comprehensive Analysis
  async analyzeRequirements(prompt: string, requirements: any): Promise<any> {
    const analysisPrompt = `${ROLE_PROMPTS.databaseArchitect}
    
    You are conducting a comprehensive analysis for a full-stack application generation.
    
    User Request: "${prompt}"
    Requirements: ${JSON.stringify(requirements)}
    
    Perform a detailed analysis and respond with JSON:
    {
      "applicationType": "webapp|api|mobile|desktop",
      "complexity": "simple|medium|complex",
      "databaseNeeds": {
        "required": true,
        "type": "relational|document|key-value",
        "estimatedTables": 5,
        "relationships": ["one-to-many", "many-to-many"],
        "scalability": "small|medium|large"
      },
      "apiNeeds": {
        "required": true,
        "endpoints": ["auth", "crud", "file-upload"],
        "authentication": "jwt|session|oauth",
        "realtime": false,
        "webhooks": false
      },
      "frontendNeeds": {
        "framework": "react|vue|angular",
        "styling": "css|scss|tailwind",
        "components": ["auth", "dashboard", "forms"],
        "responsive": true,
        "accessibility": true
      },
      "securityRequirements": {
        "authentication": true,
        "authorization": true,
        "dataEncryption": true,
        "inputValidation": true,
        "rateLimiting": true
      },
      "integrationPoints": ["database", "api", "auth", "storage"],
      "estimatedDevelopmentTime": "2-3 weeks",
      "technicalStack": {
        "frontend": "React with TypeScript",
        "backend": "Node.js with Express",
        "database": "PostgreSQL",
        "authentication": "JWT"
      }
    }
    
    Consider security, scalability, and maintainability in your analysis.
    Provide realistic estimates and technical recommendations.`

    try {
      const response = await this.zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an expert system architect and technical analyst.'
          },
          {
            role: 'user',
            content: analysisPrompt
          }
        ],
        temperature: 0.3,
        max_tokens: 2000
      })

      const analysisText = response.choices[0]?.message?.content || '{}'
      return JSON.parse(analysisText)
    } catch (error) {
      console.error('Analysis failed:', error)
      // Return fallback analysis
      return {
        applicationType: 'webapp',
        complexity: 'medium',
        databaseNeeds: { required: true, type: 'relational', estimatedTables: 5 },
        apiNeeds: { required: true, endpoints: ['auth', 'crud'] },
        frontendNeeds: { framework: 'react', styling: 'tailwind' },
        securityRequirements: { authentication: true, authorization: true },
        integrationPoints: ['database', 'api'],
        technicalStack: { frontend: 'React', backend: 'Node.js', database: 'PostgreSQL' }
      }
    }
  }

  // Step 2: Database Schema Generation
  async generateDatabaseSchema(analysis: any): Promise<any> {
    const schemaPrompt = `${ROLE_PROMPTS.databaseArchitect}
    
    Based on the following analysis, design a comprehensive database schema:
    
    Analysis: ${JSON.stringify(analysis)}
    
    ${SECURITY_PATTERNS.validation.sql}
    
    ${FEW_SHOT_EXAMPLES.databaseSchema}
    
    Generate a complete database schema with the following requirements:
    1. Follow normalization principles (at least 3NF)
    2. Include proper data types and constraints
    3. Design indexes for performance optimization
    4. Consider relationships and foreign keys
    5. Add timestamps for auditing (created_at, updated_at)
    6. Include soft delete capability where appropriate
    7. Design for scalability and future growth
    
    Respond with JSON:
    {
      "schema": {
        "tables": [
          {
            "name": "users",
            "columns": [
              {"name": "id", "type": "UUID", "primary": true, "default": "gen_random_uuid()"},
              {"name": "email", "type": "VARCHAR(255)", "unique": true, "nullable": false},
              {"name": "password_hash", "type": "VARCHAR(255)", "nullable": false},
              {"name": "created_at", "type": "TIMESTAMP", "default": "CURRENT_TIMESTAMP"},
              {"name": "updated_at", "type": "TIMESTAMP", "default": "CURRENT_TIMESTAMP"}
            ],
            "indexes": [
              {"name": "idx_users_email", "columns": ["email"], "unique": true}
            ]
          }
        ]
      },
      "relationships": [
        {
          "from": "users",
          "to": "profiles",
          "type": "one-to-one",
          "foreignKey": "user_id"
        }
      ],
      "migrations": [
        "CREATE TABLE users (...)",
        "CREATE TABLE profiles (...)",
        "ALTER TABLE profiles ADD CONSTRAINT fk_profiles_user_id FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE"
      ],
      "securityConsiderations": [
        "Always hash passwords before storing",
        "Use parameterized queries to prevent SQL injection",
        "Implement proper indexing for performance"
      ]
    }`

    try {
      const response = await this.zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an expert database architect specializing in secure, scalable database design.'
          },
          {
            role: 'user',
            content: schemaPrompt
          }
        ],
        temperature: 0.2,
        max_tokens: 3000
      })

      const schemaText = response.choices[0]?.message?.content || '{}'
      return JSON.parse(schemaText)
    } catch (error) {
      console.error('Schema generation failed:', error)
      throw new Error('Failed to generate database schema')
    }
  }

  // Step 3: Backend API Generation
  async generateBackendAPI(analysis: any, databaseSchema: any): Promise<any> {
    const apiPrompt = `${ROLE_PROMPTS.backendEngineer}
    
    Based on the analysis and database schema, generate a comprehensive backend API:
    
    Analysis: ${JSON.stringify(analysis)}
    Database Schema: ${JSON.stringify(databaseSchema)}
    
    ${SECURITY_PATTERNS.authentication.jwt}
    ${SECURITY_PATTERNS.validation.input}
    ${SECURITY_PATTERNS.api.rate}
    
    ${FEW_SHOT_EXAMPLES.backendApi}
    
    Generate a complete backend API with the following requirements:
    1. Follow RESTful API design principles
    2. Implement proper authentication and authorization
    3. Include comprehensive input validation
    4. Add error handling and logging
    5. Implement rate limiting
    6. Include API documentation (JSDoc comments)
    7. Consider security best practices
    
    Respond with JSON:
    {
      "apiStructure": {
        "endpoints": [
          {
            "method": "POST",
            "path": "/api/auth/register",
            "description": "Register a new user",
            "authentication": false,
            "validation": {
              "body": {
                "email": "required|email",
                "password": "required|min:8"
              }
            },
            "implementation": "async function register(req, res) { ... }"
          }
        ]
      },
      "middleware": [
        {
          "name": "authenticate",
          "purpose": "JWT authentication middleware",
          "implementation": "function authenticate(req, res, next) { ... }"
        }
      ],
      "utilities": [
        {
          "name": "validateRequest",
          "purpose": "Request validation utility",
          "implementation": "function validateRequest(schema) { ... }"
        }
      ],
      "securityMeasures": [
        "JWT token validation",
        "Rate limiting middleware",
        "Input sanitization",
        "Error handling without information leakage"
      ]
    }`

    try {
      const response = await this.zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an expert backend engineer specializing in secure, scalable API design.'
          },
          {
            role: 'user',
            content: apiPrompt
          }
        ],
        temperature: 0.3,
        max_tokens: 4000
      })

      const apiText = response.choices[0]?.message?.content || '{}'
      return JSON.parse(apiText)
    } catch (error) {
      console.error('API generation failed:', error)
      throw new Error('Failed to generate backend API')
    }
  }

  // Step 4: Frontend Components Generation
  async generateFrontend(analysis: any, backendAPI: any): Promise<any> {
    const frontendPrompt = `${ROLE_PROMPTS.frontendArchitect}
    
    Based on the analysis and backend API, generate comprehensive frontend components:
    
    Analysis: ${JSON.stringify(analysis)}
    Backend API: ${JSON.stringify(backendAPI)}
    
    ${FEW_SHOT_EXAMPLES.frontendComponent}
    
    Generate a complete frontend with the following requirements:
    1. Use React with TypeScript and functional components
    2. Implement proper state management (useState, useEffect, useContext)
    3. Include responsive design with Tailwind CSS
    4. Add accessibility features (ARIA labels, keyboard navigation)
    5. Implement proper error handling and loading states
    6. Include form validation and user feedback
    7. Consider performance optimization
    
    Respond with JSON:
    {
      "components": [
        {
          "name": "UserRegistration",
          "purpose": "User registration form",
          "implementation": "import React, { useState } from 'react';\\n\\nconst UserRegistration = () => { ... }",
          "dependencies": ["react-hook-form", "axios"],
          "styling": "Tailwind CSS classes"
        }
      ],
      "pages": [
        {
          "name": "Dashboard",
          "route": "/dashboard",
          "components": ["UserCard", "StatsCard", "ActivityList"],
          "layout": "Main layout with sidebar"
        }
      ],
      "hooks": [
        {
          "name": "useAuth",
          "purpose": "Authentication hook",
          "implementation": "export const useAuth = () => { ... }"
        }
      ],
      "utilities": [
        {
          "name": "api",
          "purpose": "API utility functions",
          "implementation": "export const api = { ... }"
        }
      ],
      "styling": {
        "approach": "Tailwind CSS with custom theme",
        "components": "Consistent design system",
        "responsive": "Mobile-first responsive design"
      }
    }`

    try {
      const response = await this.zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an expert frontend architect specializing in React, TypeScript, and modern web development.'
          },
          {
            role: 'user',
            content: frontendPrompt
          }
        ],
        temperature: 0.4,
        max_tokens: 4000
      })

      const frontendText = response.choices[0]?.message?.content || '{}'
      return JSON.parse(frontendText)
    } catch (error) {
      console.error('Frontend generation failed:', error)
      throw new Error('Failed to generate frontend components')
    }
  }

  // Step 5: Integration Configuration
  async generateIntegrationConfig(analysis: any, databaseSchema: any, backendAPI: any, frontend: any): Promise<any> {
    const integrationPrompt = `${ROLE_PROMPTS.backendEngineer}
    
    Generate integration configuration for the complete application:
    
    Analysis: ${JSON.stringify(analysis)}
    Database Schema: ${JSON.stringify(databaseSchema)}
    Backend API: ${JSON.stringify(backendAPI)}
    Frontend: ${JSON.stringify(frontend)}
    
    Generate comprehensive integration configuration including:
    1. Environment variables and configuration
    2. Database connection setup
    3. API client configuration
    4. Authentication flow configuration
    5. Deployment configuration
    6. Monitoring and logging setup
    
    Respond with JSON:
    {
      "environment": {
        "variables": [
          {"name": "DATABASE_URL", "description": "Database connection string", "required": true},
          {"name": "JWT_SECRET", "description": "JWT signing secret", "required": true}
        ]
      },
      "configuration": {
        "database": "Connection pool configuration",
        "api": "API client setup and interceptors",
        "auth": "Authentication provider configuration"
      },
      "deployment": {
        "frontend": "Static file deployment configuration",
        "backend": "Server deployment configuration",
        "database": "Database migration and seeding"
      },
      "monitoring": {
        "logging": "Logging configuration and levels",
        "errorTracking": "Error tracking setup",
        "performance": "Performance monitoring setup"
      }
    }`

    try {
      const response = await this.zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an expert DevOps engineer specializing in application deployment and integration.'
          },
          {
            role: 'user',
            content: integrationPrompt
          }
        ],
        temperature: 0.3,
        max_tokens: 2000
      })

      const integrationText = response.choices[0]?.message?.content || '{}'
      return JSON.parse(integrationText)
    } catch (error) {
      console.error('Integration configuration failed:', error)
      throw new Error('Failed to generate integration configuration')
    }
  }

  // Main generation orchestration
  async generateFullStack(prompt: string, requirements: any): Promise<DecomposedResponse> {
    const steps: GenerationStep[] = []
    const startTime = new Date()

    try {
      // Initialize AI
      if (!(await this.initialize())) {
        throw new Error('Failed to initialize AI service')
      }

      // Step 1: Analysis
      steps.push({
        step: 'analysis',
        status: 'in-progress',
        timestamp: new Date()
      })

      const analysis = await this.analyzeRequirements(prompt, requirements)
      
      steps[steps.length - 1] = {
        ...steps[steps.length - 1],
        status: 'completed',
        output: analysis,
        timestamp: new Date()
      }

      // Step 2: Database Schema
      steps.push({
        step: 'database-schema',
        status: 'in-progress',
        timestamp: new Date()
      })

      const databaseSchema = await this.generateDatabaseSchema(analysis)
      
      steps[steps.length - 1] = {
        ...steps[steps.length - 1],
        status: 'completed',
        output: databaseSchema,
        timestamp: new Date()
      }

      // Step 3: Backend API
      steps.push({
        step: 'backend-api',
        status: 'in-progress',
        timestamp: new Date()
      })

      const backendAPI = await this.generateBackendAPI(analysis, databaseSchema)
      
      steps[steps.length - 1] = {
        ...steps[steps.length - 1],
        status: 'completed',
        output: backendAPI,
        timestamp: new Date()
      }

      // Step 4: Frontend
      steps.push({
        step: 'frontend',
        status: 'in-progress',
        timestamp: new Date()
      })

      const frontend = await this.generateFrontend(analysis, backendAPI)
      
      steps[steps.length - 1] = {
        ...steps[steps.length - 1],
        status: 'completed',
        output: frontend,
        timestamp: new Date()
      }

      // Step 5: Integration
      steps.push({
        step: 'integration',
        status: 'in-progress',
        timestamp: new Date()
      })

      const integration = await this.generateIntegrationConfig(analysis, databaseSchema, backendAPI, frontend)
      
      steps[steps.length - 1] = {
        ...steps[steps.length - 1],
        status: 'completed',
        output: integration,
        timestamp: new Date()
      }

      return {
        success: true,
        sessionId: this.sessionId,
        steps,
        finalOutput: {
          database: databaseSchema,
          backend: backendAPI,
          frontend: frontend,
          integration: integration
        },
        explanation: `Successfully generated full-stack application with ${steps.length} sequential steps. Total generation time: ${Math.round((new Date().getTime() - startTime.getTime()) / 1000)}s`
      }

    } catch (error) {
      // Mark current step as failed
      if (steps.length > 0 && steps[steps.length - 1].status === 'in-progress') {
        steps[steps.length - 1] = {
          ...steps[steps.length - 1],
          status: 'error',
          error: error instanceof Error ? error.message : 'Unknown error',
          timestamp: new Date()
        }
      }

      return {
        success: false,
        sessionId: this.sessionId,
        steps,
        error: error instanceof Error ? error.message : 'Unknown error occurred during generation'
      }
    }
  }
}

export async function POST(request: NextRequest) {
  try {
    const body: DecomposedRequest = await request.json()
    const { prompt, type, requirements, context, industry, targetAudience, brandPersonality } = body

    if (!prompt) {
      return NextResponse.json(
        { error: 'Prompt is required' },
        { status: 400 }
      )
    }

    const generator = new DecomposedAIGenerator()
    const result = await generator.generateFullStack(prompt, {
      type,
      requirements,
      context,
      industry,
      targetAudience,
      brandPersonality
    })

    return NextResponse.json(result)
  } catch (error) {
    console.error('Decomposed generation error:', error)
    return NextResponse.json(
      { 
        error: 'Internal server error',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}