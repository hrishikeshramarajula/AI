import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

// Enhanced interfaces for role-based generation
interface RoleBasedRequest {
  prompt: string
  type: 'webpage' | 'component' | 'backend' | 'database' | 'full-stack'
  role: 'frontend-architect' | 'backend-engineer' | 'database-architect' | 'security-expert' | 'devops-engineer' | 'ux-designer' | 'full-stack-developer'
  complexity?: 'simple' | 'medium' | 'complex'
  industry?: string
  securityLevel?: 'basic' | 'standard' | 'high' | 'enterprise'
  context?: string
}

interface RoleBasedResponse {
  success: boolean
  sessionId: string
  role: string
  persona: {
    name: string
    expertise: string[]
    experience: string
    focus: string
  }
  analysis?: {
    requirements: string[]
    constraints: string[]
    bestPractices: string[]
    securityConsiderations: string[]
  }
  generatedContent?: {
    code?: string
    explanation?: string
    recommendations?: string[]
    alternatives?: string[]
  }
  metadata?: {
    tokensUsed: number
    processingTime: number
    confidence: number
    suggestions: string[]
  }
  error?: string
}

// Comprehensive Role-Based Personas
const ROLE_PERSONAS = {
  'frontend-architect': {
    name: 'Senior Frontend Architect',
    expertise: ['React', 'TypeScript', 'Next.js', 'Tailwind CSS', 'Accessibility', 'Performance Optimization', 'State Management'],
    experience: '15+ years building scalable, accessible web applications',
    focus: 'Clean component architecture, user experience, accessibility, and performance',
    systemPrompt: `You are a Senior Frontend Architect with 15+ years of experience building enterprise-scale web applications.
    Your expertise includes React, TypeScript, Next.js, modern CSS frameworks, and accessibility standards.
    You specialize in creating component-driven architectures that are scalable, maintainable, and accessible.
    Always consider:
    1. Component composition and reusability
    2. Accessibility (WCAG 2.1 AA compliance)
    3. Performance optimization (code splitting, lazy loading)
    4. Responsive design and mobile-first approach
    5. State management patterns
    6. Error boundaries and error handling
    7. TypeScript best practices and type safety
    8. Cross-browser compatibility
    9. SEO optimization
    10. User experience and interaction design`
  },

  'backend-engineer': {
    name: 'Senior Backend Engineer',
    expertise: ['Node.js', 'Express', 'FastAPI', 'PostgreSQL', 'MongoDB', 'Redis', 'Microservices', 'API Design'],
    experience: '12+ years building scalable backend systems and APIs',
    focus: 'Clean architecture, API design, database optimization, and system scalability',
    systemPrompt: `You are a Senior Backend Engineer with 12+ years of experience in building scalable, secure backend systems.
    Your expertise includes Node.js, Python, database design, API development, and system architecture.
    You specialize in creating RESTful APIs, microservices, and data-intensive applications.
    Always consider:
    1. Clean architecture and separation of concerns
    2. RESTful API design principles
    3. Database optimization and indexing strategies
    4. Caching strategies and performance optimization
    5. Error handling and logging
    6. Security best practices (authentication, authorization, input validation)
    7. Scalability and load balancing
    8. Monitoring and observability
    9. Testing strategies (unit, integration, e2e)
    10. Documentation and API specifications`
  },

  'database-architect': {
    name: 'Senior Database Architect',
    expertise: ['PostgreSQL', 'MySQL', 'MongoDB', 'Redis', 'Data Modeling', 'Query Optimization', 'Scalability'],
    experience: '18+ years designing enterprise-grade database systems',
    focus: 'Data integrity, performance optimization, scalability, and security',
    systemPrompt: `You are a Senior Database Architect with 18+ years of experience in designing enterprise-grade database systems.
    Your expertise includes relational databases, NoSQL systems, data modeling, and performance optimization.
    You specialize in creating scalable, secure, and performant database architectures.
    Always consider:
    1. Database normalization and denormalization strategies
    2. Index design and query optimization
    3. Data integrity and constraint design
    4. Scalability and sharding strategies
    5. Security and access control
    6. Backup and recovery strategies
    7. Data migration strategies
    8. Performance monitoring and tuning
    9. Concurrency and transaction management
    10. Data warehousing and analytics considerations`
  },

  'security-expert': {
    name: 'Application Security Expert',
    expertise: ['OWASP Top 10', 'Penetration Testing', 'Security Architecture', 'Compliance', 'Risk Assessment'],
    experience: '14+ years in application security and penetration testing',
    focus: 'Security by design, threat modeling, and vulnerability prevention',
    systemPrompt: `You are an Application Security Expert with 14+ years of experience in web application security.
    Your expertise includes OWASP Top 10, penetration testing, security architecture, and compliance frameworks.
    You specialize in building secure applications and identifying potential vulnerabilities.
    Always consider:
    1. OWASP Top 10 vulnerabilities and mitigation
    2. Secure coding practices and principles
    3. Authentication and authorization mechanisms
    4. Input validation and output encoding
    5. Session management and secure cookies
    6. Cryptography and data protection
    7. Security headers and CSP implementation
    8. Error handling and information disclosure
    9. Logging and monitoring for security events
    10. Compliance requirements (GDPR, HIPAA, PCI-DSS)`
  },

  'devops-engineer': {
    name: 'Senior DevOps Engineer',
    expertise: ['Docker', 'Kubernetes', 'CI/CD', 'Cloud Infrastructure', 'Monitoring', 'Infrastructure as Code'],
    experience: '10+ years in DevOps and cloud infrastructure',
    focus: 'Automation, scalability, reliability, and deployment optimization',
    systemPrompt: `You are a Senior DevOps Engineer with 10+ years of experience in cloud infrastructure and automation.
    Your expertise includes containerization, orchestration, CI/CD pipelines, and cloud platforms.
    You specialize in building scalable, reliable, and automated deployment pipelines.
    Always consider:
    1. Infrastructure as Code (IaC) principles
    2. Containerization and orchestration strategies
    3. CI/CD pipeline design and optimization
    4. Monitoring, logging, and observability
    5. High availability and disaster recovery
    6. Security in the deployment pipeline
    7. Cost optimization and resource management
    8. Configuration management and secrets management
    9. Performance testing and optimization
    10. Backup and disaster recovery strategies`
  },

  'ux-designer': {
    name: 'Senior UX Designer',
    expertise: ['User Research', 'Interaction Design', 'Prototyping', 'Design Systems', 'Accessibility'],
    experience: '12+ years in user experience design and research',
    focus: 'User-centered design, accessibility, and intuitive interfaces',
    systemPrompt: `You are a Senior UX Designer with 12+ years of experience in user experience design and research.
    Your expertise includes user research, interaction design, prototyping, and design systems.
    You specialize in creating intuitive, accessible, and user-centered digital experiences.
    Always consider:
    1. User-centered design principles
    2. Accessibility and inclusive design (WCAG 2.1 AA)
    3. Information architecture and navigation
    4. Interaction design and user flows
    5. Visual hierarchy and design consistency
    6. Mobile-first and responsive design
    7. Usability testing and iteration
    8. Design systems and component libraries
    9. Performance and perceived performance
    10. Cross-cultural and international considerations`
  },

  'full-stack-developer': {
    name: 'Senior Full-Stack Developer',
    expertise: ['React', 'Node.js', 'TypeScript', 'Databases', 'Cloud Services', 'System Architecture'],
    experience: '16+ years in full-stack development and system architecture',
    focus: 'End-to-end application development, system integration, and technical leadership',
    systemPrompt: `You are a Senior Full-Stack Developer with 16+ years of experience in building complete web applications.
    Your expertise spans frontend, backend, databases, and cloud infrastructure.
    You specialize in end-to-end application development and system architecture.
    Always consider:
    1. Full-stack architecture and integration
    2. Frontend-backend communication patterns
    3. Database design and optimization
    4. API design and integration
    5. Authentication and authorization flows
    6. State management across the stack
    7. Performance optimization at all layers
    8. Security best practices end-to-end
    9. Testing strategies across the stack
    10. Deployment and operations considerations`
  }
}

// Security and Best Practices Guidelines
const SECURITY_GUIDELINES = {
  basic: [
    'Input validation and sanitization',
    'Basic error handling',
    'Simple authentication',
    'HTTPS usage',
    'Basic logging'
  ],
  standard: [
    'Comprehensive input validation',
    'JWT authentication with expiration',
    'Rate limiting',
    'SQL injection prevention',
    'XSS prevention',
    'CSRF protection',
    'Security headers',
    'Secure password hashing',
    'Environment variable management',
    'Audit logging'
  ],
  high: [
    'Advanced input validation and sanitization',
    'Multi-factor authentication',
    'OAuth 2.0/OpenID Connect',
    'Advanced rate limiting and bot detection',
    'Comprehensive OWASP Top 10 coverage',
    'Content Security Policy (CSP)',
    'Advanced session management',
    'Data encryption at rest and in transit',
    'Advanced audit logging and monitoring',
    'Secrets management',
    'Vulnerability scanning integration'
  ],
  enterprise: [
    'Enterprise-grade security architecture',
    'Zero-trust security model',
    'Advanced identity and access management (IAM)',
    'Multi-layered security controls',
    'Advanced threat detection and response',
    'Comprehensive audit trails and compliance reporting',
    'Data loss prevention (DLP)',
    'Advanced encryption and key management',
    'Security information and event management (SIEM)',
    'Penetration testing and security assessments',
    'Compliance automation (GDPR, HIPAA, SOC 2, etc.)'
  ]
}

// Industry-Specific Considerations
const INDUSTRY_CONSIDERATIONS = {
  healthcare: [
    'HIPAA compliance requirements',
    'Protected Health Information (PHI) handling',
    'Patient data privacy and security',
    'Audit trails for data access',
    'Business Associate Agreement (BAA) considerations'
  ],
  finance: [
    'PCI-DSS compliance',
    'Financial data protection',
    'SOX compliance considerations',
    'Fraud detection and prevention',
    'Regulatory reporting requirements'
  ],
  ecommerce: [
    'Payment Card Industry (PCI) compliance',
    'Shopping cart and checkout security',
    'Customer data protection',
    'Fraud prevention',
    'Order processing and inventory management'
  ],
  education: [
    'FERPA compliance',
    'Student data privacy',
    'Accessibility requirements (Section 508)',
    'Educational content management',
    'User role management'
  ],
  technology: [
    'Scalability considerations',
    'API-first architecture',
    'Integration capabilities',
    'Performance optimization',
    'Developer experience'
  ]
}

class RoleBasedAIGenerator {
  private zai: any
  private sessionId: string

  constructor() {
    this.sessionId = `role_session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  }

  async initialize() {
    try {
      this.zai = await ZAI.create()
      return true
    } catch (error) {
      console.error('Failed to initialize ZAI:', error)
      return false
    }
  }

  // Analyze requirements based on role and context
  async analyzeRequirements(prompt: string, role: string, context: any): Promise<any> {
    const persona = ROLE_PERSONAS[role as keyof typeof ROLE_PERSONAS]
    const securityGuidelines = SECURITY_GUIDELINES[context.securityLevel || 'standard']
    const industryConsiderations = context.industry ? INDUSTRY_CONSIDERATIONS[context.industry as keyof typeof INDUSTRY_CONSIDERATIONS] || [] : []

    const analysisPrompt = `${persona.systemPrompt}
    
    You are analyzing a development request from your professional perspective.
    
    User Request: "${prompt}"
    Role: ${persona.name}
    Complexity: ${context.complexity || 'medium'}
    Security Level: ${context.securityLevel || 'standard'}
    Industry: ${context.industry || 'general'}
    
    Provide a comprehensive analysis from your professional perspective.
    Respond with JSON:
    {
      "requirements": [
        "Specific requirement 1 based on the request",
        "Specific requirement 2 considering the role"
      ],
      "constraints": [
        "Technical constraint 1",
        "Business constraint 2"
      ],
      "bestPractices": [
        "Industry best practice 1",
        "Role-specific best practice 2"
      ],
      "securityConsiderations": [
        "Security consideration 1",
        "Security consideration 2"
      ],
      "recommendations": [
        "Technical recommendation 1",
        "Architecture recommendation 2"
      ],
      "potentialChallenges": [
        "Challenge 1 that might be encountered",
        "Challenge 2 related to scalability"
      ],
      "successCriteria": [
        "Success metric 1",
        "Success metric 2"
      ]
    }
    
    Consider your specific expertise and the context provided.
    Provide actionable insights and recommendations.`

    try {
      const response = await this.zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: `You are ${persona.name}. ${persona.focus}`
          },
          {
            role: 'user',
            content: analysisPrompt
          }
        ],
        temperature: 0.3,
        max_tokens: 2000
      })

      const analysisText = response.choices[0]?.message?.content || '{}'
      return JSON.parse(analysisText)
    } catch (error) {
      console.error('Analysis failed:', error)
      throw new Error('Failed to analyze requirements')
    }
  }

  // Generate content based on role and analysis
  async generateContent(prompt: string, role: string, analysis: any, context: any): Promise<any> {
    const persona = ROLE_PERSONAS[role as keyof typeof ROLE_PERSONAS]
    const securityGuidelines = SECURITY_GUIDELINES[context.securityLevel || 'standard']
    const industryConsiderations = context.industry ? INDUSTRY_CONSIDERATIONS[context.industry as keyof typeof INDUSTRY_CONSIDERATIONS] || [] : []

    let generationPrompt = `${persona.systemPrompt}
    
    Based on the following analysis and request, generate high-quality content from your professional perspective:
    
    User Request: "${prompt}"
    Analysis: ${JSON.stringify(analysis)}
    Security Requirements: ${securityGuidelines.join(', ')}
    Industry Considerations: ${industryConsiderations.join(', ')}
    
    Generate comprehensive content that includes:
    
    1. Primary Implementation:
       - Well-structured, production-ready code
       - Comprehensive comments and documentation
       - Error handling and edge cases
       - Performance considerations
       
    2. Security Implementation:
       - Implement all relevant security measures
       - Add proper validation and sanitization
       - Include security-focused comments
       
    3. Best Practices:
       - Follow industry and role-specific best practices
       - Include proper error handling
       - Add logging and monitoring points
       
    4. Documentation:
       - Clear code documentation
       - Usage examples
       - Configuration requirements
       
    5. Testing Considerations:
       - Unit testing suggestions
       - Integration testing points
       - Edge cases to test
    
    Respond with JSON:
    {
      "code": "The generated code with proper formatting and comments",
      "explanation": "Detailed explanation of the implementation decisions",
      "recommendations": [
        "Recommendation 1 for improvement",
        "Recommendation 2 for optimization"
      ],
      "alternatives": [
        "Alternative approach 1",
        "Alternative approach 2"
      ],
      "testingStrategy": "Testing approach and key test cases",
      "deploymentConsiderations": "Deployment requirements and considerations",
      "monitoringPoints": "Key monitoring and logging points"
    }`

    // Add role-specific generation guidance
    if (role === 'frontend-architect') {
      generationPrompt += `
    
    Frontend-Specific Requirements:
    - Use React with TypeScript and functional components
    - Implement proper TypeScript types and interfaces
    - Include accessibility attributes (ARIA labels, etc.)
    - Use Tailwind CSS for styling
    - Implement proper state management
    - Add loading states and error handling
    - Consider responsive design
    - Include proper component composition`
    } else if (role === 'backend-engineer') {
      generationPrompt += `
    
    Backend-Specific Requirements:
    - Use Node.js with Express.js
    - Implement proper RESTful API design
    - Add comprehensive input validation
    - Include proper error handling and HTTP status codes
    - Implement authentication/authorization middleware
    - Add rate limiting and security headers
    - Include proper logging and monitoring
    - Use TypeScript for type safety`
    } else if (role === 'database-architect') {
      generationPrompt += `
    
    Database-Specific Requirements:
    - Design normalized database schema
    - Include proper data types and constraints
    - Add indexes for performance optimization
    - Consider foreign key relationships
    - Include proper error handling
    - Add security considerations
    - Provide migration scripts
    - Include performance optimization tips`
    } else if (role === 'security-expert') {
      generationPrompt += `
    
    Security-Specific Requirements:
    - Implement comprehensive security measures
    - Address OWASP Top 10 vulnerabilities
    - Include proper input validation and sanitization
    - Add authentication and authorization
    - Implement proper error handling
    - Include security headers and CSP
    - Add logging and monitoring
    - Provide security testing recommendations`
    }

    try {
      const response = await this.zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: `You are ${persona.name}. ${persona.focus}`
          },
          {
            role: 'user',
            content: generationPrompt
          }
        ],
        temperature: 0.4,
        max_tokens: 4000
      })

      const contentText = response.choices[0]?.message?.content || '{}'
      return JSON.parse(contentText)
    } catch (error) {
      console.error('Content generation failed:', error)
      throw new Error('Failed to generate content')
    }
  }

  // Main role-based generation orchestration
  async generateWithRole(prompt: string, role: string, context: any): Promise<RoleBasedResponse> {
    const startTime = Date.now()

    try {
      // Initialize AI
      if (!(await this.initialize())) {
        throw new Error('Failed to initialize AI service')
      }

      const persona = ROLE_PERSONAS[role as keyof typeof ROLE_PERSONAS]

      // Step 1: Analyze requirements
      const analysis = await this.analyzeRequirements(prompt, role, context)

      // Step 2: Generate content
      const generatedContent = await this.generateContent(prompt, role, analysis, context)

      const processingTime = Date.now() - startTime

      return {
        success: true,
        sessionId: this.sessionId,
        role: role,
        persona: {
          name: persona.name,
          expertise: persona.expertise,
          experience: persona.experience,
          focus: persona.focus
        },
        analysis: analysis,
        generatedContent: generatedContent,
        metadata: {
          tokensUsed: Math.floor(processingTime / 10), // Estimated token usage
          processingTime: processingTime,
          confidence: 0.85, // Confidence score based on role match
          suggestions: [
            'Review generated code for project-specific requirements',
            'Test the implementation thoroughly',
            'Consider performance optimization opportunities',
            'Validate security measures implementation'
          ]
        }
      }

    } catch (error) {
      return {
        success: false,
        sessionId: this.sessionId,
        role: role,
        persona: ROLE_PERSONAS[role as keyof typeof ROLE_PERSONAS],
        error: error instanceof Error ? error.message : 'Unknown error occurred during generation'
      }
    }
  }
}

export async function POST(request: NextRequest) {
  try {
    const body: RoleBasedRequest = await request.json()
    const { prompt, type, role, complexity, industry, securityLevel, context } = body

    if (!prompt || !role) {
      return NextResponse.json(
        { error: 'Prompt and role are required' },
        { status: 400 }
      )
    }

    if (!ROLE_PERSONAS[role as keyof typeof ROLE_PERSONAS]) {
      return NextResponse.json(
        { 
          error: 'Invalid role specified',
          availableRoles: Object.keys(ROLE_PERSONAS)
        },
        { status: 400 }
      )
    }

    const generator = new RoleBasedAIGenerator()
    const result = await generator.generateWithRole(prompt, role, {
      type,
      complexity,
      industry,
      securityLevel,
      context
    })

    return NextResponse.json(result)
  } catch (error) {
    console.error('Role-based generation error:', error)
    return NextResponse.json(
      { 
        error: 'Internal server error',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}

export async function GET() {
  return NextResponse.json({
    availableRoles: Object.keys(ROLE_PERSONAS).map(role => ({
      id: role,
      ...ROLE_PERSONAS[role as keyof typeof ROLE_PERSONAS]
    })),
    securityLevels: Object.keys(SECURITY_GUIDELINES),
    industries: Object.keys(INDUSTRY_CONSIDERATIONS)
  })
}