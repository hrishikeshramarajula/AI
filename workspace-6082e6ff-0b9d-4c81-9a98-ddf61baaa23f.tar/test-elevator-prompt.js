/**
 * Test the AI-IDE system with an elevator/lift company prompt
 */

const testPrompt = "Create a complete elevator and lift company website";

console.log("🏢 Testing AI-IDE with Elevator/Lift Company Prompt");
console.log("=".repeat(60));
console.log("");

console.log("📝 Test Prompt:");
console.log(`"${testPrompt}"`);
console.log("");

console.log("🎯 Expected Results:");
console.log("- Professional company website");
console.log("- Services section (elevator installation, maintenance, etc.)");
console.log("- About section with company information");
console.log("- Contact form and information");
console.log("- Responsive design");
console.log("- Interactive elements");
console.log("- Professional styling");
console.log("");

console.log("🔧 How to run this test:");
console.log("1. Open http://localhost:3000 in your browser");
console.log("2. Copy and paste this exact prompt:");
console.log(`   "${testPrompt}"`);
console.log("3. Click the Generate button");
console.log("4. Wait for processing (you'll see console updates)");
console.log("5. View the generated files in the file explorer");
console.log("6. Click 'Show Preview' to see the website");
console.log("");

console.log("📁 Expected File Structure:");
console.log("├── index.html (main webpage with elevator company content)");
console.log("├── styles.css (professional styling and layout)");
console.log("└── script.js (interactive features like contact form)");
console.log("");

console.log("✅ Success Indicators:");
console.log("- Console shows '✅ Complete webpage generated successfully!'");
console.log("- File explorer shows 3 new files");
console.log("- Preview displays a professional elevator company website");
console.log("- All interactive elements work (not dummy content)");
console.log("");

console.log("🚀 System is ready for testing!");
console.log("   The AI-IDE will generate a complete, functional elevator company website");
console.log("   with real content and interactive features, not just placeholders.");