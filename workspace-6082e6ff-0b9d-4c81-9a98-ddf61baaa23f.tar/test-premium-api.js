const testPremiumGeneration = async () => {
  console.log('🧪 Testing Premium Webpage Generation API...\n');
  
  try {
    const testPrompt = 'Create a complete business website with all professional features';
    
    console.log('📤 Sending request to /api/premium-webpage...');
    console.log('📝 Test prompt:', testPrompt);
    
    const startTime = Date.now();
    
    const response = await fetch('http://localhost:3000/api/premium-webpage', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: testPrompt,
        features: ['navigation', 'hero', 'services', 'about', 'contact', 'footer'],
        requirements: ['Professional design', 'Responsive layout', 'Modern styling']
      })
    });
    
    const endTime = Date.now();
    const duration = (endTime - startTime) / 1000;
    
    console.log(`⏱️  Request completed in ${duration} seconds`);
    console.log(`📊 Response status: ${response.status}`);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const data = await response.json();
    
    console.log('✅ Premium generation successful!');
    console.log('📋 Response summary:');
    console.log(`   - Success: ${data.success}`);
    console.log(`   - Files generated: ${data.files?.length || 0}`);
    console.log(`   - Tasks created: ${data.tasks?.length || 0}`);
    console.log(`   - Console logs: ${data.consoleLogs?.length || 0}`);
    
    if (data.files && data.files.length > 0) {
      console.log('\n📁 Generated files:');
      data.files.forEach((file, index) => {
        console.log(`   ${index + 1}. ${file.name} (${file.language}) - ${file.content.length} characters`);
      });
    }
    
    if (data.tasks && data.tasks.length > 0) {
      console.log('\n📋 Tasks created:');
      data.tasks.forEach((task, index) => {
        console.log(`   ${index + 1}. [${task.status}] ${task.title}`);
      });
    }
    
    if (data.consoleLogs && data.consoleLogs.length > 0) {
      console.log('\n📝 Console logs (last 5):');
      data.consoleLogs.slice(-5).forEach((log, index) => {
        console.log(`   ${index + 1}. [${log.type.toUpperCase()}] ${log.message}`);
      });
    }
    
    console.log('\n🎉 Premium Webpage Generation Test Completed Successfully!');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    console.error('🔍 This might be the 502 error you mentioned.');
    
    // Test if the server is running
    try {
      console.log('\n🔍 Testing if server is running...');
      const healthResponse = await fetch('http://localhost:3000/api/health');
      console.log('✅ Server is running, health check passed');
    } catch (healthError) {
      console.error('❌ Server health check failed:', healthError.message);
      console.log('💡 Make sure the development server is running with: npm run dev');
    }
  }
};

testPremiumGeneration();