// Test script to verify the improved premium generation
const testImprovedPremiumGeneration = async () => {
  console.log('🧪 Testing Improved Premium Generation...\n');
  
  const testCases = [
    {
      name: 'Business Website',
      prompt: 'Create a complete business website with professional navigation, services, and contact form'
    },
    {
      name: 'Portfolio Website',
      prompt: 'Design a modern portfolio website for a creative professional'
    },
    {
      name: 'E-commerce Site',
      prompt: 'Build an e-commerce website with product catalog and shopping features'
    }
  ];
  
  for (const testCase of testCases) {
    console.log(`📋 Testing: ${testCase.name}`);
    console.log(`📝 Prompt: ${testCase.prompt}`);
    
    try {
      const controller = new AbortController();
      const timeoutMs = 180000; // 3 minutes
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
      
      const startTime = Date.now();
      
      const response = await fetch('http://localhost:3000/api/premium-webpage', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: testCase.prompt,
          features: ['navigation', 'hero', 'services', 'contact', 'footer']
        }),
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      const endTime = Date.now();
      const duration = (endTime - startTime) / 1000;
      
      console.log(`⏱️  Completed in ${duration.toFixed(1)} seconds`);
      console.log(`📊 Status: ${response.status}`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (!data.success) {
        throw new Error(data.error || 'Generation failed');
      }
      
      // Validate files
      if (!data.files || !Array.isArray(data.files) || data.files.length === 0) {
        throw new Error('No files generated');
      }
      
      const validFiles = data.files.filter(file => 
        file.content && file.content.trim().length > 0
      );
      
      console.log(`✅ Success! Generated ${validFiles.length} valid files`);
      
      // Show file details
      validFiles.forEach((file, index) => {
        const sizeKB = Math.round(file.content.length / 1024);
        console.log(`   ${index + 1}. ${file.name} (${file.language}) - ${sizeKB}KB`);
      });
      
      // Check for required features in HTML
      const htmlFile = validFiles.find(f => f.language === 'html');
      if (htmlFile) {
        const content = htmlFile.content.toLowerCase();
        const features = {
          navigation: content.includes('nav') || content.includes('navigation'),
          hero: content.includes('hero') || content.includes('banner'),
          services: content.includes('service') || content.includes('feature'),
          contact: content.includes('contact') || content.includes('form'),
          footer: content.includes('footer')
        };
        
        console.log('🔍 Features detected:');
        Object.entries(features).forEach(([feature, present]) => {
          console.log(`   ${feature}: ${present ? '✅' : '❌'}`);
        });
      }
      
      console.log('---');
      
    } catch (error) {
      console.error(`❌ Test failed for ${testCase.name}:`, error.message);
      console.log('---');
    }
  }
  
  console.log('🎉 Improved Premium Generation Test Completed!');
};

testImprovedPremiumGeneration();