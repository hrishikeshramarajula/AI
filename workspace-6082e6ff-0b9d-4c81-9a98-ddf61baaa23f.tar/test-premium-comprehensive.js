const testPremiumWithRetry = async () => {
  console.log('🧪 Testing Premium Webpage Generation with Retry Logic...\n');
  
  const testPrompt = 'Create a professional business website';
  const maxRetries = 3;
  const timeoutMs = 180000; // 3 minutes
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    console.log(`📤 Attempt ${attempt}/${maxRetries}`);
    console.log('📝 Test prompt:', testPrompt);
    
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
      
      const startTime = Date.now();
      
      const response = await fetch('http://localhost:3000/api/premium-webpage', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: testPrompt,
          features: ['navigation', 'hero', 'services', 'contact', 'footer']
        }),
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      const endTime = Date.now();
      const duration = (endTime - startTime) / 1000;
      
      console.log(`⏱️  Request completed in ${duration} seconds`);
      console.log(`📊 Response status: ${response.status}`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      console.log('✅ Premium generation successful!');
      console.log('📋 Response summary:');
      console.log(`   - Success: ${data.success}`);
      console.log(`   - Files generated: ${data.files?.length || 0}`);
      console.log(`   - Tasks created: ${data.tasks?.length || 0}`);
      
      if (data.files && data.files.length > 0) {
        console.log('\n📁 Generated files:');
        data.files.forEach((file, index) => {
          console.log(`   ${index + 1}. ${file.name} (${file.language}) - ${Math.round(file.content.length / 1024)}KB`);
        });
        
        // Show a sample of the HTML content
        const htmlFile = data.files.find(f => f.language === 'html');
        if (htmlFile) {
          console.log('\n📝 HTML content sample (first 500 chars):');
          console.log(htmlFile.content.substring(0, 500) + '...');
        }
      }
      
      console.log('\n🎉 Premium Webpage Generation Test Completed Successfully!');
      return true;
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error(`❌ Attempt ${attempt} failed:`, errorMessage);
      
      if (attempt === maxRetries) {
        console.error('🔍 All retry attempts exhausted');
        return false;
      }
      
      console.log(`⏳ Waiting before retry ${attempt + 1}...`);
      await new Promise(resolve => setTimeout(resolve, 2000)); // Wait 2 seconds before retry
    }
  }
  
  return false;
};

// Additional test to check server health and connection
const testServerHealth = async () => {
  console.log('🏥 Testing Server Health...\n');
  
  try {
    const response = await fetch('http://localhost:3000/api/health');
    console.log('✅ Server health check passed');
    console.log(`📊 Health status: ${response.status}`);
    return true;
  } catch (error) {
    console.error('❌ Server health check failed:', error.message);
    return false;
  }
};

// Run all tests
const runAllTests = async () => {
  console.log('🚀 Starting Comprehensive Premium Generation Tests\n');
  
  // Test server health first
  const healthOk = await testServerHealth();
  if (!healthOk) {
    console.log('💡 Please start the development server with: npm run dev');
    return;
  }
  
  console.log('\n' + '='.repeat(50) + '\n');
  
  // Test premium generation with retry
  const premiumOk = await testPremiumWithRetry();
  
  console.log('\n' + '='.repeat(50) + '\n');
  
  if (premiumOk) {
    console.log('🎉 All tests passed! Premium generation is working correctly.');
    console.log('💡 The 502 error might be due to temporary network issues or timeouts.');
    console.log('💡 The premium generation takes 60-120 seconds, which is normal.');
  } else {
    console.log('❌ Premium generation failed. There might be a persistent issue.');
    console.log('💡 Check the server logs for more details.');
  }
};

runAllTests();