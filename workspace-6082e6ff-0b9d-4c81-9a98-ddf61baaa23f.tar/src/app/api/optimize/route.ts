import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

interface OptimizationRequest {
  code: string
  language: string
  optimizationType: 'performance' | 'readability' | 'security' | 'all'
  autoFix: boolean
}

interface OptimizationReport {
  originalCode: string
  optimizedCode: string
  improvements: CodeImprovement[]
  metrics: {
    performance: number
    readability: number
    security: number
    overall: number
  }
  explanation: string
  autoFixes: AutoFix[]
}

interface CodeImprovement {
  type: 'performance' | 'readability' | 'security' | 'best-practice'
  description: string
  suggestion: string
  impact: 'high' | 'medium' | 'low'
  line?: number
}

interface AutoFix {
  description: string
  original: string
  fixed: string
  reason: string
}

export async function POST(request: NextRequest) {
  try {
    const { code, language, optimizationType, autoFix }: OptimizationRequest = await request.json()
    
    if (!code || !language) {
      return NextResponse.json({
        success: false,
        error: 'Code and language are required'
      }, { status: 400 })
    }

    const zai = await ZAI.create()
    
    // Analyze code for optimization opportunities
    const analysis = await analyzeOptimizationOpportunities(code, language, optimizationType)
    
    // Generate optimizations using AI
    const optimizations = await generateOptimizations(zai, code, language, analysis, optimizationType)
    
    // Apply auto-fixes if requested
    let finalCode = code
    const autoFixes: AutoFix[] = []
    
    if (autoFix) {
      const autoFixResult = await applyAutoFixes(code, optimizations.improvements)
      finalCode = autoFixResult.code
      autoFixes.push(...autoFixResult.fixes)
    }
    
    // Calculate metrics
    const metrics = calculateOptimizationMetrics(optimizations.improvements)
    
    const report: OptimizationReport = {
      originalCode: code,
      optimizedCode: finalCode,
      improvements: optimizations.improvements,
      metrics,
      explanation: optimizations.explanation,
      autoFixes
    }
    
    return NextResponse.json({
      success: true,
      report,
      message: 'Code optimization completed successfully'
    })
    
  } catch (error) {
    console.error('Optimization error:', error)
    return NextResponse.json({
      success: false,
      error: 'Failed to optimize code'
    }, { status: 500 })
  }
}

async function analyzeOptimizationOpportunities(code: string, language: string, optimizationType: string) {
  const opportunities: any[] = []
  
  // Performance optimizations
  if (optimizationType === 'performance' || optimizationType === 'all') {
    // Check for DOM manipulation in loops
    if (language === 'javascript') {
      const domInLoops = code.match(/for\s*\([^)]*\)\s*{[^}]*\.(innerHTML|appendChild|removeChild)/g)
      if (domInLoops) {
        opportunities.push({
          type: 'performance',
          pattern: 'dom-in-loop',
          severity: 'high',
          description: 'DOM manipulation inside loops',
          suggestion: 'Cache DOM elements or use document fragments'
        })
      }
      
      // Check for expensive selectors
      const expensiveSelectors = code.match(/document\.querySelectorAll\(/g)
      if (expensiveSelectors && expensiveSelectors.length > 2) {
        opportunities.push({
          type: 'performance',
          pattern: 'expensive-selectors',
          severity: 'medium',
          description: 'Multiple expensive DOM queries',
          suggestion: 'Cache query results or use more specific selectors'
        })
      }
      
      // Check for synchronous operations
      if (code.includes('setTimeout(') || code.includes('setInterval(')) {
        opportunities.push({
          type: 'performance',
          pattern: 'timer-functions',
          severity: 'low',
          description: 'Timer functions detected',
          suggestion: 'Ensure proper cleanup and consider async alternatives'
        })
      }
    }
  }
  
  // Readability optimizations
  if (optimizationType === 'readability' || optimizationType === 'all') {
    // Check for long functions
    const functionBlocks = code.split(/function\s+\w+\s*\([^)]*\)\s*\{/)
    functionBlocks.forEach((block, index) => {
      const lines = block.split('\n').length
      if (lines > 30) {
        opportunities.push({
          type: 'readability',
          pattern: 'long-function',
          severity: 'medium',
          description: `Function ${index + 1} is too long (${lines} lines)`,
          suggestion: 'Break down into smaller, focused functions'
        })
      }
    })
    
    // Check for deep nesting
    const maxIndent = Math.max(...code.split('\n').map(line => 
      line.match(/^\s*/)?.[0]?.length || 0
    ))
    if (maxIndent > 8) {
      opportunities.push({
        type: 'readability',
        pattern: 'deep-nesting',
        severity: 'medium',
        description: 'Code is deeply nested',
        suggestion: 'Reduce nesting by extracting logic or using early returns'
      })
    }
    
    // Check for magic numbers
    const magicNumbers = code.match(/\b\d{2,}\b/g)
    if (magicNumbers && magicNumbers.length > 3) {
      opportunities.push({
        type: 'readability',
        pattern: 'magic-numbers',
        severity: 'low',
        description: 'Magic numbers detected',
        suggestion: 'Replace magic numbers with named constants'
      })
    }
  }
  
  // Security optimizations
  if (optimizationType === 'security' || optimizationType === 'all') {
    if (language === 'javascript') {
      // Check for eval()
      if (code.includes('eval(')) {
        opportunities.push({
          type: 'security',
          pattern: 'eval-usage',
          severity: 'critical',
          description: 'Use of eval() detected',
          suggestion: 'Replace with safer alternatives like JSON.parse()'
        })
      }
      
      // Check for innerHTML
      if (code.includes('innerHTML')) {
        opportunities.push({
          type: 'security',
          pattern: 'inner-html',
          severity: 'high',
          description: 'Use of innerHTML detected',
          suggestion: 'Use textContent or DOM manipulation methods'
        })
      }
      
      // Check for hardcoded secrets
      const secretPatterns = [
        /password\s*=\s*['"][^'"]+['"]/i,
        /api_key\s*=\s*['"][^'"]+['"]/i,
        /secret\s*=\s*['"][^'"]+['"]/i
      ]
      
      secretPatterns.forEach((pattern, index) => {
        if (pattern.test(code)) {
          opportunities.push({
            type: 'security',
            pattern: 'hardcoded-secrets',
            severity: 'critical',
            description: 'Potential hardcoded sensitive data',
            suggestion: 'Move to environment variables or secure configuration'
          })
        }
      })
    }
  }
  
  return opportunities
}

async function generateOptimizations(zai: any, code: string, language: string, opportunities: any[], optimizationType: string) {
  const improvements: CodeImprovement[] = []
  
  for (const opportunity of opportunities) {
    const improvement: CodeImprovement = {
      type: opportunity.type,
      description: opportunity.description,
      suggestion: opportunity.suggestion,
      impact: getImpactFromSeverity(opportunity.severity)
    }
    
    improvements.push(improvement)
  }
  
  // Generate AI-powered optimization explanation
  const systemPrompt = `You are an expert ${language} developer specializing in code optimization and performance tuning. Analyze the provided code and generate specific optimization recommendations.`
  
  const userPrompt = `Analyze this ${language} code for ${optimizationType} optimizations:

${code}

Opportunities identified:
${opportunities.map((opp: any) => `- ${opp.description}: ${opp.suggestion}`).join('\n')}

Provide specific optimization recommendations and explain the improvements.`

  const completion = await zai.chat.completions.create({
    messages: [
      {
        role: 'system',
        content: systemPrompt
      },
      {
        role: 'user',
        content: userPrompt
      }
    ],
    temperature: 0.7,
    max_tokens: 1500
  })
  
  const explanation = completion.choices[0]?.message?.content || 'No explanation available.'
  
  return {
    improvements,
    explanation
  }
}

async function applyAutoFixes(code: string, improvements: CodeImprovement[]) {
  let fixedCode = code
  const fixes: AutoFix[] = []
  
  for (const improvement of improvements) {
    if (improvement.impact === 'high') {
      const fix = await generateAutoFix(code, improvement)
      if (fix) {
        fixedCode = fix.fixedCode
        fixes.push(fix)
      }
    }
  }
  
  return { code: fixedCode, fixes }
}

async function generateAutoFix(code: string, improvement: CodeImprovement): Promise<AutoFix | null> {
  // Simple auto-fixes for common patterns
  switch (improvement.type) {
    case 'performance':
      if (improvement.description.includes('DOM manipulation inside loops')) {
        return {
          description: 'Optimize DOM manipulation in loops',
          original: code,
          fixed: code.replace(
            /for\s*\([^)]*\)\s*{([^}]*\.(innerHTML|appendChild|removeChild)[^}]*)}/g,
            (match, content) => {
              return `// Cache DOM elements before loop
const fragment = document.createDocumentFragment();
for (...) {
  ${content.replace(/\.(innerHTML|appendChild|removeChild)/g, 'fragment.$1')}
}
// Append fragment once
document.body.appendChild(fragment);`
            }
          ),
          reason: 'Reduced DOM reflows by batching operations'
        }
      }
      break
      
    case 'readability':
      if (improvement.description.includes('long function')) {
        return {
          description: 'Extract long function into smaller functions',
          original: code,
          fixed: code + '\n\n// TODO: Extract long function into smaller, focused functions',
          reason: 'Improved code readability and maintainability'
        }
      }
      break
      
    case 'security':
      if (improvement.description.includes('eval()')) {
        return {
          description: 'Replace eval() with safer alternative',
          original: code,
          fixed: code.replace(/eval\(([^)]+)\)/g, 'JSON.parse($1)'),
          reason: 'Eliminated code injection vulnerability'
        }
      }
      break
  }
  
  return null
}

function calculateOptimizationMetrics(improvements: CodeImprovement[]) {
  const metrics = {
    performance: 100,
    readability: 100,
    security: 100,
    overall: 100
  }
  
  improvements.forEach(improvement => {
    const impactScore = improvement.impact === 'high' ? 20 : improvement.impact === 'medium' ? 10 : 5
    
    switch (improvement.type) {
      case 'performance':
        metrics.performance -= impactScore
        break
      case 'readability':
        metrics.readability -= impactScore
        break
      case 'security':
        metrics.security -= impactScore * 2 // Security issues are more critical
        break
    }
  })
  
  // Ensure metrics don't go below 0
  metrics.performance = Math.max(0, metrics.performance)
  metrics.readability = Math.max(0, metrics.readability)
  metrics.security = Math.max(0, metrics.security)
  
  // Calculate overall score
  metrics.overall = Math.round((metrics.performance + metrics.readability + metrics.security) / 3)
  
  return metrics
}

function getImpactFromSeverity(severity: string): 'high' | 'medium' | 'low' {
  switch (severity) {
    case 'critical':
    case 'high':
      return 'high'
    case 'medium':
      return 'medium'
    case 'low':
    default:
      return 'low'
  }
}

export async function GET() {
  return NextResponse.json({
    message: 'Code Optimization API is running',
    endpoints: {
      optimize: 'POST /api/optimize - Optimize code',
      health: 'GET /api/optimize - Health check'
    },
    optimizationTypes: [
      'performance - Optimize for performance and speed',
      'readability - Improve code readability and maintainability',
      'security - Fix security vulnerabilities',
      'all - Apply all optimizations'
    ]
  })
}