import { NextRequest, NextResponse } from 'next/server'

interface Template {
  id: string
  name: string
  category: 'frontend' | 'backend' | 'database' | 'testing' | 'utility'
  language: string
  description: string
  files: TemplateFile[]
  dependencies?: string[]
  setup?: string
}

interface TemplateFile {
  name: string
  content: string
  path: string
  language: string
}

const templates: Template[] = [
  // Frontend Templates
  {
    id: 'react-component',
    name: 'React Component',
    category: 'frontend',
    language: 'javascript',
    description: 'A reusable React component with props, state, and lifecycle methods',
    files: [
      {
        name: 'Component.jsx',
        content: `import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';

/**
 * A reusable React component with props and state management
 * @param {Object} props - Component props
 * @param {string} props.title - The title of the component
 * @param {string} props.subtitle - The subtitle of the component
 * @param {boolean} props.showDetails - Whether to show detailed information
 * @param {Function} props.onAction - Callback function for actions
 */
const Component = ({ title, subtitle, showDetails = false, onAction }) => {
  const [count, setCount] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [data, setData] = useState(null);

  useEffect(() => {
    if (showDetails) {
      fetchData();
    }
  }, [showDetails]);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      // Simulate API call
      const response = await fetch('/api/data');
      const result = await response.json();
      setData(result);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAction = () => {
    setCount(prev => prev + 1);
    if (onAction) {
      onAction(count + 1);
    }
  };

  return (
    <div className="component-container">
      <div className="component-header">
        <h2>{title}</h2>
        {subtitle && <p className="subtitle">{subtitle}</p>}
      </div>
      
      <div className="component-body">
        <p>Count: {count}</p>
        <button onClick={handleAction} className="action-button">
          Action
        </button>
      </div>

      {showDetails && (
        <div className="component-details">
          <h3>Details</h3>
          {isLoading ? (
            <p>Loading...</p>
          ) : data ? (
            <pre>{JSON.stringify(data, null, 2)}</pre>
          ) : (
            <p>No data available</p>
          )}
        </div>
      )}
    </div>
  );
};

Component.propTypes = {
  title: PropTypes.string.isRequired,
  subtitle: PropTypes.string,
  showDetails: PropTypes.bool,
  onAction: PropTypes.func
};

export default Component;`,
        path: 'src/components/',
        language: 'javascript'
      },
      {
        name: 'Component.css',
        content: `.component-container {
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 16px;
  margin: 16px 0;
  background: white;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.component-header {
  margin-bottom: 16px;
}

.component-header h2 {
  margin: 0 0 8px 0;
  color: #333;
}

.subtitle {
  color: #666;
  margin: 0;
}

.component-body {
  margin-bottom: 16px;
}

.action-button {
  background: #007bff;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
}

.action-button:hover {
  background: #0056b3;
}

.component-details {
  background: #f8f9fa;
  padding: 12px;
  border-radius: 4px;
  border-top: 1px solid #ddd;
}

.component-details h3 {
  margin: 0 0 8px 0;
  color: #333;
}

.component-details pre {
  background: white;
  padding: 8px;
  border-radius: 4px;
  overflow-x: auto;
  font-size: 12px;
}`,
        path: 'src/components/',
        language: 'css'
      }
    ],
    dependencies: ['react', 'prop-types'],
    setup: 'npm install react prop-types'
  },

  {
    id: 'api-endpoint',
    name: 'REST API Endpoint',
    category: 'backend',
    language: 'javascript',
    description: 'A REST API endpoint with proper error handling and validation',
    files: [
      {
        name: 'route.js',
        content: `const express = require('express');
const { body, validationResult } = require('express-validator');
const router = express.Router();

/**
 * GET /api/users - Get all users
 * Query params: page, limit, search
 */
router.get('/users', async (req, res) => {
  try {
    const { page = 1, limit = 10, search = '' } = req.query;
    
    // Validate query parameters
    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    
    if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
      return res.status(400).json({
        error: 'Invalid pagination parameters',
        message: 'Page and limit must be positive numbers'
      });
    }

    // Simulate database query
    const users = [
      { id: 1, name: 'John Doe', email: 'john@example.com' },
      { id: 2, name: 'Jane Smith', email: 'jane@example.com' }
    ];

    const filteredUsers = users.filter(user => 
      user.name.toLowerCase().includes(search.toLowerCase()) ||
      user.email.toLowerCase().includes(search.toLowerCase())
    );

    const startIndex = (pageNum - 1) * limitNum;
    const endIndex = startIndex + limitNum;
    const paginatedUsers = filteredUsers.slice(startIndex, endIndex);

    res.json({
      success: true,
      data: paginatedUsers,
      pagination: {
        current: pageNum,
        total: Math.ceil(filteredUsers.length / limitNum),
        count: filteredUsers.length
      }
    });

  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch users'
    });
  }
});

/**
 * POST /api/users - Create a new user
 */
router.post('/users',
  [
    body('name').trim().notEmpty().withMessage('Name is required'),
    body('email').isEmail().withMessage('Valid email is required'),
    body('age').optional().isInt({ min: 0 }).withMessage('Age must be a positive number')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          error: 'Validation failed',
          details: errors.array()
        });
      }

      const { name, email, age } = req.body;

      // Simulate user creation
      const newUser = {
        id: Date.now(),
        name,
        email,
        age: age || null,
        createdAt: new Date().toISOString()
      };

      res.status(201).json({
        success: true,
        data: newUser,
        message: 'User created successfully'
      });

    } catch (error) {
      console.error('Error creating user:', error);
      res.status(500).json({
        error: 'Internal server error',
        message: 'Failed to create user'
      });
    }
  }
);

/**
 * PUT /api/users/:id - Update a user
 */
router.put('/users/:id',
  [
    body('name').optional().trim().notEmpty().withMessage('Name cannot be empty'),
    body('email').optional().isEmail().withMessage('Valid email is required')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          error: 'Validation failed',
          details: errors.array()
        });
      }

      const { id } = req.params;
      const { name, email, age } = req.body;

      // Simulate user update
      const updatedUser = {
        id: parseInt(id),
        name: name || 'Updated Name',
        email: email || 'updated@example.com',
        age: age || null,
        updatedAt: new Date().toISOString()
      };

      res.json({
        success: true,
        data: updatedUser,
        message: 'User updated successfully'
      });

    } catch (error) {
      console.error('Error updating user:', error);
      res.status(500).json({
        error: 'Internal server error',
        message: 'Failed to update user'
      });
    }
  }
);

/**
 * DELETE /api/users/:id - Delete a user
 */
router.delete('/users/:id', async (req, res) => {
  try {
    const { id } = req.params;

    // Simulate user deletion
    res.json({
      success: true,
      message: 'User deleted successfully'
    });

  } catch (error) {
    console.error('Error deleting user:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to delete user'
    });
  }
});

module.exports = router;`,
        path: 'src/routes/',
        language: 'javascript'
      }
    ],
    dependencies: ['express', 'express-validator'],
    setup: 'npm install express express-validator'
  },

  {
    id: 'database-model',
    name: 'Database Model',
    category: 'database',
    language: 'javascript',
    description: 'A database model with validation, associations, and CRUD operations',
    files: [
      {
        name: 'User.js',
        content: `const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const bcrypt = require('bcryptjs');

/**
 * User model with authentication and validation
 */
const User = sequelize.define('User', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  username: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
    validate: {
      len: [3, 30],
      isAlphanumeric: true
    }
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
    validate: {
      isEmail: true
    }
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: {
      len: [6, 100]
    }
  },
  firstName: {
    type: DataTypes.STRING,
    allowNull: true,
    validate: {
      len: [1, 50]
    }
  },
  lastName: {
    type: DataTypes.STRING,
    allowNull: true,
    validate: {
      len: [1, 50]
    }
  },
  age: {
    type: DataTypes.INTEGER,
    allowNull: true,
    validate: {
      min: 0,
      max: 150
    }
  },
  isActive: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  },
  lastLogin: {
    type: DataTypes.DATE,
    allowNull: true
  },
  role: {
    type: DataTypes.ENUM('user', 'admin', 'moderator'),
    defaultValue: 'user'
  }
}, {
  tableName: 'users',
  timestamps: true,
  hooks: {
    beforeCreate: async (user) => {
      if (user.password) {
        user.password = await bcrypt.hash(user.password, 10);
      }
    },
    beforeUpdate: async (user) => {
      if (user.changed('password')) {
        user.password = await bcrypt.hash(user.password, 10);
      }
    }
  }
});

// Instance methods
User.prototype.comparePassword = async function(candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

User.prototype.toJSON = function() {
  const values = Object.assign({}, this.get());
  delete values.password;
  return values;
};

// Class methods
User.findByCredentials = async (email, password) => {
  const user = await User.findOne({ where: { email } });
  if (!user || !await user.comparePassword(password)) {
    throw new Error('Invalid login credentials');
  }
  return user;
};

// Define associations
User.associate = (models) => {
  User.hasMany(models.Post, {
    foreignKey: 'userId',
    as: 'posts'
  });
  
  User.hasMany(models.Comment, {
    foreignKey: 'userId',
    as: 'comments'
  });
};

module.exports = User;`,
        path: 'src/models/',
        language: 'javascript'
      }
    ],
    dependencies: ['sequelize', 'bcryptjs'],
    setup: 'npm install sequelize bcryptjs'
  },

  {
    id: 'auth-middleware',
    name: 'Authentication Middleware',
    category: 'backend',
    language: 'javascript',
    description: 'JWT-based authentication middleware with role-based access control',
    files: [
      {
        name: 'auth.js',
        content: `const jwt = require('jsonwebtoken');
const { User } = require('../models/User');

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '24h';

/**
 * Generate JWT token
 */
const generateToken = (user) => {
  return jwt.sign(
    { 
      id: user.id, 
      email: user.email, 
      role: user.role 
    },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
};

/**
 * Verify JWT token
 */
const verifyToken = (token) => {
  return jwt.verify(token, JWT_SECRET);
};

/**
 * Authentication middleware
 */
const authenticate = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({
        error: 'Access denied',
        message: 'No token provided'
      });
    }

    const decoded = verifyToken(token);
    const user = await User.findByPk(decoded.id);
    
    if (!user || !user.isActive) {
      return res.status(401).json({
        error: 'Access denied',
        message: 'Invalid token or user not active'
      });
    }

    req.user = user;
    next();
  } catch (error) {
    res.status(401).json({
      error: 'Access denied',
      message: 'Invalid token'
    });
  }
};

/**
 * Role-based authorization middleware
 */
const authorize = (roles = []) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        error: 'Access denied',
        message: 'User not authenticated'
      });
    }

    if (roles.length && !roles.includes(req.user.role)) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Insufficient permissions'
      });
    }

    next();
  };
};

/**
 * Optional authentication middleware (doesn't fail if no token)
 */
const optionalAuth = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (token) {
      const decoded = verifyToken(token);
      const user = await User.findByPk(decoded.id);
      
      if (user && user.isActive) {
        req.user = user;
      }
    }
    
    next();
  } catch (error) {
    // Continue without authentication
    next();
  }
};

/**
 * Login handler
 */
const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({
        error: 'Validation failed',
        message: 'Email and password are required'
      });
    }

    const user = await User.findByCredentials(email, password);
    
    // Update last login
    user.lastLogin = new Date();
    await user.save();

    const token = generateToken(user);

    res.json({
      success: true,
      data: {
        user: user.toJSON(),
        token
      },
      message: 'Login successful'
    });

  } catch (error) {
    res.status(401).json({
      error: 'Login failed',
      message: error.message
    });
  }
};

/**
 * Register handler
 */
const register = async (req, res) => {
  try {
    const { username, email, password, firstName, lastName } = req.body;
    
    // Check if user already exists
    const existingUser = await User.findOne({
      where: {
        $or: [{ email }, { username }]
      }
    });
    
    if (existingUser) {
      return res.status(400).json({
        error: 'Registration failed',
        message: 'User with this email or username already exists'
      });
    }

    // Create new user
    const user = await User.create({
      username,
      email,
      password,
      firstName,
      lastName
    });

    const token = generateToken(user);

    res.status(201).json({
      success: true,
      data: {
        user: user.toJSON(),
        token
      },
      message: 'Registration successful'
    });

  } catch (error) {
    res.status(400).json({
      error: 'Registration failed',
      message: error.message
    });
  }
};

module.exports = {
  authenticate,
  authorize,
  optionalAuth,
  login,
  register,
  generateToken,
  verifyToken
};`,
        path: 'src/middleware/',
        language: 'javascript'
      }
    ],
    dependencies: ['jsonwebtoken', 'sequelize'],
    setup: 'npm install jsonwebtoken sequelize'
  },

  {
    id: 'test-suite',
    name: 'Test Suite',
    category: 'testing',
    language: 'javascript',
    description: 'Comprehensive test suite with unit, integration, and API tests',
    files: [
      {
        name: 'user.test.js',
        content: `const request = require('supertest');
const app = require('../app');
const User = require('../models/User');

describe('User API', () => {
  beforeEach(async () => {
    // Clean up database before each test
    await User.destroy({ where: {} });
  });

  describe('POST /api/users', () => {
    it('should create a new user with valid data', async () => {
      const userData = {
        username: 'testuser',
        email: 'test@example.com',
        password: 'password123',
        firstName: 'Test',
        lastName: 'User'
      };

      const response = await request(app)
        .post('/api/users')
        .send(userData)
        .expect(201);

      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveProperty('id');
      expect(response.body.data.email).toBe(userData.email);
      expect(response.body.data).not.toHaveProperty('password');
    });

    it('should return validation error for invalid email', async () => {
      const userData = {
        username: 'testuser',
        email: 'invalid-email',
        password: 'password123'
      };

      const response = await request(app)
        .post('/api/users')
        .send(userData)
        .expect(400);

      expect(response.body.error).toBe('Validation failed');
      expect(response.body.details).toHaveLength(1);
      expect(response.body.details[0].path).toContain('email');
    });

    it('should return error for duplicate email', async () => {
      const userData = {
        username: 'testuser',
        email: 'test@example.com',
        password: 'password123'
      };

      // Create first user
      await request(app)
        .post('/api/users')
        .send(userData)
        .expect(201);

      // Try to create user with same email
      const response = await request(app)
        .post('/api/users')
        .send(userData)
        .expect(400);

      expect(response.body.error).toBe('Registration failed');
    });
  });

  describe('GET /api/users', () => {
    it('should return list of users', async () => {
      // Create test users
      await User.create({
        username: 'user1',
        email: 'user1@example.com',
        password: 'password123'
      });

      await User.create({
        username: 'user2',
        email: 'user2@example.com',
        password: 'password123'
      });

      const response = await request(app)
        .get('/api/users')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveLength(2);
      expect(response.body.pagination).toHaveProperty('total');
    });

    it('should filter users by search term', async () => {
      await User.create({
        username: 'john',
        email: 'john@example.com',
        password: 'password123'
      });

      await User.create({
        username: 'jane',
        email: 'jane@example.com',
        password: 'password123'
      });

      const response = await request(app)
        .get('/api/users?search=john')
        .expect(200);

      expect(response.body.data).toHaveLength(1);
      expect(response.body.data[0].username).toBe('john');
    });
  });

  describe('PUT /api/users/:id', () => {
    it('should update user data', async () => {
      const user = await User.create({
        username: 'testuser',
        email: 'test@example.com',
        password: 'password123'
      });

      const updateData = {
        firstName: 'Updated',
        lastName: 'Name'
      };

      const response = await request(app)
        .put(\`/api/users/\${user.id}\`)
        .send(updateData)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.firstName).toBe(updateData.firstName);
      expect(response.body.data.lastName).toBe(updateData.lastName);
    });

    it('should return 404 for non-existent user', async () => {
      const response = await request(app)
        .put('/api/users/99999')
        .send({ firstName: 'Updated' })
        .expect(404);

      expect(response.body.error).toBe('User not found');
    });
  });

  describe('DELETE /api/users/:id', () => {
    it('should delete user', async () => {
      const user = await User.create({
        username: 'testuser',
        email: 'test@example.com',
        password: 'password123'
      });

      await request(app)
        .delete(\`/api/users/\${user.id}\`)
        .expect(200);

      // Verify user is deleted
      const deletedUser = await User.findByPk(user.id);
      expect(deletedUser).toBeNull();
    });
  });
});

describe('User Model', () => {
  describe('User creation', () => {
    it('should create user with valid data', async () => {
      const user = await User.create({
        username: 'testuser',
        email: 'test@example.com',
        password: 'password123'
      });

      expect(user.id).toBeDefined();
      expect(user.username).toBe('testuser');
      expect(user.email).toBe('test@example.com');
      expect(user.password).not.toBe('password123'); // Should be hashed
    });

    it('should not create user with invalid email', async () => {
      await expect(User.create({
        username: 'testuser',
        email: 'invalid-email',
        password: 'password123'
      })).rejects.toThrow();
    });

    it('should not create user with duplicate username', async () => {
      await User.create({
        username: 'testuser',
        email: 'test1@example.com',
        password: 'password123'
      });

      await expect(User.create({
        username: 'testuser',
        email: 'test2@example.com',
        password: 'password123'
      })).rejects.toThrow();
    });
  });

  describe('Password hashing', () => {
    it('should hash password before creating user', async () => {
      const user = await User.create({
        username: 'testuser',
        email: 'test@example.com',
        password: 'password123'
      });

      expect(user.password).not.toBe('password123');
      expect(user.password.length).toBeGreaterThan(50); // bcrypt hash length
    });

    it('should compare password correctly', async () => {
      const user = await User.create({
        username: 'testuser',
        email: 'test@example.com',
        password: 'password123'
      });

      const isValid = await user.comparePassword('password123');
      expect(isValid).toBe(true);

      const isInvalid = await user.comparePassword('wrongpassword');
      expect(isInvalid).toBe(false);
    });
  });
});`,
        path: 'tests/',
        language: 'javascript'
      }
    ],
    dependencies: ['supertest', 'jest'],
    setup: 'npm install supertest jest --save-dev'
  }
];

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const category = searchParams.get('category')
  const language = searchParams.get('language')

  let filteredTemplates = templates

  if (category) {
    filteredTemplates = filteredTemplates.filter(
      template => template.category === category
    )
  }

  if (language) {
    filteredTemplates = filteredTemplates.filter(
      template => template.language === language
    )
  }

  return NextResponse.json({
    success: true,
    templates: filteredTemplates,
    categories: ['frontend', 'backend', 'database', 'testing', 'utility'],
    languages: ['javascript', 'typescript', 'python', 'java']
  })
}

export async function POST(request: NextRequest) {
  try {
    const { templateId, customizations = {} } = await request.json()
    
    const template = templates.find(t => t.id === templateId)
    
    if (!template) {
      return NextResponse.json({
        success: false,
        error: 'Template not found'
      }, { status: 404 })
    }

    // Apply customizations to template files
    const customizedFiles = template.files.map(file => ({
      ...file,
      content: applyCustomizations(file.content, customizations)
    }))

    return NextResponse.json({
      success: true,
      template: {
        ...template,
        files: customizedFiles
      },
      message: 'Template customized successfully'
    })

  } catch (error) {
    console.error('Template error:', error)
    return NextResponse.json({
      success: false,
      error: 'Failed to process template'
    }, { status: 500 })
  }
}

function applyCustomizations(content: string, customizations: any): string {
  let customizedContent = content

  // Apply common customizations
  if (customizations.projectName) {
    customizedContent = customizedContent.replace(
      /Component/g,
      customizations.projectName.charAt(0).toUpperCase() + customizations.projectName.slice(1)
    )
  }

  if (customizations.author) {
    customizedContent = customizedContent.replace(
      /@author/g,
      `@author ${customizations.author}`
    )
  }

  if (customizations.database) {
    customizedContent = customizedContent.replace(
      /sequelize/g,
      customizations.database
    )
  }

  return customizedContent
}