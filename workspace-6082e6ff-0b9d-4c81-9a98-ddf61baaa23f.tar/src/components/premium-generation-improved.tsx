// Improved Premium Generation Function with Better Error Handling
const generatePremiumWebpageImproved = async () => {
  if (!prompt.trim()) {
    addConsoleOutput('error', 'Please enter a prompt to generate premium webpage')
    return
  }
  
  setIsGenerating(true)
  addConsoleOutput('info', `🚀 Starting premium webpage generation for: "${prompt}"`)
  addConsoleOutput('info', '🤖 Initializing Premium Webpage Generator...')
  
  const maxRetries = 2
  const timeoutMs = 180000 // 3 minutes
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      if (attempt > 1) {
        addConsoleOutput('info', `🔄 Retry attempt ${attempt}/${maxRetries}...`)
      }
      
      // Create a timeout promise with AbortController
      const controller = new AbortController()
      const timeoutId = setTimeout(() => {
        controller.abort()
        addConsoleOutput('error', `⏰ Request timeout after ${timeoutMs / 1000} seconds`)
      }, timeoutMs)
      
      addConsoleOutput('info', `📤 Sending request to premium API (attempt ${attempt})...`)
      
      // Create the fetch promise
      const fetchPromise = fetch('/api/premium-webpage', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: prompt,
          features: [
            'navigation',
            'hero', 
            'services',
            'detailedServices',
            'about',
            'testimonials',
            'contact',
            'footer',
            'backToTop'
          ]
        }),
        signal: controller.signal
      })
      
      // Race between fetch and timeout
      const response = await Promise.race([fetchPromise, new Promise((_, reject) => {
        setTimeout(() => reject(new Error('Request timeout')), timeoutMs)
      })]) as Response
      
      clearTimeout(timeoutId)
      
      addConsoleOutput('info', `📊 Response received: ${response.status}`)
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      
      const data = await response.json()
      
      // Validate response data
      if (!data.success) {
        throw new Error(data.error || 'Premium generation failed')
      }
      
      if (!data.files || !Array.isArray(data.files) || data.files.length === 0) {
        throw new Error('No files generated')
      }
      
      // Validate files have content
      const validFiles = data.files.filter(file => 
        file.content && file.content.trim().length > 0
      )
      
      if (validFiles.length === 0) {
        throw new Error('Generated files are empty')
      }
      
      addConsoleOutput('success', `✅ Premium generation successful!`)
      addConsoleOutput('info', `📁 Generated ${validFiles.length} valid files`)
      
      // Use premium-generated files
      const newFiles: File[] = []
      
      validFiles.forEach((fileData: any, index: number) => {
        newFiles.push({
          id: (index + 1).toString(),
          name: fileData.name,
          content: fileData.content,
          language: fileData.language,
          lastModified: new Date()
        })
      })
      
      setFiles(newFiles)
      setActiveFile('1') // Select first file (usually HTML)
      
      // Add tasks from the premium generation
      if (data.tasks && Array.isArray(data.tasks)) {
        const premiumTasks: Task[] = data.tasks.map((task: any) => ({
          id: task.id,
          title: task.title,
          description: task.description,
          status: task.status,
          priority: task.priority,
          createdAt: new Date(task.createdAt)
        }))
        setTasks(prev => [...prev, ...premiumTasks])
        addConsoleOutput('info', `📋 Added ${premiumTasks.length} tasks`)
      }
      
      // Add console logs from premium generation
      if (data.consoleLogs && Array.isArray(data.consoleLogs)) {
        const premiumConsoleLogs: ConsoleOutput[] = data.consoleLogs.map((log: any) => ({
          id: log.id,
          type: log.type,
          message: log.message,
          timestamp: new Date(log.timestamp)
        }))
        setConsoleOutput(prev => [...prev, ...premiumConsoleLogs])
        addConsoleOutput('info', `📝 Added ${premiumConsoleLogs.length} console logs`)
      }
      
      // Add final console outputs
      addConsoleOutput('success', `🎉 Premium webpage generated successfully!`)
      addConsoleOutput('info', `📁 Generated ${validFiles.length} premium files with all advanced features`)
      
      if (data.explanation) {
        addConsoleOutput('success', `🤖 Premium AI Explanation: ${data.explanation}`)
      }
      
      // Update preview
      setTimeout(() => {
        updatePreview()
        setShowPreview(true)
      }, 500)
      
      toast({
        title: "Premium Webpage Generated Successfully",
        description: `Created ${validFiles.length} premium files with advanced features`,
      })
      
      // Success - break out of retry loop
      break
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred'
      addConsoleOutput('error', `❌ Attempt ${attempt} failed: ${errorMessage}`)
      
      if (attempt === maxRetries) {
        addConsoleOutput('error', `❌ All retry attempts exhausted`)
        addConsoleOutput('info', '🛠️ Premium API unavailable. Please try standard generation...')
        
        toast({
          title: "Premium Generation Unavailable",
          description: "Please try standard webpage generation",
          variant: "destructive"
        })
      } else {
        addConsoleOutput('info', `⏳ Waiting ${2} seconds before retry...`)
        await new Promise(resolve => setTimeout(resolve, 2000))
      }
    }
  }
  
  setIsGenerating(false)
}

// Export the function to be used in the main component
export { generatePremiumWebpageImproved }