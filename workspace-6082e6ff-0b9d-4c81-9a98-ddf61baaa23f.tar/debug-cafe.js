// Debug script to check actual API response
const debugCafePrompt = async () => {
  console.log('🔍 DEBUGGING CAFE API RESPONSE...');
  
  try {
    const response = await fetch('http://localhost:3000/api/ai-prompt', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: 'designe me an cafe webpage',
        type: 'complete-webpage'
      })
    });
    
    console.log('Response status:', response.status);
    console.log('Response headers:', response.headers);
    
    const data = await response.json();
    
    console.log('Full API Response:');
    console.log(JSON.stringify(data, null, 2));
    
  } catch (error) {
    console.log('Error:', error.message);
  }
};

debugCafePrompt();