// Debug script to see exactly what the AI is returning
const debugAIResponse = async () => {
  console.log('🔍 Debugging AI Response Format...');
  
  try {
    const response = await fetch('http://localhost:3000/api/ai-prompt', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: "Create a simple test webpage with HTML, CSS, and JavaScript",
        type: 'complete-webpage'
      })
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const data = await response.json();
    
    console.log('📊 API Response:');
    console.log(`Success: ${data.success}`);
    console.log(`Files: ${data.files?.length || 0}`);
    
    if (data.files && data.files.length > 0) {
      console.log('\n📄 Files returned:');
      data.files.forEach((file, index) => {
        console.log(`\n--- File ${index + 1}: ${file.name} ---`);
        console.log(`Language: ${file.language}`);
        console.log(`Content Length: ${file.content.length}`);
        if (file.content.length > 0) {
          console.log('First 500 characters:');
          console.log(file.content.substring(0, 500));
          console.log('...');
        } else {
          console.log('❌ Empty content');
        }
      });
    }
    
    // Now let's test what happens when we get a raw response
    console.log('\n🔍 Testing raw AI response...');
    
    // Let's make a direct test to see the raw content
    const testResponse = await fetch('http://localhost:3000/api/ai-prompt', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: "Return HTML, CSS, and JavaScript in separate code blocks",
        type: 'complete-webpage'
      })
    });
    
    const testData = await testResponse.json();
    
    if (testData.files && testData.files.length > 0) {
      const htmlContent = testData.files[0].content;
      console.log('📝 Raw HTML Content Analysis:');
      console.log('Contains ```html block:', htmlContent.includes('```html'));
      console.log('Contains ```css block:', htmlContent.includes('```css'));
      console.log('Contains ```js block:', htmlContent.includes('```js'));
      console.log('Contains ```javascript block:', htmlContent.includes('```javascript'));
      
      // Show different types of code blocks that might be present
      const codeBlocks = htmlContent.match(/```[\s\S]*?```/g) || [];
      console.log(`\n🔍 Found ${codeBlocks.length} code blocks:`);
      codeBlocks.forEach((block, index) => {
        console.log(`Block ${index + 1}: ${block.substring(0, 100)}...`);
      });
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
};

debugAIResponse();