// Test script for the todo list prompt
const testTodoPrompt = async () => {
  console.log('🧪 Testing AI-IDE Clone System with Todo List Prompt...');
  
  const prompt = "Create me a complete todo list webpage with add, edit, delete, and mark as complete functionality";
  
  try {
    const response = await fetch('http://localhost:3000/api/ai-prompt', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: prompt,
        type: 'complete-webpage'
      })
    });
    
    const data = await response.json();
    
    console.log('✅ API Response Received:');
    console.log('- Success:', data.success);
    console.log('- Files generated:', data.files?.length || 0);
    
    if (data.files) {
      data.files.forEach((file, index) => {
        console.log(`\n📁 File ${index + 1}: ${file.name} (${file.language})`);
        console.log('Preview (first 200 chars):');
        console.log(file.content.substring(0, 200) + '...');
      });
    }
    
    if (data.explanation) {
      console.log('\n🤖 AI Explanation:');
      console.log(data.explanation);
    }
    
    console.log('\n🎉 Test completed successfully!');
    console.log('🌐 Open http://localhost:3000 to see the complete AI-IDE Clone system');
    console.log('💡 Enter the todo list prompt in the Prompt tab to see it work live!');
    
  } catch (error) {
    console.error('❌ Test failed:', error);
  }
};

// Run the test
testTodoPrompt();