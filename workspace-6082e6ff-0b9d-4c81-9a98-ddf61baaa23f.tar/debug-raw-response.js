// Debug script to see the raw AI response
const debugRawResponse = async () => {
  console.log('🔍 Debugging Raw AI Response...');
  
  try {
    const response = await fetch('http://localhost:3000/api/ai-prompt', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: "Create a simple test webpage with HTML, CSS, and JavaScript",
        type: 'complete-webpage'
      })
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const data = await response.json();
    
    console.log('📊 API Response Structure:');
    console.log(`Success: ${data.success}`);
    console.log(`Files count: ${data.files?.length || 0}`);
    
    if (data.files && data.files.length > 0) {
      console.log('\n📄 Files Details:');
      data.files.forEach((file, index) => {
        console.log(`\n--- File ${index + 1}: ${file.name} ---`);
        console.log(`Language: ${file.language}`);
        console.log(`Content length: ${file.content.length} characters`);
        
        if (file.content.length > 0) {
          console.log('Content preview:');
          console.log('----------------------------------------');
          console.log(file.content);
          console.log('----------------------------------------');
        } else {
          console.log('❌ EMPTY CONTENT');
        }
      });
    }
    
    // Now let's test the fallback system by forcing a timeout
    console.log('\n🔄 Testing fallback system...');
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
};

debugRawResponse();