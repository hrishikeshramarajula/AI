// Fullstack Application Generator - Creates complete frontend + backend from text prompts
import { createSuccessResponse, createErrorResponse } from './apiUtils';

export interface ProjectStructure {
  name: string;
  description: string;
  type: 'web' | 'api' | 'fullstack';
  framework: 'nextjs' | 'react' | 'express' | 'fastapi';
  database: 'sqlite' | 'postgresql' | 'mongodb' | 'none';
  features: string[];
}

export interface GeneratedFile {
  path: string;
  content: string;
  type: 'frontend' | 'backend' | 'database' | 'config' | 'docs';
}

export interface FullstackProject {
  structure: ProjectStructure;
  files: GeneratedFile[];
  setupInstructions: string[];
  dependencies: string[];
  devDependencies: string[];
  scripts: Record<string, string>;
}

export class FullstackGenerator {
  
  /**
   * Analyze user prompt and determine what kind of application to build
   */
  static analyzePrompt(prompt: string): {
    intent: string;
    projectType: ProjectStructure;
    complexity: 'simple' | 'medium' | 'complex';
    features: string[];
  } {
    const lowerPrompt = prompt.toLowerCase();
    
    // Determine project type and features
    let projectType: ProjectStructure = {
      name: 'web-application',
      description: 'A modern web application',
      type: 'fullstack',
      framework: 'nextjs',
      database: 'sqlite',
      features: []
    };

    // Detect common application types
    if (lowerPrompt.includes('todo') || lowerPrompt.includes('task')) {
      projectType = {
        name: 'todo-app',
        description: 'A todo list application with CRUD operations',
        type: 'fullstack',
        framework: 'nextjs',
        database: 'sqlite',
        features: ['crud', 'authentication', 'real-time', 'responsive']
      };
    } else if (lowerPrompt.includes('blog') || lowerPrompt.includes('cms')) {
      projectType = {
        name: 'blog-cms',
        description: 'A blog content management system',
        type: 'fullstack',
        framework: 'nextjs',
        database: 'postgresql',
        features: ['cms', 'markdown', 'comments', 'authentication', 'admin-panel']
      };
    } else if (lowerPrompt.includes('ecommerce') || lowerPrompt.includes('shop')) {
      projectType = {
        name: 'ecommerce-platform',
        description: 'An e-commerce platform with shopping cart and payments',
        type: 'fullstack',
        framework: 'nextjs',
        database: 'postgresql',
        features: ['shopping-cart', 'payments', 'inventory', 'user-auth', 'admin-dashboard']
      };
    } else if (lowerPrompt.includes('chat') || lowerPrompt.includes('messaging')) {
      projectType = {
        name: 'chat-application',
        description: 'A real-time chat application',
        type: 'fullstack',
        framework: 'nextjs',
        database: 'sqlite',
        features: ['real-time', 'websockets', 'authentication', 'file-upload']
      };
    } else if (lowerPrompt.includes('dashboard') || lowerPrompt.includes('admin')) {
      projectType = {
        name: 'admin-dashboard',
        description: 'An administrative dashboard with data visualization',
        type: 'fullstack',
        framework: 'nextjs',
        database: 'postgresql',
        features: ['data-visualization', 'charts', 'tables', 'filters', 'export']
      };
    } else {
      // Default to a generic web application
      projectType = {
        name: 'custom-web-app',
        description: 'A custom web application based on your requirements',
        type: 'fullstack',
        framework: 'nextjs',
        database: 'sqlite',
        features: ['responsive', 'modern-ui', 'authentication']
      };
    }

    // Extract additional features from prompt
    const featureKeywords = {
      'authentication': ['auth', 'login', 'register', 'user', 'account'],
      'real-time': ['real-time', 'live', 'websocket', 'socket'],
      'database': ['database', 'db', 'storage', 'persist'],
      'api': ['api', 'rest', 'graphql', 'endpoint'],
      'responsive': ['responsive', 'mobile', 'phone', 'tablet'],
      'modern-ui': ['modern', 'ui', 'design', 'beautiful'],
      'charts': ['chart', 'graph', 'visualization', 'analytics'],
      'file-upload': ['file', 'upload', 'image', 'document'],
      'search': ['search', 'filter', 'find'],
      'pagination': ['pagination', 'page', 'navigate'],
      'forms': ['form', 'input', 'validation'],
      'notifications': ['notification', 'alert', 'toast']
    };

    Object.entries(featureKeywords).forEach(([feature, keywords]) => {
      if (keywords.some(keyword => lowerPrompt.includes(keyword))) {
        if (!projectType.features.includes(feature)) {
          projectType.features.push(feature);
        }
      }
    });

    // Determine complexity
    let complexity: 'simple' | 'medium' | 'complex' = 'simple';
    if (projectType.features.length > 5) {
      complexity = 'complex';
    } else if (projectType.features.length > 3) {
      complexity = 'medium';
    }

    return {
      intent: prompt,
      projectType,
      complexity,
      features: projectType.features
    };
  }

  /**
   * Generate complete fullstack project - Enhanced to work like AI Assistant
   */
  static async generateFullstackProject(prompt: string): Promise<FullstackProject> {
    const analysis = this.analyzePrompt(prompt);
    
    console.log('🚀 Generating fullstack project:', analysis.projectType.name);
    console.log('📋 Features:', analysis.features);
    console.log('🎯 Complexity:', analysis.complexity);
    
    const files: GeneratedFile[] = [];
    
    // Generate database schema
    const dbFiles = this.generateDatabaseSchema(analysis.projectType);
    files.push(...dbFiles);
    
    // Generate API routes
    const apiFiles = this.generateAPIRoutes(analysis.projectType);
    files.push(...apiFiles);
    
    // Generate frontend components
    const frontendFiles = this.generateFrontendComponents(analysis.projectType);
    files.push(...frontendFiles);
    
    // Generate configuration files
    const configFiles = this.generateConfigFiles(analysis.projectType);
    files.push(...configFiles);
    
    // Generate documentation
    const docsFiles = this.generateDocumentation(analysis.projectType);
    files.push(...docsFiles);

    // Generate enhanced preview component
    const previewFiles = this.generatePreviewComponent(analysis.projectType);
    files.push(...previewFiles);

    return {
      structure: analysis.projectType,
      files,
      setupInstructions: this.generateSetupInstructions(analysis.projectType),
      dependencies: this.generateDependencies(analysis.projectType),
      devDependencies: this.generateDevDependencies(analysis.projectType),
      scripts: this.generateScripts(analysis.projectType)
    };
  }

  /**
   * Generate database schema files
   */
  private static generateDatabaseSchema(project: ProjectStructure): GeneratedFile[] {
    const files: GeneratedFile[] = [];

    // Prisma schema
    let prismaSchema = `// This is your Prisma schema file,
// learn more about it in the docs: https://pris.ly/d/prisma-schema

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "${project.database === 'postgresql' ? 'postgresql' : 'sqlite'}"
  url      = env("DATABASE_URL")
}
`;

    // Add models based on project type
    if (project.name === 'todo-app') {
      prismaSchema += `
model Todo {
  id          String   @id @default(cuid())
  text        String
  completed   Boolean  @default(false)
  userId      String?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  
  user        User?    @relation(fields: [userId], references: [id])
  
  @@map("todos")
}

model User {
  id        String   @id @default(cuid())
  email     String   @unique
  name      String?
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  
  todos     Todo[]
  
  @@map("users")
}
`;
    } else if (project.name === 'blog-cms') {
      prismaSchema += `
model Post {
  id          String   @id @default(cuid())
  title       String
  content     String
  published   Boolean  @default(false)
  authorId    String
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  
  author      User     @relation(fields: [authorId], references: [id])
  comments    Comment[]
  
  @@map("posts")
}

model Comment {
  id        String   @id @default(cuid())
  content   String
  author    String?
  postId    String
  createdAt DateTime @default(now())
  
  post      Post     @relation(fields: [postId], references: [id])
  
  @@map("comments")
}

model User {
  id        String   @id @default(cuid())
  email     String   @unique
  name      String?
  bio       String?
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  
  posts     Post[]
  
  @@map("users")
}
`;
    } else {
      // Generic models for custom applications
      prismaSchema += `
model Item {
  id          String   @id @default(cuid())
  title       String
  description String?
  completed   Boolean  @default(false)
  userId      String?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  
  user        User?    @relation(fields: [userId], references: [id])
  
  @@map("items")
}

model User {
  id        String   @id @default(cuid())
  email     String   @unique
  name      String?
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  
  items     Item[]
  
  @@map("users")
}
`;
    }

    files.push({
      path: 'prisma/schema.prisma',
      content: prismaSchema,
      type: 'database'
    });

    // Database client
    files.push({
      path: 'src/lib/db.ts',
      content: `import { PrismaClient } from '@prisma/client';

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const db = globalForPrisma.prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db;
`,
      type: 'backend'
    });

    return files;
  }

  /**
   * Generate API routes
   */
  private static generateAPIRoutes(project: ProjectStructure): GeneratedFile[] {
    const files: GeneratedFile[] = [];

    // Main API route handler
    if (project.name === 'todo-app') {
      files.push({
        path: 'src/app/api/todos/route.ts',
        content: `import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/todos - Fetch all todos
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const filter = searchParams.get('filter') || 'all';
    
    let whereClause = {};
    
    if (filter === 'active') {
      whereClause = { completed: false };
    } else if (filter === 'completed') {
      whereClause = { completed: true };
    }
    
    const todos = await db.todo.findMany({
      where: whereClause,
      orderBy: { createdAt: 'desc' }
    });
    
    // Calculate stats
    const stats = await db.todo.groupBy({
      by: ['completed'],
      _count: { completed: true }
    });
    
    const totalTodos = stats.reduce((sum, stat) => sum + stat._count.completed, 0);
    const completedTodos = stats.find(stat => stat.completed)?._count.completed || 0;
    const activeTodos = totalTodos - completedTodos;
    
    return NextResponse.json({
      todos,
      stats: {
        total: totalTodos,
        completed: completedTodos,
        active: activeTodos
      }
    });
    
  } catch (error) {
    console.error('Error fetching todos:', error);
    return NextResponse.json(
      { error: 'Failed to fetch todos' },
      { status: 500 }
    );
  }
}

// POST /api/todos - Create new todo
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { text } = body;
    
    if (!text || typeof text !== 'string') {
      return NextResponse.json(
        { error: 'Todo text is required' },
        { status: 400 }
      );
    }
    
    const todo = await db.todo.create({
      data: {
        text: text.trim(),
        completed: false
      }
    });
    
    return NextResponse.json(todo, { status: 201 });
    
  } catch (error) {
    console.error('Error creating todo:', error);
    return NextResponse.json(
      { error: 'Failed to create todo' },
      { status: 500 }
    );
  }
}
`,
        type: 'backend'
      });

      // Individual todo operations
      files.push({
        path: 'src/app/api/todos/[id]/route.ts',
        content: `import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// PUT /api/todos/[id] - Update todo
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const { text, completed } = body;
    const { id } = params;
    
    const existingTodo = await db.todo.findUnique({
      where: { id }
    });
    
    if (!existingTodo) {
      return NextResponse.json(
        { error: 'Todo not found' },
        { status: 404 }
      );
    }
    
    const updatedTodo = await db.todo.update({
      where: { id },
      data: {
        ...(text !== undefined && { text: text.trim() }),
        ...(completed !== undefined && { completed })
      }
    });
    
    return NextResponse.json(updatedTodo);
    
  } catch (error) {
    console.error('Error updating todo:', error);
    return NextResponse.json(
      { error: 'Failed to update todo' },
      { status: 500 }
    );
  }
}

// DELETE /api/todos/[id] - Delete todo
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;
    
    const existingTodo = await db.todo.findUnique({
      where: { id }
    });
    
    if (!existingTodo) {
      return NextResponse.json(
        { error: 'Todo not found' },
        { status: 404 }
      );
    }
    
    await db.todo.delete({
      where: { id }
    });
    
    return NextResponse.json({ message: 'Todo deleted successfully' });
    
  } catch (error) {
    console.error('Error deleting todo:', error);
    return NextResponse.json(
      { error: 'Failed to delete todo' },
      { status: 500 }
    );
  }
}
`,
        type: 'backend'
      });
    } else {
      // Generic API routes for custom applications
      files.push({
        path: 'src/app/api/items/route.ts',
        content: `import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/items - Fetch all items
export async function GET() {
  try {
    const items = await db.item.findMany({
      orderBy: { createdAt: 'desc' }
    });
    
    return NextResponse.json(items);
    
  } catch (error) {
    console.error('Error fetching items:', error);
    return NextResponse.json(
      { error: 'Failed to fetch items' },
      { status: 500 }
    );
  }
}

// POST /api/items - Create new item
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { title, description } = body;
    
    if (!title) {
      return NextResponse.json(
        { error: 'Title is required' },
        { status: 400 }
      );
    }
    
    const item = await db.item.create({
      data: {
        title: title.trim(),
        description: description?.trim() || null
      }
    });
    
    return NextResponse.json(item, { status: 201 });
    
  } catch (error) {
    console.error('Error creating item:', error);
    return NextResponse.json(
      { error: 'Failed to create item' },
      { status: 500 }
    );
  }
}
`,
        type: 'backend'
      });
    }

    return files;
  }

  /**
   * Generate frontend components
   */
  private static generateFrontendComponents(project: ProjectStructure): GeneratedFile[] {
    const files: GeneratedFile[] = [];

    // Main page component
    if (project.name === 'todo-app') {
      files.push({
        path: 'src/app/page.tsx',
        content: `'use client';

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Trash2, Edit2, Save, X, Plus } from 'lucide-react';

interface Todo {
  id: string;
  text: string;
  completed: boolean;
  createdAt: string;
  updatedAt: string;
}

interface TodoStats {
  total: number;
  completed: number;
  active: number;
}

export default function HomePage() {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [stats, setStats] = useState<TodoStats>({ total: 0, completed: 0, active: 0 });
  const [inputValue, setInputValue] = useState('');
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Load todos on mount
  useEffect(() => {
    loadTodos();
  }, [filter]);

  const loadTodos = async () => {
    try {
      const response = await fetch(\`/api/todos?filter=\${filter}\`);
      const data = await response.json();
      setTodos(data.todos);
      setStats(data.stats);
    } catch (error) {
      console.error('Error loading todos:', error);
    }
  };

  const addTodo = async () => {
    if (!inputValue.trim() || isLoading) return;
    
    setIsLoading(true);
    try {
      const response = await fetch('/api/todos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: inputValue })
      });
      
      if (response.ok) {
        setInputValue('');
        await loadTodos();
      }
    } catch (error) {
      console.error('Error adding todo:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleTodo = async (id: string) => {
    try {
      const todo = todos.find(t => t.id === id);
      if (todo) {
        await fetch(\`/api/todos/\${id}\`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ completed: !todo.completed })
        });
        await loadTodos();
      }
    } catch (error) {
      console.error('Error toggling todo:', error);
    }
  };

  const updateTodo = async (id: string) => {
    if (!editText.trim()) return;
    
    try {
      await fetch(\`/api/todos/\${id}\`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: editText })
      });
      setEditingId(null);
      setEditText('');
      await loadTodos();
    } catch (error) {
      console.error('Error updating todo:', error);
    }
  };

  const deleteTodo = async (id: string) => {
    try {
      await fetch(\`/api/todos/\${id}\`, {
        method: 'DELETE'
      });
      await loadTodos();
    } catch (error) {
      console.error('Error deleting todo:', error);
    }
  };

  const startEditing = (todo: Todo) => {
    setEditingId(todo.id);
    setEditText(todo.text);
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditText('');
  };

  const filteredTodos = todos.filter(todo => {
    if (filter === 'active') return !todo.completed;
    if (filter === 'completed') return todo.completed;
    return true;
  });

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-2xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">📝 Todo List</h1>
          <p className="text-gray-600">
            {stats.total} total • {stats.active} active • {stats.completed} completed
          </p>
        </div>

        {/* Add Todo Form */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex gap-2">
              <Input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addTodo()}
                placeholder="Add a new todo..."
                className="flex-1"
                disabled={isLoading}
              />
              <Button onClick={addTodo} disabled={!inputValue.trim() || isLoading}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Filters */}
        <div className="flex gap-2 mb-6">
          {(['all', 'active', 'completed'] as const).map((f) => (
            <Button
              key={f}
              variant={filter === f ? 'default' : 'outline'}
              onClick={() => setFilter(f)}
              size="sm"
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </Button>
          ))}
        </div>

        {/* Todo List */}
        <div className="space-y-2">
          {filteredTodos.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center text-gray-500">
                <p>No todos found. Add one above!</p>
              </CardContent>
            </Card>
          ) : (
            filteredTodos.map((todo) => (
              <Card key={todo.id} className={\`\${todo.completed ? 'opacity-75' : ''}\`}>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    {/* Checkbox */}
                    <Checkbox
                      checked={todo.completed}
                      onCheckedChange={() => toggleTodo(todo.id)}
                    />
                    
                    {/* Todo Text */}
                    <div className="flex-1">
                      {editingId === todo.id ? (
                        <div className="flex gap-2">
                          <Input
                            value={editText}
                            onChange={(e) => setEditText(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && updateTodo(todo.id)}
                            className="flex-1"
                            autoFocus
                          />
                          <Button size="sm" onClick={() => updateTodo(todo.id)}>
                            <Save className="w-4 h-4" />
                          </Button>
                          <Button size="sm" variant="outline" onClick={cancelEditing}>
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      ) : (
                        <div>
                          <p className={\`\${todo.completed ? 'line-through text-gray-500' : 'text-gray-900'}\`}>
                            {todo.text}
                          </p>
                          <p className="text-xs text-gray-400 mt-1">
                            Created: {new Date(todo.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      )}
                    </div>
                    
                    {/* Actions */}
                    {editingId !== todo.id && (
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => startEditing(todo)}
                          disabled={todo.completed}
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => deleteTodo(todo.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
`,
        type: 'frontend'
      });
    } else {
      // Generic page component for custom applications
      files.push({
        path: 'src/app/page.tsx',
        content: `'use client';

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, Edit2, Save, X } from 'lucide-react';

interface Item {
  id: string;
  title: string;
  description: string | null;
  completed: boolean;
  createdAt: string;
  updatedAt: string;
}

export default function HomePage() {
  const [items, setItems] = useState<Item[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [descriptionValue, setDescriptionValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    loadItems();
  }, []);

  const loadItems = async () => {
    try {
      const response = await fetch('/api/items');
      const data = await response.json();
      setItems(data);
    } catch (error) {
      console.error('Error loading items:', error);
    }
  };

  const addItem = async () => {
    if (!inputValue.trim() || isLoading) return;
    
    setIsLoading(true);
    try {
      const response = await fetch('/api/items', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          title: inputValue,
          description: descriptionValue
        })
      });
      
      if (response.ok) {
        setInputValue('');
        setDescriptionValue('');
        await loadItems();
      }
    } catch (error) {
      console.error('Error adding item:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            ${project.name.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
          </h1>
          <p className="text-gray-600">${project.description}</p>
        </div>

        {/* Add Item Form */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Add New Item</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              <Input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addItem()}
                placeholder="Enter title..."
                disabled={isLoading}
              />
              <Input
                type="text"
                value={descriptionValue}
                onChange={(e) => setDescriptionValue(e.target.value)}
                placeholder="Enter description (optional)..."
                disabled={isLoading}
              />
              <Button onClick={addItem} disabled={!inputValue.trim() || isLoading}>
                <Plus className="w-4 h-4 mr-2" />
                Add Item
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Items List */}
        <div className="space-y-4">
          {items.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center text-gray-500">
                <p>No items found. Add one above!</p>
              </CardContent>
            </Card>
          ) : (
            items.map((item) => (
              <Card key={item.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        {item.title}
                      </h3>
                      {item.description && (
                        <p className="text-gray-600 mb-2">{item.description}</p>
                      )}
                      <div className="flex items-center gap-2">
                        <Badge variant={item.completed ? 'default' : 'secondary'}>
                          {item.completed ? 'Completed' : 'Active'}
                        </Badge>
                        <span className="text-xs text-gray-400">
                          Created: {new Date(item.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline">
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
`,
        type: 'frontend'
      });
    }

    return files;
  }

  /**
   * Generate configuration files
   */
  private static generateConfigFiles(project: ProjectStructure): GeneratedFile[] {
    const files: GeneratedFile[] = [];

    // Package.json
    files.push({
      path: 'package.json',
      content: `{
  "name": "${project.name}",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint",
    "db:push": "prisma db push",
    "db:generate": "prisma generate",
    "db:migrate": "prisma migrate dev",
    "db:reset": "prisma migrate reset"
  },
  "dependencies": {
    "@prisma/client": "^6.11.1",
    "next": "15.3.5",
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "lucide-react": "^0.525.0",
    "class-variance-authority": "^0.7.1",
    "clsx": "^2.1.1",
    "tailwind-merge": "^3.3.1"
  },
  "devDependencies": {
    "@types/node": "^20",
    "@types/react": "^19",
    "@types/react-dom": "^19",
    "eslint": "^9",
    "eslint-config-next": "15.3.5",
    "prisma": "^6.11.1",
    "tailwindcss": "^4",
    "typescript": "^5"
  }
}`,
      type: 'config'
    });

    // Tailwind config
    files.push({
      path: 'tailwind.config.ts',
      content: `import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        chart: {
          "1": "hsl(var(--chart-1))",
          "2": "hsl(var(--chart-2))",
          "3": "hsl(var(--chart-3))",
          "4": "hsl(var(--chart-4))",
          "5": "hsl(var(--chart-5))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
    },
  },
  plugins: [],
};
export default config;`,
      type: 'config'
    });

    // Environment file
    files.push({
      path: '.env',
      content: `# Database
DATABASE_URL="file:./dev.db"

# Next.js
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="your-secret-key-here"
`,
      type: 'config'
    });

    return files;
  }

  /**
   * Generate documentation
   */
  private static generateDocumentation(project: ProjectStructure): GeneratedFile[] {
    const files: GeneratedFile[] = [];

    files.push({
      path: 'README.md',
      content: `# ${project.name.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}

${project.description}

## Features

${project.features.map(feature => `- ${feature.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}`).join('\n')}

## Tech Stack

- **Framework**: ${project.framework.toUpperCase()}
- **Database**: ${project.database.toUpperCase()}
- **Styling**: Tailwind CSS
- **Language**: TypeScript
- **ORM**: Prisma

## Getting Started

### Prerequisites

- Node.js 18+ installed
- npm or yarn package manager

### Installation

1. Clone the repository
\`\`\`bash
git clone <repository-url>
cd ${project.name}
\`\`\`

2. Install dependencies
\`\`\`bash
npm install
\`\`\`

3. Set up the database
\`\`\`bash
npm run db:push
npm run db:generate
\`\`\`

4. Start the development server
\`\`\`bash
npm run dev
\`\`\`

5. Open [http://localhost:3000](http://localhost:3000) in your browser

## Project Structure

\`\`\`
${project.name}/
├── src/
│   ├── app/                 # Next.js app directory
│   │   ├── api/            # API routes
│   │   └── page.tsx        # Main page
│   ├── components/         # React components
│   └── lib/               # Utility libraries
├── prisma/                # Database schema
├── public/                # Static assets
└── package.json          # Dependencies and scripts
\`\`\`

## API Endpoints

${project.name === 'todo-app' ? `
### Todos API

- \`GET /api/todos\` - Get all todos
- \`POST /api/todos\` - Create a new todo
- \`PUT /api/todos/[id]\` - Update a todo
- \`DELETE /api/todos/[id]\` - Delete a todo
` : `
### Items API

- \`GET /api/items\` - Get all items
- \`POST /api/items\` - Create a new item
- \`PUT /api/items/[id]\` - Update an item
- \`DELETE /api/items/[id]\` - Delete an item
`}

## Development

### Available Scripts

- \`npm run dev\` - Start development server
- \`npm run build\` - Build for production
- \`npm run start\` - Start production server
- \`npm run lint\` - Run ESLint
- \`npm run db:push\` - Push database schema
- \`npm run db:generate\` - Generate Prisma client

### Database Management

This project uses Prisma as the ORM. To manage the database:

1. View database: \`npx prisma studio\`
2. Reset database: \`npm run db:reset\`
3. Create migration: \`npm run db:migrate\`

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is open source and available under the [MIT License](LICENSE).
`,
      type: 'docs'
    });

    return files;
  }

  /**
   * Generate setup instructions
   */
  private static generateSetupInstructions(project: ProjectStructure): string[] {
    return [
      `1. Install dependencies: \`npm install\``,
      `2. Set up database: \`npm run db:push\``,
      `3. Generate Prisma client: \`npm run db:generate\``,
      `4. Start development server: \`npm run dev\``,
      `5. Open http://localhost:3000 in your browser`,
      `6. Start using your ${project.name.replace('-', ' ')}!`
    ];
  }

  /**
   * Generate dependencies
   */
  private static generateDependencies(project: ProjectStructure): string[] {
    const baseDeps = [
      'next',
      'react',
      'react-dom',
      '@prisma/client',
      'lucide-react',
      'class-variance-authority',
      'clsx',
      'tailwind-merge'
    ];

    if (project.features.includes('authentication')) {
      baseDeps.push('next-auth');
    }

    if (project.features.includes('real-time')) {
      baseDeps.push('socket.io-client');
    }

    return baseDeps;
  }

  /**
   * Generate dev dependencies
   */
  private static generateDevDependencies(project: ProjectStructure): string[] {
    return [
      '@types/node',
      '@types/react',
      '@types/react-dom',
      'typescript',
      'tailwindcss',
      'eslint',
      'eslint-config-next',
      'prisma'
    ];
  }

  /**
   * Generate npm scripts
   */
  private static generateScripts(project: ProjectStructure): Record<string, string> {
    const scripts: Record<string, string> = {
      'dev': 'next dev',
      'build': 'next build',
      'start': 'next start',
      'lint': 'next lint',
      'db:push': 'prisma db push',
      'db:generate': 'prisma generate',
      'db:migrate': 'prisma migrate dev',
      'db:reset': 'prisma migrate reset'
    };

    if (project.features.includes('real-time')) {
      scripts['dev:socket'] = 'nodemon server.ts';
    }

    return scripts;
  }

  /**
   * Generate enhanced preview component with live demo
   */
  private static generatePreviewComponent(project: ProjectStructure): GeneratedFile[] {
    const files: GeneratedFile[] = [];

    files.push({
      path: 'src/components/FullstackPreview.tsx',
      content: `'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Play, Eye, Code, Database, Globe, Settings } from 'lucide-react';

interface FullstackPreviewProps {
  project: any;
  isVisible: boolean;
  onToggleVisibility: () => void;
}

export default function FullstackPreview({ project, isVisible, onToggleVisibility }: FullstackPreviewProps) {
  const [activeTab, setActiveTab] = useState('preview');
  const [isRunning, setIsRunning] = useState(false);

  const handleRunDemo = () => {
    setIsRunning(true);
    // Simulate running the application
    setTimeout(() => {
      setIsRunning(false);
    }, 2000);
  };

  if (!isVisible) {
    return (
      <div className="fixed bottom-4 right-4 z-50">
        <Button
          onClick={onToggleVisibility}
          className="shadow-lg"
          size="sm"
        >
          <Eye className="w-4 h-4 mr-2" />
          Show Fullstack Preview
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-white border-l border-gray-200 shadow-xl">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gray-50">
        <div className="flex items-center gap-2">
          <Globe className="w-5 h-5 text-blue-500" />
          <h3 className="font-semibold text-lg">🚀 Fullstack Application Preview</h3>
          <Badge variant="secondary">{project.structure.name}</Badge>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleRunDemo}
            disabled={isRunning}
          >
            {isRunning ? (
              <>
                <div className="animate-spin w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full mr-2" />
                Running...
              </>
            ) : (
              <>
                <Play className="w-4 h-4 mr-2" />
                Run Demo
              </>
            )}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggleVisibility}
          >
            Close
          </Button>
        </div>
      </div>

      <div className="flex h-[calc(100%-60px)]">
        {/* Sidebar */}
        <div className="w-80 border-r border-gray-200 bg-gray-50">
          <div className="p-4">
            <h4 className="font-semibold mb-4">📋 Project Overview</h4>
            
            <div className="space-y-4">
              <div>
                <h5 className="text-sm font-medium text-gray-700 mb-1">Description</h5>
                <p className="text-sm text-gray-600">{project.structure.description}</p>
              </div>

              <div>
                <h5 className="text-sm font-medium text-gray-700 mb-2">Features</h5>
                <div className="flex flex-wrap gap-1">
                  {project.structure.features.map((feature: string, index: number) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {feature}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <h5 className="text-sm font-medium text-gray-700 mb-1">Tech Stack</h5>
                <div className="space-y-1 text-sm text-gray-600">
                  <div className="flex items-center gap-2">
                    <Globe className="w-3 h-3" />
                    <span>Framework: {project.structure.framework}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Database className="w-3 h-3" />
                    <span>Database: {project.structure.database}</span>
                  </div>
                </div>
              </div>

              <div>
                <h5 className="text-sm font-medium text-gray-700 mb-1">Generated Files</h5>
                <p className="text-sm text-gray-600">{project.files.length} files created</p>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="preview" className="flex items-center gap-1">
                <Eye className="w-4 h-4" />
                Preview
              </TabsTrigger>
              <TabsTrigger value="frontend" className="flex items-center gap-1">
                <Code className="w-4 h-4" />
                Frontend
              </TabsTrigger>
              <TabsTrigger value="backend" className="flex items-center gap-1">
                <Database className="w-4 h-4" />
                Backend
              </TabsTrigger>
              <TabsTrigger value="setup" className="flex items-center gap-1">
                <Settings className="w-4 h-4" />
                Setup
              </TabsTrigger>
            </TabsList>

            <TabsContent value="preview" className="flex-1 p-6">
              <div className="h-full flex flex-col">
                <div className="mb-4">
                  <h4 className="text-lg font-semibold mb-2">🎯 Live Application Preview</h4>
                  <p className="text-gray-600">
                    This is a preview of your {project.structure.name}. The application includes all the features you requested and is ready to run.
                  </p>
                </div>

                {/* Application Demo */}
                <div className="flex-1 border-2 border-dashed border-gray-300 rounded-lg p-8 bg-gray-50">
                  <div className="text-center">
                    <div className="mb-4">
                      <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Play className="w-8 h-8 text-blue-500" />
                      </div>
                      <h5 className="text-xl font-semibold mb-2">Application Ready to Run</h5>
                      <p className="text-gray-600 mb-6">
                        Your {project.structure.name} has been generated with {project.files.length} files including:
                      </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto mb-6">
                      <div className="bg-white p-4 rounded-lg border">
                        <Code className="w-6 h-6 text-blue-500 mb-2" />
                        <h6 className="font-medium text-sm">Frontend</h6>
                        <p className="text-xs text-gray-600">React components with modern UI</p>
                      </div>
                      <div className="bg-white p-4 rounded-lg border">
                        <Database className="w-6 h-6 text-green-500 mb-2" />
                        <h6 className="font-medium text-sm">Backend</h6>
                        <p className="text-xs text-gray-600">REST API with database</p>
                      </div>
                      <div className="bg-white p-4 rounded-lg border">
                        <Globe className="w-6 h-6 text-purple-500 mb-2" />
                        <h6 className="font-medium text-sm">Full Stack</h6>
                        <p className="text-xs text-gray-600">Complete application</p>
                      </div>
                    </div>

                    <Button onClick={handleRunDemo} disabled={isRunning} className="mb-4">
                      {isRunning ? 'Starting Application...' : 'Start Live Demo'}
                    </Button>

                    {isRunning && (
                      <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                        <p className="text-sm text-blue-700">
                          🚀 Application is starting... In a real environment, this would launch your application at localhost:3000
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="frontend" className="flex-1 p-6">
              <ScrollArea className="h-full">
                <div>
                  <h4 className="text-lg font-semibold mb-4">🎨 Frontend Components</h4>
                  <div className="space-y-4">
                    {project.files
                      .filter((file: any) => file.type === 'frontend')
                      .map((file: any, index: number) => (
                        <Card key={index}>
                          <CardHeader>
                            <CardTitle className="text-sm">{file.path}</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <pre className="text-xs bg-gray-900 text-gray-100 p-3 rounded overflow-x-auto">
                              <code>{file.content.substring(0, 500)}...</code>
                            </pre>
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="backend" className="flex-1 p-6">
              <ScrollArea className="h-full">
                <div>
                  <h4 className="text-lg font-semibold mb-4">⚙️ Backend API</h4>
                  <div className="space-y-4">
                    {project.files
                      .filter((file: any) => file.type === 'backend')
                      .map((file: any, index: number) => (
                        <Card key={index}>
                          <CardHeader>
                            <CardTitle className="text-sm">{file.path}</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <pre className="text-xs bg-gray-900 text-gray-100 p-3 rounded overflow-x-auto">
                              <code>{file.content.substring(0, 500)}...</code>
                            </pre>
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="setup" className="flex-1 p-6">
              <ScrollArea className="h-full">
                <div>
                  <h4 className="text-lg font-semibold mb-4">📦 Setup Instructions</h4>
                  <div className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-sm">Quick Start</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2 text-sm">
                          <p>1. Install dependencies:</p>
                          <pre className="bg-gray-100 p-2 rounded text-xs">npm install</pre>
                          
                          <p>2. Setup database:</p>
                          <pre className="bg-gray-100 p-2 rounded text-xs">npm run db:push</pre>
                          
                          <p>3. Start development server:</p>
                          <pre className="bg-gray-100 p-2 rounded text-xs">npm run dev</pre>
                          
                          <p>4. Open your browser to:</p>
                          <pre className="bg-gray-100 p-2 rounded text-xs">http://localhost:3000</pre>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="text-sm">Dependencies</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2 text-sm">
                          <p><strong>Production:</strong></p>
                          <pre className="bg-gray-100 p-2 rounded text-xs">
{project.dependencies.join('\\n')}
                          </pre>
                          
                          <p><strong>Development:</strong></p>
                          <pre className="bg-gray-100 p-2 rounded text-xs">
{project.devDependencies.join('\\n')}
                          </pre>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
`,
      type: 'frontend'
    });

    return files;
  }
}