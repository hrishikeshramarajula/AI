import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs/promises';
import path from 'path';

interface WebsiteEditRequest {
  request: string;
  model: string;
}

interface WebsiteEditResponse {
  success: boolean;
  changes: Array<{
    type: 'add' | 'modify' | 'delete';
    file: string;
    description: string;
    codeChanges?: string;
  }>;
  modifiedFiles: string[];
  previewUrl?: string;
  codeChanges?: string;
  error?: string;
}

export async function POST(request: NextRequest) {
  try {
    const body: WebsiteEditRequest = await request.json();
    const { request: userRequest, model } = body;

    console.log('Website editor request:', userRequest);

    // Initialize ZAI SDK
    const zai = await ZAI.create();

    // Analyze the user's request and generate appropriate actions
    const analysisPrompt = `
You are an expert web developer AI assistant. Analyze the user's request and determine what website modifications are needed.

User Request: "${userRequest}"

Your task is to:
1. Understand what the user wants to change/add to their website
2. Determine which files need to be modified
3. Generate the appropriate code changes
4. Provide a clear description of each change

Respond with a JSON object containing:
{
  "understanding": "Brief explanation of what the user wants",
  "changes": [
    {
      "type": "add|modify|delete",
      "file": "path/to/file",
      "description": "What this change does",
      "codeChanges": "The actual code to apply"
    }
  ],
  "priority": "high|medium|low"
}

Example responses:
For "Add a contact form to the homepage":
{
  "understanding": "User wants to add a contact form to the homepage",
  "changes": [
    {
      "type": "modify",
      "file": "src/app/page.tsx",
      "description": "Add contact form component to homepage",
      "codeChanges": "// Contact form component code here"
    }
  ],
  "priority": "high"
}

For "Change the header color to blue":
{
  "understanding": "User wants to change the header background color to blue",
  "changes": [
    {
      "type": "modify",
      "file": "src/app/page.tsx",
      "description": "Update header background color to blue",
      "codeChanges": "className=\"bg-blue-500 text-white...\""
    }
  ],
  "priority": "medium"
}
`;

    const analysisCompletion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an expert web developer AI assistant that analyzes user requests and generates structured website modification plans.'
        },
        {
          role: 'user',
          content: analysisPrompt
        }
      ],
      temperature: 0.3,
      max_tokens: 2000
    });

    const analysisResponse = analysisCompletion.choices[0]?.message?.content;
    
    if (!analysisResponse) {
      throw new Error('Failed to analyze the request');
    }

    console.log('Analysis response:', analysisResponse);

    // Parse the analysis response
    let analysis;
    try {
      // Extract JSON from the response (in case there's additional text)
      let jsonStr = analysisResponse;
      
      // Try to find JSON object in the response
      const jsonMatch = analysisResponse.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        jsonStr = jsonMatch[0];
      }
      
      // Clean up the JSON string
      jsonStr = jsonStr.replace(/[\x00-\x1F\x7F]/g, ''); // Remove control characters
      
      analysis = JSON.parse(jsonStr);
    } catch (error) {
      console.error('Failed to parse analysis response:', error);
      console.error('Raw response:', analysisResponse);
      
      // Return a simple fallback analysis
      analysis = {
        understanding: {
          intent: userRequest,
          context: "Website modification",
          complexity: "medium",
          approach: "Add requested content to website"
        },
        changes: [{
          type: "modify",
          file: "src/app/page.tsx",
          description: `Add ${userRequest} to the website`,
          codeChanges: `// Content to be added: ${userRequest}`
        }]
      };
    }

    // Generate the actual code changes
    const codeGenerationPrompt = `
You are an expert React/Next.js developer. Based on the following analysis, generate the actual code changes needed.

User Request: "${userRequest}"
Analysis: ${JSON.stringify(analysis)}

For each change, generate the complete code that should be applied. Make sure the code:
1. Follows React/Next.js best practices
2. Uses TypeScript when appropriate
3. Includes proper imports
4. Is ready to be applied directly to the files
5. Maintains the existing code structure and style

Respond with a JSON object containing:
{
  "changes": [
    {
      "type": "add|modify|delete",
      "file": "path/to/file",
      "description": "What this change does",
      "codeChanges": "The complete code to apply",
      "fullContent": "The complete new content of the file (if modifying)"
    }
  ]
}

Important: Make sure all code is syntactically correct and ready to use.
`;

    const codeCompletion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an expert React/Next.js developer that generates production-ready code.'
        },
        {
          role: 'user',
          content: codeGenerationPrompt
        }
      ],
      temperature: 0.2,
      max_tokens: 4000
    });

    const codeResponse = codeCompletion.choices[0]?.message?.content;
    
    if (!codeResponse) {
      throw new Error('Failed to generate code changes');
    }

    console.log('Code generation response:', codeResponse);

    // Parse the code generation response
    let codeChanges;
    try {
      const jsonMatch = codeResponse.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error('No JSON found in code generation response');
      }
      codeChanges = JSON.parse(jsonMatch[0]);
    } catch (error) {
      console.error('Failed to parse code generation response:', error);
      throw new Error('Failed to parse code changes');
    }

    // Apply the changes to the actual files
    const modifiedFiles: string[] = [];
    const appliedChanges: Array<{
      type: 'add' | 'modify' | 'delete';
      file: string;
      description: string;
      codeChanges?: string;
    }> = [];

    for (const change of codeChanges.changes) {
      try {
        const filePath = path.join(process.cwd(), change.file);
        
        if (change.type === 'add' || change.type === 'modify') {
          // Ensure directory exists
          const dir = path.dirname(filePath);
          await fs.mkdir(dir, { recursive: true });
          
          // Write the file content
          if (change.fullContent) {
            await fs.writeFile(filePath, change.fullContent, 'utf-8');
          } else if (change.codeChanges) {
            await fs.writeFile(filePath, change.codeChanges, 'utf-8');
          }
          
          modifiedFiles.push(change.file);
          appliedChanges.push({
            type: change.type,
            file: change.file,
            description: change.description,
            codeChanges: change.codeChanges
          });
        } else if (change.type === 'delete') {
          await fs.unlink(filePath);
          modifiedFiles.push(change.file);
          appliedChanges.push({
            type: change.type,
            file: change.file,
            description: change.description
          });
        }
        
        console.log(`Successfully applied change to ${change.file}`);
      } catch (fileError) {
        console.error(`Failed to apply change to ${change.file}:`, fileError);
        // Continue with other changes even if one fails
      }
    }

    // Generate a summary response
    const response: WebsiteEditResponse = {
      success: true,
      changes: appliedChanges,
      modifiedFiles: modifiedFiles,
      previewUrl: 'http://localhost:3000', // Local development URL
      codeChanges: appliedChanges.map(c => c.codeChanges).filter(Boolean).join('\n\n')
    };

    console.log('Website editor response:', response);

    return NextResponse.json(response);
    
  } catch (error) {
    console.error('Website editor error:', error);
    
    const errorResponse: WebsiteEditResponse = {
      success: false,
      changes: [],
      modifiedFiles: [],
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };

    return NextResponse.json(errorResponse, { status: 500 });
  }
}