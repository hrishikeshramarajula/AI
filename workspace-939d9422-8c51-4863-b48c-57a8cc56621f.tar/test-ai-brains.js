/**
 * AI Brains Testing Suite
 * 
 * This comprehensive test suite validates all AI brain components and functionality.
 * Run with: node test-ai-brains.js
 */

const fs = require('fs');
const path = require('path');

console.log('🧠 Starting AI Brains Test Suite...\n');

class AIBrainsTester {
  constructor() {
    this.results = {
      passed: 0,
      failed: 0,
      total: 0,
      errors: []
    };
    this.projectRoot = process.cwd();
  }

  // Test runner
  async runAllTests() {
    console.log('🚀 Running comprehensive AI brains tests...\n');

    await this.testFileStructure();
    await this.testUIComponents();
    await this.testAPIRoutes();
    await this.testLibraryFiles();
    await this.testConfiguration();
    await this.testDependencies();

    this.printResults();
  }

  // Test 1: File Structure
  async testFileStructure() {
    console.log('📁 Testing File Structure...');
    
    const requiredFiles = [
      // Core application files
      'src/app/page.tsx',
      'src/app/layout.tsx',
      'src/app/globals.css',
      
      // UI Components
      'src/components/ui/button.tsx',
      'src/components/ui/card.tsx',
      'src/components/ui/input.tsx',
      'src/components/ui/badge.tsx',
      'src/components/ui/tabs.tsx',
      'src/components/ui/scroll-area.tsx',
      
      // AI Brain Components
      'src/components/EnhancedAIBrainDisplay.tsx',
      'src/components/EnhancedAIBrainReal.tsx',
      'src/components/UltimateAIBrainDisplay.tsx',
      'src/components/AIBrainErrorHandling.tsx',
      'src/components/AIBrainContinuousImprovement.tsx',
      
      // API Routes
      'src/app/api/ai/route.ts',
      'src/app/api/autonomous-agent/route.ts',
      'src/app/api/real-ai-brain/route.ts',
      'src/app/api/real-ai-thinking/route.ts',
      'src/app/api/fullstack-enhanced/route.ts',
      'src/app/api/health/route.ts',
      
      // Library Files
      'src/lib/utils.ts',
      'src/lib/db.ts',
      'src/lib/apiUtils.ts',
      'src/lib/apiConfig.ts',
      'src/lib/search.ts',
      'src/lib/zaiHelper.ts',
      'src/lib/zaiInitializer.ts',
      
      // Brain Library
      'src/lib/brain/brainIntegration.ts',
      'src/lib/brain/aiModels.ts',
      'src/lib/brain/aiProcessor.ts',
      'src/lib/brain/thinkingEngine.ts',
      
      // Configuration
      'package.json',
      'tailwind.config.ts',
      'tsconfig.json',
      'components.json',
      'prisma/schema.prisma',
      
      // Documentation
      'README.md',
      'AI_BRAIN_FIX_COMPLETE.md'
    ];

    for (const file of requiredFiles) {
      const filePath = path.join(this.projectRoot, file);
      this.testFileExists(filePath, file);
    }

    console.log('✅ File Structure Tests Complete\n');
  }

  // Test 2: UI Components
  async testUIComponents() {
    console.log('🎨 Testing UI Components...');
    
    const uiComponentsPath = path.join(this.projectRoot, 'src/components/ui');
    const expectedComponents = [
      'accordion.tsx', 'alert-dialog.tsx', 'alert.tsx', 'avatar.tsx',
      'badge.tsx', 'button.tsx', 'card.tsx', 'checkbox.tsx',
      'command.tsx', 'context-menu.tsx', 'dialog.tsx',
      'dropdown-menu.tsx', 'hover-card.tsx', 'input.tsx', 'label.tsx',
      'menubar.tsx', 'navigation-menu.tsx', 'popover.tsx', 'progress.tsx',
      'radio-group.tsx', 'scroll-area.tsx', 'select.tsx', 'separator.tsx',
      'sheet.tsx', 'slider.tsx', 'switch.tsx', 'table.tsx', 'tabs.tsx',
      'textarea.tsx', 'toast.tsx', 'toaster.tsx', 'toggle.tsx', 'tooltip.tsx'
    ];

    if (fs.existsSync(uiComponentsPath)) {
      const files = fs.readdirSync(uiComponentsPath);
      
      for (const component of expectedComponents) {
        const componentPath = path.join(uiComponentsPath, component);
        this.testFileExists(componentPath, `UI Component: ${component}`);
      }
    } else {
      this.addError('UI Components directory not found', uiComponentsPath);
    }

    console.log('✅ UI Components Tests Complete\n');
  }

  // Test 3: API Routes
  async testAPIRoutes() {
    console.log('🌐 Testing API Routes...');
    
    const apiPath = path.join(this.projectRoot, 'src/app/api');
    const expectedRoutes = [
      'ai/route.ts', 'autonomous-agent/route.ts', 'real-ai-brain/route.ts',
      'real-ai-thinking/route.ts', 'fullstack-enhanced/route.ts',
      'tasks/route.ts', 'health/route.ts', 'generate-image/route.ts',
      'websocket/route.ts'
    ];

    if (fs.existsSync(apiPath)) {
      const routes = fs.readdirSync(apiPath, { recursive: true });
      
      for (const route of expectedRoutes) {
        const routePath = path.join(apiPath, route);
        this.testFileExists(routePath, `API Route: ${route}`);
      }
    } else {
      this.addError('API routes directory not found', apiPath);
    }

    console.log('✅ API Routes Tests Complete\n');
  }

  // Test 4: Library Files
  async testLibraryFiles() {
    console.log('📚 Testing Library Files...');
    
    const libPath = path.join(this.projectRoot, 'src/lib');
    const expectedLibFiles = [
      'utils.ts', 'db.ts', 'apiUtils.ts', 'apiConfig.ts', 'search.ts',
      'zaiHelper.ts', 'zaiInitializer.ts', 'fullstackGenerator.ts',
      'enhancedFullstackGenerator.ts', 'socket.ts'
    ];

    if (fs.existsSync(libPath)) {
      const libFiles = fs.readdirSync(libPath);
      
      for (const libFile of expectedLibFiles) {
        const libFilePath = path.join(libPath, libFile);
        this.testFileExists(libFilePath, `Library File: ${libFile}`);
      }
    } else {
      this.addError('Library directory not found', libPath);
    }

    // Test brain library
    const brainPath = path.join(libPath, 'brain');
    if (fs.existsSync(brainPath)) {
      const brainFiles = fs.readdirSync(brainPath);
      const expectedBrainFiles = [
        'brainIntegration.ts', 'aiModels.ts', 'aiProcessor.ts', 'thinkingEngine.ts'
      ];
      
      for (const brainFile of expectedBrainFiles) {
        const brainFilePath = path.join(brainPath, brainFile);
        this.testFileExists(brainFilePath, `Brain Library: ${brainFile}`);
      }
    } else {
      this.addError('Brain library directory not found', brainPath);
    }

    console.log('✅ Library Files Tests Complete\n');
  }

  // Test 5: Configuration
  async testConfiguration() {
    console.log('⚙️ Testing Configuration Files...');
    
    const configFiles = [
      { path: 'package.json', test: 'dependencies' },
      { path: 'tailwind.config.ts', test: 'content' },
      { path: 'tsconfig.json', test: 'compilerOptions' },
      { path: 'components.json', test: 'style' },
      { path: 'prisma/schema.prisma', test: 'generator' }
    ];

    for (const config of configFiles) {
      const configPath = path.join(this.projectRoot, config.path);
      
      if (fs.existsSync(configPath)) {
        try {
          const content = fs.readFileSync(configPath, 'utf8');
          
          if (config.test === 'dependencies') {
            const pkg = JSON.parse(content);
            if (pkg.dependencies && pkg.dependencies['next']) {
              this.addPass(`Configuration: ${config.path} has valid dependencies`);
            } else {
              this.addError(`Configuration: ${config.path} missing required dependencies`, configPath);
            }
          } else if (content.includes(config.test)) {
            this.addPass(`Configuration: ${config.path} contains ${config.test}`);
          } else {
            this.addError(`Configuration: ${config.path} missing ${config.test}`, configPath);
          }
        } catch (error) {
          this.addError(`Configuration: ${config.path} parse error`, configPath);
        }
      } else {
        this.addError(`Configuration file not found: ${config.path}`, configPath);
      }
    }

    console.log('✅ Configuration Tests Complete\n');
  }

  // Test 6: Dependencies
  async testDependencies() {
    console.log('📦 Testing Dependencies...');
    
    const packagePath = path.join(this.projectRoot, 'package.json');
    
    if (fs.existsSync(packagePath)) {
      try {
        const packageJson = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
        
        const requiredDeps = [
          'next', 'react', 'react-dom', 'z-ai-web-dev-sdk'
        ];
        
        const requiredDevDeps = [
          'typescript', 'tailwindcss', '@types/node', '@types/react', '@types/react-dom',
          'eslint', 'eslint-config-next', '@radix-ui/react-slot', 'class-variance-authority', 'clsx',
          'lucide-react'
        ];

        // Test dependencies
        for (const dep of requiredDeps) {
          if (packageJson.dependencies && packageJson.dependencies[dep]) {
            this.addPass(`Dependency: ${dep}@${packageJson.dependencies[dep]}`);
          } else if (packageJson.devDependencies && packageJson.devDependencies[dep]) {
            this.addPass(`Dev Dependency: ${dep}@${packageJson.devDependencies[dep]}`);
          } else {
            this.addError(`Missing dependency: ${dep}`, packagePath);
          }
        }

        // Test dev dependencies
        for (const devDep of requiredDevDeps) {
          if (packageJson.devDependencies && packageJson.devDependencies[devDep]) {
            this.addPass(`Dev Dependency: ${devDep}@${packageJson.devDependencies[devDep]}`);
          } else if (packageJson.dependencies && packageJson.dependencies[devDep]) {
            this.addPass(`Dependency: ${devDep}@${packageJson.dependencies[devDep]}`);
          } else {
            this.addError(`Missing dev dependency: ${devDep}`, packagePath);
          }
        }

        // Test scripts
        const requiredScripts = ['dev', 'build', 'start', 'lint'];
        for (const script of requiredScripts) {
          if (packageJson.scripts && packageJson.scripts[script]) {
            this.addPass(`Script: ${script}`);
          } else {
            this.addError(`Missing script: ${script}`, packagePath);
          }
        }

      } catch (error) {
        this.addError('Failed to parse package.json', packagePath);
      }
    } else {
      this.addError('package.json not found', packagePath);
    }

    console.log('✅ Dependencies Tests Complete\n');
  }

  // Helper method to test if file exists
  testFileExists(filePath, description) {
    this.results.total++;
    
    if (fs.existsSync(filePath)) {
      try {
        const stats = fs.statSync(filePath);
        if (stats.isFile() && stats.size > 0) {
          this.addPass(description);
        } else {
          this.addError(`${description} exists but is empty or not a file`, filePath);
        }
      } catch (error) {
        this.addError(`${description} exists but cannot be read`, filePath);
      }
    } else {
      this.addError(`${description} not found`, filePath);
    }
  }

  // Helper method to add passed test
  addPass(description) {
    this.results.passed++;
    console.log(`  ✅ ${description}`);
  }

  // Helper method to add failed test
  addError(description, path) {
    this.results.failed++;
    this.results.errors.push({
      description,
      path,
      timestamp: new Date().toISOString()
    });
    console.log(`  ❌ ${description}`);
  }

  // Print test results
  printResults() {
    console.log('📊 Test Results Summary');
    console.log('='.repeat(50));
    console.log(`Total Tests: ${this.results.total}`);
    console.log(`Passed: ${this.results.passed} ✅`);
    console.log(`Failed: ${this.results.failed} ❌`);
    console.log(`Success Rate: ${((this.results.passed / this.results.total) * 100).toFixed(1)}%`);
    
    if (this.results.errors.length > 0) {
      console.log('\n❌ Failed Tests:');
      this.results.errors.forEach((error, index) => {
        console.log(`  ${index + 1}. ${error.description}`);
        console.log(`     Path: ${error.path}`);
        console.log(`     Time: ${error.timestamp}`);
      });
    }

    console.log('\n🎯 Overall Status:');
    if (this.results.failed === 0) {
      console.log('🎉 ALL TESTS PASSED! AI Brains system is fully restored and operational.');
    } else if (this.results.failed <= 5) {
      console.log('⚠️  MOSTLY COMPLETE - A few issues found but system is functional.');
    } else {
      console.log('❌ NEEDS ATTENTION - Multiple issues found that need to be resolved.');
    }

    console.log('\n🚀 Next Steps:');
    if (this.results.failed === 0) {
      console.log('• Start the development server: npm run dev');
      console.log('• Test AI functionality in the browser');
      console.log('• Verify all features are working correctly');
    } else {
      console.log('• Review and fix failed tests');
      console.log('• Check file permissions and paths');
      console.log('• Ensure all dependencies are installed');
      console.log('• Run tests again after fixes');
    }

    console.log('\n🧠 AI Brains Test Suite Complete!');
  }
}

// Run the tests
async function main() {
  const tester = new AIBrainsTester();
  await tester.runAllTests();
}

// Execute if run directly
if (require.main === module) {
  main().catch(console.error);
}

module.exports = AIBrainsTester;