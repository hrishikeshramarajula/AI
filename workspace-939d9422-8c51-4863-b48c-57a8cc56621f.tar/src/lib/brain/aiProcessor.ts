import { AIModel, getModelById, getModelConfiguration } from './aiModels';
import { AIMessage } from '@/types/ai';
import ZAI from 'z-ai-web-dev-sdk';

export interface ProcessingOptions {
  model: string;
  temperature?: number;
  maxTokens?: number;
  systemPrompt?: string;
  streaming?: boolean;
}

export interface ProcessingResult {
  content: string;
  model: string;
  provider: string;
  tokensUsed?: number;
  processingTime: number;
  confidence?: number;
}

export class AIProcessor {
  private zai: ZAI | null = null;

  constructor() {
    this.initializeZAI();
  }

  private async initializeZAI(): Promise<void> {
    try {
      this.zai = await ZAI.create();
      console.log('🤖 ZAI SDK initialized successfully');
    } catch (error) {
      console.error('❌ Failed to initialize ZAI SDK:', error);
      throw new Error('Failed to initialize AI SDK');
    }
  }

  async processMessage(
    messages: AIMessage[], 
    options: ProcessingOptions
  ): Promise<ProcessingResult> {
    const startTime = Date.now();
    
    try {
      if (!this.zai) {
        await this.initializeZAI();
      }

      const model = getModelById(options.model);
      if (!model) {
        throw new Error(`Unknown model: ${options.model}`);
      }

      console.log('🤖 Processing message with model:', model.name);
      console.log('📋 Messages count:', messages.length);

      // Prepare messages for the AI
      const processedMessages = this.prepareMessages(messages, options.systemPrompt);

      // Configure the request
      const requestConfig = {
        model: model.apiModel || options.model,
        messages: processedMessages,
        temperature: options.temperature ?? model.temperature ?? 0.7,
        max_tokens: options.maxTokens ?? model.maxTokens ?? 2000,
        stream: options.streaming ?? false,
      };

      console.log('🚀 Sending request to AI provider:', model.provider);

      // Make the API call
      const response = await this.makeAPIRequest(model.provider, requestConfig);

      const processingTime = Date.now() - startTime;
      
      const result: ProcessingResult = {
        content: this.extractContent(response, model.provider),
        model: model.name,
        provider: model.provider,
        tokensUsed: this.extractTokenUsage(response, model.provider),
        processingTime,
        confidence: this.calculateConfidence(response, model.provider),
      };

      console.log('✅ AI processing completed in', processingTime, 'ms');
      console.log('📝 Response length:', result.content.length, 'characters');

      return result;

    } catch (error) {
      console.error('❌ AI processing failed:', error);
      throw this.handleProcessingError(error);
    }
  }

  private prepareMessages(messages: AIMessage[], systemPrompt?: string): any[] {
    const processedMessages: any[] = [];

    // Add system message if provided
    if (systemPrompt) {
      processedMessages.push({
        role: 'system',
        content: systemPrompt,
      });
    }

    // Process user and assistant messages
    for (const message of messages) {
      if (message.role === 'user' || message.role === 'assistant') {
        processedMessages.push({
          role: message.role,
          content: message.content,
        });
      }
    }

    return processedMessages;
  }

  private async makeAPIRequest(provider: string, config: any): Promise<any> {
    switch (provider) {
      case 'openai':
        return this.callOpenAI(config);
      case 'anthropic':
        return this.callAnthropic(config);
      case 'google':
        return this.callGoogle(config);
      case 'openrouter':
        return this.callOpenRouter(config);
      default:
        throw new Error(`Unsupported provider: ${provider}`);
    }
  }

  private async callOpenAI(config: any): Promise<any> {
    if (!this.zai) throw new Error('ZAI not initialized');

    try {
      const response = await this.zai.chat.completions.create({
        messages: config.messages,
        model: config.model,
        temperature: config.temperature,
        max_tokens: config.max_tokens,
        stream: config.stream,
      });

      return response;
    } catch (error) {
      console.error('❌ OpenAI API error:', error);
      throw error;
    }
  }

  private async callAnthropic(config: any): Promise<any> {
    if (!this.zai) throw new Error('ZAI not initialized');

    try {
      // For Anthropic, we need to adapt the message format
      const systemMessage = config.messages.find((m: any) => m.role === 'system');
      const userMessages = config.messages.filter((m: any) => m.role !== 'system');

      const response = await this.zai.chat.completions.create({
        messages: userMessages,
        model: config.model,
        temperature: config.temperature,
        max_tokens: config.max_tokens,
        system: systemMessage?.content,
      });

      return response;
    } catch (error) {
      console.error('❌ Anthropic API error:', error);
      throw error;
    }
  }

  private async callGoogle(config: any): Promise<any> {
    if (!this.zai) throw new Error('ZAI not initialized');

    try {
      // For Google, we need to adapt the message format
      const systemMessage = config.messages.find((m: any) => m.role === 'system');
      const userMessage = config.messages.find((m: any) => m.role === 'user');

      const response = await this.zai.chat.completions.create({
        messages: [{
          role: 'user',
          content: `${systemMessage ? systemMessage.content + '\n\n' : ''}${userMessage?.content || ''}`,
        }],
        model: config.model,
        temperature: config.temperature,
        max_tokens: config.max_tokens,
      });

      return response;
    } catch (error) {
      console.error('❌ Google API error:', error);
      throw error;
    }
  }

  private async callOpenRouter(config: any): Promise<any> {
    if (!this.zai) throw new Error('ZAI not initialized');

    try {
      const response = await this.zai.chat.completions.create({
        messages: config.messages,
        model: config.model,
        temperature: config.temperature,
        max_tokens: config.max_tokens,
        stream: config.stream,
      });

      return response;
    } catch (error) {
      console.error('❌ OpenRouter API error:', error);
      throw error;
    }
  }

  private extractContent(response: any, provider: string): string {
    try {
      switch (provider) {
        case 'openai':
        case 'openrouter':
          return response.choices?.[0]?.message?.content || 'No response generated';
        
        case 'anthropic':
          return response.content?.[0]?.text || 'No response generated';
        
        case 'google':
          return response.candidates?.[0]?.content?.parts?.[0]?.text || 'No response generated';
        
        default:
          return 'Response format not supported';
      }
    } catch (error) {
      console.error('❌ Failed to extract content:', error);
      return 'Failed to extract response content';
    }
  }

  private extractTokenUsage(response: any, provider: string): number {
    try {
      switch (provider) {
        case 'openai':
        case 'openrouter':
          return response.usage?.total_tokens || 0;
        
        case 'anthropic':
          return response.usage?.input_tokens + response.usage?.output_tokens || 0;
        
        case 'google':
          return response.usageMetadata?.totalTokenCount || 0;
        
        default:
          return 0;
      }
    } catch (error) {
      console.error('❌ Failed to extract token usage:', error);
      return 0;
    }
  }

  private calculateConfidence(response: any, provider: string): number {
    // This is a simplified confidence calculation
    // In a real implementation, you might use more sophisticated metrics
    try {
      const content = this.extractContent(response, provider);
      const contentLength = content.length;
      
      // Basic confidence based on response length and quality indicators
      if (contentLength < 50) return 0.3;
      if (contentLength < 200) return 0.6;
      if (contentLength < 500) return 0.8;
      return 0.9;
    } catch (error) {
      return 0.5; // Default confidence
    }
  }

  private handleProcessingError(error: any): Error {
    if (error.message?.includes('API key')) {
      return new Error('Invalid API key configuration');
    }
    
    if (error.message?.includes('quota')) {
      return new Error('API quota exceeded');
    }
    
    if (error.message?.includes('timeout')) {
      return new Error('Request timeout');
    }
    
    if (error.message?.includes('rate limit')) {
      return new Error('Rate limit exceeded');
    }
    
    // Return original error if it's a known type
    if (error instanceof Error) {
      return error;
    }
    
    // Wrap unknown errors
    return new Error(`AI processing failed: ${error.message || 'Unknown error'}`);
  }

  // Specialized processing methods
  async processCodeGeneration(
    prompt: string, 
    language: string,
    options: ProcessingOptions
  ): Promise<ProcessingResult> {
    const systemPrompt = `You are an expert ${language} developer. Generate clean, well-commented, production-ready code. Include explanations and best practices.`;
    
    const messages: AIMessage[] = [
      { role: 'user', content: prompt }
    ];

    return this.processMessage(messages, {
      ...options,
      systemPrompt,
      temperature: 0.3, // Lower temperature for more consistent code
    });
  }

  async processCreativeWriting(
    prompt: string,
    style: string,
    options: ProcessingOptions
  ): Promise<ProcessingResult> {
    const systemPrompt = `You are a creative writer specializing in ${style}. Write engaging, imaginative content with vivid descriptions and compelling narratives.`;
    
    const messages: AIMessage[] = [
      { role: 'user', content: prompt }
    ];

    return this.processMessage(messages, {
      ...options,
      systemPrompt,
      temperature: 0.8, // Higher temperature for more creativity
    });
  }

  async processAnalysis(
    data: string,
    analysisType: string,
    options: ProcessingOptions
  ): Promise<ProcessingResult> {
    const systemPrompt = `You are an expert analyst specializing in ${analysisType}. Provide thorough, evidence-based analysis with clear insights and actionable recommendations.`;
    
    const messages: AIMessage[] = [
      { role: 'user', content: data }
    ];

    return this.processMessage(messages, {
      ...options,
      systemPrompt,
      temperature: 0.5, // Balanced temperature for analysis
    });
  }
}

// Singleton instance
export const aiProcessor = new AIProcessor();