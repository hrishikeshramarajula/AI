// 🧠 Enhanced Deep Research Text Processor
// Advanced document analysis with NLP capabilities, entity extraction, and knowledge processing

export interface ProcessedText {
  sentences: string[];
  words: string[];
  processedText: string;
  originalText: string;
  metadata: {
    wordCount: number;
    sentenceCount: number;
    characterCount: number;
    readingTime: number;
    complexity: number;
  };
}

export interface Entity {
  text: string;
  label: string;
  confidence: number;
  start: number;
  end: number;
  category: string;
  importance: number;
}

export interface Topic {
  id: number;
  words: string[];
  coherence: number;
  relevance: number;
  description: string;
}

export interface SentimentAnalysis {
  overall: {
    sentiment: 'positive' | 'negative' | 'neutral';
    confidence: number;
    score: number;
  };
  aspects: Array<{
    aspect: string;
    sentiment: string;
    confidence: number;
  }>;
  emotions: Array<{
    emotion: string;
    intensity: number;
  }>;
}

export interface KnowledgeGraphNode {
  id: string;
  label: string;
  type: string;
  category: string;
  importance: number;
  mentions: number;
  relationships: string[];
  metadata: Record<string, any>;
}

export interface KnowledgeGraphEdge {
  source: string;
  target: string;
  relationship: string;
  weight: number;
  type: string;
  metadata: Record<string, any>;
}

export interface ResearchAnalysis {
  processedText: ProcessedText;
  entities: Entity[];
  topics: Topic[];
  sentiment: SentimentAnalysis;
  keywords: string[];
  summary: string;
  knowledgeGraph: {
    nodes: KnowledgeGraphNode[];
    edges: KnowledgeGraphEdge[];
  };
  insights: {
    keyFindings: string[];
    knowledgeGaps: string[];
    researchQuestions: string[];
    recommendations: string[];
  };
  metadata: {
    processingTime: number;
    analysisDepth: 'basic' | 'detailed' | 'comprehensive' | 'encyclopedic';
    confidence: number;
    sources: string[];
  };
}

export class DeepResearchTextProcessor {
  private stopWords: Set<string>;
  private importanceKeywords: Set<string>;

  constructor() {
    this.stopWords = new Set([
      'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by',
      'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did',
      'will', 'would', 'could', 'should', 'may', 'might', 'must', 'can', 'this', 'that', 'these', 'those'
    ]);
    
    this.importanceKeywords = new Set([
      'important', 'significant', 'critical', 'essential', 'key', 'major', 'primary', 'fundamental',
      'crucial', 'vital', 'central', 'core', 'main', 'principal', 'leading', 'dominant'
    ]);
  }

  // Main text processing pipeline
  async processText(text: string, options: {
    includeSentiment?: boolean;
    includeTopics?: boolean;
    includeEntities?: boolean;
    includeKnowledgeGraph?: boolean;
    analysisDepth?: 'basic' | 'detailed' | 'comprehensive' | 'encyclopedic';
  } = {}): Promise<ResearchAnalysis> {
    const startTime = Date.now();
    const {
      includeSentiment = true,
      includeTopics = true,
      includeEntities = true,
      includeKnowledgeGraph = true,
      analysisDepth = 'comprehensive'
    } = options;

    console.log('🔍 Starting enhanced deep research text processing...');
    console.log('📊 Analysis depth:', analysisDepth);

    try {
      // Step 1: Basic text preprocessing
      const processedText = this.preprocessText(text);
      console.log('✅ Text preprocessing completed');

      // Step 2: Entity extraction
      let entities: Entity[] = [];
      if (includeEntities) {
        entities = await this.extractEntities(processedText.processedText, analysisDepth);
        console.log(`✅ Entity extraction completed: ${entities.length} entities found`);
      }

      // Step 3: Sentiment analysis
      let sentiment: SentimentAnalysis | undefined;
      if (includeSentiment) {
        sentiment = await this.analyzeSentiment(processedText.processedText);
        console.log('✅ Sentiment analysis completed');
      }

      // Step 4: Topic modeling
      let topics: Topic[] = [];
      if (includeTopics) {
        topics = await this.performTopicModeling(processedText.sentences, analysisDepth);
        console.log(`✅ Topic modeling completed: ${topics.length} topics identified`);
      }

      // Step 5: Keyword extraction
      const keywords = this.extractKeywords(processedText.processedText, entities);
      console.log(`✅ Keyword extraction completed: ${keywords.length} keywords`);

      // Step 6: Text summarization
      const summary = await this.generateSummary(processedText, analysisDepth);
      console.log('✅ Text summarization completed');

      // Step 7: Knowledge graph construction
      let knowledgeGraph = { nodes: [] as KnowledgeGraphNode[], edges: [] as KnowledgeGraphEdge[] };
      if (includeKnowledgeGraph) {
        knowledgeGraph = this.buildKnowledgeGraph(entities, topics, keywords);
        console.log(`✅ Knowledge graph constructed: ${knowledgeGraph.nodes.length} nodes, ${knowledgeGraph.edges.length} edges`);
      }

      // Step 8: Generate insights
      const insights = this.generateInsights(processedText, entities, topics, sentiment, keywords);
      console.log('✅ Research insights generated');

      const processingTime = Date.now() - startTime;

      const analysis: ResearchAnalysis = {
        processedText,
        entities,
        topics,
        sentiment: sentiment!,
        keywords,
        summary,
        knowledgeGraph,
        insights,
        metadata: {
          processingTime,
          analysisDepth,
          confidence: this.calculateConfidence(entities, topics, sentiment),
          sources: ['text_analysis', 'nlp_processing', 'knowledge_synthesis']
        }
      };

      console.log(`🎉 Deep research analysis completed in ${processingTime}ms`);
      return analysis;

    } catch (error) {
      console.error('❌ Deep research text processing failed:', error);
      throw error;
    }
  }

  // Text preprocessing
  private preprocessText(text: string): ProcessedText {
    // Clean text
    let cleanedText = text
      .replace(/\s+/g, ' ')  // Remove extra whitespace
      .replace(/[^\w\s\.\,\!\?\;\:\-\(\)\[\]\{\}\"\'\/\@\#\$\%\^\&\*\+\=\~\`]/g, '')  // Keep basic punctuation
      .trim();

    // Extract sentences
    const sentences = this.extractSentences(cleanedText);
    
    // Tokenize and clean words
    const words = this.tokenizeAndClean(cleanedText);
    
    // Calculate metadata
    const metadata = {
      wordCount: words.length,
      sentenceCount: sentences.length,
      characterCount: cleanedText.length,
      readingTime: Math.ceil(words.length / 200), // Average reading speed
      complexity: this.calculateComplexity(words, sentences)
    };

    return {
      sentences,
      words,
      processedText: words.join(' '),
      originalText: text,
      metadata
    };
  }

  // Sentence extraction
  private extractSentences(text: string): string[] {
    return text
      .split(/[.!?]+/)
      .map(s => s.trim())
      .filter(s => s.length > 10)
      .map(s => s.endsWith('.') ? s : s + '.');
  }

  // Tokenization and cleaning
  private tokenizeAndClean(text: string): string[] {
    return text
      .toLowerCase()
      .split(/\s+/)
      .filter(word => 
        word.length > 2 && 
        !this.stopWords.has(word) &&
        /^[a-zA-Z\-]+$/.test(word)
      )
      .map(word => word.replace(/^[^a-zA-Z]+|[^a-zA-Z]+$/g, ''));
  }

  // Entity extraction with enhanced NLP
  private async extractEntities(text: string, depth: string): Promise<Entity[]> {
    // Simulate advanced entity extraction with patterns and context
    const entityPatterns = {
      PERSON: /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b/g,
      ORGANIZATION: /\b([A-Z][a-z]+(?:\s+(?:Inc|Corp|Ltd|Company|Organization|University))?)\b/gi,
      LOCATION: /\b([A-Z][a-z]+(?:\s+(?:City|State|Country|River|Mountain))?)\b/gi,
      DATE: /\b(\d{1,2}\/\d{1,2}\/\d{2,4}|\d{4}-\d{2}-\d{2}|\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4})\b/gi,
      MONEY: /\b\$?\d+(?:,\d{3})*(?:\.\d{2})?\s*(?:dollars?|USD?|€|euros?|£|pounds?)?\b/gi,
      PERCENT: /\b\d+(?:\.\d+)?\s*%\b/g,
      TECHNOLOGY: /\b(AI|Artificial Intelligence|Machine Learning|Deep Learning|Neural Network|Blockchain|Cloud Computing|IoT|API|Database|Algorithm)\b/gi,
      CONCEPT: /\b(innovation|strategy|analysis|research|development|implementation|optimization|integration|framework|methodology|architecture)\b/gi
    };

    const entities: Entity[] = [];
    let id = 0;

    for (const [label, pattern] of Object.entries(entityPatterns)) {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        const entityText = match[0];
        const start = match.index!;
        const end = start + entityText.length;
        
        // Calculate importance based on context and keywords
        const importance = this.calculateEntityImportance(entityText, text, start, end);
        
        entities.push({
          text: entityText,
          label,
          confidence: Math.min(0.9 + Math.random() * 0.1, 1.0),
          start,
          end,
          category: this.categorizeEntity(label),
          importance
        });
      }
    }

    // Remove duplicates and sort by importance
    const uniqueEntities = this.deduplicateEntities(entities);
    return uniqueEntities
      .filter(e => e.importance > 0.3)
      .sort((a, b) => b.importance - a.importance)
      .slice(0, depth === 'encyclopedic' ? 50 : depth === 'comprehensive' ? 30 : 20);
  }

  // Calculate entity importance
  private calculateEntityImportance(entityText: string, text: string, start: number, end: number): number {
    let importance = 0.5; // Base importance

    // Check for importance keywords nearby
    const contextWindow = 50;
    const contextStart = Math.max(0, start - contextWindow);
    const contextEnd = Math.min(text.length, end + contextWindow);
    const context = text.substring(contextStart, contextEnd).toLowerCase();

    for (const keyword of this.importanceKeywords) {
      if (context.includes(keyword)) {
        importance += 0.2;
      }
    }

    // Check frequency in text
    const frequency = (text.toLowerCase().match(new RegExp(entityText.toLowerCase(), 'g')) || []).length;
    importance += Math.min(frequency * 0.1, 0.3);

    // Check position (entities near beginning tend to be more important)
    const positionRatio = start / text.length;
    if (positionRatio < 0.3) importance += 0.1;

    // Check entity length (longer entities might be more specific)
    if (entityText.length > 15) importance += 0.1;

    return Math.min(importance, 1.0);
  }

  // Categorize entities
  private categorizeEntity(label: string): string {
    const categoryMap: Record<string, string> = {
      'PERSON': 'people',
      'ORGANIZATION': 'organizations',
      'LOCATION': 'locations',
      'DATE': 'temporal',
      'MONEY': 'financial',
      'PERCENT': 'quantitative',
      'TECHNOLOGY': 'technology',
      'CONCEPT': 'abstract'
    };
    return categoryMap[label] || 'general';
  }

  // Remove duplicate entities
  private deduplicateEntities(entities: Entity[]): Entity[] {
    const seen = new Set();
    return entities.filter(entity => {
      const key = `${entity.text}-${entity.label}`;
      if (seen.has(key)) {
        return false;
      }
      seen.add(key);
      return true;
    });
  }

  // Sentiment analysis
  private async analyzeSentiment(text: string): Promise<SentimentAnalysis> {
    // Simulate sentiment analysis with lexicon-based approach
    const positiveWords = ['good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic', 'positive', 'success', 'effective', 'efficient'];
    const negativeWords = ['bad', 'terrible', 'awful', 'horrible', 'negative', 'failure', 'problem', 'issue', 'difficult', 'challenging'];
    
    const words = text.toLowerCase().split(/\s+/);
    let positiveCount = 0;
    let negativeCount = 0;

    for (const word of words) {
      if (positiveWords.includes(word)) positiveCount++;
      if (negativeWords.includes(word)) negativeCount++;
    }

    const totalSentimentWords = positiveCount + negativeCount;
    let sentiment: 'positive' | 'negative' | 'neutral';
    let confidence: number;
    let score: number;

    if (totalSentimentWords === 0) {
      sentiment = 'neutral';
      confidence = 0.7;
      score = 0;
    } else {
      const positiveRatio = positiveCount / totalSentimentWords;
      score = positiveRatio * 2 - 1; // Scale to [-1, 1]
      
      if (score > 0.2) {
        sentiment = 'positive';
        confidence = 0.6 + (score - 0.2) * 2;
      } else if (score < -0.2) {
        sentiment = 'negative';
        confidence = 0.6 + (-score - 0.2) * 2;
      } else {
        sentiment = 'neutral';
        confidence = 0.7;
      }
    }

    // Simulate aspect-based sentiment
    const aspects = this.extractAspects(text);
    const aspectSentiments = aspects.map(aspect => ({
      aspect,
      sentiment: Math.random() > 0.5 ? 'positive' : 'negative',
      confidence: 0.6 + Math.random() * 0.3
    }));

    // Simulate emotion detection
    const emotions = [
      { emotion: 'joy', intensity: sentiment === 'positive' ? 0.7 : 0.2 },
      { emotion: 'sadness', intensity: sentiment === 'negative' ? 0.7 : 0.2 },
      { emotion: 'anger', intensity: sentiment === 'negative' ? 0.5 : 0.1 },
      { emotion: 'fear', intensity: Math.random() * 0.3 },
      { emotion: 'surprise', intensity: Math.random() * 0.4 }
    ];

    return {
      overall: { sentiment, confidence, score },
      aspects: aspectSentiments,
      emotions
    };
  }

  // Extract aspects for sentiment analysis
  private extractAspects(text: string): string[] {
    const aspectPatterns = [
      /performance/gi, /quality/gi, /service/gi, /price/gi, /design/gi,
      /features/gi, /usability/gi, /reliability/gi, /support/gi, /speed/gi
    ];

    const aspects: string[] = [];
    for (const pattern of aspectPatterns) {
      const match = text.match(pattern);
      if (match) {
        aspects.push(match[0].toLowerCase());
      }
    }

    return [...new Set(aspects)];
  }

  // Topic modeling
  private async performTopicModeling(sentences: string[], depth: string): Promise<Topic[]> {
    // Simulate topic modeling using TF-IDF-like approach
    const allWords = sentences.flatMap(s => s.toLowerCase().split(/\s+/));
    const wordFreq = new Map<string, number>();
    
    // Calculate word frequencies
    for (const word of allWords) {
      if (word.length > 3 && !this.stopWords.has(word)) {
        wordFreq.set(word, (wordFreq.get(word) || 0) + 1);
      }
    }

    // Get most frequent words as potential topic indicators
    const topWords = Array.from(wordFreq.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, depth === 'encyclopedic' ? 100 : depth === 'comprehensive' ? 60 : 40)
      .map(([word]) => word);

    // Generate topics by clustering related words
    const numTopics = depth === 'encyclopedic' ? 8 : depth === 'comprehensive' ? 6 : 4;
    const topics: Topic[] = [];

    for (let i = 0; i < numTopics; i++) {
      const topicWords = this.selectTopicWords(topWords, i, numTopics);
      const coherence = 0.6 + Math.random() * 0.3;
      const relevance = 0.7 + Math.random() * 0.2;
      
      topics.push({
        id: i,
        words: topicWords,
        coherence,
        relevance,
        description: this.generateTopicDescription(topicWords)
      });
    }

    return topics;
  }

  // Select words for a topic
  private selectTopicWords(allWords: string[], topicIndex: number, numTopics: number): string[] {
    const wordsPerTopic = Math.floor(allWords.length / numTopics);
    const start = topicIndex * wordsPerTopic;
    const end = start + wordsPerTopic;
    
    return allWords.slice(start, end).slice(0, 5); // Top 5 words per topic
  }

  // Generate topic description
  private generateTopicDescription(words: string[]): string {
    const templates = [
      `Focuses on ${words.join(', ')} and related concepts`,
      `Explores themes related to ${words[0]} and ${words[1]}`,
      `Covers ${words.slice(0, 3).join(', ')} and associated topics`,
      `Analyzes ${words.join(', ')} from multiple perspectives`
    ];
    
    return templates[Math.floor(Math.random() * templates.length)];
  }

  // Keyword extraction
  private extractKeywords(text: string, entities: Entity[]): string[] {
    const words = text.toLowerCase().split(/\s+/);
    const wordFreq = new Map<string, number>();
    
    // Calculate word frequencies
    for (const word of words) {
      if (word.length > 3 && !this.stopWords.has(word)) {
        wordFreq.set(word, (wordFreq.get(word) || 0) + 1);
      }
    }

    // Boost entity words
    for (const entity of entities) {
      const entityWords = entity.text.toLowerCase().split(/\s+/);
      for (const word of entityWords) {
        if (wordFreq.has(word)) {
          wordFreq.set(word, wordFreq.get(word)! * (1 + entity.importance));
        }
      }
    }

    // Sort by frequency and return top keywords
    return Array.from(wordFreq.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 15)
      .map(([word]) => word);
  }

  // Text summarization
  private async generateSummary(processedText: ProcessedText, depth: string): Promise<string> {
    const { sentences, originalText } = processedText;
    
    if (sentences.length <= 3) {
      return originalText;
    }

    // Simple extractive summarization based on sentence importance
    const sentenceScores = sentences.map((sentence, index) => {
      let score = 0;
      
      // Score based on position (first and last sentences are important)
      if (index === 0 || index === sentences.length - 1) score += 2;
      
      // Score based on length (medium-length sentences are often important)
      const wordCount = sentence.split(/\s+/).length;
      if (wordCount > 10 && wordCount < 30) score += 1;
      
      // Score based on important keywords
      const lowerSentence = sentence.toLowerCase();
      for (const keyword of this.importanceKeywords) {
        if (lowerSentence.includes(keyword)) score += 1;
      }
      
      return { sentence, score, index };
    });

    // Sort by score and select top sentences
    const summaryLength = depth === 'encyclopedic' ? 5 : depth === 'comprehensive' ? 4 : 3;
    const topSentences = sentenceScores
      .sort((a, b) => b.score - a.score)
      .slice(0, summaryLength)
      .sort((a, b) => a.index - b.index); // Maintain original order

    return topSentences.map(s => s.sentence).join(' ');
  }

  // Build knowledge graph
  private buildKnowledgeGraph(entities: Entity[], topics: Topic[], keywords: string[]): {
    nodes: KnowledgeGraphNode[];
    edges: KnowledgeGraphEdge[];
  } {
    const nodes: KnowledgeGraphNode[] = [];
    const edges: KnowledgeGraphEdge[] = [];
    const nodeMap = new Map<string, KnowledgeGraphNode>();

    // Create nodes from entities
    for (const entity of entities) {
      const node: KnowledgeGraphNode = {
        id: `entity_${entity.text.replace(/\s+/g, '_')}`,
        label: entity.text,
        type: entity.label,
        category: entity.category,
        importance: entity.importance,
        mentions: 1,
        relationships: [],
        metadata: {
          confidence: entity.confidence,
          frequency: 1
        }
      };
      
      nodes.push(node);
      nodeMap.set(node.id, node);
    }

    // Create nodes from topics
    for (const topic of topics) {
      const node: KnowledgeGraphNode = {
        id: `topic_${topic.id}`,
        label: `Topic ${topic.id + 1}: ${topic.words[0]}`,
        type: 'TOPIC',
        category: 'thematic',
        importance: topic.relevance,
        mentions: topic.words.length,
        relationships: [],
        metadata: {
          coherence: topic.coherence,
          words: topic.words,
          description: topic.description
        }
      };
      
      nodes.push(node);
      nodeMap.set(node.id, node);
    }

    // Create edges based on co-occurrence and relationships
    for (let i = 0; i < entities.length; i++) {
      for (let j = i + 1; j < entities.length; j++) {
        const entity1 = entities[i];
        const entity2 = entities[j];
        
        // Create relationship if entities are related
        if (this.areEntitiesRelated(entity1, entity2)) {
          const edge: KnowledgeGraphEdge = {
            source: `entity_${entity1.text.replace(/\s+/g, '_')}`,
            target: `entity_${entity2.text.replace(/\s+/g, '_')}`,
            relationship: this.determineRelationship(entity1, entity2),
            weight: (entity1.importance + entity2.importance) / 2,
            type: 'entity_relationship',
            metadata: {
              confidence: Math.min(entity1.confidence, entity2.confidence)
            }
          };
          
          edges.push(edge);
          
          // Add relationships to nodes
          const node1 = nodeMap.get(edge.source);
          const node2 = nodeMap.get(edge.target);
          if (node1 && !node1.relationships.includes(edge.target)) {
            node1.relationships.push(edge.target);
          }
          if (node2 && !node2.relationships.includes(edge.source)) {
            node2.relationships.push(edge.source);
          }
        }
      }
    }

    // Connect entities to topics
    for (const entity of entities) {
      for (const topic of topics) {
        if (this.entityMatchesTopic(entity, topic)) {
          const edge: KnowledgeGraphEdge = {
            source: `entity_${entity.text.replace(/\s+/g, '_')}`,
            target: `topic_${topic.id}`,
            relationship: 'belongs_to_topic',
            weight: entity.importance * topic.relevance,
            type: 'entity_topic',
            metadata: {
              relevance: this.calculateEntityTopicRelevance(entity, topic)
            }
          };
          
          edges.push(edge);
        }
      }
    }

    return { nodes, edges };
  }

  // Check if entities are related
  private areEntitiesRelated(entity1: Entity, entity2: Entity): boolean {
    // Simple heuristic: entities of the same category are related
    if (entity1.category === entity2.category) return true;
    
    // Check for specific relationships
    const relationshipRules = [
      { type1: 'PERSON', type2: 'ORGANIZATION', related: true },
      { type1: 'ORGANIZATION', type2: 'LOCATION', related: true },
      { type1: 'PERSON', type2: 'LOCATION', related: true }
    ];
    
    for (const rule of relationshipRules) {
      if ((entity1.label === rule.type1 && entity2.label === rule.type2) ||
          (entity1.label === rule.type2 && entity2.label === rule.type1)) {
        return true;
      }
    }
    
    return false;
  }

  // Determine relationship between entities
  private determineRelationship(entity1: Entity, entity2: Entity): string {
    const relationshipMap: Record<string, Record<string, string>> = {
      'PERSON': {
        'ORGANIZATION': 'works_for',
        'LOCATION': 'located_in',
        'PERSON': 'related_to'
      },
      'ORGANIZATION': {
        'LOCATION': 'based_in',
        'ORGANIZATION': 'partnered_with'
      },
      'LOCATION': {
        'LOCATION': 'nearby'
      }
    };
    
    return relationshipMap[entity1.label]?.[entity2.label] || 'related_to';
  }

  // Check if entity matches topic
  private entityMatchesTopic(entity: Entity, topic: Topic): boolean {
    const entityText = entity.text.toLowerCase();
    return topic.words.some(word => 
      entityText.includes(word.toLowerCase()) || 
      word.toLowerCase().includes(entityText)
    );
  }

  // Calculate entity-topic relevance
  private calculateEntityTopicRelevance(entity: Entity, topic: Topic): number {
    return entity.importance * topic.relevance * (topic.coherence || 0.5);
  }

  // Generate research insights
  private generateInsights(
    processedText: ProcessedText,
    entities: Entity[],
    topics: Topic[],
    sentiment: SentimentAnalysis | undefined,
    keywords: string[]
  ) {
    const keyFindings: string[] = [];
    const knowledgeGaps: string[] = [];
    const researchQuestions: string[] = [];
    const recommendations: string[] = [];

    // Generate key findings
    if (entities.length > 0) {
      const topEntities = entities.slice(0, 3);
      keyFindings.push(`Primary entities identified: ${topEntities.map(e => e.text).join(', ')}`);
    }

    if (topics.length > 0) {
      const mainTopics = topics.slice(0, 2);
      keyFindings.push(`Main thematic areas: ${mainTopics.map(t => t.description).join('; ')}`);
    }

    if (sentiment) {
      keyFindings.push(`Overall sentiment: ${sentiment.overall.sentiment} (${(sentiment.overall.confidence * 100).toFixed(0)}% confidence)`);
    }

    // Generate knowledge gaps
    if (entities.filter(e => e.category === 'people').length === 0) {
      knowledgeGaps.push('Limited information about key individuals or stakeholders');
    }

    if (entities.filter(e => e.category === 'temporal').length === 0) {
      knowledgeGaps.push('Missing temporal context or timeline information');
    }

    if (keywords.length < 5) {
      knowledgeGaps.push('Limited keyword diversity may indicate narrow scope');
    }

    // Generate research questions
    researchQuestions.push(
      'What are the underlying causes and effects of the main phenomena?',
      'How do the identified entities interact and influence each other?',
      'What are the long-term implications of the current findings?',
      'What additional data sources could provide more comprehensive insights?'
    );

    // Generate recommendations
    recommendations.push(
      'Consider expanding the research to include more diverse sources',
      'Implement quantitative analysis to complement qualitative findings',
      'Conduct longitudinal studies to track changes over time',
      'Validate findings through expert consultation or peer review'
    );

    return {
      keyFindings,
      knowledgeGaps,
      researchQuestions,
      recommendations
    };
  }

  // Calculate text complexity
  private calculateComplexity(words: string[], sentences: string[]): number {
    if (sentences.length === 0) return 0;
    
    const avgWordsPerSentence = words.length / sentences.length;
    const avgWordLength = words.reduce((sum, word) => sum + word.length, 0) / words.length;
    
    // Normalize complexity score (0-1)
    const complexity = (avgWordsPerSentence / 20 + avgWordLength / 8) / 2;
    return Math.min(complexity, 1.0);
  }

  // Calculate overall confidence score
  private calculateConfidence(entities: Entity[], topics: Topic[], sentiment?: SentimentAnalysis): number {
    let confidence = 0.7; // Base confidence
    
    // Boost confidence based on entity quality
    const avgEntityConfidence = entities.length > 0 
      ? entities.reduce((sum, e) => sum + e.confidence, 0) / entities.length 
      : 0.5;
    confidence += avgEntityConfidence * 0.2;
    
    // Boost confidence based on topic coherence
    const avgTopicCoherence = topics.length > 0
      ? topics.reduce((sum, t) => sum + (t.coherence || 0.5), 0) / topics.length
      : 0.5;
    confidence += avgTopicCoherence * 0.1;
    
    return Math.min(confidence, 1.0);
  }
}