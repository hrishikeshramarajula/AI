// 🕸️ Enhanced Knowledge Graph Construction
// Advanced entity relationship mapping and knowledge graph visualization

import { 
  KnowledgeGraphNode, 
  KnowledgeGraphEdge, 
  Entity, 
  Topic 
} from './textProcessor';

export interface GraphMetrics {
  nodes: number;
  edges: number;
  density: number;
  averageDegree: number;
  clusteringCoefficient: number;
  connectedComponents: number;
  diameter: number;
}

export interface Community {
  id: string;
  nodes: string[];
  label: string;
  importance: number;
  themes: string[];
  metadata: Record<string, any>;
}

export interface PathAnalysis {
  source: string;
  target: string;
  paths: Array<{
    nodes: string[];
    edges: string[];
    length: number;
    weight: number;
  }>;
  shortestPath: string[];
  distance: number;
}

export interface CentralityMeasures {
  degree: Record<string, number>;
  betweenness: Record<string, number>;
  closeness: Record<string, number>;
  eigenvector: Record<string, number>;
  pagerank: Record<string, number>;
}

export class KnowledgeGraphConstructor {
  private nodes: Map<string, KnowledgeGraphNode>;
  private edges: Map<string, KnowledgeGraphEdge>;
  private adjacencyList: Map<string, Array<{ neighbor: string; edge: string }>>;

  constructor() {
    this.nodes = new Map();
    this.edges = new Map();
    this.adjacencyList = new Map();
  }

  // Build comprehensive knowledge graph from entities and topics
  buildEnhancedKnowledgeGraph(
    entities: Entity[], 
    topics: Topic[], 
    options: {
      includeSemanticRelationships?: boolean;
      includeTemporalRelationships?: boolean;
      includeCausalRelationships?: boolean;
      minConfidence?: number;
      maxNodes?: number;
    } = {}
  ): {
    nodes: KnowledgeGraphNode[];
    edges: KnowledgeGraphEdge[];
    metrics: GraphMetrics;
    communities: Community[];
    centrality: CentralityMeasures;
  } {
    const {
      includeSemanticRelationships = true,
      includeTemporalRelationships = true,
      includeCausalRelationships = true,
      minConfidence = 0.3,
      maxNodes = 200
    } = options;

    console.log('🕸️ Building enhanced knowledge graph...');

    // Clear existing data
    this.nodes.clear();
    this.edges.clear();
    this.adjacencyList.clear();

    // Step 1: Create nodes from entities
    this.createEntityNodes(entities, minConfidence, maxNodes);
    
    // Step 2: Create nodes from topics
    this.createTopicNodes(topics);
    
    // Step 3: Create entity-entity relationships
    this.createEntityRelationships(entities, includeSemanticRelationships);
    
    // Step 4: Create entity-topic relationships
    this.createEntityTopicRelationships(entities, topics);
    
    // Step 5: Create topic-topic relationships
    this.createTopicRelationships(topics);
    
    // Step 6: Add temporal relationships if enabled
    if (includeTemporalRelationships) {
      this.addTemporalRelationships(entities);
    }
    
    // Step 7: Add causal relationships if enabled
    if (includeCausalRelationships) {
      this.addCausalRelationships(entities);
    }

    // Step 8: Calculate graph metrics
    const metrics = this.calculateGraphMetrics();
    
    // Step 9: Detect communities
    const communities = this.detectCommunities();
    
    // Step 10: Calculate centrality measures
    const centrality = this.calculateCentralityMeasures();

    console.log(`✅ Knowledge graph built: ${this.nodes.size} nodes, ${this.edges.size} edges`);

    return {
      nodes: Array.from(this.nodes.values()),
      edges: Array.from(this.edges.values()),
      metrics,
      communities,
      centrality
    };
  }

  // Create nodes from entities
  private createEntityNodes(entities: Entity[], minConfidence: number, maxNodes: number): void {
    const sortedEntities = entities
      .filter(e => e.confidence >= minConfidence)
      .sort((a, b) => b.importance - a.importance)
      .slice(0, maxNodes);

    for (const entity of sortedEntities) {
      const nodeId = `entity_${entity.text.replace(/\s+/g, '_').toLowerCase()}`;
      
      const node: KnowledgeGraphNode = {
        id: nodeId,
        label: entity.text,
        type: entity.label,
        category: entity.category,
        importance: entity.importance,
        mentions: 1,
        relationships: [],
        metadata: {
          confidence: entity.confidence,
          frequency: 1,
          source: 'entity_extraction',
          originalLabel: entity.label,
          start: entity.start,
          end: entity.end
        }
      };

      this.nodes.set(nodeId, node);
      this.adjacencyList.set(nodeId, []);
    }
  }

  // Create nodes from topics
  private createTopicNodes(topics: Topic[]): void {
    for (const topic of topics) {
      const nodeId = `topic_${topic.id}`;
      
      const node: KnowledgeGraphNode = {
        id: nodeId,
        label: `Topic: ${topic.words[0]}`,
        type: 'TOPIC',
        category: 'thematic',
        importance: topic.relevance,
        mentions: topic.words.length,
        relationships: [],
        metadata: {
          coherence: topic.coherence,
          words: topic.words,
          description: topic.description,
          source: 'topic_modeling'
        }
      };

      this.nodes.set(nodeId, node);
      this.adjacencyList.set(nodeId, []);
    }
  }

  // Create relationships between entities
  private createEntityRelationships(entities: Entity[], includeSemantic: boolean): void {
    for (let i = 0; i < entities.length; i++) {
      for (let j = i + 1; j < entities.length; j++) {
        const entity1 = entities[i];
        const entity2 = entities[j];
        
        const nodeId1 = `entity_${entity1.text.replace(/\s+/g, '_').toLowerCase()}`;
        const nodeId2 = `entity_${entity2.text.replace(/\s+/g, '_').toLowerCase()}`;
        
        if (!this.nodes.has(nodeId1) || !this.nodes.has(nodeId2)) continue;

        // Determine relationship type and strength
        const relationship = this.determineEntityRelationship(entity1, entity2);
        const weight = this.calculateRelationshipWeight(entity1, entity2, relationship);

        if (weight > 0.3) { // Only create significant relationships
          this.createEdge(nodeId1, nodeId2, relationship.type, weight, 'entity_relationship', {
            confidence: Math.min(entity1.confidence, entity2.confidence),
            semanticScore: relationship.semanticScore,
            contextualScore: relationship.contextualScore,
            relationshipType: relationship.type
          });
        }
      }
    }

    // Add semantic relationships if enabled
    if (includeSemantic) {
      this.addSemanticRelationships();
    }
  }

  // Determine relationship between entities
  private determineEntityRelationship(entity1: Entity, entity2: Entity): {
    type: string;
    semanticScore: number;
    contextualScore: number;
  } {
    // Direct relationship mapping
    const relationshipMap: Record<string, Record<string, string>> = {
      'PERSON': {
        'ORGANIZATION': 'works_for',
        'LOCATION': 'located_in',
        'PERSON': 'related_to'
      },
      'ORGANIZATION': {
        'LOCATION': 'based_in',
        'ORGANIZATION': 'partnered_with',
        'PERSON': 'employs'
      },
      'LOCATION': {
        'LOCATION': 'nearby',
        'PERSON': 'birthplace_of',
        'ORGANIZATION': 'location_of'
      },
      'DATE': {
        'PERSON': 'born_on',
        'ORGANIZATION': 'founded_on',
        'EVENT': 'occurred_on'
      },
      'MONEY': {
        'ORGANIZATION': 'revenue_of',
        'PERSON': 'salary_of',
        'PROJECT': 'budget_of'
      }
    };

    const directType = relationshipMap[entity1.label]?.[entity2.label] || 
                      relationshipMap[entity2.label]?.[entity1.label] || 
                      'related_to';

    // Calculate semantic similarity
    const semanticScore = this.calculateSemanticSimilarity(entity1, entity2);
    
    // Calculate contextual relevance
    const contextualScore = this.calculateContextualRelevance(entity1, entity2);

    return {
      type: directType,
      semanticScore,
      contextualScore
    };
  }

  // Calculate semantic similarity between entities
  private calculateSemanticSimilarity(entity1: Entity, entity2: Entity): number {
    let similarity = 0;

    // Category similarity
    if (entity1.category === entity2.category) {
      similarity += 0.4;
    }

    // Type-based similarity
    const typeSimilarityMap: Record<string, Record<string, number>> = {
      'PERSON': { 'PERSON': 0.8, 'ORGANIZATION': 0.3, 'LOCATION': 0.2 },
      'ORGANIZATION': { 'ORGANIZATION': 0.7, 'PERSON': 0.3, 'LOCATION': 0.4 },
      'LOCATION': { 'LOCATION': 0.9, 'PERSON': 0.2, 'ORGANIZATION': 0.4 },
      'DATE': { 'DATE': 0.6, 'PERSON': 0.3, 'ORGANIZATION': 0.2 },
      'MONEY': { 'MONEY': 0.8, 'ORGANIZATION': 0.5, 'PERSON': 0.3 }
    };

    similarity += typeSimilarityMap[entity1.label]?.[entity2.label] || 0;

    return Math.min(similarity, 1.0);
  }

  // Calculate contextual relevance
  private calculateContextualRelevance(entity1: Entity, entity2: Entity): number {
    // Simple heuristic based on importance and confidence
    const importanceFactor = (entity1.importance + entity2.importance) / 2;
    const confidenceFactor = (entity1.confidence + entity2.confidence) / 2;
    
    return (importanceFactor + confidenceFactor) / 2;
  }

  // Calculate relationship weight
  private calculateRelationshipWeight(entity1: Entity, entity2: Entity, relationship: any): number {
    const baseWeight = (relationship.semanticScore + relationship.contextualScore) / 2;
    const importanceWeight = (entity1.importance + entity2.importance) / 2;
    const confidenceWeight = (entity1.confidence + entity2.confidence) / 2;
    
    return (baseWeight * 0.4 + importanceWeight * 0.4 + confidenceWeight * 0.2);
  }

  // Create entity-topic relationships
  private createEntityTopicRelationships(entities: Entity[], topics: Topic[]): void {
    for (const entity of entities) {
      const entityId = `entity_${entity.text.replace(/\s+/g, '_').toLowerCase()}`;
      if (!this.nodes.has(entityId)) continue;

      for (const topic of topics) {
        const topicId = `topic_${topic.id}`;
        if (!this.nodes.has(topicId)) continue;

        const relevance = this.calculateEntityTopicRelevance(entity, topic);
        
        if (relevance > 0.3) {
          this.createEdge(entityId, topicId, 'belongs_to_topic', relevance, 'entity_topic', {
            relevance: relevance,
            confidence: entity.confidence * topic.coherence,
            strength: relevance
          });
        }
      }
    }
  }

  // Calculate entity-topic relevance
  private calculateEntityTopicRelevance(entity: Entity, topic: Topic): number {
    const entityText = entity.text.toLowerCase();
    let relevance = 0;

    // Check if entity words match topic words
    for (const topicWord of topic.words) {
      if (entityText.includes(topicWord.toLowerCase()) || 
          topicWord.toLowerCase().includes(entityText)) {
        relevance += 0.3;
      }
    }

    // Factor in importance and coherence
    relevance *= entity.importance * (topic.coherence || 0.5) * topic.relevance;

    return Math.min(relevance, 1.0);
  }

  // Create topic-topic relationships
  private createTopicRelationships(topics: Topic[]): void {
    for (let i = 0; i < topics.length; i++) {
      for (let j = i + 1; j < topics.length; j++) {
        const topic1 = topics[i];
        const topic2 = topics[j];
        
        const topicId1 = `topic_${topic1.id}`;
        const topicId2 = `topic_${topic2.id}`;
        
        if (!this.nodes.has(topicId1) || !this.nodes.has(topicId2)) continue;

        const similarity = this.calculateTopicSimilarity(topic1, topic2);
        
        if (similarity > 0.3) {
          this.createEdge(topicId1, topicId2, 'similar_to', similarity, 'topic_relationship', {
            similarity: similarity,
            coherence: (topic1.coherence + topic2.coherence) / 2,
            sharedWords: this.countSharedWords(topic1.words, topic2.words)
          });
        }
      }
    }
  }

  // Calculate similarity between topics
  private calculateTopicSimilarity(topic1: Topic, topic2: Topic): number {
    const sharedWords = this.countSharedWords(topic1.words, topic2.words);
    const totalWords = new Set([...topic1.words, ...topic2.words]).size;
    
    const jaccardSimilarity = totalWords > 0 ? sharedWords / totalWords : 0;
    
    // Factor in coherence and relevance
    const coherenceFactor = (topic1.coherence + topic2.coherence) / 2;
    const relevanceFactor = (topic1.relevance + topic2.relevance) / 2;
    
    return jaccardSimilarity * 0.6 + coherenceFactor * 0.2 + relevanceFactor * 0.2;
  }

  // Count shared words between topics
  private countSharedWords(words1: string[], words2: string[]): number {
    const set1 = new Set(words1.map(w => w.toLowerCase()));
    const set2 = new Set(words2.map(w => w.toLowerCase()));
    
    let shared = 0;
    for (const word of set1) {
      if (set2.has(word)) shared++;
    }
    
    return shared;
  }

  // Add semantic relationships
  private addSemanticRelationships(): void {
    // Group entities by category
    const categoryGroups = new Map<string, string[]>();
    
    for (const [nodeId, node] of this.nodes) {
      if (node.type !== 'TOPIC') {
        if (!categoryGroups.has(node.category)) {
          categoryGroups.set(node.category, []);
        }
        categoryGroups.get(node.category)!.push(nodeId);
      }
    }

    // Create relationships within categories
    for (const [category, nodeIds] of categoryGroups) {
      if (nodeIds.length > 1) {
        for (let i = 0; i < nodeIds.length; i++) {
          for (let j = i + 1; j < nodeIds.length; j++) {
            const nodeId1 = nodeIds[i];
            const nodeId2 = nodeIds[j];
            
            // Check if relationship already exists
            if (!this.edgeExists(nodeId1, nodeId2)) {
              this.createEdge(nodeId1, nodeId2, 'same_category', 0.5, 'semantic_relationship', {
                category: category,
                semanticType: 'categorical_similarity'
              });
            }
          }
        }
      }
    }
  }

  // Add temporal relationships
  private addTemporalRelationships(entities: Entity[]): void {
    const dateEntities = entities.filter(e => e.label === 'DATE');
    const otherEntities = entities.filter(e => e.label !== 'DATE');

    for (const dateEntity of dateEntities) {
      const dateNodeId = `entity_${dateEntity.text.replace(/\s+/g, '_').toLowerCase()}`;
      if (!this.nodes.has(dateNodeId)) continue;

      for (const otherEntity of otherEntities) {
        const otherNodeId = `entity_${otherEntity.text.replace(/\s+/g, '_').toLowerCase()}`;
        if (!this.nodes.has(otherNodeId)) continue;

        // Create temporal relationship
        this.createEdge(otherNodeId, dateNodeId, 'associated_with_time', 0.6, 'temporal_relationship', {
          date: dateEntity.text,
          confidence: dateEntity.confidence,
          temporalType: 'association'
        });
      }
    }
  }

  // Add causal relationships
  private addCausalRelationships(entities: Entity[]): void {
    // Simple heuristic: look for causal patterns in entity types
    const causalPatterns = [
      { cause: 'PERSON', effect: 'ORGANIZATION', relationship: 'influences' },
      { cause: 'ORGANIZATION', effect: 'LOCATION', relationship: 'impacts' },
      { cause: 'TECHNOLOGY', effect: 'CONCEPT', relationship: 'enables' }
    ];

    for (const pattern of causalPatterns) {
      const causeEntities = entities.filter(e => e.label === pattern.cause);
      const effectEntities = entities.filter(e => e.label === pattern.effect);

      for (const causeEntity of causeEntities) {
        for (const effectEntity of effectEntities) {
          const causeNodeId = `entity_${causeEntity.text.replace(/\s+/g, '_').toLowerCase()}`;
          const effectNodeId = `entity_${effectEntity.text.replace(/\s+/g, '_').toLowerCase()}`;
          
          if (!this.nodes.has(causeNodeId) || !this.nodes.has(effectNodeId)) continue;

          // Create causal relationship
          this.createEdge(causeNodeId, effectNodeId, pattern.relationship, 0.7, 'causal_relationship', {
            causalType: pattern.relationship,
            confidence: (causeEntity.confidence + effectEntity.confidence) / 2,
            strength: 0.7
          });
        }
      }
    }
  }

  // Create an edge between nodes
  private createEdge(
    source: string, 
    target: string, 
    relationship: string, 
    weight: number, 
    type: string, 
    metadata: Record<string, any> = {}
  ): void {
    const edgeId = `${source}_${target}_${relationship}`;
    
    const edge: KnowledgeGraphEdge = {
      source,
      target,
      relationship,
      weight,
      type,
      metadata: {
        ...metadata,
        createdAt: new Date().toISOString()
      }
    };

    this.edges.set(edgeId, edge);
    
    // Update adjacency list
    if (!this.adjacencyList.has(source)) {
      this.adjacencyList.set(source, []);
    }
    if (!this.adjacencyList.has(target)) {
      this.adjacencyList.set(target, []);
    }
    
    this.adjacencyList.get(source)!.push({ neighbor: target, edge: edgeId });
    this.adjacencyList.get(target)!.push({ neighbor: source, edge: edgeId });

    // Update node relationships
    const sourceNode = this.nodes.get(source);
    const targetNode = this.nodes.get(target);
    
    if (sourceNode && !sourceNode.relationships.includes(target)) {
      sourceNode.relationships.push(target);
    }
    if (targetNode && !targetNode.relationships.includes(source)) {
      targetNode.relationships.push(source);
    }
  }

  // Check if edge exists between nodes
  private edgeExists(source: string, target: string): boolean {
    for (const edge of this.edges.values()) {
      if ((edge.source === source && edge.target === target) || 
          (edge.source === target && edge.target === source)) {
        return true;
      }
    }
    return false;
  }

  // Calculate graph metrics
  private calculateGraphMetrics(): GraphMetrics {
    const nodeCount = this.nodes.size;
    const edgeCount = this.edges.size;
    
    if (nodeCount === 0) {
      return {
        nodes: 0,
        edges: 0,
        density: 0,
        averageDegree: 0,
        clusteringCoefficient: 0,
        connectedComponents: 0,
        diameter: 0
      };
    }

    // Calculate density
    const maxPossibleEdges = nodeCount * (nodeCount - 1) / 2;
    const density = edgeCount / maxPossibleEdges;

    // Calculate average degree
    let totalDegree = 0;
    for (const [nodeId, neighbors] of this.adjacencyList) {
      totalDegree += neighbors.length;
    }
    const averageDegree = totalDegree / nodeCount;

    // Calculate clustering coefficient (simplified)
    const clusteringCoefficient = this.calculateClusteringCoefficient();

    // Calculate connected components
    const connectedComponents = this.calculateConnectedComponents();

    // Calculate diameter (simplified - longest shortest path)
    const diameter = this.calculateDiameter();

    return {
      nodes: nodeCount,
      edges: edgeCount,
      density,
      averageDegree,
      clusteringCoefficient,
      connectedComponents,
      diameter
    };
  }

  // Calculate clustering coefficient
  private calculateClusteringCoefficient(): number {
    let totalClustering = 0;
    let nodeCount = 0;

    for (const [nodeId, neighbors] of this.adjacencyList) {
      if (neighbors.length < 2) continue;

      const neighborIds = neighbors.map(n => n.neighbor);
      let triangles = 0;

      for (let i = 0; i < neighborIds.length; i++) {
        for (let j = i + 1; j < neighborIds.length; j++) {
          if (this.edgeExists(neighborIds[i], neighborIds[j])) {
            triangles++;
          }
        }
      }

      const possibleTriangles = neighborIds.length * (neighborIds.length - 1) / 2;
      if (possibleTriangles > 0) {
        totalClustering += triangles / possibleTriangles;
        nodeCount++;
      }
    }

    return nodeCount > 0 ? totalClustering / nodeCount : 0;
  }

  // Calculate connected components using BFS
  private calculateConnectedComponents(): number {
    const visited = new Set<string>();
    let components = 0;

    for (const nodeId of this.nodes.keys()) {
      if (!visited.has(nodeId)) {
        this.bfs(nodeId, visited);
        components++;
      }
    }

    return components;
  }

  // BFS traversal
  private bfs(startNode: string, visited: Set<string>): void {
    const queue = [startNode];
    visited.add(startNode);

    while (queue.length > 0) {
      const currentNode = queue.shift()!;
      const neighbors = this.adjacencyList.get(currentNode) || [];

      for (const neighbor of neighbors) {
        if (!visited.has(neighbor.neighbor)) {
          visited.add(neighbor.neighbor);
          queue.push(neighbor.neighbor);
        }
      }
    }
  }

  // Calculate graph diameter (simplified)
  private calculateDiameter(): number {
    // This is a simplified version - in practice, you'd use Floyd-Warshall or BFS from each node
    const nodeIds = Array.from(this.nodes.keys());
    let maxDistance = 0;

    for (let i = 0; i < Math.min(nodeIds.length, 10); i++) {
      for (let j = i + 1; j < Math.min(nodeIds.length, 10); j++) {
        const distance = this.calculateShortestPath(nodeIds[i], nodeIds[j]);
        maxDistance = Math.max(maxDistance, distance);
      }
    }

    return maxDistance;
  }

  // Calculate shortest path between two nodes (BFS)
  private calculateShortestPath(source: string, target: string): number {
    if (source === target) return 0;

    const visited = new Set<string>();
    const queue = [{ node: source, distance: 0 }];
    visited.add(source);

    while (queue.length > 0) {
      const { node, distance } = queue.shift()!;
      
      if (node === target) return distance;

      const neighbors = this.adjacencyList.get(node) || [];
      for (const neighbor of neighbors) {
        if (!visited.has(neighbor.neighbor)) {
          visited.add(neighbor.neighbor);
          queue.push({ node: neighbor.neighbor, distance: distance + 1 });
        }
      }
    }

    return Infinity; // No path exists
  }

  // Detect communities using simplified Louvain method
  private detectCommunities(): Community[] {
    const communities: Community[] = [];
    const visited = new Set<string>();
    let communityId = 0;

    for (const [nodeId, node] of this.nodes) {
      if (!visited.has(nodeId)) {
        const community = this.growCommunity(nodeId, visited, communityId);
        communities.push(community);
        communityId++;
      }
    }

    return communities.sort((a, b) => b.importance - a.importance);
  }

  // Grow a community from a seed node
  private growCommunity(seedNode: string, visited: Set<string>, communityId: number): Community {
    const communityNodes: string[] = [];
    const queue = [seedNode];
    visited.add(seedNode);

    while (queue.length > 0) {
      const currentNode = queue.shift()!;
      communityNodes.push(currentNode);

      const neighbors = this.adjacencyList.get(currentNode) || [];
      for (const neighbor of neighbors) {
        if (!visited.has(neighbor.neighbor)) {
          // Check if neighbor should be included in community
          if (this.shouldIncludeInCommunity(currentNode, neighbor.neighbor)) {
            visited.add(neighbor.neighbor);
            queue.push(neighbor.neighbor);
          }
        }
      }
    }

    // Calculate community importance and themes
    const importance = this.calculateCommunityImportance(communityNodes);
    const themes = this.extractCommunityThemes(communityNodes);

    return {
      id: `community_${communityId}`,
      nodes: communityNodes,
      label: `Community ${communityId + 1}`,
      importance,
      themes,
      metadata: {
        size: communityNodes.length,
        density: this.calculateCommunityDensity(communityNodes),
        averageImportance: communityNodes.reduce((sum, nodeId) => 
          sum + (this.nodes.get(nodeId)?.importance || 0), 0) / communityNodes.length
      }
    };
  }

  // Determine if a node should be included in a community
  private shouldIncludeInCommunity(node1: string, node2: string): boolean {
    const edge = this.findEdge(node1, node2);
    if (!edge) return false;

    // Include if edge weight is above threshold
    return edge.weight > 0.4;
  }

  // Find edge between two nodes
  private findEdge(node1: string, node2: string): KnowledgeGraphEdge | undefined {
    for (const edge of this.edges.values()) {
      if ((edge.source === node1 && edge.target === node2) || 
          (edge.source === node2 && edge.target === node1)) {
        return edge;
      }
    }
    return undefined;
  }

  // Calculate community importance
  private calculateCommunityImportance(nodeIds: string[]): number {
    let totalImportance = 0;
    let totalConnections = 0;

    for (const nodeId of nodeIds) {
      const node = this.nodes.get(nodeId);
      if (node) {
        totalImportance += node.importance;
        totalConnections += node.relationships.length;
      }
    }

    const avgImportance = totalImportance / nodeIds.length;
    const avgConnections = totalConnections / nodeIds.length;

    return (avgImportance + avgConnections / 10) / 2; // Normalize
  }

  // Extract themes from community
  private extractCommunityThemes(nodeIds: string[]): string[] {
    const themes: string[] = [];
    const categories = new Set<string>();
    const types = new Set<string>();

    for (const nodeId of nodeIds) {
      const node = this.nodes.get(nodeId);
      if (node) {
        categories.add(node.category);
        types.add(node.type);
      }
    }

    // Convert to themes
    if (categories.has('technology')) themes.push('Technology-focused');
    if (categories.has('people')) themes.push('People-centric');
    if (categories.has('organizations')) themes.push('Organizational');
    if (types.has('TOPIC')) themes.push('Thematic analysis');
    if (categories.has('abstract')) themes.push('Conceptual');

    return themes.length > 0 ? themes : ['General'];
  }

  // Calculate community density
  private calculateCommunityDensity(nodeIds: string[]): number {
    if (nodeIds.length <= 1) return 1.0;

    let internalEdges = 0;
    const maxPossibleEdges = nodeIds.length * (nodeIds.length - 1) / 2;

    for (let i = 0; i < nodeIds.length; i++) {
      for (let j = i + 1; j < nodeIds.length; j++) {
        if (this.edgeExists(nodeIds[i], nodeIds[j])) {
          internalEdges++;
        }
      }
    }

    return internalEdges / maxPossibleEdges;
  }

  // Calculate centrality measures
  private calculateCentralityMeasures(): CentralityMeasures {
    const nodeIds = Array.from(this.nodes.keys());
    const degree: Record<string, number> = {};
    const betweenness: Record<string, number> = {};
    const closeness: Record<string, number> = {};
    const eigenvector: Record<string, number> = {};
    const pagerank: Record<string, number> = {};

    // Initialize
    for (const nodeId of nodeIds) {
      degree[nodeId] = 0;
      betweenness[nodeId] = 0;
      closeness[nodeId] = 0;
      eigenvector[nodeId] = 0;
      pagerank[nodeId] = 0;
    }

    // Degree centrality
    for (const [nodeId, neighbors] of this.adjacencyList) {
      degree[nodeId] = neighbors.length;
    }

    // Betweenness centrality (simplified)
    for (const nodeId of nodeIds) {
      betweenness[nodeId] = this.calculateBetweennessCentrality(nodeId);
    }

    // Closeness centrality (simplified)
    for (const nodeId of nodeIds) {
      closeness[nodeId] = this.calculateClosenessCentrality(nodeId);
    }

    // Eigenvector centrality (simplified)
    for (const nodeId of nodeIds) {
      eigenvector[nodeId] = this.calculateEigenvectorCentrality(nodeId);
    }

    // PageRank (simplified)
    for (const nodeId of nodeIds) {
      pagerank[nodeId] = this.calculatePageRank(nodeId);
    }

    return { degree, betweenness, closeness, eigenvector, pagerank };
  }

  // Calculate betweenness centrality
  private calculateBetweennessCentrality(nodeId: string): number {
    // Simplified betweenness calculation
    const neighbors = this.adjacencyList.get(nodeId) || [];
    return neighbors.length / this.nodes.size;
  }

  // Calculate closeness centrality
  private calculateClosenessCentrality(nodeId: string): number {
    let totalDistance = 0;
    let reachableNodes = 0;

    for (const otherNodeId of this.nodes.keys()) {
      if (nodeId !== otherNodeId) {
        const distance = this.calculateShortestPath(nodeId, otherNodeId);
        if (distance !== Infinity) {
          totalDistance += distance;
          reachableNodes++;
        }
      }
    }

    if (reachableNodes === 0) return 0;
    return reachableNodes / totalDistance;
  }

  // Calculate eigenvector centrality (simplified)
  private calculateEigenvectorCentrality(nodeId: string): number {
    const node = this.nodes.get(nodeId);
    if (!node) return 0;

    // Simplified: based on importance of neighbors
    const neighbors = this.adjacencyList.get(nodeId) || [];
    let neighborImportance = 0;

    for (const neighbor of neighbors) {
      const neighborNode = this.nodes.get(neighbor.neighbor);
      if (neighborNode) {
        neighborImportance += neighborNode.importance;
      }
    }

    return node.importance * (1 + neighborImportance / 10);
  }

  // Calculate PageRank (simplified)
  private calculatePageRank(nodeId: string): number {
    const node = this.nodes.get(nodeId);
    if (!node) return 0;

    const neighbors = this.adjacencyList.get(nodeId) || [];
    let incomingImportance = 0;

    for (const [otherNodeId, otherNeighbors] of this.adjacencyList) {
      if (otherNodeId !== nodeId) {
        const otherNode = this.nodes.get(otherNodeId);
        if (otherNode) {
          const hasLinkToNode = otherNeighbors.some(n => n.neighbor === nodeId);
          if (hasLinkToNode) {
            incomingImportance += otherNode.importance / otherNeighbors.length;
          }
        }
      }
    }

    return 0.15 + 0.85 * incomingImportance; // Damping factor 0.85
  }

  // Path analysis between nodes
  analyzePath(source: string, target: string): PathAnalysis {
    const paths = this.findAllPaths(source, target, 4); // Max path length 4
    const shortestPath = this.findShortestPath(source, target);
    const distance = shortestPath.length - 1;

    return {
      source,
      target,
      paths,
      shortestPath,
      distance
    };
  }

  // Find all paths between nodes (with max length)
  private findAllPaths(source: string, target: string, maxLength: number): Array<{
    nodes: string[];
    edges: string[];
    length: number;
    weight: number;
  }> {
    const paths: Array<{ nodes: string[]; edges: string[]; length: number; weight: number }> = [];
    const visited = new Set<string>();

    this.dfsFindPaths(source, target, visited, [source], [], paths, maxLength);

    return paths;
  }

  // DFS to find all paths
  private dfsFindPaths(
    current: string,
    target: string,
    visited: Set<string>,
    currentPath: string[],
    currentEdges: string[],
    allPaths: Array<{ nodes: string[]; edges: string[]; length: number; weight: number }>,
    maxLength: number
  ): void {
    if (current === target) {
      const pathWeight = this.calculatePathWeight(currentEdges);
      allPaths.push({
        nodes: [...currentPath],
        edges: [...currentEdges],
        length: currentPath.length - 1,
        weight: pathWeight
      });
      return;
    }

    if (currentPath.length - 1 >= maxLength) return;

    visited.add(current);

    const neighbors = this.adjacencyList.get(current) || [];
    for (const neighbor of neighbors) {
      if (!visited.has(neighbor.neighbor)) {
        currentPath.push(neighbor.neighbor);
        currentEdges.push(neighbor.edge);
        
        this.dfsFindPaths(neighbor.neighbor, target, visited, currentPath, currentEdges, allPaths, maxLength);
        
        currentPath.pop();
        currentEdges.pop();
      }
    }

    visited.delete(current);
  }

  // Calculate path weight
  private calculatePathWeight(edgeIds: string[]): number {
    let totalWeight = 0;
    for (const edgeId of edgeIds) {
      const edge = this.edges.get(edgeId);
      if (edge) {
        totalWeight += edge.weight;
      }
    }
    return edgeIds.length > 0 ? totalWeight / edgeIds.length : 0;
  }

  // Find shortest path using BFS
  private findShortestPath(source: string, target: string): string[] {
    if (source === target) return [source];

    const queue: { node: string; path: string[] }[] = [{ node: source, path: [source] }];
    const visited = new Set<string>([source]);

    while (queue.length > 0) {
      const { node, path } = queue.shift()!;
      
      if (node === target) return path;

      const neighbors = this.adjacencyList.get(node) || [];
      for (const neighbor of neighbors) {
        if (!visited.has(neighbor.neighbor)) {
          visited.add(neighbor.neighbor);
          queue.push({ node: neighbor.neighbor, path: [...path, neighbor.neighbor] });
        }
      }
    }

    return []; // No path found
  }
}