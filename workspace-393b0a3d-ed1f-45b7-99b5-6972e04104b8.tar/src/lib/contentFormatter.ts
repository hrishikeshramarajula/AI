/**
 * Enhanced Content Formatter for Clean, Professional Output
 * Removes unwanted symbols and provides well-structured, readable content
 */

export interface FormatOptions {
  removeMarkdown?: boolean;
  enhanceReadability?: boolean;
  structureContent?: boolean;
  optimizeSpacing?: boolean;
  useProfessionalFonts?: boolean;
  headingStyle?: 'clean' | 'elegant' | 'modern';
  listStyle?: 'clean' | 'elegant' | 'minimal';
}

export class ContentFormatter {
  private static readonly MARKDOWN_PATTERNS = {
    headings: /^#{1,6}\s*\*\*([^*]+)\*\*/gm,
    boldText: /\*\*([^*]+)\*\*/g,
    italicText: /\*([^*]+)\*/g,
    codeBlocks: /```[\s\S]*?```/g,
    inlineCode: /`([^`]+)`/g,
    links: /\[([^\]]+)\]\(([^)]+)\)/g,
    horizontalRules: /^[-*_]{3,}$/gm,
    blockquotes: /^>\s*/gm,
    // Additional patterns to catch more markdown variations
    markdownHeadings: /^#{1,6}\s*(.+)$/gm,
    markdownBoldAlt: /\_\_([^_]+)\_\_/g,
    markdownItalicAlt: /\_([^_]+)\_/g,
    markdownCombined: /\*\*\*([^*]+)\*\*\*/g,
  };

  private static readonly UNWANTED_SYMBOLS = [
    /[#{*}`\[\]()_~]/g,  // Markdown symbols
    /[►▼▶▷▸▹▻▽▼]/g,  // Arrow symbols
    /[●○■□▪▫]/g,     // Bullet symbols
    /[★☆✦✧✩✪]/g,   // Star symbols
    /[←↑→↓↔↕]/g,     // Direction arrows
    /[♠♣♥♦]/g,       // Card symbols
    /[©®™]/g,        // Trademark symbols
    // Additional unwanted symbols
    /[‹›«»¿¡]/g,     // Quote symbols
    /[¶§]/g,         // Paragraph symbols
    /[†‡]/g,         // Dagger symbols
    /[•‣⁃∙]/g,      // Bullet variations
    /[◊◦]/g,        // More symbols
    /[⁋]/g,          // Line break symbols
    /[☐☑☒]/g,       // Checkbox symbols
    /[⚠⚡⚪⚫]/g,     // Warning and color symbols
    /[▪▫▬▭▮▯]/g,     // More geometric symbols
    /[░▒▓█]/g,       // Block symbols
    /[↑↓←→↖↗↘↙]/g,  // More arrow symbols
    /[⌘⌥⎋⎌⎍⎎]/g,   // Keyboard symbols
    // EMOJI AND SYMBOL CLEANUP - Add common problematic emojis and symbols
    /[❓❔]/g,        // Question mark emojis
    /[ℹ️ℹ]/g,        // Information emojis (with and without variant selector)
    /[⚠️⚠]/g,        // Warning emojis (with and without variant selector)
    /[✅✓✔]/g,        // Check mark emojis
    /[❌✗✘]/g,        // Cross mark emojis
    /[🚨🔥⭐💡📝📌🔑🧠👍👎📊😊😔🚀🏁]/g, // Common emojis that cause issues
    /[👉]/g,         // Finger pointing emojis
    // Additional problematic symbols
    /[…‽]/g,        // Ellipsis and interrobang
    /[©®™]/g,        // Trademark symbols (duplicate for emphasis)
  ];

  /**
   * Main formatting method - cleans and structures content beautifully
   */
  static formatContent(content: string, options: FormatOptions = {}): string {
    let formattedContent = content;

    // Apply core cleaning
    if (options.removeMarkdown !== false) {
      formattedContent = this.removeMarkdownSymbols(formattedContent);
    }

    // Remove unwanted symbols
    formattedContent = this.removeUnwantedSymbols(formattedContent);

    // Enhance readability and structure
    if (options.enhanceReadability !== false) {
      formattedContent = this.enhanceReadability(formattedContent);
    }

    // Optimize spacing and flow
    if (options.optimizeSpacing !== false) {
      formattedContent = this.optimizeSpacing(formattedContent);
    }

    // Structure content intelligently
    if (options.structureContent !== false) {
      formattedContent = this.structureContent(formattedContent, options);
    }

    return formattedContent.trim();
  }

  /**
   * Remove markdown symbols and convert to clean text
   */
  private static removeMarkdownSymbols(content: string): string {
    let cleaned = content;

    // Convert markdown headings to clean text with proper capitalization
    cleaned = cleaned.replace(this.MARKDOWN_PATTERNS.headings, (match, title) => {
      return this.formatHeading(title.trim());
    });

    // Handle additional markdown heading patterns
    cleaned = cleaned.replace(this.MARKDOWN_PATTERNS.markdownHeadings, (match, title) => {
      return this.formatHeading(title.trim());
    });

    // Convert bold text to properly emphasized text
    cleaned = cleaned.replace(this.MARKDOWN_PATTERNS.boldText, (match, text) => {
      return this.formatBoldText(text.trim());
    });

    // Handle alternative bold patterns
    cleaned = cleaned.replace(this.MARKDOWN_PATTERNS.markdownBoldAlt, (match, text) => {
      return this.formatBoldText(text.trim());
    });

    // Convert italic text to properly emphasized text
    cleaned = cleaned.replace(this.MARKDOWN_PATTERNS.italicText, (match, text) => {
      return this.formatItalicText(text.trim());
    });

    // Handle alternative italic patterns
    cleaned = cleaned.replace(this.MARKDOWN_PATTERNS.markdownItalicAlt, (match, text) => {
      return this.formatItalicText(text.trim());
    });

    // Handle combined bold/italic patterns
    cleaned = cleaned.replace(this.MARKDOWN_PATTERNS.markdownCombined, (match, text) => {
      return this.formatBoldText(text.trim()); // Treat as bold for simplicity
    });

    // Handle code blocks gracefully
    cleaned = cleaned.replace(this.MARKDOWN_PATTERNS.codeBlocks, (match) => {
      return this.formatCodeBlock(match);
    });

    // Handle inline code
    cleaned = cleaned.replace(this.MARKDOWN_PATTERNS.inlineCode, (match, code) => {
      return this.formatInlineCode(code.trim());
    });

    // Convert links to clean text format
    cleaned = cleaned.replace(this.MARKDOWN_PATTERNS.links, (match, text, url) => {
      return this.formatLink(text.trim(), url.trim());
    });

    // Remove horizontal rules
    cleaned = cleaned.replace(this.MARKDOWN_PATTERNS.horizontalRules, '');

    // Convert blockquotes to clean indented text
    cleaned = cleaned.replace(this.MARKDOWN_PATTERNS.blockquotes, (match) => {
      return '    ';
    });

    return cleaned;
  }

  /**
   * Remove unwanted symbols and special characters
   */
  private static removeUnwantedSymbols(content: string): string {
    let cleaned = content;

    // Remove each category of unwanted symbols
    this.UNWANTED_SYMBOLS.forEach(pattern => {
      cleaned = cleaned.replace(pattern, '');
    });

    // Clean up multiple spaces that might result from symbol removal
    cleaned = cleaned.replace(/\s{2,}/g, ' ');

    // Fix punctuation spacing
    cleaned = cleaned.replace(/\s+([.,!?;:])/g, '$1');
    cleaned = cleaned.replace(/([.,!?;:])\s*([A-Z])/g, '$1 $2');

    // Remove excessive punctuation
    cleaned = cleaned.replace(/([.,!?;:]){2,}/g, '$1');

    // Clean up spacing around common punctuation
    cleaned = cleaned.replace(/\s*([.,!?;:])\s*/g, '$1 ');

    // Ensure proper spacing after commas, semicolons, and colons
    cleaned = cleaned.replace(/([,;:])\s*([^\s])/g, '$1 $2');

    // Remove any remaining orphaned punctuation at the beginning of lines
    cleaned = cleaned.replace(/^\s*([.,!?;:])\s*/gm, '');

    return cleaned;
  }

  /**
   * Enhance readability with proper structure and flow
   */
  private static enhanceReadability(content: string): string {
    let enhanced = content;

    // Split into paragraphs and enhance each one
    const paragraphs = enhanced.split(/\n\s*\n/);
    const enhancedParagraphs = paragraphs.map(paragraph => {
      if (paragraph.trim() === '') return '';
      
      // Remove excessive line breaks within paragraphs
      let cleanParagraph = paragraph.replace(/\n+/g, ' ');
      
      // Ensure proper spacing
      cleanParagraph = cleanParagraph.replace(/\s+/g, ' ');
      cleanParagraph = cleanParagraph.trim();
      
      // Enhance sentence structure
      cleanParagraph = this.enhanceSentenceStructure(cleanParagraph);
      
      // Ensure proper paragraph length
      if (cleanParagraph.length > 400) {
        cleanParagraph = this.breakLongParagraph(cleanParagraph);
      }
      
      return cleanParagraph;
    });

    // Reassemble with proper paragraph spacing
    enhanced = enhancedParagraphs.filter(p => p.length > 0).join('\n\n');

    // Add strategic spacing for important transitions
    enhanced = this.addStrategicSpacing(enhanced);

    return enhanced;
  }

  /**
   * Optimize spacing for visual appeal and readability
   */
  private static optimizeSpacing(content: string): string {
    let optimized = content;

    // Ensure proper spacing around punctuation
    optimized = optimized.replace(/([.,!?;:])(?=[A-Z])/g, '$1 ');
    optimized = optimized.replace(/\s+([.,!?;:])/g, '$1');

    // AGGRESSIVE PARAGRAPH SPACING - Ensure double line breaks between paragraphs
    optimized = optimized.replace(/\n{3,}/g, '\n\n'); // Remove excessive line breaks
    optimized = optimized.replace(/\n\s*\n/g, '\n\n'); // Standardize paragraph breaks
    
    // Add paragraph spacing after sentences that end paragraphs
    optimized = optimized.replace(/([.!?])\s*([A-Z])/g, '$1\n\n$2');
    
    // Ensure single line breaks within paragraphs are removed
    optimized = optimized.replace(/([^\n])\n([^\n])/g, '$1 $2');

    // Add strategic spacing before major content sections
    optimized = this.addStrategicSpacing(optimized);

    // ENHANCED BULLET POINT SPACING
    // Ensure proper spacing before and after bullet points
    optimized = optimized.replace(/([^\n])\n(•\s+)/g, '$1\n\n$2'); // Add space before bullets
    optimized = optimized.replace(/(•\s+[^\n]+)\n([^\n•])/g, '$1\n\n$2'); // Add space after bullets
    optimized = optimized.replace(/(\d+\.\s+[^\n]+)\n([^\n\d])/g, '$1\n\n$2'); // Add space after numbered lists
    
    // Ensure consistent spacing between bullet points
    optimized = optimized.replace(/(•\s+[^\n]+)\n(•\s+)/g, '$1\n$2');
    optimized = optimized.replace(/(\d+\.\s+[^\n]+)\n(\d+\.\s+)/g, '$1\n$2');

    // Add spacing before and after headings
    optimized = optimized.replace(/([A-Z][A-Z\s]{10,}):\n/g, '\n$1:\n\n');
    optimized = optimized.replace(/([A-Z][A-Z\s]{10,})\n/g, '\n\n$1\n\n');

    // Clean up spacing around common transitions
    optimized = optimized.replace(/([.!?])\s*(However|Therefore|In addition|Furthermore|Moreover|Additionally|Nevertheless|Nonetheless)/gi, '$1\n\n$2');

    // FINAL SPACING CLEANUP - Ensure proper paragraph structure
    // Split into lines and reassemble with proper spacing
    const lines = optimized.split('\n');
    const cleanedLines = lines.map(line => line.trim()).filter(line => line.length > 0);
    const finalLines = [];
    
    for (let i = 0; i < cleanedLines.length; i++) {
      const currentLine = cleanedLines[i];
      const prevLine = i > 0 ? cleanedLines[i - 1] : '';
      
      // Add double line break before major headings
      if (this.isMajorHeading(currentLine) && i > 0) {
        finalLines.push('');
      }
      
      // Add double line break after bullet points if next line is not a bullet
      if (this.isBulletPoint(prevLine) && !this.isBulletPoint(currentLine) && i > 0) {
        finalLines.push('');
      }
      
      finalLines.push(currentLine);
    }
    
    optimized = finalLines.join('\n');

    return optimized;
  }

  /**
   * Check if a line is a major heading
   */
  private static isMajorHeading(line: string): boolean {
    const trimmed = line.trim();
    return trimmed === trimmed.toUpperCase() && 
           trimmed.length > 4 && 
           (trimmed.includes(':') || trimmed.length > 10);
  }

  /**
   * Check if a line is a bullet point
   */
  private static isBulletPoint(line: string): boolean {
    const trimmed = line.trim();
    return trimmed.startsWith('• ') || /^\d+\.\s/.test(trimmed);
  }

  /**
   * Structure content intelligently based on content type with enhanced visual hierarchy
   */
  private static structureContent(content: string, options: FormatOptions): string {
    let structured = content;

    // ENHANCED CONTENT ANALYSIS - Identify content types and structure
    structured = this.analyzeAndStructureContent(structured);
    
    // Apply intelligent structuring
    structured = this.structureHeadings(structured, options.headingStyle || 'clean');
    structured = this.structureLists(structured, options.listStyle || 'clean');
    structured = this.structureParagraphs(structured);
    
    // Add enhanced visual hierarchy
    structured = this.addVisualHierarchy(structured);

    // Add final polish
    structured = this.addFinalPolish(structured);

    return structured;
  }

  /**
   * Analyze content and apply intelligent structuring
   */
  private static analyzeAndStructureContent(content: string): string {
    let analyzed = content;
    
    // Split into lines for analysis
    const lines = analyzed.split('\n');
    const processedLines = [];
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (line === '') continue;
      
      // Identify and structure different content types
      if (this.isMajorHeading(line)) {
        // Add spacing before major headings
        if (i > 0 && processedLines.length > 0 && processedLines[processedLines.length - 1] !== '') {
          processedLines.push('');
        }
        processedLines.push(line);
        processedLines.push(''); // Add space after heading
      } else if (this.isSubheading(line)) {
        // Add spacing before subheadings
        if (i > 0 && processedLines.length > 0 && processedLines[processedLines.length - 1] !== '') {
          processedLines.push('');
        }
        processedLines.push(line);
        processedLines.push(''); // Add space after subheading
      } else if (this.isBulletPoint(line)) {
        processedLines.push(line);
      } else {
        // Regular content - ensure proper paragraph separation
        if (i > 0 && processedLines.length > 0) {
          const prevLine = processedLines[processedLines.length - 1];
          if (prevLine !== '' && !this.isBulletPoint(prevLine)) {
            processedLines.push('');
          }
        }
        processedLines.push(line);
      }
    }
    
    return processedLines.join('\n');
  }

  /**
   * Check if a line is a subheading
   */
  private static isSubheading(line: string): boolean {
    const trimmed = line.trim();
    return (
      // Ends with colon and has reasonable length
      (trimmed.endsWith(':') && trimmed.length > 10 && trimmed.length < 100) ||
      // Title case with moderate length
      (/^[A-Z][a-zA-Z\s]{10,50}$/.test(trimmed) && !trimmed.includes('.')) ||
      // Contains keywords that suggest subheadings
      /(Overview|Summary|Introduction|Conclusion|Background|Analysis|Key Points|Important Notes|Findings|Results|Details|Information)/.test(trimmed)
    );
  }

  /**
   * Add visual hierarchy with enhanced spacing and structure
   */
  private static addVisualHierarchy(content: string): string {
    let hierarchical = content;
    
    // Split into lines for processing
    const lines = hierarchical.split('\n');
    const processedLines = [];
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const trimmed = line.trim();
      
      if (trimmed === '') {
        processedLines.push('');
        continue;
      }
      
      // Add enhanced spacing based on content type
      if (this.isMajorHeading(trimmed)) {
        // Major headings get more spacing
        processedLines.push('');
        processedLines.push(trimmed);
        processedLines.push('');
        processedLines.push('');
      } else if (this.isSubheading(trimmed)) {
        // Subheadings get moderate spacing
        processedLines.push('');
        processedLines.push(trimmed);
        processedLines.push('');
      } else if (this.isBulletPoint(trimmed)) {
        // Bullet points get standard spacing
        processedLines.push(trimmed);
      } else {
        // Regular paragraphs
        processedLines.push(trimmed);
      }
    }
    
    // Clean up excessive empty lines
    const cleanedLines = [];
    let emptyLineCount = 0;
    
    for (const line of processedLines) {
      if (line.trim() === '') {
        emptyLineCount++;
        if (emptyLineCount <= 2) { // Max 2 consecutive empty lines
          cleanedLines.push('');
        }
      } else {
        emptyLineCount = 0;
        cleanedLines.push(line);
      }
    }
    
    return cleanedLines.join('\n');
  }

  /**
   * Format headings cleanly without markdown symbols
   */
  private static formatHeading(title: string): string {
    // Remove any remaining markdown symbols from title
    const cleanTitle = title.replace(/[#*`]/g, '').trim();
    
    // Determine heading level based on title characteristics
    const words = cleanTitle.split(' ').length;
    const hasColon = cleanTitle.includes(':');
    
    if (hasColon || words > 8) {
      // Main heading - add spacing and emphasis
      return `\n\n${cleanTitle.toUpperCase()}\n${'='.repeat(cleanTitle.length)}\n\n`;
    } else if (words > 4) {
      // Subheading - medium emphasis
      return `\n\n${cleanTitle}\n${'-'.repeat(cleanTitle.length)}\n\n`;
    } else {
      // Minor heading - simple emphasis
      return `\n\n${cleanTitle}:\n\n`;
    }
  }

  /**
   * Format bold text without markdown symbols
   */
  private static formatBoldText(text: string): string {
    return text.toUpperCase(); // Simple emphasis through capitalization
  }

  /**
   * Format italic text without markdown symbols
   */
  private static formatItalicText(text: string): string {
    return `"${text}"`; // Use quotes for emphasis
  }

  /**
   * Format code blocks cleanly
   */
  private static formatCodeBlock(code: string): string {
    const cleanCode = code.replace(/```/g, '').trim();
    return `\n[CODE BLOCK]\n${cleanCode}\n[END CODE BLOCK]\n`;
  }

  /**
   * Format inline code cleanly
   */
  private static formatInlineCode(code: string): string {
    return `'${code}'`; // Use single quotes for inline code
  }

  /**
   * Format links cleanly
   */
  private static formatLink(text: string, url: string): string {
    return `${text} (see: ${url})`;
  }

  /**
   * Enhance sentence structure for better readability
   */
  private static enhanceSentenceStructure(paragraph: string): string {
    let enhanced = paragraph;

    // Fix common sentence structure issues
    enhanced = enhanced.replace(/\bi\b/g, 'I'); // Capitalize "i"
    enhanced = enhanced.replace(/([.!?])\s*([a-z])/g, (match, punctuation, letter) => {
      return `${punctuation} ${letter.toUpperCase()}`;
    });

    // Ensure proper spacing around common punctuation
    enhanced = enhanced.replace(/([,;:])(?=[^\s])/g, '$1 ');

    return enhanced;
  }

  /**
   * Add strategic spacing for visual hierarchy
   */
  private static addStrategicSpacing(content: string): string {
    let spaced = content;

    // Add spacing before major content indicators
    const majorIndicators = [
      /^(Introduction|Overview|Summary|Conclusion|Background|Analysis)/gmi,
      /^(Key Points|Main Points|Important Notes|Findings|Results)/gmi,
      /^(However|Therefore|In addition|Furthermore|Moreover|Additionally|Nevertheless|Nonetheless)/gmi,
      /^(First|Second|Third|Finally|Lastly)/gmi,
      /^(In conclusion|To summarize|In summary)/gmi
    ];

    majorIndicators.forEach(pattern => {
      spaced = spaced.replace(pattern, (match) => `\n\n${match}`);
    });

    // Add spacing before numbered sections
    spaced = spaced.replace(/^(\d+\.\s+[A-Z])/gm, '\n$1');

    // Add spacing before bullet points that start a new section
    spaced = spaced.replace(/^([A-Z][a-z\s]+:)\n•/gm, '\n$1\n\n•');

    return spaced;
  }

  /**
   * Structure headings with clean formatting
   */
  private static structureHeadings(content: string, style: 'clean' | 'elegant' | 'modern'): string {
    let structured = content;

    // Identify potential headings and format them
    const lines = structured.split('\n');
    const processedLines = lines.map(line => {
      const trimmed = line.trim();
      
      if (this.isHeadingLine(trimmed)) {
        return this.formatHeadingByStyle(trimmed, style);
      }
      
      return line;
    });

    return processedLines.join('\n');
  }

  /**
   * Structure lists with clean formatting and enhanced spacing
   */
  private static structureLists(content: string, style: 'clean' | 'elegant' | 'minimal'): string {
    let structured = content;

    // Convert markdown-style lists to clean format
    structured = structured.replace(/^[\s]*[-*+]\s+/gm, '• ');
    structured = structured.replace(/^[\s]*\d+\.[\s]+/gm, (match) => {
      const number = match.match(/\d+/)?.[0] || '1';
      return `${number}. `;
    });

    // ENHANCED LIST SPACING - Add proper spacing around lists
    // Add space before lists when they follow non-list content
    structured = structured.replace(/([^\n])\n(•\s+)/g, '$1\n\n• ');
    structured = structured.replace(/([^\n])\n(\d+\.\s+)/g, '$1\n\n$1. ');

    // Add space after lists when followed by non-list content
    structured = structured.replace(/(•\s+[^\n]+)\n([^\n•])/g, '$1\n\n$2');
    structured = structured.replace(/(\d+\.\s+[^\n]+)\n([^\n\d])/g, '$1\n\n$2');

    // Ensure consistent spacing between list items
    structured = structured.replace(/(•\s+[^\n]+)\n(•\s+)/g, '$1\n$2');
    structured = structured.replace(/(\d+\.\s+[^\n]+)\n(\d+\.\s+)/g, '$1\n$2');

    // Format list items with proper indentation and spacing based on style
    switch (style) {
      case 'elegant':
        // Add subtle indentation and consistent spacing
        structured = structured.replace(/^(•\s+[^\n]+)$/gm, '  $1');
        structured = structured.replace(/^(\d+\.\s+[^\n]+)$/gm, '  $1');
        break;
      case 'minimal':
        // Clean, minimal formatting with consistent spacing
        structured = structured.replace(/^(•\s+[^\n]+)$/gm, '$1');
        structured = structured.replace(/^(\d+\.\s+[^\n]+)$/gm, '$1');
        break;
      case 'clean':
      default:
        // Standard clean formatting with proper spacing
        structured = structured.replace(/^(•\s+[^\n]+)$/gm, '• $1'.substring(2));
        structured = structured.replace(/^(\d+\.\s+[^\n]+)$/gm, '$1');
        break;
    }

    // ENSURE PROPER LIST TERMINATION
    // Add blank line after lists to separate from following content
    const lines = structured.split('\n');
    const processedLines = [];
    let inList = false;
    let listEnded = false;

    for (let i = 0; i < lines.length; i++) {
      const currentLine = lines[i].trim();
      const nextLine = i < lines.length - 1 ? lines[i + 1].trim() : '';
      
      // Check if current line is a list item
      const isListItem = this.isBulletPoint(currentLine);
      
      if (isListItem && !inList) {
        // Starting a new list
        inList = true;
        listEnded = false;
        // Add space before list if previous content exists
        if (i > 0 && processedLines.length > 0) {
          const prevLine = processedLines[processedLines.length - 1];
          if (prevLine.trim() !== '') {
            processedLines.push('');
          }
        }
      } else if (!isListItem && inList) {
        // Ending a list
        inList = false;
        listEnded = true;
        // Add space after list
        processedLines.push('');
      }
      
      processedLines.push(currentLine);
    }

    structured = processedLines.join('\n');

    return structured;
  }

  /**
   * Structure paragraphs for optimal readability
   */
  private static structureParagraphs(content: string): string {
    let structured = content;

    // Split into paragraphs and ensure proper length
    const paragraphs = structured.split('\n\n');
    const structuredParagraphs = paragraphs.map(paragraph => {
      const trimmed = paragraph.trim();
      if (trimmed === '') return '';

      // Break very long paragraphs into smaller ones
      if (trimmed.length > 300) {
        return this.breakLongParagraph(trimmed);
      }

      return trimmed;
    });

    return structuredParagraphs.join('\n\n');
  }

  /**
   * Add final polish to the content
   */
  private static addFinalPolish(content: string): string {
    let polished = content;

    // Remove any remaining multiple spaces
    polished = polished.replace(/\s{2,}/g, ' ');

    // Ensure proper spacing at the beginning and end
    polished = polished.trim();

    // Add proper spacing around common transitions
    polished = polished.replace(/([.!?])\s*(However|Therefore|In addition|Furthermore)/gi, '$1\n\n$2');

    return polished;
  }

  /**
   * Check if a line is a heading
   */
  private static isHeadingLine(line: string): boolean {
    const trimmed = line.trim();
    const headingIndicators = [
      /^[A-Z][A-Z\s]+$/, // All caps
      /^[A-Z][a-z\s]+:$/, // Ends with colon
      /^[A-Z][a-z\s]{10,50}$/, // Medium length, starts with capital
    ];

    return headingIndicators.some(pattern => pattern.test(trimmed));
  }

  /**
   * Format heading by style
   */
  private static formatHeadingByStyle(heading: string, style: 'clean' | 'elegant' | 'modern'): string {
    const cleanHeading = heading.replace(/[#*`]/g, '').trim();

    switch (style) {
      case 'elegant':
        return `\n\n${cleanHeading}\n${'─'.repeat(cleanHeading.length)}\n\n`;
      case 'modern':
        return `\n\n▸ ${cleanHeading.toUpperCase()}\n\n`;
      case 'clean':
      default:
        return `\n\n${cleanHeading}:\n\n`;
    }
  }

  /**
   * Break long paragraphs into smaller, more readable ones
   */
  private static breakLongParagraph(paragraph: string): string {
    const sentences = paragraph.split(/(?<=[.!?])\s+/);
    const chunks: string[] = [];
    let currentChunk = '';

    sentences.forEach(sentence => {
      if ((currentChunk + sentence).length > 200) {
        if (currentChunk) {
          chunks.push(currentChunk.trim());
          currentChunk = sentence;
        }
      } else {
        currentChunk += sentence;
      }
    });

    if (currentChunk) {
      chunks.push(currentChunk.trim());
    }

    return chunks.join('\n\n');
  }

  /**
   * Format research content specifically for deep research mode
   */
  static formatResearchContent(content: string): string {
    return this.formatContent(content, {
      removeMarkdown: true,
      enhanceReadability: true,
      structureContent: true,
      optimizeSpacing: true,
      headingStyle: 'elegant',
      listStyle: 'clean'
    });
  }

  /**
   * Format chat content specifically for intelligent chat mode
   */
  static formatChatContent(content: string): string {
    return this.formatContent(content, {
      removeMarkdown: true,
      enhanceReadability: true,
      structureContent: true,
      optimizeSpacing: true,
      headingStyle: 'clean',
      listStyle: 'minimal'
    });
  }

  /**
   * Aggressive formatting for maximum cleanliness (used for both modes)
   */
  static formatContentAggressively(content: string): string {
    return this.formatContent(content, {
      removeMarkdown: true,
      enhanceReadability: true,
      structureContent: true,
      optimizeSpacing: true,
      headingStyle: 'clean',
      listStyle: 'clean'
    });
  }
}