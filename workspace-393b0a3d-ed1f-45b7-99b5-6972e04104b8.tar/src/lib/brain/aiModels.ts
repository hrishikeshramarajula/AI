export interface AIModel {
  id: string;
  name: string;
  provider: string;
  description: string;
  apiModel?: string;
  intelligence?: string;
  contextLength?: string;
  inputCredits?: string;
  outputCredits?: string;
  specialty?: 'chat' | 'image' | 'code' | 'fullstack' | 'deep-research' | 'autonomous-agent';
  capabilities?: string[];
  maxTokens?: number;
  temperature?: number;
  topP?: number;
  frequencyPenalty?: number;
  presencePenalty?: number;
}

export const AI_MODELS: AIModel[] = [
  // OpenRouter Free Models - Top Tier
  {
    id: 'llama-4-maverick-free',
    name: 'Llama 4 Maverick (Free)',
    provider: 'openrouter',
    description: '400B parameters (17B active), 256K context, multimodal capabilities',
    apiModel: 'meta-llama/llama-4-maverick:free',
    intelligence: 'Very High',
    contextLength: '256K',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'autonomous-agent',
    capabilities: ['reasoning', 'coding', 'creative', 'analysis', 'multimodal'],
    maxTokens: 4096,
    temperature: 0.7,
    topP: 0.9,
  },
  {
    id: 'gemini-2-5-pro-free',
    name: 'Gemini 2.5 Pro (Free)',
    provider: 'openrouter',
    description: '1M context length, top performance on benchmarks',
    apiModel: 'google/gemini-2.5-pro-exp-03-25:free',
    intelligence: 'Very High',
    contextLength: '1M',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'deep-research',
    capabilities: ['research', 'analysis', 'coding', 'multimodal'],
    maxTokens: 8192,
    temperature: 0.7,
    topP: 0.9,
  },
  {
    id: 'llama-4-scout-free',
    name: 'Llama 4 Scout (Free)',
    provider: 'openrouter',
    description: '109B parameters (17B active), 512K context, optimized for deployment',
    apiModel: 'meta-llama/llama-4-scout:free',
    intelligence: 'High',
    contextLength: '512K',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'chat',
    capabilities: ['reasoning', 'coding', 'creative'],
    maxTokens: 4096,
    temperature: 0.7,
    topP: 0.9,
  },

  // OpenRouter Free Models - Specialized
  {
    id: 'deepseek-r1-zero-free',
    name: 'DeepSeek R1 Zero (Free)',
    provider: 'openrouter',
    description: 'Research and scientific reasoning',
    apiModel: 'deepseek/deepseek-r1-zero:free',
    intelligence: 'High',
    contextLength: '32K',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'deep-research',
    capabilities: ['research', 'analysis', 'scientific', 'reasoning'],
    maxTokens: 4096,
    temperature: 0.7,
    topP: 0.9,
  },
  {
    id: 'deepseek-v3-base-free',
    name: 'DeepSeek V3 Base (Free)',
    provider: 'openrouter',
    description: 'Technical domain optimization',
    apiModel: 'deepseek/deepseek-v3-base:free',
    intelligence: 'High',
    contextLength: '32K',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'code',
    capabilities: ['coding', 'technical', 'analysis'],
    maxTokens: 4096,
    temperature: 0.7,
    topP: 0.9,
  },
  {
    id: 'deepseek-chat-v3-free',
    name: 'DeepSeek Chat V3 (Free)',
    provider: 'openrouter',
    description: 'Dialogue-optimized transformer',
    apiModel: 'deepseek/deepseek-chat-v3-0324:free',
    intelligence: 'High',
    contextLength: '32K',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'chat',
    capabilities: ['reasoning', 'coding', 'creative'],
    maxTokens: 4096,
    temperature: 0.7,
    topP: 0.9,
  },
  {
    id: 'mistral-small-3-1-free',
    name: 'Mistral Small 3.1 (Free)',
    provider: 'openrouter',
    description: '24B model with function calling',
    apiModel: 'mistralai/mistral-small-3.1-24b-instruct:free',
    intelligence: 'High',
    contextLength: '32K',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'code',
    capabilities: ['coding', 'function-calling', 'analysis'],
    maxTokens: 4096,
    temperature: 0.7,
    topP: 0.9,
  },
  {
    id: 'kimi-vl-a3b-thinking-free',
    name: 'Kimi VL A3B Thinking (Free)',
    provider: 'openrouter',
    description: 'Lightweight multimodal with visual reasoning',
    apiModel: 'moonshotai/kimi-vl-a3b-thinking:free',
    intelligence: 'Medium',
    contextLength: '32K',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'image',
    capabilities: ['multimodal', 'visual-reasoning', 'creative'],
    maxTokens: 4096,
    temperature: 0.7,
    topP: 0.9,
  },
  {
    id: 'qwen2-5-vl-3b-free',
    name: 'Qwen 2.5 VL 3B (Free)',
    provider: 'openrouter',
    description: 'Compact multimodal model',
    apiModel: 'qwen/qwen2.5-vl-3b-instruct:free',
    intelligence: 'Medium',
    contextLength: '32K',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'image',
    capabilities: ['multimodal', 'visual', 'creative'],
    maxTokens: 4096,
    temperature: 0.7,
    topP: 0.9,
  },
  {
    id: 'llama-3-1-nemotron-nano-free',
    name: 'Llama 3.1 Nemotron Nano (Free)',
    provider: 'openrouter',
    description: 'NVIDIA-optimized 8B model',
    apiModel: 'nvidia/llama-3.1-nemotron-nano-8b-v1:free',
    intelligence: 'Medium',
    contextLength: '8K',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'chat',
    capabilities: ['reasoning', 'coding', 'creative'],
    maxTokens: 4096,
    temperature: 0.7,
    topP: 0.9,
  },
  {
    id: 'deephermes-3-llama-3-8b-free',
    name: 'DeepHermes 3 Llama 3 8B (Free)',
    provider: 'openrouter',
    description: 'Modified Llama 3 with specialized tuning',
    apiModel: 'nousresearch/deephermes-3-llama-3-8b-preview:free',
    intelligence: 'Medium',
    contextLength: '8K',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'chat',
    capabilities: ['reasoning', 'coding', 'creative'],
    maxTokens: 4096,
    temperature: 0.7,
    topP: 0.9,
  },
  {
    id: 'optimus-alpha-free',
    name: 'Optimus Alpha (Free)',
    provider: 'openrouter',
    description: 'OpenRouter\'s in-house general assistant',
    apiModel: 'openrouter/optimus-alpha',
    intelligence: 'High',
    contextLength: '32K',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'chat',
    capabilities: ['reasoning', 'coding', 'creative'],
    maxTokens: 4096,
    temperature: 0.7,
    topP: 0.9,
  },
  {
    id: 'quasar-alpha-free',
    name: 'Quasar Alpha (Free)',
    provider: 'openrouter',
    description: 'Specialized for reasoning tasks',
    apiModel: 'openrouter/quasar-alpha',
    intelligence: 'High',
    contextLength: '32K',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'deep-research',
    capabilities: ['reasoning', 'analysis', 'research'],
    maxTokens: 4096,
    temperature: 0.7,
    topP: 0.9,
  },
];

// Specialized models for specific tasks - Using OpenRouter Free Models
export const SPECIALIZED_MODELS = {
  code: [
    'deepseek-v3-base-free',
    'mistral-small-3-1-free',
    'llama-4-maverick-free',
    'deepseek-chat-v3-free',
  ],
  creative: [
    'llama-4-maverick-free',
    'llama-4-scout-free',
    'deepseek-chat-v3-free',
    'optimus-alpha-free',
  ],
  analysis: [
    'gemini-2-5-pro-free',
    'quasar-alpha-free',
    'llama-4-maverick-free',
    'deepseek-r1-zero-free',
  ],
  research: [
    'gemini-2-5-pro-free',
    'deepseek-r1-zero-free',
    'quasar-alpha-free',
    'llama-4-maverick-free',
  ],
  autonomous: [
    'llama-4-maverick-free',
    'gemini-2-5-pro-free',
    'deepseek-r1-zero-free',
    'quasar-alpha-free',
  ],
  chat: [
    'llama-4-scout-free',
    'deepseek-chat-v3-free',
    'llama-3-1-nemotron-nano-free',
    'deephermes-3-llama-3-8b-free',
  ],
  image: [
    'kimi-vl-a3b-thinking-free',
    'qwen2-5-vl-3b-free',
    'llama-4-maverick-free',
    'gemini-2-5-pro-free',
  ],
};

// Helper functions
export function getModelById(id: string): AIModel | undefined {
  return AI_MODELS.find(model => model.id === id);
}

export function getModelsByProvider(provider: string): AIModel[] {
  return AI_MODELS.filter(model => model.provider === provider);
}

export function getModelsBySpecialty(specialty: string): AIModel[] {
  return AI_MODELS.filter(model => model.specialty === specialty);
}

export function getBestModelForTask(taskType: string): AIModel {
  const specializedModels = SPECIALIZED_MODELS[taskType as keyof typeof SPECIALIZED_MODELS];
  if (specializedModels && specializedModels.length > 0) {
    const modelId = specializedModels[0];
    const model = getModelById(modelId);
    if (model) return model;
  }
  
  // Default to Llama 4 Maverick (Free) if no specialized model found
  return getModelById('llama-4-maverick-free') || AI_MODELS[0];
}

export function getModelConfiguration(modelId: string): Partial<AIModel> {
  const model = getModelById(modelId);
  if (!model) return {};
  
  return {
    maxTokens: model.maxTokens,
    temperature: model.temperature,
    topP: model.topP,
    frequencyPenalty: model.frequencyPenalty,
    presencePenalty: model.presencePenalty,
  };
}