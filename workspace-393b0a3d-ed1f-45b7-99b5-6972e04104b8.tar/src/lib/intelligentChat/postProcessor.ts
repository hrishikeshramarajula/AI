// ====== 6. POST-PROCESSOR ======
import { ContentFormatter } from '../contentFormatter';
export interface ProcessingOptions {
  addFormatting?: boolean;
  addSafetyChecks?: boolean;
  addDisclaimers?: boolean;
  maxLength?: number;
  style?: 'formal' | 'casual' | 'technical' | 'friendly';
  includeSources?: boolean;
  addEmojis?: boolean;
  structureResponse?: boolean;
}

export interface ProcessedResponse {
  content: string;
  warnings: string[];
  formattingApplied: string[];
  safetyChecks: string[];
  disclaimers: string[];
  sources: string[];
  metadata: {
    wordCount: number;
    readingTime: number;
    complexityScore: number;
    sentimentScore: number;
  };
}

export class PostProcessor {
  private static readonly SENSITIVE_TOPICS = [
    'medical', 'legal', 'financial', 'psychological', 'safety_critical',
    'emergency', 'self_harm', 'violence', 'illegal', 'harmful'
  ];

  private static readonly DISCLAIMERS = {
    medical: "Note: This information is not medical advice. Please consult with a qualified healthcare professional for medical concerns.",
    legal: "Disclaimer: This is not legal advice. Please consult with a qualified legal professional for legal matters.",
    financial: "Note: This is not financial advice. Please consult with a qualified financial advisor for financial decisions.",
    technical: "Technical information may change. Verify with current documentation and standards.",
    general: "Information provided is based on available knowledge and may not cover all aspects of your situation."
  };

  private static readonly FORMATTING_RULES = {
    bulletPoints: /^• /gm,
    numberedLists: /^\d+\. /gm,
    codeBlocks: /```[\s\S]*?```/g,
    boldText: /\*\*([^*]+)\*\*/g,
    italicText: /\*([^*]+)\*/g,
    links: /\[([^\]]+)\]\(([^)]+)\)/g
  };

  /**
   * Format response with proper structure and styling
   */
  static formatResponse(response: string, options: ProcessingOptions = {}): ProcessedResponse {
    const processed: ProcessedResponse = {
      content: response,
      warnings: [],
      formattingApplied: [],
      safetyChecks: [],
      disclaimers: [],
      sources: [],
      metadata: {
        wordCount: 0,
        readingTime: 0,
        complexityScore: 0,
        sentimentScore: 0
      }
    };

    // Apply formatting
    if (options.addFormatting !== false) {
      processed.content = this.applyFormatting(processed.content, processed.formattingApplied);
    }

    // Apply style
    if (options.style) {
      processed.content = this.applyStyle(processed.content, options.style, processed.formattingApplied);
    }

    // Add structure
    if (options.structureResponse !== false) {
      processed.content = this.addStructure(processed.content, processed.formattingApplied);
    }

    // Apply safety checks
    if (options.addSafetyChecks !== false) {
      processed.content = this.applySafetyChecks(processed.content, processed.safetyChecks);
    }

    // Add disclaimers
    if (options.addDisclaimers !== false) {
      processed.content = this.addDisclaimers(processed.content, processed.disclaimers);
    }

    // Add emojis if requested
    if (options.addEmojis) {
      processed.content = this.addEmojis(processed.content, processed.formattingApplied);
    }

    // Apply length limits
    if (options.maxLength && processed.content.length > options.maxLength) {
      processed.content = this.truncateResponse(processed.content, options.maxLength, processed.warnings);
    }

    // Generate metadata
    processed.metadata = this.generateMetadata(processed.content);

    return processed;
  }

  /**
   * Apply text formatting improvements using enhanced content formatter
   */
  private static applyFormatting(content: string, formattingApplied: string[]): string {
    // Use the aggressive content formatter for maximum cleanliness
    const formattedContent = ContentFormatter.formatContentAggressively(content);
    
    formattingApplied.push('clean_formatting', 'symbol_removal', 'enhanced_readability', 'proper_spacing', 'aggressive_cleaning');
    
    return formattedContent;
  }

  /**
   * Format lists and bullet points
   */
  private static formatLists(content: string): string {
    let formatted = content;

    // Format bullet points with consistent spacing
    formatted = formatted.replace(/^[\s]*[-*+][\s]+/gm, '• ');
    formatted = formatted.replace(/^[\s]*\d+\.[\s]+/gm, match => {
      const number = match.match(/\d+/)?.[0] || '1';
      return `${number}. `;
    });

    // Ensure consistent bullet point formatting with proper spacing
    formatted = formatted.replace(/^•\s*/gm, '• ');
    formatted = formatted.replace(/^\d+\.\s*/gm, match => {
      const number = match.match(/\d+/)?.[0] || '1';
      return `${number}. `;
    });

    // Add spacing between bullet points and other content
    formatted = formatted.replace(/(•\s+[^\n]+)\n([^\n•])/g, '$1\n\n$2');
    formatted = formatted.replace(/(\d+\.\s+[^\n]+)\n([^\n\d])/g, '$1\n\n$2');

    // Ensure bullet points have proper spacing after them
    formatted = formatted.replace(/(•\s+[^\n]+)\n(•\s+)/g, '$1\n$2');
    formatted = formatted.replace(/(\d+\.\s+[^\n]+)\n(\d+\.\s+)/g, '$1\n$2');

    return formatted;
  }

  /**
   * Format headings and subheadings with enhanced visual appeal
   */
  private static formatHeadings(content: string): string {
    let formatted = content;

    // Ensure main title formatting is preserved
    formatted = formatted.replace(/^#\s*\*\*([^*]+)\*\*$/gm, '# **$1**');
    
    // Ensure secondary headings are properly formatted
    formatted = formatted.replace(/^##\s*\*\*([^*]+)\*\*$/gm, '## **$1**');
    
    // Ensure tertiary headings are properly formatted  
    formatted = formatted.replace(/^###\s*\*\*([^*]+)\*\*$/gm, '### **$1**');

    // Add extra spacing before main headings for better visual separation
    formatted = formatted.replace(/\n(#\s*\*\*[^*]+\*\*\s*\n)/g, '\n\n$1');
    formatted = formatted.replace(/\n(##\s*\*\*[^*]+\*\*\s*\n)/g, '\n\n$1');

    return formatted;
  }

  /**
   * Apply style preferences
   */
  private static applyStyle(content: string, style: string, formattingApplied: string[]): string {
    let styledContent = content;

    switch (style) {
      case 'formal':
        styledContent = this.makeFormal(styledContent);
        formattingApplied.push('formal_style');
        break;
      case 'casual':
        styledContent = this.makeCasual(styledContent);
        formattingApplied.push('casual_style');
        break;
      case 'technical':
        styledContent = this.makeTechnical(styledContent);
        formattingApplied.push('technical_style');
        break;
      case 'friendly':
        styledContent = this.makeFriendly(styledContent);
        formattingApplied.push('friendly_style');
        break;
    }

    return styledContent;
  }

  /**
   * Make content more formal
   */
  private static makeFormal(content: string): string {
    const formalReplacements: Record<string, string> = {
      "don't": "do not",
      "won't": "will not",
      "can't": "cannot",
      "I'm": "I am",
      "you're": "you are",
      "it's": "it is",
      "that's": "that is",
      "we're": "we are",
      "they're": "they are",
      "isn't": "is not",
      "aren't": "are not",
      "wasn't": "was not",
      "weren't": "were not",
      "hasn't": "has not",
      "haven't": "have not",
      "hadn't": "had not",
      "doesn't": "does not",
      "don't": "do not",
      "didn't": "did not",
      "wouldn't": "would not",
      "couldn't": "could not",
      "shouldn't": "should not",
      "mightn't": "might not",
      "mustn't": "must not"
    };

    let formalContent = content;
    for (const [informal, formal] of Object.entries(formalReplacements)) {
      formalContent = formalContent.replace(new RegExp(`\\b${informal}\\b`, 'gi'), formal);
    }

    return formalContent;
  }

  /**
   * Make content more casual
   */
  private static makeCasual(content: string): string {
    return content
      .replace(/\b(therefore|consequently|thus|hence)\b/gi, 'so')
      .replace(/\b(additionally|furthermore|moreover)\b/gi, 'also')
      .replace(/\b(nevertheless|nonetheless)\b/gi, 'still')
      .replace(/\b(utilize|utilization)\b/gi, match => match.toLowerCase() === 'utilize' ? 'use' : 'usage');
  }

  /**
   * Make content more technical
   */
  private static makeTechnical(content: string): string {
    return content
      .replace(/\b(simple|basic|easy)\b/gi, 'fundamental')
      .replace(/\b(use)\b/gi, 'utilize')
      .replace(/\b(help)\b/gi, 'assist')
      .replace(/\b(show)\b/gi, 'demonstrate')
      .replace(/\b(make)\b/gi, 'implement');
  }

  /**
   * Make content more friendly
   */
  private static makeFriendly(content: string): string {
    return content
      .replace(/\b(You should|You need to)\b/gi, 'You might want to')
      .replace(/\b(You must)\b/gi, 'It would be great if you could')
      .replace(/\b(However|Nevertheless)\b/gi, 'But hey,')
      .replace(/\b(Therefore|Thus)\b/gi, 'So,');
  }

  /**
   * Add structural elements to response (preserving beautiful format)
   */
  private static addStructure(content: string, formattingApplied: string[]): string {
    let structuredContent = content;

    // Only add introduction if the content doesn't already have a structured format
    if (!structuredContent.includes('# **') && !structuredContent.match(/^(Hello|Hi|Hey|Good|Welcome|I'll|Here's|Let's)/i)) {
      structuredContent = `Here's what I found:\n\n${structuredContent}`;
      formattingApplied.push('introduction');
    }

    // Only add conclusion if missing and not already in beautiful format
    if (!structuredContent.includes('---') && !structuredContent.match(/(Let me know|Feel free|Hope this helps|Is there anything)/i)) {
      structuredContent += '\n\nLet me know if you need any clarification!';
      formattingApplied.push('conclusion');
    }

    return structuredContent;
  }

  /**
   * Apply safety checks and filtering
   */
  private static applySafetyChecks(content: string, safetyChecks: string[]): string {
    let safeContent = content;

    // Check for sensitive topics
    for (const topic of this.SENSITIVE_TOPICS) {
      if (safeContent.toLowerCase().includes(topic)) {
        safetyChecks.push(`sensitive_topic_${topic}`);
        safeContent = this.addSafetyDisclaimer(safeContent, topic);
      }
    }

    // Filter harmful content
    safeContent = this.filterHarmfulContent(safeContent, safetyChecks);

    // Add general safety note if needed
    if (safetyChecks.length > 0) {
      safetyChecks.push('general_safety_review');
    }

    return safeContent;
  }

  /**
   * Add safety disclaimer for sensitive topics
   */
  private static addSafetyDisclaimer(content: string, topic: string): string {
    const disclaimer = this.getDisclaimerForTopic(topic);
    return `${content}\n\n⚠️ ${disclaimer}`;
  }

  /**
   * Get appropriate disclaimer for topic
   */
  private static getDisclaimerForTopic(topic: string): string {
    if (topic.includes('medical')) return this.DISCLAIMERS.medical;
    if (topic.includes('legal')) return this.DISCLAIMERS.legal;
    if (topic.includes('financial')) return this.DISCLAIMERS.financial;
    if (topic.includes('technical')) return this.DISCLAIMERS.technical;
    return this.DISCLAIMERS.general;
  }

  /**
   * Filter harmful content
   */
  private static filterHarmfulContent(content: string, safetyChecks: string[]): string {
    const harmfulPatterns = [
      /(?:kill|harm|hurt|damage|destroy)\s+(?:yourself|others)/gi,
      /(?:how to)\s+(?:commit|perform)\s+(?:suicide|self-harm)/gi,
      /(?:illegal|unlawful|prohibited)\s+(?:activities|actions)/gi,
      /(?:dangerous|hazardous|risky)\s+(?:behavior|conduct)/gi
    ];

    let filteredContent = content;
    
    for (const pattern of harmfulPatterns) {
      if (pattern.test(filteredContent)) {
        safetyChecks.push('harmful_content_detected');
        filteredContent = filteredContent.replace(pattern, '[Content removed for safety]');
      }
    }

    return filteredContent;
  }

  /**
   * Add relevant disclaimers
   */
  private static addDisclaimers(content: string, disclaimers: string[]): string {
    let contentWithDisclaimers = content;

    // Add technical disclaimer for technical content
    if (contentWithDisclaimers.toLowerCase().includes('technical') || 
        contentWithDisclaimers.toLowerCase().includes('code') ||
        contentWithDisclaimers.toLowerCase().includes('programming')) {
      contentWithDisclaimers += `\n\n${this.DISCLAIMERS.technical}`;
      disclaimers.push('technical');
    }

    // Add general disclaimer for informational content
    if (disclaimers.length === 0) {
      contentWithDisclaimers += `\n\n${this.DISCLAIMERS.general}`;
      disclaimers.push('general');
    }

    return contentWithDisclaimers;
  }

  /**
   * Add appropriate emojis to enhance readability
   */
  private static addEmojis(content: string, formattingApplied: string[]): string {
    const emojiMap: Record<string, string> = {
      'important': '🔸',
      'warning': '⚠️',
      'success': '✅',
      'info': 'ℹ️',
      'tip': '💡',
      'example': '📝',
      'note': '📌',
      'question': '❓',
      'answer': '✅',
      'step': '👉',
      'conclusion': '🎯',
      'summary': '📋',
      'key point': '🔑',
      'remember': '🧠',
      'attention': '⚠️',
      'good': '👍',
      'bad': '👎',
      'neutral': '📊',
      'positive': '😊',
      'negative': '😔',
      'start': '🚀',
      'end': '🏁'
    };

    let emojiContent = content;

    // Add emojis to section headers
    for (const [key, emoji] of Object.entries(emojiMap)) {
      const pattern = new RegExp(`\\b${key}\\s*[:\\-]?\\s*`, 'gi');
      emojiContent = emojiContent.replace(pattern, `${emoji} `);
    }

    // Add emojis to bullet points for important sections
    emojiContent = emojiContent.replace(/^•\s*(important|warning|success|info|tip|example|note)/gim, 
      (match, key) => `• ${emojiMap[key.toLowerCase()] || '📌'} ${key.charAt(0).toUpperCase() + key.slice(1)}`);

    formattingApplied.push('emojis');

    return emojiContent;
  }

  /**
   * Truncate response to maximum length
   */
  private static truncateResponse(content: string, maxLength: number, warnings: string[]): string {
    if (content.length <= maxLength) return content;

    warnings.push('content_truncated');
    
    // Try to truncate at a sentence boundary
    const truncated = content.substring(0, maxLength - 100);
    const lastSentenceEnd = Math.max(
      truncated.lastIndexOf('.'),
      truncated.lastIndexOf('!'),
      truncated.lastIndexOf('?')
    );

    if (lastSentenceEnd > maxLength * 0.7) {
      return content.substring(0, lastSentenceEnd + 1) + '\n\n[Response truncated for brevity...]';
    }

    return content.substring(0, maxLength - 50) + '...[truncated]';
  }

  /**
   * Generate metadata about the response
   */
  private static generateMetadata(content: string) {
    const words = content.split(/\s+/).filter(word => word.length > 0);
    const wordCount = words.length;
    const readingTime = Math.ceil(wordCount / 200); // Average reading speed
    
    // Simple complexity score based on word length and sentence structure
    const avgWordLength = words.reduce((sum, word) => sum + word.length, 0) / wordCount;
    const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 0);
    const avgSentenceLength = words.length / sentences.length;
    const complexityScore = Math.min((avgWordLength + avgSentenceLength) / 15, 1);

    // Simple sentiment analysis
    const positiveWords = ['good', 'great', 'excellent', 'amazing', 'wonderful', 'helpful', 'success', 'effective'];
    const negativeWords = ['bad', 'terrible', 'awful', 'poor', 'difficult', 'problem', 'issue', 'fail'];
    
    const positiveCount = positiveWords.filter(word => content.toLowerCase().includes(word)).length;
    const negativeCount = negativeWords.filter(word => content.toLowerCase().includes(word)).length;
    const sentimentScore = (positiveCount - negativeCount) / Math.max(positiveCount + negativeCount, 1);

    return {
      wordCount,
      readingTime,
      complexityScore,
      sentimentScore
    };
  }

  /**
   * Clean and normalize final response using enhanced formatter
   */
  static cleanFinalResponse(processed: ProcessedResponse): string {
    // Use the ContentFormatter for final cleaning and polishing
    const cleanedContent = ContentFormatter.formatChatContent(processed.content);
    
    return cleanedContent;
  }

  /**
   * Get processing statistics
   */
  static getProcessingStats(processed: ProcessedResponse): {
    processingSteps: string[];
    safetyIssues: number;
    disclaimersAdded: number;
    formattingChanges: number;
  } {
    return {
      processingSteps: processed.formattingApplied,
      safetyIssues: processed.safetyChecks.length,
      disclaimersAdded: processed.disclaimers.length,
      formattingChanges: processed.formattingApplied.length
    };
  }
}