// 🧠 Brain-Enhanced Chat Interface
// Main chat component that integrates brain processing for every message

'use client';

import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Brain, 
  Paperclip, 
  Loader2, 
  ChevronDown,
  MessageSquare,
  Bot,
  User,
  Clock,
  Zap,
  Target,
  BookOpen
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import BrainChatMessage from './BrainChatMessage';

// Import brain processing
import { realBrainIntegration, BrainProcessingInput } from '@/lib/brain/brainIntegration';

interface ChatMessage {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: string;
  model?: string;
  brainProcessing?: any;
}

interface AIModel {
  id: string;
  name: string;
  provider: string;
  description: string;
  specialty: 'chat' | 'image' | 'code' | 'fullstack' | 'deep-research' | 'autonomous-agent';
}

const aiModels: AIModel[] = [
  {
    id: 'claude-3',
    name: '🤖 Claude 3',
    provider: 'Anthropic',
    description: 'Advanced AI assistant with deep reasoning capabilities',
    specialty: 'chat'
  },
  {
    id: 'gpt-4',
    name: '🚀 GPT-4',
    provider: 'OpenAI',
    description: 'Powerful language model with broad knowledge',
    specialty: 'deep-research'
  },
  {
    id: 'autonomous-agent',
    name: '🧠 Autonomous Agent',
    provider: 'Advanced AI',
    description: 'Self-directed AI with comprehensive brain processing',
    specialty: 'autonomous-agent'
  }
];

const chatModes = [
  { id: 'chat', name: '💬 Chat', description: 'Natural conversation' },
  { id: 'deep-research', name: '🔬 Deep Research', description: 'Comprehensive analysis' },
  { id: 'problem-solving', name: '⚡ Problem Solving', description: 'Structured solutions' },
  { id: 'creative', name: '🎨 Creative', description: 'Innovative responses' }
];

export default function BrainChatInterface() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedModel, setSelectedModel] = useState('claude-3');
  const [selectedMode, setSelectedMode] = useState('chat');
  const [brainProcessingEnabled, setBrainProcessingEnabled] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputText.trim() || isLoading) return;

    // Add user message
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: inputText,
      timestamp: new Date().toLocaleTimeString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);

    try {
      // Process with brain if enabled
      if (brainProcessingEnabled) {
        const brainInput: BrainProcessingInput = {
          text: inputText,
          context: {
            source: 'brain_chat_interface',
            model: selectedModel,
            mode: selectedMode,
            timestamp: new Date().toISOString()
          },
          preferences: {
            approach: 'balanced',
            priority: 'comprehensive',
            style: selectedMode === 'creative' ? 'creative' : 'analytical'
          }
        };

        console.log('🧠 Processing with brain integration...');
        const brainResult = await realBrainIntegration.processWithRealBrain(brainInput);
        console.log('✅ Brain processing result:', brainResult);

        // Create brain processing data for display
        const brainProcessingData = {
          actualAnswer: brainResult.actualAnswer || brainResult.synthesizedStrategy.approach,
          textAnalysis: {
            primaryIntent: brainResult.textAnalysis.intent.primaryIntent,
            confidence: brainResult.textAnalysis.intent.confidence,
            domain: brainResult.textAnalysis.entities.domain,
            complexity: brainResult.textAnalysis.complexity.overallComplexity,
            emotionalContext: brainResult.textAnalysis.emotional.primaryEmotion,
            entitiesFound: brainResult.textAnalysis.entities.entities.length
          },
          goalDecomposition: {
            subGoalsGenerated: brainResult.goalDecomposition?.processingMetadata?.subGoalsGenerated || 0,
            executionApproach: brainResult.goalDecomposition?.hierarchy?.executionPlan?.approach || 'N/A',
            estimatedDuration: brainResult.goalDecomposition?.processingMetadata?.estimatedTotalDuration || 0,
            riskLevel: brainResult.goalDecomposition?.hierarchy?.riskAssessment?.overallRiskLevel || 'N/A'
          },
          knowledgeRetrieval: {
            knowledgeItems: brainResult.knowledgeRetrieval.knowledgeItems.length,
            strategies: brainResult.knowledgeRetrieval.strategies.length,
            recommendations: brainResult.knowledgeRetrieval.recommendations.length
          },
          processingMetadata: {
            totalProcessingTime: brainResult.processingMetadata.totalProcessingTime,
            confidence: brainResult.processingMetadata.confidence,
            brainCapabilities: brainResult.processingMetadata.brainCapabilities
          }
        };

        // Add AI response with brain processing
        const aiMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          type: 'assistant',
          content: brainResult.actualAnswer || 'Processing complete...',
          timestamp: new Date().toLocaleTimeString(),
          model: aiModels.find(m => m.id === selectedModel)?.name,
          brainProcessing: brainProcessingData
        };

        setMessages(prev => [...prev, aiMessage]);
      } else {
        // Fallback to simple response (without brain processing)
        const aiMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          type: 'assistant',
          content: `I understand you're asking about "${inputText}". This is a response without brain processing enabled.`,
          timestamp: new Date().toLocaleTimeString(),
          model: aiModels.find(m => m.id === selectedModel)?.name
        };

        setMessages(prev => [...prev, aiMessage]);
      }
    } catch (error) {
      console.error('❌ Error processing message:', error);
      
      // Add error message
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: 'I apologize, but I encountered an error while processing your request. Please try again.',
        timestamp: new Date().toLocaleTimeString(),
        model: aiModels.find(m => m.id === selectedModel)?.name
      };

      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const clearChat = () => {
    setMessages([]);
  };

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Header */}
      <Card className="border-b rounded-none">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <Brain className="w-6 h-6 text-blue-600" />
                <CardTitle className="text-lg">🧠 Brain-Enhanced Chat</CardTitle>
              </div>
              {brainProcessingEnabled && (
                <Badge className="bg-green-100 text-green-800">
                  <Zap className="w-3 h-3 mr-1" />
                  Brain Processing Active
                </Badge>
              )}
            </div>
            
            <div className="flex items-center gap-3">
              {/* Model Selector */}
              <Select value={selectedModel} onValueChange={setSelectedModel}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {aiModels.map((model) => (
                    <SelectItem key={model.id} value={model.id}>
                      <div className="flex items-center gap-2">
                        <span>{model.name}</span>
                        <Badge variant="outline" className="text-xs">
                          {model.specialty}
                        </Badge>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Mode Selector */}
              <Select value={selectedMode} onValueChange={setSelectedMode}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {chatModes.map((mode) => (
                    <SelectItem key={mode.id} value={mode.id}>
                      {mode.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Brain Processing Toggle */}
              <Button
                variant={brainProcessingEnabled ? "default" : "outline"}
                size="sm"
                onClick={() => setBrainProcessingEnabled(!brainProcessingEnabled)}
                className="flex items-center gap-2"
              >
                <Brain className="w-4 h-4" />
                {brainProcessingEnabled ? 'Brain ON' : 'Brain OFF'}
              </Button>

              {/* Clear Chat */}
              <Button variant="outline" size="sm" onClick={clearChat}>
                Clear
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Messages Area */}
      <div className="flex-1 overflow-hidden">
        <ScrollArea className="h-full p-4">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-500">
              <Brain className="w-16 h-16 mb-4 text-blue-200" />
              <h3 className="text-lg font-semibold mb-2">🧠 Brain-Enhanced Chat Ready</h3>
              <p className="text-center max-w-md">
                Start a conversation and watch as AI brain processing analyzes, 
                decomposes goals, retrieves knowledge, and provides comprehensive responses.
              </p>
              <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <Target className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                  <div className="font-semibold text-sm">Text Analysis</div>
                  <div className="text-xs text-gray-600">Intent & context understanding</div>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg">
                  <Zap className="w-8 h-8 mx-auto mb-2 text-purple-600" />
                  <div className="font-semibold text-sm">Goal Decomposition</div>
                  <div className="text-xs text-gray-600">Strategic planning & execution</div>
                </div>
                <div className="p-4 bg-green-50 rounded-lg">
                  <Brain className="w-8 h-8 mx-auto mb-2 text-green-600" />
                  <div className="font-semibold text-sm">Knowledge Integration</div>
                  <div className="text-xs text-gray-600">Smart response generation</div>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map((message) => (
                <BrainChatMessage
                  key={message.id}
                  content={message.content}
                  brainProcessing={message.brainProcessing}
                  model={message.model}
                  timestamp={message.timestamp}
                  isUser={message.type === 'user'}
                />
              ))}
              <div ref={messagesEndRef} />
            </div>
          )}
        </ScrollArea>
      </div>

      {/* Input Area */}
      <Card className="border-t rounded-none">
        <CardContent className="p-4">
          <div className="flex gap-3 items-end">
            <div className="flex-1">
              <Textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type your message... (Brain processing will analyze and respond comprehensively)"
                className="min-h-[80px] resize-none"
                disabled={isLoading}
              />
            </div>
            
            <div className="flex flex-col gap-2">
              <Button
                onClick={handleSendMessage}
                disabled={!inputText.trim() || isLoading}
                className="flex items-center gap-2"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    Send
                  </>
                )}
              </Button>
              
              {brainProcessingEnabled && (
                <Badge variant="secondary" className="text-xs justify-center">
                  <Brain className="w-3 h-3 mr-1" />
                  Brain Active
                </Badge>
              )}
            </div>
          </div>
          
          {/* Status Bar */}
          <div className="flex items-center justify-between mt-3 text-xs text-gray-500">
            <div className="flex items-center gap-4">
              <span>Model: {aiModels.find(m => m.id === selectedModel)?.name}</span>
              <span>Mode: {chatModes.find(m => m.id === selectedMode)?.name}</span>
              <span>Messages: {messages.length}</span>
            </div>
            <div className="flex items-center gap-2">
              {brainProcessingEnabled ? (
                <>
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Brain processing enabled</span>
                </>
              ) : (
                <>
                  <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                  <span>Brain processing disabled</span>
                </>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}