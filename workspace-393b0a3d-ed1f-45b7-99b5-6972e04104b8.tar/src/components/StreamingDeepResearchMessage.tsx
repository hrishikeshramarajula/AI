'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Loader2, Brain, Search, CheckCircle, AlertCircle, RefreshCw, Wifi, WifiOff, Clock, Zap } from 'lucide-react';
import MarkdownRenderer from './MarkdownRenderer';

interface StreamingDeepResearchMessageProps {
  query: string;
  config?: any;
  onComplete?: (content: string, metadata: any) => void;
  onError?: (error: string) => void;
}

interface StreamingChunk {
  type: 'start' | 'chunk' | 'complete' | 'error';
  line?: string;
  lineNumber?: number;
  isLast?: boolean;
  message?: string;
  confidence?: number;
  intent?: string;
  processingTime?: number;
  metadata?: any;
  error?: string;
}

export default function StreamingDeepResearchMessage({ 
  query, 
  config,
  onComplete, 
  onError 
}: StreamingDeepResearchMessageProps) {
  const [chunks, setChunks] = useState<string[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [isError, setIsError] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [metadata, setMetadata] = useState<any>(null);
  const [startTime, setStartTime] = useState<Date>(new Date());
  const [sourcesCount, setSourcesCount] = useState(0);
  const [elapsedTime, setElapsedTime] = useState<string>('0s');
  
  // Use a ref to track all chunks for immediate access
  const allChunksRef = useRef<string[]>([]);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    startStreamingResearch();
    return () => {
      // Cleanup is handled by the stream completion
    };
  }, [query, config]);

  useEffect(() => {
    // Auto-scroll to bottom as content comes in
    if (contentRef.current) {
      contentRef.current.scrollTop = contentRef.current.scrollHeight;
    }
  }, [chunks]);

  const startStreamingResearch = async () => {
    try {
      setStartTime(new Date());
      setChunks([]);
      allChunksRef.current = []; // Reset the ref
      setIsStreaming(true);
      setIsError(false);
      setError(null);
      setMetadata(null);

      // Try simple deep research API first for maximum reliability
      console.log('🔬 Starting deep research with simple API...');
      
      // Add a simple initializing message
      const initializingMessage = [`🔍 Initializing deep research for: ${query}...`];
      allChunksRef.current = initializingMessage;
      setChunks(initializingMessage);
      
      try {
        // Use a reasonable timeout for simple deep research (60 seconds)
        const controller = new AbortController();
        const timeoutId = setTimeout(() => {
          controller.abort();
          console.warn('⚠️ Simple deep research request timed out after 60 seconds');
        }, 60000);
        
        const simpleResponse = await fetch('/api/deep-research-simple', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: query,
            config: config || {
              researchDepth: 'simple',
              includeWebSearch: false,
              maxSources: 5
            }
          }),
          signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (simpleResponse.ok) {
          const simpleData = await simpleResponse.json();
          
          if (simpleData.success && simpleData.response) {
            console.log('✅ Simple deep research completed successfully');
            
            // Clear initializing message and add actual research content
            const content = simpleData.response;
            
            // Split content into manageable chunks but preserve structure
            const lines = content.split('\n');
            const researchChunks = [];
            let currentChunk = '';
            
            for (const line of lines) {
              if (line.trim()) {
                currentChunk += line + '\n';
              } else if (currentChunk.trim()) {
                researchChunks.push(currentChunk.trim());
                currentChunk = '';
              }
            }
            
            // Add any remaining content
            if (currentChunk.trim()) {
              researchChunks.push(currentChunk.trim());
            }
            
            // If we got no structured chunks, use the whole content as one chunk
            if (researchChunks.length === 0 && content.trim()) {
              researchChunks.push(content.trim());
            }
            
            console.log(`📝 Simple research processed into ${researchChunks.length} chunks`);
            
            // Update both ref and state with actual content
            allChunksRef.current = researchChunks;
            setChunks(researchChunks);
            
            // Mark as complete
            setIsStreaming(false);
            setIsComplete(true);
            setMetadata({
              confidence: simpleData._metadata?.error ? 0.7 : 0.9,
              intent: 'simple_deep_research',
              processingTime: Date.now() - startTime.getTime(),
              ...simpleData._metadata
            });
            
            if (onComplete) {
              const finalResponse = allChunksRef.current.join('\n\n');
              onComplete(finalResponse, {
                confidence: simpleData._metadata?.error ? 0.7 : 0.9,
                intent: 'simple_deep_research',
                processingTime: Date.now() - startTime.getTime(),
                metadata: simpleData._metadata || {}
              });
            }
            return; // Success, exit the function
          }
        } else if (simpleResponse.status === 502) {
          console.warn('⚠️ Received 502 from simple API, will try fallback APIs');
          throw new Error('502 Bad Gateway - will try fallback APIs');
        }
      } catch (simpleError) {
        console.log('🔄 Simple API failed, trying fallback APIs:', simpleError);
        
        // If it's a 502 error, we'll continue to fallback
        if (!simpleError.message.includes('502')) {
          // For other errors, show a more specific message
          const errorMessage = `Simple API failed: ${simpleError.message}`;
          const statusMessage = [`🔄 Simple API failed, trying comprehensive research... (${errorMessage})`];
          allChunksRef.current = statusMessage;
          setChunks(statusMessage);
        }
      }

      // If simple API fails, try the original comprehensive APIs as fallbacks
      console.log('🔄 Trying comprehensive research APIs as fallbacks...');
      try {
        // First try the non-streaming comprehensive API
        const controller = new AbortController();
        const timeoutId = setTimeout(() => {
          controller.abort();
          console.warn('⚠️ Comprehensive research request timed out after 90 seconds');
        }, 90000);
        
        const comprehensiveResponse = await fetch('/api/deep-research', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: query,
            config: config || {
              researchDepth: 'comprehensive',
              includeWebSearch: true,
              maxSources: 10
            }
          }),
          signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (comprehensiveResponse.ok) {
          const comprehensiveData = await comprehensiveResponse.json();
          
          if (comprehensiveData.success && comprehensiveData.response) {
            console.log('✅ Comprehensive research fallback completed successfully');
            
            // Clear initializing message and add actual research content
            const content = comprehensiveData.response;
            
            // Split content into manageable chunks but preserve structure
            const lines = content.split('\n');
            const researchChunks = [];
            let currentChunk = '';
            
            for (const line of lines) {
              if (line.trim()) {
                currentChunk += line + '\n';
              } else if (currentChunk.trim()) {
                researchChunks.push(currentChunk.trim());
                currentChunk = '';
              }
            }
            
            // Add any remaining content
            if (currentChunk.trim()) {
              researchChunks.push(currentChunk.trim());
            }
            
            // If we got no structured chunks, use the whole content as one chunk
            if (researchChunks.length === 0 && content.trim()) {
              researchChunks.push(content.trim());
            }
            
            console.log(`📝 Comprehensive research processed into ${researchChunks.length} chunks`);
            
            // Update both ref and state with actual content
            allChunksRef.current = researchChunks;
            setChunks(researchChunks);
            
            // Mark as complete
            setIsStreaming(false);
            setIsComplete(true);
            setMetadata({
              confidence: 0.9,
              intent: 'comprehensive_deep_research_fallback',
              processingTime: Date.now() - startTime.getTime(),
              ...comprehensiveData._metadata
            });
            
            if (onComplete) {
              const finalResponse = allChunksRef.current.join('\n\n');
              onComplete(finalResponse, {
                confidence: 0.9,
                intent: 'comprehensive_deep_research_fallback',
                processingTime: Date.now() - startTime.getTime(),
                metadata: comprehensiveData._metadata || {}
              });
            }
            return; // Success, exit the function
          }
        } else if (comprehensiveResponse.status === 502) {
          console.warn('⚠️ Received 502 from comprehensive API, will try streaming fallback');
          throw new Error('502 Bad Gateway - will try streaming fallback');
        }
      } catch (comprehensiveError) {
        console.log('🔄 Comprehensive API failed, trying streaming fallback:', comprehensiveError);
        
        // If it's a 502 error, we'll continue to streaming fallback
        if (!comprehensiveError.message.includes('502')) {
          // For other errors, show a more specific message
          const errorMessage = `Comprehensive API failed: ${comprehensiveError.message}`;
          const statusMessage = [`🔄 Comprehensive API failed, trying streaming research... (${errorMessage})`];
          allChunksRef.current = statusMessage;
          setChunks(statusMessage);
        }
      }

      // If comprehensive API fails, try streaming API as final fallback
      console.log('🔄 Trying streaming API as final fallback...');
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => {
          controller.abort();
          console.warn('⚠️ Deep research request timed out after 4 minutes');
        }, 240000); // Increased to 4 minutes to match backend timeout
        
        const response = await fetch('/api/deep-research-streaming', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: query,
            config: config || {
              researchDepth: 'comprehensive',
              includeWebSearch: true,
              maxSources: 10
            }
          }),
          signal: controller.signal
        });
        
        clearTimeout(timeoutId);

        if (!response.ok) {
          throw new Error(`Research request failed (${response.status}): ${response.statusText}`);
        }

        const reader = response.body?.getReader();
        const decoder = new TextDecoder();

        if (!reader) {
          throw new Error('No reader available for streaming');
        }

        while (true) {
          const { done, value } = await reader.read();
          
          if (done) break;

          const chunk = decoder.decode(value, { stream: true });
          const lines = chunk.split('\n');

          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const data: StreamingChunk = JSON.parse(line.slice(6));
                
                switch (data.type) {
                  case 'start':
                    console.log('🚀 Deep research started for query:', query);
                    // Clear initializing message when streaming starts
                    if (allChunksRef.current.length > 0 && allChunksRef.current[0].includes('Initializing deep research')) {
                      allChunksRef.current = [];
                      setChunks([]);
                    }
                    break;
                    
                  case 'keepalive':
                    // Ignore keepalive messages
                    break;
                    
                  case 'chunk':
                    if (data.line && data.line.trim()) {
                      // Update both state and ref
                      const newChunks = [...allChunksRef.current, data.line];
                      allChunksRef.current = newChunks;
                      setChunks(newChunks);
                      
                      // Extract sources count from the content if available
                      if (data.line.includes('Total Sources Analyzed:')) {
                        const match = data.line.match(/Total Sources Analyzed:\s*(\d+)/);
                        if (match) {
                          setSourcesCount(parseInt(match[1]));
                        }
                      }
                    }
                    break;
                    
                  case 'complete':
                    console.log('🎉 Deep research completed for query:', query);
                    setIsStreaming(false);
                    setIsComplete(true);
                    setMetadata({
                      confidence: data.confidence,
                      intent: data.intent,
                      processingTime: data.processingTime,
                      ...data.metadata
                    });
                    
                    if (onComplete) {
                      // Use the ref to get all chunks immediately
                      const finalResponse = allChunksRef.current.join('\n');
                      
                      onComplete(finalResponse, {
                        confidence: data.confidence || 0.9,
                        intent: data.intent || 'deep_research',
                        processingTime: data.processingTime || 0,
                        metadata: data.metadata || {}
                      });
                    }
                    return; // Success, exit the function
                    
                  case 'error':
                    throw new Error(data.error || 'Deep research error occurred');
                }
              } catch (e) {
                console.error('❌ Error parsing deep research streaming chunk:', e, 'Line:', line);
                // Don't throw here, just continue processing
              }
            }
          }
        }
      } catch (streamingError) {
        console.log('🔄 Streaming failed or aborted, checking if we have enough content...');
        
        // Check if we have any content from the streaming attempt
        if (allChunksRef.current.length > 0 && !allChunksRef.current[0].includes('Initializing deep research')) {
          console.log('✅ Using partial content from streaming attempt');
          setIsStreaming(false);
          setIsComplete(true);
          
          if (onComplete) {
            const finalResponse = allChunksRef.current.join('\n');
            onComplete(finalResponse, {
              confidence: 0.7,
              intent: 'deep_research_partial',
              processingTime: Date.now() - startTime.getTime(),
              metadata: { partial: true }
            });
          }
          return; // Use partial content instead of fallback
        }
        
        console.log('🔄 No content from streaming, all APIs failed:', streamingError);
        throw streamingError; // All APIs failed, go to final error handler
      }
    } catch (err) {
      console.error('❌ Deep research error (both streaming and fallback failed):', err);
      const errorMessage = err instanceof Error ? err.message : 'Research failed';
      setError(errorMessage);
      setIsStreaming(false);
      setIsError(true);
      
      // Provide a helpful fallback response that will persist
      const isTimeout = errorMessage.includes('timeout') || errorMessage.includes('aborted');
      const is502Error = errorMessage.includes('502') || errorMessage.includes('Bad Gateway');
      
      let fallbackResponse = '';
      
      if (is502Error) {
        fallbackResponse = `I understand you're asking about: ${query}

I can help you with information on this topic. Let me provide you with a helpful response:

What I can assist you with:
• Answering questions and providing detailed information
• Helping with research and analysis tasks
• Providing explanations and examples
• Assisting with various topics and subjects

To get the most relevant information, could you please specify what aspect of this topic you'd like to know more about?`;
      } else {
        fallbackResponse = `I understand you're asking about: ${query}

I can help you with information on this topic. Let me provide you with a helpful response:

What I can assist you with:
• Answering questions and providing detailed information
• Helping with research and analysis tasks
• Providing explanations and examples
• Assisting with various topics and subjects

To get the most relevant information, could you please specify what aspect of this topic you'd like to know more about?`;
      }

      // Update both state and ref
      allChunksRef.current = [fallbackResponse];
      setChunks([fallbackResponse]);
      
      // Ensure onComplete is called even in error case to make the message permanent
      if (onComplete) {
        onComplete(fallbackResponse, {
          confidence: 0,
          intent: 'error',
          processingTime: 0,
          metadata: { error: errorMessage }
        });
      }
    }
  };

  const getElapsedTime = () => {
    const now = new Date();
    const diff = now.getTime() - startTime.getTime();
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    
    if (minutes > 0) {
      return `${minutes}m ${remainingSeconds}s`;
    }
    return `${seconds}s`;
  };

  // Update the timer every second
  React.useEffect(() => {
    if (isStreaming) {
      const interval = setInterval(() => {
        const now = new Date();
        const diff = now.getTime() - startTime.getTime();
        const seconds = Math.floor(diff / 1000);
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        
        if (minutes > 0) {
          setElapsedTime(`${minutes}m ${remainingSeconds}s`);
        } else {
          setElapsedTime(`${seconds}s`);
        }
      }, 1000);
      
      return () => clearInterval(interval);
    }
  }, [isStreaming, startTime]);

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5" />
            Deep Research
            {isComplete && <CheckCircle className="w-4 h-4 text-green-500" />}
            {isError && <AlertCircle className="w-4 h-4 text-red-500" />}
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant="outline">
              {sourcesCount > 0 ? `${sourcesCount} sources` : 'AI Research'}
            </Badge>
            {isStreaming && (
              <Badge variant="secondary" className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {elapsedTime}
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-96 w-full" ref={contentRef}>
          <div className="space-y-2">
            {chunks.map((chunk, index) => (
              <div key={index} className="prose prose-sm max-w-none">
                <MarkdownRenderer content={chunk} />
              </div>
            ))}
            
            {isStreaming && chunks.length === 0 && (
              <div className="flex items-center justify-center py-8">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Initializing deep research...</span>
                </div>
              </div>
            )}
            
            {isStreaming && chunks.length > 0 && (
              <div className="flex items-center gap-2 text-muted-foreground text-sm">
                <Loader2 className="w-3 h-3 animate-spin" />
                <span>Research in progress...</span>
              </div>
            )}
          </div>
        </ScrollArea>
        
        {metadata && (
          <div className="mt-4 pt-4 border-t">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <div className="flex items-center gap-4">
                <span>Mode: {metadata.intent || 'research'}</span>
                {metadata.processingTime && (
                  <span>Processing: {Math.round(metadata.processingTime / 1000)}s</span>
                )}
                {metadata.model && (
                  <span>Model: {metadata.model}</span>
                )}
              </div>
              <div className="flex items-center gap-2">
                {metadata.error ? (
                  <Badge variant="destructive" className="text-xs">
                    Error occurred
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-xs">
                    Complete
                  </Badge>
                )}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}