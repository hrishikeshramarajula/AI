import { NextRequest, NextResponse } from 'next/server';
import { getZAIInstance, safeZAIChatCompletion } from '@/lib/zaiHelper';

// Enhanced code generation with intelligent features
export async function POST(request: NextRequest) {
  let body: any;
  try {
    body = await request.json();
    const { 
      description, 
      language = 'typescript', 
      constraints = [], 
      context = '',
      useTemplate = true,
      forceAI = false,
      complexity = 'intermediate'
    } = body;

    if (!description) {
      return NextResponse.json(
        { error: 'Description is required' },
        { status: 400 }
      );
    }

    console.log('🤖 Intelligent Code Generation Request:', {
      description,
      language,
      constraints,
      context,
      useTemplate,
      forceAI,
      complexity
    });

    // Create intelligent prompt based on parameters
    const intelligentPrompt = createIntelligentPrompt({
      description,
      language,
      constraints,
      context,
      complexity,
      useTemplate
    });

    console.log('🎯 Generated Intelligent Prompt:', intelligentPrompt);

    // Generate code using AI with enhanced error handling
    try {
      // Quick fallback check - if we detect common patterns, provide immediate fallback
      const quickFallbackPatterns = [
        /hello world/i,
        /simple.*function/i,
        /basic.*example/i,
        /test.*code/i,
        /demo/i
      ];
      
      const shouldUseQuickFallback = quickFallbackPatterns.some(pattern => 
        pattern.test(description) && complexity === 'beginner'
      );
      
      if (shouldUseQuickFallback) {
        console.log('🚀 Using quick fallback for simple request');
        const quickFallbackCode = generateQuickFallbackCode(language, description);
        const quickDependencies = extractDependencies(quickFallbackCode, language);
        
        return NextResponse.json({
          success: true,
          code: quickFallbackCode,
          language,
          dependencies: quickDependencies,
          analysis: {
            summary: 'Quick fallback for simple request',
            quality: 8,
            issues: [],
            suggestions: []
          },
          metadata: {
            generatedAt: new Date().toISOString(),
            isFallback: true,
            fallbackType: 'quick',
            complexity,
            responseTime: 100 // Simulate fast response
          }
        });
      }
      
      // Try multiple models with fallback strategy - optimized for speed
      const modelsToTry = [
        'meta-llama/llama-4-scout:free',  // Faster model first
        'deepseek/deepseek-v3-base:free',  // Fast and reliable
        'meta-llama/llama-4-maverick:free', // More capable but slower
        'google/gemini-2-5-pro-exp-03-25:free', // High quality
        'gpt-4o',  // Premium fallback
        'claude-3-5-sonnet-20241022'  // Alternative premium
      ];
      
      let completion = null;
      let lastError = null;
      
      // Reduced timeout for faster fallback
      const requestTimeout = 15000; // 15 seconds total timeout
      
      for (const model of modelsToTry) {
        try {
          const startTime = Date.now();
          console.log(`🔄 Trying model: ${model} (timeout: ${requestTimeout}ms)`);
          
          // Create a timeout promise for this specific model attempt
          const modelTimeoutPromise = new Promise((_, reject) => {
            setTimeout(() => reject(new Error(`Model ${model} timeout`)), requestTimeout);
          });
          
          const completionPromise = safeZAIChatCompletion([
            {
              role: 'system',
              content: `You are an expert software developer specializing in ${language} code generation. 
              
              Your capabilities include:
              - Writing clean, efficient, and well-documented code
              - Following best practices and design patterns
              - Adding appropriate error handling
              - Including necessary imports and dependencies
              - Providing clear comments and documentation
              - Adapting to different complexity levels
              - Understanding context and constraints
              
              Always respond with code only, no explanations unless specifically requested.`
            },
            {
              role: 'user',
              content: intelligentPrompt
            }
          ], {
            temperature: 0.2,
            max_tokens: 1500, // Reduced token limit for faster response
            model: model
          });
          
          completion = await Promise.race([completionPromise, modelTimeoutPromise]);
          
          const responseTime = Date.now() - startTime;
          console.log(`✅ Successfully generated code using model: ${model} in ${responseTime}ms`);
          
          if (completion && completion.choices[0]?.message?.content) {
            break;
          }
        } catch (modelError) {
          console.warn(`⚠️ Model ${model} failed:`, modelError.message);
          lastError = modelError;
          
          // If it's a timeout, don't wait to try the next model
          if (modelError.message.includes('timeout')) {
            continue;
          }
          
          // Brief delay before trying next model
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      }
      
      if (!completion || !completion.choices[0]?.message?.content) {
        throw new Error(`All models failed. Last error: ${lastError?.message || 'Unknown error'}`);
      }

      const generatedCode = completion.choices[0]?.message?.content || '';
      
      if (!generatedCode.trim()) {
        throw new Error('No code was generated');
      }
      
      // Post-process the generated code
      const processedCode = postProcessCode(generatedCode, language);
      
      // Extract dependencies from the code
      const dependencies = extractDependencies(processedCode, language);
      
      // Generate code analysis (skip if it fails)
      let analysis;
      try {
        const zai = await getZAIInstance();
        analysis = await analyzeCode(processedCode, language, zai);
      } catch (analysisError) {
        console.warn('⚠️ Code analysis failed, continuing without analysis:', analysisError);
        analysis = {
          summary: 'Analysis unavailable due to service issues',
          quality: 7,
          issues: [],
          suggestions: []
        };
      }

      console.log('✅ Code Generation Complete:', {
        language,
        dependenciesCount: dependencies.length,
        codeLength: processedCode.length,
        analysis
      });

      return NextResponse.json({
        success: true,
        code: processedCode,
        language,
        dependencies,
        analysis,
        metadata: {
          generatedAt: new Date().toISOString(),
          complexity,
          constraintsApplied: constraints.length,
          contextUsed: context.length > 0
        }
      });

    } catch (aiError: any) {
      console.error('❌ AI Service Error:', aiError);
      
      // Check if it's a 502 error or similar service issue
      if (aiError.message && (aiError.message.includes('502') || 
          aiError.message.includes('Bad Gateway') ||
          aiError.message.includes('timeout') ||
          aiError.message.includes('ECONNREFUSED') ||
          aiError.message.includes('All models failed'))) {
        
        console.log('🔄 AI Service unavailable, generating enhanced fallback code...');
        
        // Generate enhanced fallback code with templates
        const fallbackCode = generateEnhancedFallbackCode(language, description, context, complexity);
        const fallbackDependencies = extractDependencies(fallbackCode, language);
        
        return NextResponse.json({
          success: false,
          error: 'AI service temporarily unavailable - using enhanced fallback',
          details: aiError.message,
          fallbackCode: fallbackCode,
          language,
          dependencies: fallbackDependencies,
          metadata: {
            generatedAt: new Date().toISOString(),
            isFallback: true,
            originalError: aiError.message,
            fallbackType: 'enhanced-template'
          }
        });
      }
      
      // For other errors, still try to provide enhanced fallback
      const fallbackCode = generateEnhancedFallbackCode(language, description, context, complexity);
      const fallbackDependencies = extractDependencies(fallbackCode, language);
      
      return NextResponse.json({
        success: false,
        error: 'Failed to generate code - using enhanced fallback',
        details: aiError.message,
        fallbackCode: fallbackCode,
        language,
        dependencies: fallbackDependencies,
        metadata: {
          generatedAt: new Date().toISOString(),
          isFallback: true,
          originalError: aiError.message,
          fallbackType: 'enhanced-template'
        }
      });
    }

  } catch (error: any) {
    console.error('❌ Intelligent Code Generation Error:', error);
    
    return NextResponse.json(
      { 
        error: 'Failed to generate code - using enhanced fallback',
        details: error.message,
        fallbackCode: generateEnhancedFallbackCode(body?.language || 'typescript', body?.description || '', body?.context || '', body?.complexity || 'intermediate')
      },
      { status: 500 }
    );
  }
}

// Create intelligent prompt based on parameters
function createIntelligentPrompt(params: {
  description: string;
  language: string;
  constraints: string[];
  context: string;
  complexity: string;
  useTemplate: boolean;
}): string {
  const { description, language, constraints, context, complexity, useTemplate } = params;
  
  let prompt = `Generate ${language} code for: ${description}\n\n`;
  
  if (context) {
    prompt += `Context: ${context}\n\n`;
  }
  
  if (constraints.length > 0) {
    prompt += `Constraints:\n`;
    constraints.forEach((constraint, index) => {
      prompt += `${index + 1}. ${constraint}\n`;
    });
    prompt += '\n';
  }
  
  prompt += `Complexity Level: ${complexity}\n\n`;
  
  if (useTemplate) {
    prompt += `Please follow these guidelines:\n`;
    prompt += `- Use modern ${language} syntax and best practices\n`;
    prompt += `- Include proper error handling\n`;
    prompt += `- Add necessary imports/dependencies\n`;
    prompt += `- Include clear comments and documentation\n`;
    prompt += `- Make the code reusable and maintainable\n`;
    
    if (complexity === 'beginner') {
      prompt += `- Keep the code simple and easy to understand\n`;
    } else if (complexity === 'advanced') {
      prompt += `- Use advanced patterns and optimizations\n`;
      prompt += `- Consider edge cases and robustness\n`;
    }
  }
  
  prompt += `\nGenerate only the code, no explanations.`;
  
  return prompt;
}

// Post-process generated code
function postProcessCode(code: string, language: string): string {
  let processedCode = code.trim();
  
  // Remove markdown code block markers if present
  processedCode = processedCode.replace(/^```[\w-]*\n/, '').replace(/```$/, '');
  
  // Language-specific processing
  switch (language.toLowerCase()) {
    case 'typescript':
    case 'javascript':
      // Ensure proper import statements
      if (!processedCode.includes('import ') && processedCode.includes('React')) {
        processedCode = `import React from 'react';\n\n${processedCode}`;
      }
      break;
      
    case 'python':
      // Ensure proper Python structure
      if (!processedCode.startsWith('def ') && !processedCode.startsWith('class ') && !processedCode.startsWith('import ')) {
        processedCode = `def main():\n    # Your implementation here\n    pass\n\nif __name__ == "__main__":\n    main()`;
      }
      break;
      
    case 'java':
      // Ensure proper Java class structure
      if (!processedCode.includes('class ')) {
        processedCode = `public class GeneratedCode {\n    ${processedCode}\n}`;
      }
      break;
  }
  
  return processedCode;
}

// Extract dependencies from code
function extractDependencies(code: string, language: string): string[] {
  const dependencies: string[] = [];
  
  switch (language.toLowerCase()) {
    case 'typescript':
    case 'javascript':
      // Extract import statements
      const importMatches = code.match(/import\s+.*?from\s+['"]([^'"]+)['"]/g);
      if (importMatches) {
        importMatches.forEach(match => {
          const dependency = match.match(/from\s+['"]([^'"]+)['"]/)?.[1];
          if (dependency && !dependency.startsWith('.')) {
            dependencies.push(dependency);
          }
        });
      }
      
      // Extract require statements
      const requireMatches = code.match(/require\s*\(\s*['"]([^'"]+)['"]\s*\)/g);
      if (requireMatches) {
        requireMatches.forEach(match => {
          const dependency = match.match(/require\s*\(\s*['"]([^'"]+)['"]\s*\)/)?.[1];
          if (dependency && !dependency.startsWith('.')) {
            dependencies.push(dependency);
          }
        });
      }
      break;
      
    case 'python':
      // Extract import statements
      const pythonImports = code.match(/(?:import\s+(\w+)|from\s+(\w+)\s+import)/g);
      if (pythonImports) {
        pythonImports.forEach(match => {
          const dependency = match.match(/(?:import\s+(\w+)|from\s+(\w+)\s+import)/)?.[1] || 
                           match.match(/from\s+(\w+)\s+import/)?.[1];
          if (dependency && !['os', 'sys', 'json', 'time', 'datetime'].includes(dependency)) {
            dependencies.push(dependency);
          }
        });
      }
      break;
      
    case 'java':
      // Extract import statements
      const javaImports = code.match(/import\s+([\w\.]+);/g);
      if (javaImports) {
        javaImports.forEach(match => {
          const dependency = match.match(/import\s+([\w\.]+);/)?.[1];
          if (dependency && !dependency.startsWith('java.')) {
            dependencies.push(dependency);
          }
        });
      }
      break;
  }
  
  return [...new Set(dependencies)]; // Remove duplicates
}

// Analyze generated code
async function analyzeCode(code: string, language: string, zai: any): Promise<any> {
  try {
    const analysisPrompt = `Analyze this ${language} code and provide a brief assessment:

${code}

Please provide:
1. Code quality assessment (1-10)
2. Potential issues or improvements
3. Suggested use cases
4. Complexity level`;

    const analysis = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a code analysis expert. Provide concise, helpful code analysis.'
        },
        {
          role: 'user',
          content: analysisPrompt
        }
      ],
      temperature: 0.3,
      max_tokens: 500
    });

    const analysisText = analysis.choices[0]?.message?.content || '';
    
    // Parse analysis into structured format
    return {
      summary: analysisText,
      quality: extractQualityScore(analysisText),
      issues: extractIssues(analysisText),
      suggestions: extractSuggestions(analysisText)
    };
  } catch (error) {
    console.error('Code analysis failed:', error);
    return {
      summary: 'Analysis unavailable',
      quality: 7,
      issues: [],
      suggestions: []
    };
  }
}

// Helper functions for analysis parsing
function extractQualityScore(analysis: string): number {
  const scoreMatch = analysis.match(/(\d+)\/10/i);
  return scoreMatch ? parseInt(scoreMatch[1]) : 7;
}

function extractIssues(analysis: string): string[] {
  const issues: string[] = [];
  const issuePatterns = [
    /potential (issue|problem|improvement):\s*(.+)/gi,
    /issue:\s*(.+)/gi,
    /improvement:\s*(.+)/gi
  ];
  
  issuePatterns.forEach(pattern => {
    let match;
    while ((match = pattern.exec(analysis)) !== null) {
      issues.push(match[2] || match[1]);
    }
  });
  
  return issues;
}

function extractSuggestions(analysis: string): string[] {
  const suggestions: string[] = [];
  const suggestionPatterns = [
    /suggestion:\s*(.+)/gi,
    /recommend:\s*(.+)/gi,
    /use case:\s*(.+)/gi
  ];
  
  suggestionPatterns.forEach(pattern => {
    let match;
    while ((match = pattern.exec(analysis)) !== null) {
      suggestions.push(match[1]);
    }
  });
  
  return suggestions;
}

// Generate quick fallback code for simple requests
function generateQuickFallbackCode(language: string, description: string): string {
  const timestamp = new Date().toISOString();
  
  switch (language.toLowerCase()) {
    case 'typescript':
      return `// Quick fallback for: ${description}
// Generated at: ${timestamp}

/**
 * Simple function generated for: ${description}
 * This is a quick template for basic functionality
 */
function helloWorld(): void {
    console.log('Hello, World!');
}

// Export the function
export default helloWorld;

// Example usage:
// helloWorld();`;

    case 'javascript':
      return `// Quick fallback for: ${description}
// Generated at: ${timestamp}

/**
 * Simple function generated for: ${description}
 * This is a quick template for basic functionality
 */
function helloWorld() {
    console.log('Hello, World!');
}

// Export the function
module.exports = helloWorld;

// Example usage:
// helloWorld();`;

    case 'python':
      return `# Quick fallback for: ${description}
# Generated at: ${timestamp}

def hello_world():
    """Simple function generated for: ${description}"""
    print('Hello, World!')

# Example usage:
# hello_world()`;

    case 'java':
      return `// Quick fallback for: ${description}
// Generated at: ${timestamp}

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println('Hello, World!');
    }
}`;

    default:
      return `// Quick fallback for: ${description}
// Generated at: ${timestamp}
// Language: ${language}

function helloWorld() {
    console.log('Hello, World!');
}

// Example usage:
helloWorld();`;
  }
}

// Generate enhanced fallback code with better templates
function generateEnhancedFallbackCode(language: string, description: string, context: string = '', complexity: string = 'intermediate'): string {
  const timestamp = new Date().toISOString();
  
  switch (language.toLowerCase()) {
    case 'typescript':
      return `// Generated for: ${description}
// Generated at: ${timestamp}
// Complexity: ${complexity}
// This is an enhanced fallback template - customize as needed
${context ? `// Context: ${context}` : ''}

/**
 * Enhanced TypeScript template for: ${description}
 * This template includes proper typing, error handling, and best practices
 */

interface GeneratedInterface {
  // Define your interface properties here
  id?: string;
  name?: string;
  data?: any;
  timestamp?: Date;
}

interface GeneratedOptions {
  // Configuration options for the generated function
  enableLogging?: boolean;
  maxRetries?: number;
  timeout?: number;
}

/**
 * Enhanced generated function with proper error handling and typing
 * @param options - Configuration options for the function
 * @returns Promise<GeneratedInterface> - The result of the operation
 */
export async function generatedFunction(options: GeneratedOptions = {}): Promise<GeneratedInterface> {
  const {
    enableLogging = true,
    maxRetries = 3,
    timeout = 5000
  } = options;

  try {
    if (enableLogging) {
      console.log('🚀 Starting generated function execution...');
    }

    // Your implementation here
    const result: GeneratedInterface = {
      id: generateId(),
      name: '${description}',
      data: null,
      timestamp: new Date()
    };

    // Simulate async operation
    await new Promise(resolve => setTimeout(resolve, 100));

    if (enableLogging) {
      console.log('✅ Generated function completed successfully');
    }

    return result;

  } catch (error) {
    console.error('❌ Error in generated function:', error);
    throw new Error('Failed to execute generated function');
  }
}

/**
 * Helper function to generate unique IDs
 */
function generateId(): string {
  return Math.random().toString(36).substr(2, 9);
}

/**
 * Utility functions for common operations
 */
export const GeneratedUtils = {
  formatDate: (date: Date): string => date.toISOString(),
  validateInput: (input: any): boolean => typeof input === 'object',
  sanitizeData: (data: any): any => {
    // Basic data sanitization
    return JSON.parse(JSON.stringify(data));
  }
};

// Export default for easy importing
export default generatedFunction;`;

    case 'javascript':
      return `// Generated for: ${description}
// Generated at: ${timestamp}
// Complexity: ${complexity}
// This is an enhanced fallback template - customize as needed
${context ? `// Context: ${context}` : ''}

/**
 * Enhanced JavaScript template for: ${description}
 * This template includes proper error handling and best practices
 */

/**
 * Enhanced generated function with proper error handling
 * @param {Object} options - Configuration options for the function
 * @param {boolean} options.enableLogging - Enable logging (default: true)
 * @param {number} options.maxRetries - Maximum retry attempts (default: 3)
 * @param {number} options.timeout - Timeout in milliseconds (default: 5000)
 * @returns {Promise<Object>} - The result of the operation
 */
async function generatedFunction(options = {}) {
  const {
    enableLogging = true,
    maxRetries = 3,
    timeout = 5000
  } = options;

  try {
    if (enableLogging) {
      console.log('🚀 Starting generated function execution...');
    }

    // Your implementation here
    const result = {
      id: generateId(),
      name: '${description}',
      data: null,
      timestamp: new Date().toISOString()
    };

    // Simulate async operation
    await new Promise(resolve => setTimeout(resolve, 100));

    if (enableLogging) {
      console.log('✅ Generated function completed successfully');
    }

    return result;

  } catch (error) {
    console.error('❌ Error in generated function:', error);
    throw new Error('Failed to execute generated function');
  }
}

/**
 * Helper function to generate unique IDs
 */
function generateId() {
  return Math.random().toString(36).substr(2, 9);
}

/**
 * Utility functions for common operations
 */
const GeneratedUtils = {
  formatDate: (date) => date.toISOString(),
  validateInput: (input) => typeof input === 'object',
  sanitizeData: (data) => {
    // Basic data sanitization
    return JSON.parse(JSON.stringify(data));
  }
};

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { generatedFunction, GeneratedUtils };
} else if (typeof window !== 'undefined') {
  window.generatedFunction = generatedFunction;
  window.GeneratedUtils = GeneratedUtils;
}`;

    case 'python':
      return `# Generated for: ${description}
# Generated at: ${timestamp}
# Complexity: ${complexity}
# This is an enhanced fallback template - customize as needed
${context ? `# Context: ${context}` : ''}

"""
Enhanced Python template for: ${description}
This template includes proper error handling, typing, and best practices
"""

import asyncio
import json
import logging
from typing import Any, Dict, Optional, Union
from datetime import datetime
import uuid

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class GeneratedInterface:
    """Enhanced interface for generated functionality"""
    
    def __init__(self, 
                 name: str = "${description}",
                 data: Optional[Any] = None,
                 timestamp: Optional[datetime] = None):
        self.id = str(uuid.uuid4())
        self.name = name
        self.data = data
        self.timestamp = timestamp or datetime.now()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation"""
        return {
            'id': self.id,
            'name': self.name,
            'data': self.data,
            'timestamp': self.timestamp.isoformat()
        }

class GeneratedOptions:
    """Configuration options for the generated function"""
    
    def __init__(self,
                 enable_logging: bool = True,
                 max_retries: int = 3,
                 timeout: int = 5000):
        self.enable_logging = enable_logging
        self.max_retries = max_retries
        self.timeout = timeout

async def generated_function(options: Optional[GeneratedOptions] = None) -> GeneratedInterface:
    """
    Enhanced generated function with proper error handling and typing
    
    Args:
        options: Configuration options for the function
        
    Returns:
        GeneratedInterface: The result of the operation
        
    Raises:
        Exception: If the function fails to execute
    """
    if options is None:
        options = GeneratedOptions()
    
    try:
        if options.enable_logging:
            logger.info("🚀 Starting generated function execution...")
        
        # Your implementation here
        result = GeneratedInterface(
            name="${description}",
            data=None,
            timestamp=datetime.now()
        )
        
        # Simulate async operation
        await asyncio.sleep(0.1)
        
        if options.enable_logging:
            logger.info("✅ Generated function completed successfully")
        
        return result
        
    except Exception as error:
        logger.error("❌ Error in generated function: {}".format(error))
        raise Exception("Failed to execute generated function: {}".format(error))

def generate_id() -> str:
    """Helper function to generate unique IDs"""
    return str(uuid.uuid4())

class GeneratedUtils:
    """Utility functions for common operations"""
    
    @staticmethod
    def format_date(date: datetime) -> str:
        """Format date as ISO string"""
        return date.isoformat()
    
    @staticmethod
    def validate_input(input_data: Any) -> bool:
        """Validate input data"""
        return isinstance(input_data, dict)
    
    @staticmethod
    def sanitize_data(data: Any) -> Any:
        """Basic data sanitization"""
        return json.loads(json.dumps(data))

# Export for module usage
__all__ = ['generated_function', 'GeneratedInterface', 'GeneratedOptions', 'GeneratedUtils']`;

    case 'java':
      return `// Generated for: ${description}
// Generated at: ${timestamp}
// Complexity: ${complexity}
// This is an enhanced fallback template - customize as needed
${context ? `// Context: ${context}` : ''}

import java.util.*;
import java.util.concurrent.*;
import java.util.logging.*;
import java.time.*;

/**
 * Enhanced Java template for: ${description}
 * This template includes proper error handling, typing, and best practices
 */

public class GeneratedClass {
    private static final Logger logger = Logger.getLogger(GeneratedClass.class.getName());
    
    /**
     * Configuration options for the generated function
     */
    public static class GeneratedOptions {
        private boolean enableLogging = true;
        private int maxRetries = 3;
        private int timeout = 5000;
        
        public GeneratedOptions() {}
        
        public GeneratedOptions(boolean enableLogging, int maxRetries, int timeout) {
            this.enableLogging = enableLogging;
            this.maxRetries = maxRetries;
            this.timeout = timeout;
        }
        
        // Getters and setters
        public boolean isEnableLogging() { return enableLogging; }
        public void setEnableLogging(boolean enableLogging) { this.enableLogging = enableLogging; }
        
        public int getMaxRetries() { return maxRetries; }
        public void setMaxRetries(int maxRetries) { this.maxRetries = maxRetries; }
        
        public int getTimeout() { return timeout; }
        public void setTimeout(int timeout) { this.timeout = timeout; }
    }
    
    /**
     * Result interface for the generated function
     */
    public static class GeneratedResult {
        private String id;
        private String name;
        private Object data;
        private LocalDateTime timestamp;
        
        public GeneratedResult(String name) {
            this.id = UUID.randomUUID().toString();
            this.name = name;
            this.data = null;
            this.timestamp = LocalDateTime.now();
        }
        
        // Getters and setters
        public String getId() { return id; }
        public void setId(String id) { this.id = id; }
        
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        
        public Object getData() { return data; }
        public void setData(Object data) { this.data = data; }
        
        public LocalDateTime getTimestamp() { return timestamp; }
        public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
        
        @Override
        public String toString() {
            return String.format("GeneratedResult{id='%s', name='%s', data=%s, timestamp=%s}",
                               id, name, data, timestamp);
        }
    }
    
    /**
     * Enhanced generated method with proper error handling
     * @param options Configuration options for the function
     * @return GeneratedResult The result of the operation
     * @throws Exception If the function fails to execute
     */
    public GeneratedResult generatedMethod(GeneratedOptions options) throws Exception {
        if (options == null) {
            options = new GeneratedOptions();
        }
        
        try {
            if (options.isEnableLogging()) {
                logger.info("🚀 Starting generated method execution...");
            }
            
            // Your implementation here
            GeneratedResult result = new GeneratedResult("${description}");
            
            // Simulate async operation
            Thread.sleep(100);
            
            if (options.isEnableLogging()) {
                logger.info("✅ Generated method completed successfully");
            }
            
            return result;
            
        } catch (Exception error) {
            logger.severe(String.format("❌ Error in generated method: %s", error.getMessage()));
            throw new Exception(String.format("Failed to execute generated method: %s", error.getMessage()));
        }
    }
    
    /**
     * Helper method to generate unique IDs
     */
    public String generateId() {
        return UUID.randomUUID().toString();
    }
    
    /**
     * Utility class for common operations
     */
    public static class GeneratedUtils {
        public static String formatDate(LocalDateTime date) {
            return date.toString();
        }
        
        public static boolean validateInput(Object input) {
            return input instanceof Map;
        }
        
        public static Object sanitizeData(Object data) {
            // Basic data sanitization would go here
            return data;
        }
    }
    
    /**
     * Main method for testing
     */
    public static void main(String[] args) {
        try {
            GeneratedClass instance = new GeneratedClass();
            GeneratedOptions options = new GeneratedOptions(true, 5, 10000);
            GeneratedResult result = instance.generatedMethod(options);
            
            System.out.println("Result: " + result.toString());
            
        } catch (Exception error) {
            System.err.println("Error: " + error.getMessage());
            error.printStackTrace();
        }
    }
}`;

    default:
      return `// Generated for: ${description}
// Generated at: ${timestamp}
// Language: ${language}
// Complexity: ${complexity}
// This is an enhanced fallback template - customize as needed
${context ? `// Context: ${context}` : ''}

/**
 * Enhanced template for: ${description}
 * This template includes proper structure and documentation
 * 
 * Features:
 * - Proper error handling
 * - Documentation
 * - Configurable options
 * - Utility functions
 */

// Your implementation here
// Remember to:
// 1. Add proper error handling
// 2. Include necessary imports/dependencies
// 3. Add clear comments and documentation
// 4. Make the code reusable and maintainable
// 5. Follow best practices for ${language}

// Example structure:
function main() {
  try {
    // Your main logic here
    console.log("Executing: ${description}");
    
    // Implementation
    const result = {
      success: true,
      message: "Enhanced fallback template executed successfully",
      timestamp: new Date().toISOString()
    };
    
    return result;
    
  } catch (error) {
    console.error("Error:", error);
    throw error;
  }
}

// Export if needed
module.exports = { main };`;
  }
}

// Generate fallback code (keeping the original for compatibility)
function generateFallbackCode(language: string, description: string): string {
  const timestamp = new Date().toISOString();
  
  switch (language.toLowerCase()) {
    case 'typescript':
      return `// Generated for: ${description}
// Generated at: ${timestamp}
// This is a fallback template - customize as needed

interface GeneratedInterface {
  // Define your interface here
}

export function generatedFunction(): GeneratedInterface {
  // Your implementation here
  return {} as GeneratedInterface;
}

export default generatedFunction;`;

    case 'javascript':
      return `// Generated for: ${description}
// Generated at: ${timestamp}
// This is a fallback template - customize as needed

function generatedFunction() {
  // Your implementation here
  return {};
}

module.exports = generatedFunction;`;

    case 'python':
      return `# Generated for: ${description}
# Generated at: ${timestamp}
# This is a fallback template - customize as needed

def generated_function():
    # Your implementation here
    pass

if __name__ == "__main__":
    generated_function()`;

    case 'java':
      return `// Generated for: ${description}
// Generated at: ${timestamp}
# This is a fallback template - customize as needed

public class GeneratedClass {
    public void generatedMethod() {
        // Your implementation here
    }
    
    public static void main(String[] args) {
        GeneratedClass instance = new GeneratedClass();
        instance.generatedMethod();
    }
}`;

    default:
      return `// Generated for: ${description}
// Generated at: ${timestamp}
// Language: ${language}
// This is a fallback template - customize as needed

// Your code here`;
  }
}