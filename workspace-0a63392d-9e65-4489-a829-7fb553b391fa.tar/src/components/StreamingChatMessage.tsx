'use client';

import React, { useState, useEffect, useRef, forwardRef, useImperativeHandle } from 'react';
import { Brain, Loader2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import MarkdownRenderer from './MarkdownRenderer';

interface StreamingChatMessageProps {
  messageId: string;
  onStreamingComplete?: (finalResponse: any) => void;
  className?: string;
}

interface StreamingChunk {
  type: 'start' | 'chunk' | 'complete' | 'error';
  line?: string;
  lineNumber?: number;
  isLast?: boolean;
  message?: string;
  confidence?: number;
  intent?: string;
  processingTime?: number;
  metadata?: any;
  error?: string;
}

export interface StreamingChatMessageRef {
  setupStreaming: (message: string, config: any) => Promise<void>;
}

const StreamingChatMessage = forwardRef<StreamingChatMessageRef, StreamingChatMessageProps>(({ 
  messageId, 
  onStreamingComplete, 
  className = '' 
}, ref) => {
  const [chunks, setChunks] = useState<string[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [metadata, setMetadata] = useState<any>(null);
  
  // Use a ref to track all chunks for immediate access
  const allChunksRef = useRef<string[]>([]);

  const setupStreaming = async (message: string, config: any) => {
    try {
      setIsStreaming(true);
      setError(null);
      setChunks([]);
      allChunksRef.current = []; // Reset the ref

      const response = await fetch('/api/intelligent-chat/stream', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message,
          config,
        }),
      });

      if (!response.ok) {
        throw new Error(`Streaming request failed (${response.status}): ${response.statusText}`);
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();

      if (!reader) {
        throw new Error('No reader available for streaming');
      }

      while (true) {
        const { done, value } = await reader.read();
        
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data: StreamingChunk = JSON.parse(line.slice(6));
              
              switch (data.type) {
                case 'start':
                  console.log('🚀 Streaming started for message:', messageId);
                  break;
                  
                case 'chunk':
                  if (data.line && data.line.trim()) {
                    // Update both state and ref
                    const newChunks = [...allChunksRef.current, data.line];
                    allChunksRef.current = newChunks;
                    setChunks(newChunks);
                  }
                  break;
                  
                case 'complete':
                  console.log('🎉 Streaming completed for message:', messageId);
                  setIsStreaming(false);
                  setMetadata({
                    confidence: data.confidence,
                    intent: data.intent,
                    processingTime: data.processingTime,
                    ...data.metadata
                  });
                  
                  if (onStreamingComplete) {
                    // Use the ref to get all chunks immediately
                    const finalResponse = allChunksRef.current.join('\n');
                    
                    // Ensure we have a meaningful response
                    let responseContent = finalResponse.trim();
                    
                    // If response is empty or too short, provide a helpful fallback
                    if (!responseContent || responseContent.length < 10) {
                      responseContent = `I apologize, but I wasn't able to generate a proper response. This could be due to:
                      
• Temporary AI service unavailability
• Network connectivity issues  
• High demand on AI services

**Please try:**
1. Waiting 30 seconds and trying again
2. Using a different AI model
3. Rephrasing your question

The system is designed to recover automatically from these temporary issues.`;
                    }
                    
                    onStreamingComplete({
                      response: responseContent,
                      confidence: data.confidence || 0.5,
                      intent: data.intent || 'informational',
                      processingTime: data.processingTime || 0,
                      metadata: data.metadata || {}
                    });
                  }
                  break;
                  
                case 'error':
                  setError(data.error || 'Streaming error occurred');
                  setIsStreaming(false);
                  
                  // Ensure fallback response is set and call onComplete
                  const errorFallback = `# **⚠️ AI Service Error**

I apologize, but the AI service encountered an error: ${data.error || 'Unknown error'}.

**Current Status:**
- AI Service: ❌ Error occurred
- System: ✅ All other components working normally
- Recovery: 🔄 Attempting to recover

**Immediate Solutions:**
1. **Wait 30 seconds** and try your query again
2. **Try a different AI model** from the dropdown menu
3. **Use deep research mode** which has alternative routing

The system is designed to handle these situations gracefully. Please try again in a moment.`;
                  
                  // Update both state and ref
                  allChunksRef.current = [errorFallback];
                  setChunks([errorFallback]);
                  
                  // Still call onComplete to ensure the message becomes permanent
                  if (onStreamingComplete) {
                    onStreamingComplete({
                      response: errorFallback,
                      confidence: 0,
                      intent: 'error',
                      processingTime: 0,
                      metadata: { error: data.error }
                    });
                  }
                  break;
              }
            } catch (e) {
              console.error('❌ Error parsing streaming chunk:', e, 'Line:', line);
              // Don't throw here, just continue processing
            }
          }
        }
      }
    } catch (err) {
      console.error('❌ Streaming error:', err);
      const errorMessage = err instanceof Error ? err.message : 'Streaming failed';
      setError(errorMessage);
      setIsStreaming(false);
      
      // Provide a helpful fallback response that will persist
      const fallbackResponse = `# **🔧 AI Service - Fallback Response**

I apologize, but I encountered an error while trying to connect to the AI service: ${errorMessage}.

**Current Status:**
- AI Service: ⚠️ Temporarily experiencing technical difficulties
- System: ✅ All other components working normally
- Recovery: 🔄 Auto-recovery in progress

This could be due to:
• Temporary network connectivity issues
• AI service being temporarily unavailable
• High demand on AI services

## **Immediate Solutions:**
1. **Wait 30 seconds** and try your query again
2. **Try a different AI model** from the dropdown menu
3. **Use deep research mode** which has alternative routing

The system is designed to handle these situations gracefully and will recover automatically.

If the problem persists, you can try using a different AI model from the dropdown menu.`;

      // Update both state and ref
      allChunksRef.current = [fallbackResponse];
      setChunks([fallbackResponse]);
      
      // Ensure onComplete is called even in error case to make the message permanent
      if (onStreamingComplete) {
        onStreamingComplete({
          response: fallbackResponse,
          confidence: 0,
          intent: 'error',
          processingTime: 0,
          metadata: { error: errorMessage }
        });
      }
    }
  };

  // Expose setupStreaming function to parent component
  useImperativeHandle(ref, () => ({
    setupStreaming
  }));

  // Auto-start streaming if messageId changes - REMOVED demo data, now uses real API
  useEffect(() => {
    // Demo functionality removed - now uses real API calls through setupStreaming
    // The component will now only show real data from the AI APIs
  }, [messageId, onStreamingComplete]);

  return (
    <div className={`w-full ${className}`}>
      <Card className="border-l-4 border-l-blue-500 bg-blue-50">
        <CardContent className="p-4">
          {/* Header */}
          <div className="flex items-center gap-2 mb-3">
            <Brain className="w-5 h-5 text-blue-600" />
            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
              🤖 Intelligent Chat
            </Badge>
            {isStreaming && (
              <Badge variant="outline" className="flex items-center gap-1">
                <Loader2 className="w-3 h-3 animate-spin" />
                Streaming
              </Badge>
            )}
          </div>

          {/* Error State */}
          {error && (
            <div className="mb-3 p-3 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm text-red-700">❌ {error}</p>
            </div>
          )}

          {/* Streaming Content */}
          <div className="space-y-1">
            {chunks.map((chunk, index) => (
              <div 
                key={index} 
                className="text-sm text-gray-800 leading-relaxed"
                style={{ 
                  opacity: 1,
                  transition: 'opacity 0.3s ease-in-out'
                }}
              >
                <MarkdownRenderer content={chunk} />
              </div>
            ))}
          </div>

          {/* Loading Indicator */}
          {isStreaming && chunks.length === 0 && (
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>AI is thinking and responding...</span>
            </div>
          )}

          {/* Streaming Progress - REMOVED per user request - only show actual data, not backend process info */}
          {false && isStreaming && chunks.length > 0 && (
            <div className="flex items-center gap-2 mt-2 text-xs text-blue-600">
              <Loader2 className="w-3 h-3 animate-spin" />
              <span>Streaming response... ({chunks.length} lines)</span>
            </div>
          )}

          {/* Metadata - REMOVED per user request - only show actual data, not backend process info */}
          {false && metadata && !isStreaming && (
            <div className="mt-4 pt-3 border-t border-blue-200">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                <div>
                  <span className="font-medium text-gray-600">Intent:</span>
                  <div className="text-gray-800">{metadata.intent}</div>
                </div>
                <div>
                  <span className="font-medium text-gray-600">Confidence:</span>
                  <div className="text-gray-800">{Math.round((metadata.confidence || 0) * 100)}%</div>
                </div>
                <div>
                  <span className="font-medium text-gray-600">Processing:</span>
                  <div className="text-gray-800">{metadata.processingTime}ms</div>
                </div>
                <div>
                  <span className="font-medium text-gray-600">Words:</span>
                  <div className="text-gray-800">{metadata.wordCount || 0}</div>
                </div>
              </div>
              
              {metadata.suggestions && metadata.suggestions.length > 0 && (
                <div className="mt-2">
                  <span className="font-medium text-gray-600 text-xs">Suggestions:</span>
                  <div className="text-xs text-gray-700 mt-1">
                    {metadata.suggestions.join(', ')}
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
});

StreamingChatMessage.displayName = 'StreamingChatMessage';

export default StreamingChatMessage;