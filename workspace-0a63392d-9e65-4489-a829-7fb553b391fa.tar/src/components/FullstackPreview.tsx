'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Eye, EyeOff, Maximize2, Minimize2, RefreshCw, Download, Play, 
  FileCode, Database, Globe, Settings, CheckCircle, AlertCircle,
  ChevronUp, ChevronDown, ArrowUp, ArrowDown
} from 'lucide-react';

interface GeneratedFile {
  path: string;
  content: string;
  type: 'frontend' | 'backend' | 'database' | 'config' | 'docs';
}

interface FullstackProject {
  structure: {
    name: string;
    description: string;
    type: 'web' | 'api' | 'fullstack';
    framework: 'nextjs' | 'react' | 'express' | 'fastapi';
    database: 'sqlite' | 'postgresql' | 'mongodb' | 'none';
    features: string[];
  };
  files: GeneratedFile[];
  setupInstructions: string[];
  dependencies: string[];
  devDependencies: string[];
  scripts: Record<string, string>;
}

interface FullstackPreviewProps {
  project: FullstackProject;
  isVisible: boolean;
  onToggleVisibility: () => void;
}

export default function FullstackPreview({ project, isVisible, onToggleVisibility }: FullstackPreviewProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [selectedTab, setSelectedTab] = useState('overview');
  const [selectedFile, setSelectedFile] = useState<GeneratedFile | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [showScrollBottom, setShowScrollBottom] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  
  const overviewRef = useRef<HTMLDivElement>(null);
  const filesRef = useRef<HTMLDivElement>(null);
  const codeRef = useRef<HTMLDivElement>(null);
  const setupRef = useRef<HTMLDivElement>(null);
  const previewRef = useRef<HTMLDivElement>(null);

  // Get current tab ref
  const getCurrentTabRef = () => {
    switch (selectedTab) {
      case 'overview': return overviewRef;
      case 'files': return filesRef;
      case 'code': return codeRef;
      case 'setup': return setupRef;
      case 'preview': return previewRef;
      default: return overviewRef;
    }
  };

  // Handle scroll events with enhanced mouse wheel support
  const handleScroll = (container: HTMLDivElement) => {
    if (container) {
      const scrollTop = container.scrollTop;
      const scrollHeight = container.scrollHeight;
      const clientHeight = container.clientHeight;
      const progress = (scrollTop / (scrollHeight - clientHeight)) * 100;
      
      setShowScrollTop(scrollTop > 50);
      setShowScrollBottom(scrollTop + clientHeight < scrollHeight - 50);
      setScrollProgress(progress);
    }
  };

  // Enhanced wheel event handler for smooth scrolling
  const handleWheel = (e: React.WheelEvent) => {
    const container = getCurrentTabRef().current;
    if (container && e.currentTarget === container) {
      e.preventDefault();
      const delta = e.deltaY;
      container.scrollTop += delta;
      handleScroll(container);
    }
  };

  // Add mouse wheel event listeners to all tab containers
  useEffect(() => {
    const containers = [overviewRef, filesRef, codeRef, setupRef, previewRef];
    
    const handleWheelEvent = (e: WheelEvent) => {
      const container = getCurrentTabRef().current;
      if (container && e.target instanceof Node && container.contains(e.target)) {
        e.preventDefault();
        const delta = e.deltaY;
        container.scrollTop += delta;
        handleScroll(container);
      }
    };

    containers.forEach(ref => {
      const container = ref.current;
      if (container) {
        container.addEventListener('wheel', handleWheelEvent, { passive: false });
      }
    });

    return () => {
      containers.forEach(ref => {
        const container = ref.current;
        if (container) {
          container.removeEventListener('wheel', handleWheelEvent);
        }
      });
    };
  }, [selectedTab]);

  // Scroll to top
  const scrollToTop = () => {
    const container = getCurrentTabRef().current;
    if (container) {
      container.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Scroll to bottom
  const scrollToBottom = () => {
    const container = getCurrentTabRef().current;
    if (container) {
      container.scrollTo({ top: container.scrollHeight, behavior: 'smooth' });
    }
  };

  // Handle keyboard events
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Home') {
      e.preventDefault();
      scrollToTop();
    } else if (e.key === 'End') {
      e.preventDefault();
      scrollToBottom();
    }
  };

  // Add keyboard event listener
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Home' || e.key === 'End') {
        const container = getCurrentTabRef().current;
        if (container && document.activeElement?.closest('.FullstackPreview')) {
          e.preventDefault();
          if (e.key === 'Home') {
            scrollToTop();
          } else {
            scrollToBottom();
          }
        }
      }
    };

    document.addEventListener('keydown', handleGlobalKeyDown);
    return () => {
      document.removeEventListener('keydown', handleGlobalKeyDown);
    };
  }, [selectedTab]);

  // Group files by type
  const filesByType = project.files.reduce((acc, file) => {
    if (!acc[file.type]) acc[file.type] = [];
    acc[file.type].push(file);
    return acc;
  }, {} as Record<string, GeneratedFile[]>);

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'frontend': return <FileCode className="w-4 h-4 text-blue-500" />;
      case 'backend': return <Globe className="w-4 h-4 text-green-500" />;
      case 'database': return <Database className="w-4 h-4 text-orange-500" />;
      case 'config': return <Settings className="w-4 h-4 text-purple-500" />;
      case 'docs': return <FileCode className="w-4 h-4 text-gray-500" />;
      default: return <FileCode className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'frontend': return 'bg-blue-100 text-blue-800';
      case 'backend': return 'bg-green-100 text-green-800';
      case 'database': return 'bg-orange-100 text-orange-800';
      case 'config': return 'bg-purple-100 text-purple-800';
      case 'docs': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (!isVisible) {
    return (
      <div className="fixed bottom-4 right-4 z-50">
        <Button
          onClick={onToggleVisibility}
          className="shadow-lg bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
          size="sm"
        >
          <Eye className="w-4 h-4 mr-2" />
          Show Fullstack App ({project.files.length} files)
        </Button>
      </div>
    );
  }

  const getPositionClasses = () => {
    return isFullscreen 
      ? 'fixed inset-0 z-50 bg-white' 
      : 'fixed bottom-4 right-4 w-[600px] h-[500px] z-50';
  };

  return (
    <div className={`${getPositionClasses()} FullstackPreview border border-gray-200 rounded-lg shadow-2xl bg-white flex flex-col`} onKeyDown={handleKeyDown}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-purple-50 rounded-t-lg">
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white w-8 h-8 rounded-lg flex items-center justify-center">
            <Play className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-semibold text-lg">{project.structure.name}</h3>
            <p className="text-xs text-gray-600">{project.structure.description}</p>
          </div>
          <Badge variant="secondary" className="text-xs">
            {project.files.length} files
          </Badge>
        </div>
        <div className="flex items-center gap-1">
          {/* Enhanced Scrolling Controls */}
          {showScrollTop && (
            <Button
              variant="default"
              size="sm"
              onClick={scrollToTop}
              className="h-8 w-8 p-0 shadow-md bg-blue-500 hover:bg-blue-600 text-white transition-all duration-200"
              title="Scroll to Top (Home)"
            >
              <ArrowUp className="w-4 h-4" />
            </Button>
          )}
          {showScrollBottom && (
            <Button
              variant="default"
              size="sm"
              onClick={scrollToBottom}
              className="h-8 w-8 p-0 shadow-md bg-blue-500 hover:bg-blue-600 text-white transition-all duration-200"
              title="Scroll to Bottom (End)"
            >
              <ArrowDown className="w-4 h-4" />
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="h-8 w-8 p-0 hover:bg-gray-100 transition-all duration-200"
            title={isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggleVisibility}
            className="h-8 w-8 p-0 hover:bg-gray-100 transition-all duration-200"
            title="Hide Preview"
          >
            <EyeOff className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Scroll Progress Bar */}
      <div className="h-1 bg-gray-200">
        <div 
          className="h-full bg-gradient-to-r from-blue-500 to-purple-600 transition-all duration-300"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      {/* Enhanced Keyboard Shortcut Hint */}
      <div className="px-4 py-3 bg-gradient-to-r from-blue-50 to-purple-50 border-b border-gray-200 text-xs text-gray-700 text-center">
        💡 <strong>Scrolling Controls:</strong> 
        <kbd className="mx-1 px-2 py-1 bg-white border border-gray-300 rounded shadow-sm">Mouse Wheel</kbd> • 
        <kbd className="mx-1 px-2 py-1 bg-white border border-gray-300 rounded shadow-sm">Home</kbd> (Top) • 
        <kbd className="mx-1 px-2 py-1 bg-white border border-gray-300 rounded shadow-sm">End</kbd> (Bottom) • 
        <kbd className="mx-1 px-2 py-1 bg-white border border-gray-300 rounded shadow-sm">Click Buttons</kbd> 
        <span className="ml-2 text-blue-600">📜 Progress: {Math.round(scrollProgress)}%</span>
      </div>

      {/* Tabs */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-5 h-auto">
            <TabsTrigger value="overview" className="text-xs">
              Overview
            </TabsTrigger>
            <TabsTrigger value="files" className="text-xs">
              Files ({project.files.length})
            </TabsTrigger>
            <TabsTrigger value="code" className="text-xs">
              Code View
            </TabsTrigger>
            <TabsTrigger value="setup" className="text-xs">
              Setup
            </TabsTrigger>
            <TabsTrigger value="preview" className="text-xs">
              Live Demo
            </TabsTrigger>
          </TabsList>

          <div className="flex-1 overflow-hidden relative">
            {/* Enhanced Floating Scroll Buttons */}
            <div className="absolute bottom-4 right-4 z-10 flex flex-col gap-2">
              {showScrollTop && (
                <Button
                  variant="default"
                  size="sm"
                  onClick={scrollToTop}
                  className="shadow-xl bg-blue-500 hover:bg-blue-600 text-white h-10 w-10 p-0 rounded-full transition-all duration-300 hover:scale-110 border-2 border-white"
                  title="Scroll to Top (Home)"
                >
                  <ChevronUp className="w-5 h-5" />
                </Button>
              )}
              {showScrollBottom && (
                <Button
                  variant="default"
                  size="sm"
                  onClick={scrollToBottom}
                  className="shadow-xl bg-blue-500 hover:bg-blue-600 text-white h-10 w-10 p-0 rounded-full transition-all duration-300 hover:scale-110 border-2 border-white"
                  title="Scroll to Bottom (End)"
                >
                  <ChevronDown className="w-5 h-5" />
                </Button>
              )}
            </div>
            {/* Overview Tab */}
            <TabsContent value="overview" className="h-full p-0 overflow-hidden">
              <div 
                ref={overviewRef}
                className="h-full overflow-y-auto p-4"
                onScroll={(e) => handleScroll(e.currentTarget)}
              >
                <div className="space-y-4">
                  {/* Project Info */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        🎉 Enhanced Fullstack Application Generated!
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="font-medium">🚀 Framework:</span>
                          <span className="ml-2 text-blue-600">{project.structure.framework.toUpperCase()}</span>
                        </div>
                        <div>
                          <span className="font-medium">🗄️ Database:</span>
                          <span className="ml-2 text-orange-600">{project.structure.database.toUpperCase()}</span>
                        </div>
                        <div>
                          <span className="font-medium">📁 Type:</span>
                          <span className="ml-2 text-purple-600">{project.structure.type.toUpperCase()}</span>
                        </div>
                        <div>
                          <span className="font-medium">📄 Files:</span>
                          <span className="ml-2">{project.files.length}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Features */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg">✨ AI-Powered Features</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2">
                        {project.structure.features.map((feature, index) => (
                          <Badge key={index} variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">
                            {feature.charAt(0).toUpperCase() + feature.slice(1).replace('-', ' ')}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  {/* File Structure */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg">📦 What's Included</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-500" />
                          <span>Frontend Components: Modern React/Next.js UI with responsive design</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-500" />
                          <span>Backend API: Complete RESTful API endpoints with error handling</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-500" />
                          <span>Database Schema: Prisma models with proper relationships</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-500" />
                          <span>Configuration: All necessary setup and config files</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-500" />
                          <span>Live Preview: Real-time application preview and testing</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            {/* Files Tab */}
            <TabsContent value="files" className="h-full p-0 overflow-hidden">
              <div 
                ref={filesRef}
                className="flex h-full"
                onScroll={(e) => handleScroll(e.currentTarget)}
              >
                {/* File List */}
                <div className="w-64 border-r border-gray-200 overflow-y-auto">
                  <div className="p-3 space-y-2">
                    {Object.entries(filesByType).map(([type, files]) => (
                      <div key={type}>
                        <div className="flex items-center gap-2 mb-2 p-2 bg-gray-50 rounded">
                          {getFileIcon(type)}
                          <span className="font-medium text-sm capitalize">{type}</span>
                          <Badge variant="secondary" className="text-xs ml-auto">
                            {files.length}
                          </Badge>
                        </div>
                        <div className="space-y-1">
                          {files.map((file, index) => (
                            <div
                              key={index}
                              className={`p-2 text-xs cursor-pointer rounded hover:bg-gray-50 transition-colors ${
                                selectedFile?.path === file.path ? 'bg-blue-50 border border-blue-200' : ''
                              }`}
                              onClick={() => setSelectedFile(file)}
                            >
                              <div className="flex items-center gap-2">
                                <FileCode className="w-3 h-3" />
                                <span className="truncate">{file.path.split('/').pop()}</span>
                              </div>
                              <div className="text-gray-400 text-xs truncate">
                                {file.path}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* File Preview */}
                <div className="flex-1 flex flex-col">
                  {selectedFile ? (
                    <div className="flex-1 flex flex-col relative">
                        {/* File Preview Scroll Progress */}
                        <div className="h-0.5 bg-gray-200 absolute top-0 left-0 right-0 z-20">
                          <div 
                            className="h-full bg-green-500 transition-all duration-300"
                            style={{ width: `${scrollProgress}%` }}
                          />
                        </div>
                        
                        <div className="p-3 border-b border-gray-200 bg-gray-50">
                          <div className="flex items-center gap-2">
                            {getFileIcon(selectedFile.type)}
                            <span className="font-medium">{selectedFile.path}</span>
                            <Badge className={`text-xs ${getTypeColor(selectedFile.type)}`}>
                              {selectedFile.type}
                            </Badge>
                          </div>
                        </div>
                        <ScrollArea className="flex-1 p-4" onScrollCapture={(e) => {
                          const container = e.currentTarget.querySelector('[data-radix-scroll-area-viewport]');
                          if (container) {
                            handleScroll(container as HTMLDivElement);
                          }
                        }}>
                          <pre className="text-xs bg-gray-900 text-gray-100 p-4 rounded overflow-x-auto">
                            <code>{selectedFile.content}</code>
                          </pre>
                        </ScrollArea>
                        
                        {/* File Preview Scroll Buttons */}
                        <div className="absolute bottom-2 right-2 z-10 flex flex-col gap-1">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              const container = document.querySelector('[data-radix-scroll-area-viewport]');
                              if (container) {
                                (container as HTMLDivElement).scrollTo({ top: 0, behavior: 'smooth' });
                              }
                            }}
                            className="h-6 w-6 p-0 bg-white shadow-md border"
                            title="Scroll to Top"
                          >
                            <ChevronUp className="w-3 h-3" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              const container = document.querySelector('[data-radix-scroll-area-viewport]');
                              if (container) {
                                (container as HTMLDivElement).scrollTo({ top: (container as HTMLDivElement).scrollHeight, behavior: 'smooth' });
                              }
                            }}
                            className="h-6 w-6 p-0 bg-white shadow-md border"
                            title="Scroll to Bottom"
                          >
                            <ChevronDown className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                  ) : (
                    <div className="flex-1 flex items-center justify-center text-gray-500">
                      <div className="text-center">
                        <FileCode className="w-12 h-12 mx-auto mb-2 opacity-50" />
                        <p>Select a file to preview</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>

            {/* Code View Tab */}
            <TabsContent value="code" className="h-full p-0 overflow-hidden">
              <div 
                ref={codeRef}
                className="h-full overflow-y-auto p-4"
                onScroll={(e) => handleScroll(e.currentTarget)}
              >
                <div className="h-full flex flex-col">
                  <div className="mb-4">
                    <h3 className="text-lg font-semibold mb-2">Complete Source Code</h3>
                    <p className="text-sm text-gray-600">
                      All generated files for your {project.structure.name} application
                    </p>
                  </div>
                  <div className="space-y-4">
                    {project.files.map((file, index) => (
                      <Card key={index}>
                        <CardHeader className="pb-2">
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-base flex items-center gap-2">
                              {getFileIcon(file.type)}
                              {file.path}
                            </CardTitle>
                            <Badge className={`text-xs ${getTypeColor(file.type)}`}>
                              {file.type}
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <pre className="text-xs bg-gray-900 text-gray-100 p-3 rounded overflow-x-auto max-h-40">
                            <code>{file.content.substring(0, 500)}{file.content.length > 500 ? '...' : ''}</code>
                          </pre>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Setup Tab */}
            <TabsContent value="setup" className="h-full p-0 overflow-hidden">
              <div 
                ref={setupRef}
                className="h-full overflow-y-auto p-4"
                onScroll={(e) => handleScroll(e.currentTarget)}
              >
                <div className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Play className="w-5 h-5 text-green-500" />
                        🚀 Quick Start Guide
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {project.setupInstructions.map((instruction, index) => (
                          <div key={index} className="flex items-start gap-3">
                            <div className="bg-blue-500 text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-medium">
                              {index + 1}
                            </div>
                            <div className="flex-1">
                              <code className="bg-gray-100 px-2 py-1 rounded text-sm">{instruction}</code>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>⚡ Setup Commands</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="bg-gray-900 text-green-400 p-3 rounded font-mono text-sm">
                          <div>npm install</div>
                          <div>npx prisma db push</div>
                          <div>npm run dev</div>
                        </div>
                        <p className="text-sm text-gray-600">
                          📝 <strong>Estimated setup time:</strong> 3-5 minutes
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>📦 Dependencies</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div>
                          <h4 className="font-medium mb-2">Production Dependencies:</h4>
                          <div className="flex flex-wrap gap-1">
                            {project.dependencies.map((dep, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {dep}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div>
                          <h4 className="font-medium mb-2">Development Dependencies:</h4>
                          <div className="flex flex-wrap gap-1">
                            {project.devDependencies.map((dep, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {dep}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>🎯 Available Scripts</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {Object.entries(project.scripts).map(([name, command]) => (
                          <div key={name} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <span className="font-medium text-sm">{name}:</span>
                            <code className="text-xs bg-gray-200 px-2 py-1 rounded">{command}</code>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            {/* Live Demo Tab */}
            <TabsContent value="preview" className="h-full p-0 overflow-hidden">
              <div 
                ref={previewRef}
                className="h-full overflow-y-auto p-4"
                onScroll={(e) => handleScroll(e.currentTarget)}
              >
                <div className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Eye className="w-5 h-5 text-blue-500" />
                        🌐 Live Application Preview
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                          <h4 className="font-medium text-blue-900 mb-2">🎉 Enhanced Fullstack Application Generated!</h4>
                          <p className="text-sm text-blue-800 mb-3">
                            I've successfully created a complete fullstack application from your request. Your application is ready to run!
                          </p>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="font-medium">📁 Project:</span>
                              <span className="ml-2 text-blue-600">{project.structure.name}</span>
                            </div>
                            <div>
                              <span className="font-medium">🚀 Framework:</span>
                              <span className="ml-2 text-blue-600">{project.structure.framework.toUpperCase()}</span>
                            </div>
                            <div>
                              <span className="font-medium">🗄️ Database:</span>
                              <span className="ml-2 text-blue-600">{project.structure.database.toUpperCase()}</span>
                            </div>
                            <div>
                              <span className="font-medium">📄 Files:</span>
                              <span className="ml-2 text-blue-600">{project.files.length}</span>
                            </div>
                          </div>
                        </div>

                        <div>
                          <h4 className="font-medium mb-2">✨ AI-Powered Features:</h4>
                          <div className="flex flex-wrap gap-2">
                            {project.structure.features.map((feature, index) => (
                              <Badge key={index} variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">
                                {feature.charAt(0).toUpperCase() + feature.slice(1).replace('-', ' ')}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div>
                          <h4 className="font-medium mb-2">📦 What's Included:</h4>
                          <div className="space-y-2 text-sm">
                            <div className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-500" />
                              <span>Frontend Components: Modern React/Next.js UI with responsive design</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-500" />
                              <span>Backend API: Complete RESTful API endpoints with error handling</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-500" />
                              <span>Database Schema: Prisma models with proper relationships</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-500" />
                              <span>Configuration: All necessary setup and config files</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-500" />
                              <span>Live Preview: Real-time application preview and testing</span>
                            </div>
                          </div>
                        </div>

                        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                          <h4 className="font-medium text-yellow-900 mb-2">🔧 Setup Instructions:</h4>
                          <div className="space-y-2">
                            {project.setupInstructions.map((instruction, index) => (
                              <div key={index} className="flex items-start gap-3">
                                <div className="bg-yellow-500 text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-medium">
                                  {index + 1}
                                </div>
                                <div className="flex-1">
                                  <code className="bg-yellow-100 px-2 py-1 rounded text-sm">{instruction}</code>
                                </div>
                              </div>
                            ))}
                          </div>
                          <p className="text-sm text-yellow-700 mt-3">
                            📝 <strong>Estimated setup time:</strong> 3-5 minutes
                          </p>
                        </div>

                        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                          <h4 className="font-medium text-green-900 mb-2">🌐 Preview:</h4>
                          <p className="text-sm text-green-800 mb-3">
                            Your application is ready to run! Open http://localhost:3000 to see it in action.
                          </p>
                          <div className="flex gap-2">
                            <Button 
                              onClick={() => {
                                // Copy setup commands to clipboard
                                const commands = project.setupInstructions.join('\n');
                                navigator.clipboard.writeText(commands);
                              }}
                              variant="outline"
                              size="sm"
                            >
                              <Download className="w-4 h-4 mr-2" />
                              Copy Commands
                            </Button>
                            <Button 
                              onClick={() => {
                                // Open setup guide
                                alert('Follow the setup instructions in the Setup tab to get started!');
                              }}
                              className="bg-green-500 hover:bg-green-600"
                              size="sm"
                            >
                              <Play className="w-4 h-4 mr-2" />
                              Start Setup
                            </Button>
                          </div>
                        </div>

                        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                          <Play className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                          <h4 className="text-lg font-medium mb-2">🎯 Enhanced Fullstack Preview</h4>
                          <p className="text-gray-600 mb-4">
                            A comprehensive preview panel has been opened where you can explore all generated files, 
                            view the complete source code, and get step-by-step setup instructions!
                          </p>
                          <div className="flex justify-center gap-2">
                            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                              🚀 Ready to Run
                            </Badge>
                            <Badge variant="secondary" className="bg-green-100 text-green-800">
                              📁 {project.files.length} Files
                            </Badge>
                            <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                              ⚡ 3-5 Min Setup
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
}