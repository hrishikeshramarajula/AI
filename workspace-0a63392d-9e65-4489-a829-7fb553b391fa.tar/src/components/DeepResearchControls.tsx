'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Settings, 
  Brain, 
  Network, 
  BarChart3, 
  Heart, 
  Users, 
  Search, 
  Globe,
  FileText,
  Target,
  Clock,
  Layers,
  Zap,
  Info
} from 'lucide-react';

interface DeepResearchConfig {
  researchDepth: 'basic' | 'detailed' | 'comprehensive' | 'encyclopedic';
  includeWebSearch: boolean;
  includeKnowledgeGraph: boolean;
  includeTopicModeling: boolean;
  includeSentimentAnalysis: boolean;
  includeEmotionalIntelligence: boolean;
  includePsychologicalProfile: boolean;
  maxSources: number;
  analysisType: 'academic' | 'business' | 'technical' | 'general';
  timeFrame: 'current' | 'historical' | 'future' | 'comparative';
  outputFormat: 'summary' | 'detailed' | 'comprehensive' | 'executive';
}

interface DeepResearchControlsProps {
  onConfigChange: (config: DeepResearchConfig) => void;
  onExecute: (query: string, config: DeepResearchConfig) => void;
  isLoading?: boolean;
}

export default function DeepResearchControls({ 
  onConfigChange, 
  onExecute, 
  isLoading = false 
}: DeepResearchControlsProps) {
  const [query, setQuery] = useState('');
  const [config, setConfig] = useState<DeepResearchConfig>({
    researchDepth: 'comprehensive',
    includeWebSearch: true,
    includeKnowledgeGraph: true,
    includeTopicModeling: true,
    includeSentimentAnalysis: true,
    includeEmotionalIntelligence: false,
    includePsychologicalProfile: false,
    maxSources: 20,
    analysisType: 'general',
    timeFrame: 'current',
    outputFormat: 'comprehensive'
  });

  const [showAdvanced, setShowAdvanced] = useState(false);

  const updateConfig = (updates: Partial<DeepResearchConfig>) => {
    const newConfig = { ...config, ...updates };
    setConfig(newConfig);
    onConfigChange(newConfig);
  };

  const handleExecute = () => {
    if (query.trim()) {
      onExecute(query.trim(), config);
    }
  };

  const getDepthDescription = (depth: string) => {
    switch (depth) {
      case 'basic': return 'Quick overview with essential analysis';
      case 'detailed': return 'Thorough analysis with multiple perspectives';
      case 'comprehensive': return 'In-depth investigation with advanced NLP';
      case 'encyclopedic': return 'Exhaustive analysis with maximum detail';
      default: return '';
    }
  };

  const getAnalysisTypeDescription = (type: string) => {
    switch (type) {
      case 'academic': return 'Focus on scholarly research and theoretical frameworks';
      case 'business': return 'Emphasize strategic insights and practical applications';
      case 'technical': return 'Concentrate on technical details and implementation';
      case 'general': return 'Balanced approach suitable for most queries';
      default: return '';
    }
  };

  return (
    <Card className="w-full border-2 border-blue-200 bg-blue-50">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-blue-900">
          <Brain className="w-5 h-5" />
          🔬 Deep Research Interface
        </CardTitle>
        <p className="text-sm text-blue-700">
          Advanced AI-powered research with multi-source analysis
        </p>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Query Input */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-blue-900">Research Query</label>
          <div className="flex gap-2">
            <Input
              placeholder="Enter your research question or topic..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="flex-1"
              onKeyPress={(e) => e.key === 'Enter' && handleExecute()}
            />
            <Button 
              onClick={handleExecute}
              disabled={!query.trim() || isLoading}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isLoading ? (
                <>
                  <Zap className="w-4 h-4 mr-2 animate-spin" />
                  Researching...
                </>
              ) : (
                <>
                  <Search className="w-4 h-4 mr-2" />
                  Execute Research
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Basic Configuration */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Research Depth */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-blue-900">Research Depth</label>
            <Select value={config.researchDepth} onValueChange={(value: any) => updateConfig({ researchDepth: value })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="basic">
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4" />
                    Basic
                  </div>
                </SelectItem>
                <SelectItem value="detailed">
                  <div className="flex items-center gap-2">
                    <BarChart3 className="w-4 h-4" />
                    Detailed
                  </div>
                </SelectItem>
                <SelectItem value="comprehensive">
                  <div className="flex items-center gap-2">
                    <Brain className="w-4 h-4" />
                    Comprehensive
                  </div>
                </SelectItem>
                <SelectItem value="encyclopedic">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4" />
                    Encyclopedic
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-blue-600">{getDepthDescription(config.researchDepth)}</p>
          </div>

          {/* Analysis Type */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-blue-900">Analysis Type</label>
            <Select value={config.analysisType} onValueChange={(value: any) => updateConfig({ analysisType: value })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="general">
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4" />
                    General
                  </div>
                </SelectItem>
                <SelectItem value="academic">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    Academic
                  </div>
                </SelectItem>
                <SelectItem value="business">
                  <div className="flex items-center gap-2">
                    <BarChart3 className="w-4 h-4" />
                    Business
                  </div>
                </SelectItem>
                <SelectItem value="technical">
                  <div className="flex items-center gap-2">
                    <Settings className="w-4 h-4" />
                    Technical
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-blue-600">{getAnalysisTypeDescription(config.analysisType)}</p>
          </div>

          {/* Time Frame */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-blue-900">Time Frame</label>
            <Select value={config.timeFrame} onValueChange={(value: any) => updateConfig({ timeFrame: value })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="current">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Current
                  </div>
                </SelectItem>
                <SelectItem value="historical">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    Historical
                  </div>
                </SelectItem>
                <SelectItem value="future">
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4" />
                    Future
                  </div>
                </SelectItem>
                <SelectItem value="comparative">
                  <div className="flex items-center gap-2">
                    <BarChart3 className="w-4 h-4" />
                    Comparative
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Output Format */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-blue-900">Output Format</label>
            <Select value={config.outputFormat} onValueChange={(value: any) => updateConfig({ outputFormat: value })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="summary">Summary</SelectItem>
                <SelectItem value="detailed">Detailed</SelectItem>
                <SelectItem value="executive">Executive</SelectItem>
                <SelectItem value="comprehensive">Comprehensive</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Core Features */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-blue-900">Core Analysis Features</label>
            <Badge variant="secondary" className="bg-blue-100 text-blue-700">
              Essential
            </Badge>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="webSearch"
                checked={config.includeWebSearch}
                onCheckedChange={(checked) => updateConfig({ includeWebSearch: checked as boolean })}
              />
              <label htmlFor="webSearch" className="text-sm text-blue-800 cursor-pointer">
                <Search className="w-4 h-4 inline mr-1" />
                Web Search Integration
              </label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="knowledgeGraph"
                checked={config.includeKnowledgeGraph}
                onCheckedChange={(checked) => updateConfig({ includeKnowledgeGraph: checked as boolean })}
              />
              <label htmlFor="knowledgeGraph" className="text-sm text-blue-800 cursor-pointer">
                <Network className="w-4 h-4 inline mr-1" />
                Knowledge Graph
              </label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="topicModeling"
                checked={config.includeTopicModeling}
                onCheckedChange={(checked) => updateConfig({ includeTopicModeling: checked as boolean })}
              />
              <label htmlFor="topicModeling" className="text-sm text-blue-800 cursor-pointer">
                <BarChart3 className="w-4 h-4 inline mr-1" />
                Topic Modeling
              </label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="sentimentAnalysis"
                checked={config.includeSentimentAnalysis}
                onCheckedChange={(checked) => updateConfig({ includeSentimentAnalysis: checked as boolean })}
              />
              <label htmlFor="sentimentAnalysis" className="text-sm text-blue-800 cursor-pointer">
                <Heart className="w-4 h-4 inline mr-1" />
                Sentiment Analysis
              </label>
            </div>
          </div>
        </div>

        {/* Advanced Options */}
        <div className="space-y-3">
          <Button
            variant="outline"
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="w-full justify-between"
          >
            <span className="flex items-center gap-2">
              <Settings className="w-4 h-4" />
              Advanced Options
            </span>
            <Badge variant="secondary">
              {showAdvanced ? 'Hide' : 'Show'}
            </Badge>
          </Button>

          {showAdvanced && (
            <div className="space-y-4 p-4 bg-blue-100 rounded-lg">
              {/* Advanced Features */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-blue-900">Advanced Intelligence Features</label>
                  <Badge variant="outline" className="bg-purple-100 text-purple-700">
                    Experimental
                  </Badge>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="emotionalIntelligence"
                      checked={config.includeEmotionalIntelligence}
                      onCheckedChange={(checked) => updateConfig({ includeEmotionalIntelligence: checked as boolean })}
                    />
                    <label htmlFor="emotionalIntelligence" className="text-sm text-blue-800 cursor-pointer">
                      <Heart className="w-4 h-4 inline mr-1" />
                      Emotional Intelligence
                    </label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="psychologicalProfile"
                      checked={config.includePsychologicalProfile}
                      onCheckedChange={(checked) => updateConfig({ includePsychologicalProfile: checked as boolean })}
                    />
                    <label htmlFor="psychologicalProfile" className="text-sm text-blue-800 cursor-pointer">
                      <Users className="w-4 h-4 inline mr-1" />
                      Psychological Profile
                    </label>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Data Sources */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-blue-900">Data Sources Configuration</label>
                <div className="flex items-center space-x-2">
                  <label className="text-sm text-blue-800">Max Web Sources:</label>
                  <Select 
                    value={config.maxSources.toString()} 
                    onValueChange={(value) => updateConfig({ maxSources: parseInt(value) })}
                  >
                    <SelectTrigger className="w-24">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="10">10</SelectItem>
                      <SelectItem value="20">20</SelectItem>
                      <SelectItem value="50">50</SelectItem>
                      <SelectItem value="100">100</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}