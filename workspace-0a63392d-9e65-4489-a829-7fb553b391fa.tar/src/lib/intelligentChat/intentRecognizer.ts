// ====== 3. INTENT RECOGNIZER ======
export interface IntentResult {
  intent: string;
  confidence: number;
  entities: Array<{ text: string; type: string; confidence: number }>;
  action?: string;
  parameters?: Record<string, any>;
}

export class IntentRecognizer {
  private static readonly INTENT_PATTERNS: Record<string, {
    keywords: string[];
    patterns: RegExp[];
    context: string[];
    confidence: number;
    action?: string;
  }> = {
    explanation: {
      keywords: ['explain', 'what is', 'how does', 'describe', 'tell me about', 'define', 'meaning of', 'clarify'],
      patterns: [
        /what\s+(?:is|are|was|were)\s+/i,
        /how\s+(?:does|do|did)\s+/i,
        /describe\s+/i,
        /tell\s+me\s+about\s+/i,
        /define\s+/i,
        /meaning\s+of\s+/i
      ],
      context: ['understanding', 'learning', 'curiosity'],
      confidence: 0.8,
      action: 'provide_explanation'
    },
    comparison: {
      keywords: ['compare', 'difference between', 'versus', 'vs', 'contrast', 'distinguish', 'better than', 'pros and cons'],
      patterns: [
        /compare\s+(?:and|to|with)\s+/i,
        /difference\s+between\s+/i,
        /\s+vs\s+/i,
        /contrast\s+/i,
        /which\s+is\s+better/i,
        /pros\s+and\s+cons/i
      ],
      context: ['decision making', 'analysis', 'evaluation'],
      confidence: 0.85,
      action: 'provide_comparison'
    },
    instruction: {
      keywords: ['how to', 'steps', 'guide', 'show me', 'tutorial', 'walkthrough', 'process', 'procedure'],
      patterns: [
        /how\s+to\s+/i,
        /steps?\s+to\s+/i,
        /guide\s+me\s+/i,
        /show\s+me\s+how\s+/i,
        /tutorial\s+on\s+/i,
        /walkthrough\s+/i
      ],
      context: ['learning', 'doing', 'creating'],
      confidence: 0.9,
      action: 'provide_instructions'
    },
    conversational: {
      keywords: ['hello', 'hi', 'thanks', 'thank you', 'joke', 'how are you', 'good morning', 'good afternoon', 'good evening', 'bye'],
      patterns: [
        /^(hello|hi|hey)\s*$/i,
        /^(thanks|thank\s+you)\s*$/i,
        /tell\s+me\s+a\s+joke/i,
        /how\s+are\s+you/i,
        /^(good\s+)?(morning|afternoon|evening)\s*$/i,
        /^(bye|goodbye)\s*$/i
      ],
      context: ['greeting', 'politeness', 'social'],
      confidence: 0.95,
      action: 'respond_socially'
    },
    question: {
      keywords: ['who', 'what', 'when', 'where', 'why', 'how', 'which', 'whose', 'whom'],
      patterns: [
        /^(who|what|when|where|why|how|which|whose|whom)\s+/i,
        /\?$/,
        /can\s+you\s+tell\s+me/i,
        /do\s+you\s+know/i
      ],
      context: ['information seeking', 'curiosity'],
      confidence: 0.7,
      action: 'answer_question'
    },
    action_request: {
      keywords: ['create', 'make', 'build', 'generate', 'write', 'code', 'develop', 'design', 'implement'],
      patterns: [
        /create\s+a?\s+/i,
        /make\s+me\s+a?\s+/i,
        /build\s+a?\s+/i,
        /generate\s+a?\s+/i,
        /write\s+(?:me\s+)?a?\s+/i,
        /code\s+a?\s+/i,
        /develop\s+a?\s+/i,
        /design\s+a?\s+/i
      ],
      context: ['creation', 'development', 'building'],
      confidence: 0.8,
      action: 'perform_action'
    },
    analysis: {
      keywords: ['analyze', 'review', 'evaluate', 'assess', 'examine', 'study', 'investigate', 'break down'],
      patterns: [
        /analyze\s+/i,
        /review\s+/i,
        /evaluate\s+/i,
        /assess\s+/i,
        /examine\s+/i,
        /study\s+/i,
        /investigate\s+/i,
        /break\s+down\s+/i
      ],
      context: ['research', 'evaluation', 'investigation'],
      confidence: 0.85,
      action: 'provide_analysis'
    },
    recommendation: {
      keywords: ['recommend', 'suggest', 'advice', 'should i', 'best', 'top', 'which one should'],
      patterns: [
        /recommend\s+/i,
        /suggest\s+/i,
        /advice\s+(?:on|about)\s+/i,
        /should\s+i\s+/i,
        /what\s+(?:is\s+)?the\s+best/i,
        /top\s+\d+/i,
        /which\s+one\s+should\s+i/i
      ],
      context: ['decision making', 'advice', 'guidance'],
      confidence: 0.8,
      action: 'provide_recommendation'
    },
    clarification: {
      keywords: ['what do you mean', 'clarify', 'explain again', 'i don\'t understand', 'can you explain', 'more details'],
      patterns: [
        /what\s+do\s+you\s+mean/i,
        /clarify\s+/i,
        /explain\s+(?:that\s+)?again/i,
        /i\s+don['']t\s+understand/i,
        /can\s+you\s+explain\s+(?:that\s+)?more/i,
        /more\s+details/i
      ],
      context: ['confusion', 'need for clarity'],
      confidence: 0.9,
      action: 'provide_clarification'
    },
    feedback: {
      keywords: ['good', 'bad', 'great', 'terrible', 'helpful', 'useless', 'thank you', 'thanks', 'appreciate'],
      patterns: [
        /^(that\s+)?(?:was\s+)?(?:very\s+)?(?:really\s+)?(?:so\s+)?(?:good|great|excellent|amazing|wonderful|fantastic)\s*!?$/i,
        /^(that\s+)?(?:was\s+)?(?:very\s+)?(?:really\s+)?(?:so\s+)?(?:bad|terrible|awful|horrible)\s*!?$/i,
        /^(?:very\s+)?helpful\s*!?$/i,
        /^(?:not\s+)?helpful\s*!?$/i,
        /^(?:i\s+)?(?:really\s+)?appreciate\s+/i,
        /^(?:thank\s+you|thanks)\s+(?:very\s+much|a\s+lot)?\s*!?$/i
      ],
      context: ['evaluation', 'gratitude', 'criticism'],
      confidence: 0.9,
      action: 'acknowledge_feedback'
    }
  };

  /**
   * Classify user intent based on text analysis
   */
  static classify(
    text: string, 
    tokens?: any[], 
    entities?: Array<{ text: string; type: string; confidence: number }>
  ): IntentResult {
    const lowerText = text.toLowerCase();
    
    // Calculate scores for each intent
    const intentScores: Record<string, number> = {};
    
    for (const [intent, config] of Object.entries(this.INTENT_PATTERNS)) {
      let score = 0;
      
      // Check keyword matches
      const keywordMatches = config.keywords.filter(keyword => 
        lowerText.includes(keyword)
      ).length;
      score += keywordMatches * 0.3;
      
      // Check pattern matches
      const patternMatches = config.patterns.filter(pattern => 
        pattern.test(text)
      ).length;
      score += patternMatches * 0.5;
      
      // Check entity relevance
      if (entities) {
        const relevantEntities = entities.filter(entity => 
          config.context.some(context => 
            entity.type.toLowerCase().includes(context) || 
            entity.text.toLowerCase().includes(context)
          )
        ).length;
        score += relevantEntities * 0.2;
      }
      
      // Apply base confidence
      score *= config.confidence;
      
      intentScores[intent] = score;
    }
    
    // Find the best matching intent
    const bestIntent = Object.entries(intentScores).reduce((best, [intent, score]) => 
      score > best.score ? { intent, score } : best, 
      { intent: 'informational', score: 0 }
    );
    
    // Extract parameters based on intent
    const parameters = this.extractParameters(text, bestIntent.intent);
    
    return {
      intent: bestIntent.intent,
      confidence: Math.min(bestIntent.score, 1.0),
      entities: entities || [],
      action: this.INTENT_PATTERNS[bestIntent.intent]?.action,
      parameters
    };
  }

  /**
   * Extract parameters based on intent type
   */
  private static extractParameters(text: string, intent: string): Record<string, any> {
    const parameters: Record<string, any> = {};
    
    switch (intent) {
      case 'comparison':
        // Extract items to compare
        const comparisonMatch = text.match(/compare\s+(.+?)\s+(?:and|to|vs|versus)\s+(.+)/i);
        if (comparisonMatch) {
          parameters.item1 = comparisonMatch[1].trim();
          parameters.item2 = comparisonMatch[2].trim();
        }
        break;
        
      case 'instruction':
        // Extract action to be instructed
        const instructionMatch = text.match(/how\s+to\s+(.+)/i);
        if (instructionMatch) {
          parameters.action = instructionMatch[1].trim();
        }
        break;
        
      case 'action_request':
        // Extract what to create/make/build
        const actionMatch = text.match(/(?:create|make|build|generate|write|code|develop|design)\s+(.+)/i);
        if (actionMatch) {
          parameters.target = actionMatch[1].trim();
        }
        break;
        
      case 'question':
        // Extract question type and subject
        const questionMatch = text.match(/^(who|what|when|where|why|how|which|whose|whom)\s+(.+)\??$/i);
        if (questionMatch) {
          parameters.questionType = questionMatch[1].toLowerCase();
          parameters.subject = questionMatch[2].trim();
        }
        break;
        
      case 'recommendation':
        // Extract recommendation category
        const recommendMatch = text.match(/(?:recommend|suggest)\s+(?:a\s+)?(.+)/i);
        if (recommendMatch) {
          parameters.category = recommendMatch[1].trim();
        }
        break;
        
      case 'analysis':
        // Extract analysis target
        const analysisMatch = text.match(/(?:analyze|review|evaluate|assess|examine|study|investigate)\s+(.+)/i);
        if (analysisMatch) {
          parameters.target = analysisMatch[1].trim();
        }
        break;
    }
    
    return parameters;
  }

  /**
   * Get all available intents
   */
  static getAvailableIntents(): string[] {
    return Object.keys(this.INTENT_PATTERNS);
  }

  /**
   * Get intent configuration
   */
  static getIntentConfig(intent: string) {
    return this.INTENT_PATTERNS[intent] || null;
  }

  /**
   * Check if text matches multiple intents (for handling ambiguous requests)
   */
  static detectAmbiguousIntents(text: string): Array<{ intent: string; confidence: number }> {
    const result = this.classify(text);
    const ambiguousIntents: Array<{ intent: string; confidence: number }> = [];
    
    // Find intents with confidence within 0.2 of the best intent
    for (const [intent, config] of Object.entries(this.INTENT_PATTERNS)) {
      if (intent === result.intent) continue;
      
      let score = 0;
      const lowerText = text.toLowerCase();
      
      const keywordMatches = config.keywords.filter(keyword => 
        lowerText.includes(keyword)
      ).length;
      score += keywordMatches * 0.3;
      
      const patternMatches = config.patterns.filter(pattern => 
        pattern.test(text)
      ).length;
      score += patternMatches * 0.5;
      
      score *= config.confidence;
      
      if (Math.abs(score - result.confidence) < 0.2 && score > 0.3) {
        ambiguousIntents.push({ intent, confidence: Math.min(score, 1.0) });
      }
    }
    
    return ambiguousIntents.sort((a, b) => b.confidence - a.confidence);
  }

  /**
   * Suggest clarification questions for ambiguous intents
   */
  static suggestClarification(ambiguousIntents: Array<{ intent: string; confidence: number }>): string[] {
    const suggestions: string[] = [];
    
    for (const { intent } of ambiguousIntents.slice(0, 2)) {
      switch (intent) {
        case 'explanation':
          suggestions.push('Would you like me to explain a concept or definition?');
          break;
        case 'instruction':
          suggestions.push('Are you looking for step-by-step instructions?');
          break;
        case 'comparison':
          suggestions.push('Do you want me to compare two or more things?');
          break;
        case 'action_request':
          suggestions.push('Would you like me to help create or build something?');
          break;
        case 'analysis':
          suggestions.push('Are you asking for an analysis or evaluation?');
          break;
        case 'recommendation':
          suggestions.push('Would you like recommendations or suggestions?');
          break;
      }
    }
    
    return suggestions;
  }
}