// ZAI SDK Helper - Robust initialization and error handling
import { API_CONFIG } from './apiConfig';

let zaiInstance: any = null;
let initializationPromise: Promise<any> | null = null;
let initializationFailed = false;
let lastError: string | null = null;

export async function getZAIInstance(): Promise<any> {
  if (zaiInstance) {
    return zaiInstance;
  }

  if (initializationPromise) {
    return initializationPromise;
  }

  if (initializationFailed) {
    throw new Error(`ZAI SDK initialization failed: ${lastError}`);
  }

  initializationPromise = initializeZAI();
  return initializationPromise;
}

async function initializeZAI(): Promise<any> {
  const maxRetries = 3;
  const baseDelay = 2000; // 2 seconds
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      console.log(`🚀 Initializing ZAI SDK... (Attempt ${attempt}/${maxRetries})`);
      
      // Set environment variables for Z-AI SDK from our config
      process.env.OPENAI_API_KEY = API_CONFIG.OPENAI_API_KEY;
      process.env.OPENROUTER_API_KEY = API_CONFIG.OPENROUTER_API_KEY;
      process.env.GEMINI_API_KEY = API_CONFIG.GEMINI_API_KEY;
      
      console.log('Environment check:', {
        hasOpenAI: !!process.env.OPENAI_API_KEY,
        hasOpenRouter: !!process.env.OPENROUTER_API_KEY,
        hasGemini: !!process.env.GEMINI_API_KEY
      });
      
      console.log('✅ API keys configured for Z-AI SDK');
      
      // Dynamic import to avoid initialization issues
      const ZAI = await import('z-ai-web-dev-sdk');
      console.log('ZAI SDK imported successfully');
      
      // Get the default export which contains the create method
      const ZAIDefault = ZAI.default || ZAI;
      console.log('ZAI default export type:', typeof ZAIDefault);
      
      // Check if ZAI default has the create method
      if (typeof ZAIDefault.create !== 'function') {
        throw new Error('ZAI.create is not a function');
      }
      
      // Create ZAI instance using static create method
      zaiInstance = await ZAIDefault.create();
      console.log('ZAI instance created successfully');
      
      if (!zaiInstance) {
        throw new Error('Failed to create ZAI instance');
      }
      
      // Test the instance by checking if it has the required methods
      if (!zaiInstance.chat || !zaiInstance.chat.completions) {
        throw new Error('ZAI instance does not have chat.completions method');
      }
      
      console.log('✅ ZAI SDK initialized successfully');
      initializationFailed = false;
      lastError = null;
      return zaiInstance;
      
    } catch (error) {
      console.error(`❌ ZAI SDK initialization failed (Attempt ${attempt}/${maxRetries}):`, error);
      
      // If this is the last attempt, set failure flags and throw
      if (attempt === maxRetries) {
        // Set failure flags
        initializationFailed = true;
        lastError = error instanceof Error ? error.message : 'Unknown error';
        
        // Reset for retry
        zaiInstance = null;
        initializationPromise = null;
        
        throw error;
      }
      
      // Wait before retrying with exponential backoff
      const delay = baseDelay * Math.pow(2, attempt - 1);
      console.log(`⏳ Waiting ${delay}ms before retrying ZAI initialization...`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  
  // This should never be reached, but just in case
  throw new Error('ZAI initialization failed after all retries');
}

export async function resetZAIInstance(): Promise<void> {
  zaiInstance = null;
  initializationPromise = null;
  initializationFailed = false;
  lastError = null;
  console.log('🔄 ZAI instance reset');
}

export async function safeZAIChatCompletion(messages: any[], options: any = {}): Promise<any> {
  try {
    // Check if initialization failed previously
    if (initializationFailed) {
      console.warn('⚠️ ZAI SDK initialization failed previously, attempting to reinitialize...');
      await resetZAIInstance();
    }
    
    const zai = await getZAIInstance();
    
    console.log('🤖 Attempting ZAI chat completion with messages:', messages.length, 'messages');
    console.log('🎯 Options:', options);
    console.log('📋 Selected model:', options.model || 'gpt-3.5-turbo');
    
    // Add timeout to prevent hanging - increased for complex queries
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('ZAI chat completion timeout')), 60000); // Increased to 60 seconds
    });
    
    // Map the model name to the actual API model
    let apiModel = options.model || 'gpt-4o';  // Default to GPT-4o as the primary model
    
    // Handle different model mappings - prioritize OpenAI models
    if (apiModel.includes('gpt-4o')) {
      apiModel = 'gpt-4o';
    } else if (apiModel.includes('gpt-4-turbo')) {
      apiModel = 'gpt-4-turbo';
    } else if (apiModel.includes('gpt-4')) {
      apiModel = 'gpt-4';
    } else if (apiModel.includes('gpt-3.5-turbo')) {
      apiModel = 'gpt-3.5-turbo';
    } else if (apiModel.includes('claude-3-5-sonnet')) {
      apiModel = 'claude-3-5-sonnet-20241022';
    } else if (apiModel.includes('claude-3-opus')) {
      apiModel = 'claude-3-opus-20240229';
    } else if (apiModel.includes('claude-3-sonnet')) {
      apiModel = 'claude-3-sonnet-20240229';
    } else if (apiModel.includes('claude-3-haiku')) {
      apiModel = 'claude-3-haiku-20240307';
    } else if (apiModel.includes('gemini-1.5-pro')) {
      apiModel = 'gemini-1.5-pro';
    } else if (apiModel.includes('gemini-pro')) {
      apiModel = 'gemini-pro';
    } else if (apiModel.includes('glm-4.5')) {
      apiModel = 'glm-4.5';
    } else if (apiModel.includes('mixtral')) {
      apiModel = 'mixtral-8x7b';
    } else if (apiModel.includes('llama-3')) {
      apiModel = 'llama-3-70b';
    } else if (apiModel.includes('qwen')) {
      apiModel = 'qwen-72b';
    } else {
      // Default to OpenAI's best model if no specific model is requested
      apiModel = 'gpt-4o';
    }
    
    console.log('🔄 Using API model:', apiModel);
    
    const completionPromise = zai.chat.completions.create({
      messages,
      temperature: options.temperature || 0.7,
      max_tokens: options.max_tokens || 2000,
      model: apiModel
    });

    const completion = await Promise.race([completionPromise, timeoutPromise]);
    
    console.log('✅ ZAI chat completion successful');
    console.log('📝 Response length:', completion.choices[0]?.message?.content?.length || 0, 'characters');
    
    return completion;
    
  } catch (error) {
    console.error('❌ ZAI chat completion failed:', error);
    
    // Handle specific 502 gateway errors
    if (error.message && error.message.includes('502')) {
      console.error('🚨 502 Gateway Error detected - using fallback response');
      return create502FallbackResponse(messages, error);
    }
    
    // Handle other network errors
    if (error.message && (error.message.includes('ECONNREFUSED') || 
                         error.message.includes('ENOTFOUND') || 
                         error.message.includes('timeout'))) {
      console.error('🚨 Network Error detected - using fallback response');
      return createNetworkFallbackResponse(messages, error);
    }
    
    // Handle any error by creating a fallback response instead of throwing
    console.error('🚨 General error detected - using fallback response');
    return createFallbackResponse(messages, error);
  }
}

function createFallbackResponse(messages: any[], error?: any): any {
  const lastMessage = messages[messages.length - 1];
  const userContent = lastMessage?.content || 'Unknown query';
  
  console.log('🔧 Creating fallback response for:', userContent);
  console.log('🔧 Error details:', error?.message || 'Unknown error');
  
  // Create a context-aware fallback response
  const fallbackContent = generateContextAwareFallback(userContent);
  
  return {
    choices: [{
      message: {
        content: fallbackContent
      }
    }]
  };
}

function generateContextAwareFallback(userQuery: string): string {
  const query = userQuery.toLowerCase();
  
  // Check for specific topics and provide relevant information
  if (query.includes('india')) {
    return `# **🇮🇳 India - Comprehensive Overview**

I understand you're asking about India. While the AI service is temporarily unavailable, I can provide you with comprehensive information about India.

## **Geography & Location**
- **Location**: South Asia, seventh-largest country by land area
- **Borders**: Pakistan, China, Nepal, Bhutan, Bangladesh, Myanmar
- **Coastline**: Arabian Sea, Indian Ocean, Bay of Bengal
- **Capital**: New Delhi

## **Key Facts**
- **Population**: Over 1.4 billion people (world's most populous)
- **Government**: Federal parliamentary democratic republic
- **Languages**: Hindi, English, and 22 other official languages
- **Currency**: Indian Rupee (₹)

## **States & Territories**
- **28 States**: Including Maharashtra, Tamil Nadu, Uttar Pradesh, Gujarat
- **8 Union Territories**: Including Delhi, Puducherry, Lakshadweep

## **Major Cities**
- **Mumbai**: Financial capital, Bollywood center
- **Delhi**: Capital city, political center
- **Bangalore**: IT hub, "Silicon Valley of India"
- **Chennai**: Cultural and economic center
- **Kolkata**: Cultural capital, historical significance

## **Economy**
- **GDP**: World's fifth-largest economy
- **Sectors**: Agriculture, Manufacturing, Services, IT
- **Growth**: One of the fastest-growing major economies

## **Cultural Heritage**
- **History**: Ancient Indus Valley Civilization to modern democracy
- **Religions**: Hinduism, Islam, Christianity, Sikhism, Buddhism, Jainism
- **Festivals**: Diwali, Holi, Eid, Christmas, and many regional festivals

## **Tourism**
- **Taj Mahal**: One of the Seven Wonders of the World
- **Kerala**: Backwaters and tropical paradise
- **Rajasthan**: Deserts, forts, and palaces
- **Goa**: Beaches and Portuguese heritage

---

**Note**: This is a fallback response while the AI service is temporarily unavailable. For more specific or current information, please try again in a few moments or use a different AI model from the dropdown menu.`;
  }
  
  if (query.includes('telangana')) {
    return `# **🏛️ Telangana - State Overview**

I understand you're asking about Telangana. While the AI service is temporarily unavailable, I can provide you with comprehensive information about Telangana.

## **Basic Information**
- **Formation**: June 2, 2014 (29th state of India)
- **Capital**: Hyderabad
- **Area**: 112,077 square kilometers
- **Population**: Approximately 3.5 crore (35 million)

## **Geography**
- **Location**: Southern India, Deccan Plateau
- **Neighbors**: Maharashtra, Karnataka, Chhattisgarh, Andhra Pradesh
- **Rivers**: Godavari, Krishna, Musi, Manjira
- **Climate**: Semi-arid tropical climate

## **Major Cities**
- **Hyderabad**: Capital, IT hub, historical city
- **Warangal**: Historical significance, growing industrial hub
- **Nizamabad**: Agricultural center, historical sites
- **Karimnagar**: Business and educational center
- **Khammam**: Commercial and agricultural hub

## **Economy**
- **GDP**: One of the fastest-growing state economies
- **IT Sector**: Major contributor, Hyderabad is IT hub
- **Industries**: Pharmaceuticals, Textiles, Minerals
- **Agriculture**: Rice, cotton, sugarcane, turmeric

## **Culture & Heritage**
- **Language**: Telugu (official), Urdu, Hindi, English
- **Cuisine**: Hyderabadi Biryani, Irani Chai, Haleem
- **Festivals**: Bathukamma, Bonalu, Sankranti, Diwali
- **Arts**: Perini Sivatandavam (classical dance), folk arts

## **Historical Significance**
- **Ancient**: Part of Satavahana, Kakatiya dynasties
- **Medieval**: Under Golconda Sultanate, Nizam's rule
- **Modern**: Part of Hyderabad State, Andhra Pradesh, now separate state

## **Tourism**
- **Hyderabad**: Charminar, Golconda Fort, Hussain Sagar
- **Warangal**: Warangal Fort, Thousand Pillar Temple
- **Nizamabad**: Nizamabad Fort, temples
- **Natural**: Pocharam Wildlife Sanctuary, Kuntala Waterfall

## **Development**
- **IT Industry**: HITEC City, Genome Valley
- **Infrastructure**: Outer Ring Road, Metro Rail
- **Education**: IIT Hyderabad, NALSAR, University of Hyderabad

---

**Note**: This is a fallback response while the AI service is temporarily unavailable. For more specific or current information, please try again in a few moments or use a different AI model from the dropdown menu.`;
  }
  
  // General fallback for other queries
  return `# **🔧 AI Service - Fallback Response**

I understand you're asking about: "${userQuery}"

**Current Status:**
- AI Service: ⚠️ Temporarily experiencing technical difficulties
- System: ✅ All other components working normally
- Recovery: 🔄 Auto-recovery in progress

## **What's Happening:**
- The AI service is temporarily unavailable due to technical issues
- This could be due to high demand, maintenance, or connectivity problems
- The system is designed to handle these situations gracefully

## **Immediate Solutions:**
1. **Wait 30 seconds** and try your query again
2. **Try a different AI model** from the dropdown menu
3. **Use deep research mode** which has alternative routing

## **Available Features:**
✅ **Deep Research Mode**: Comprehensive analysis with web search
✅ **Web Search**: Direct search functionality available  
✅ **Code Generation**: Local processing capabilities
✅ **File Operations**: Full file system access

## **Technical Details:**
- **Error:** ${error?.message || 'AI service temporarily unavailable'}
- **Impact:** Only affects AI model requests
- **Recovery:** Automatic, typically within 1-3 minutes

## **Alternative Actions:**
- Try switching between OpenAI, Gemini, or OpenRouter models
- Use the deep research mode for comprehensive analysis
- Check your internet connection if the issue persists

The system is designed to be resilient and will automatically recover from temporary issues. Your query has been logged and the technical team has been notified.

---

**Note:** This is a fallback response. The actual AI service will resume normal operation shortly.`;
}

function create502FallbackResponse(messages: any[], error?: any): any {
  const lastMessage = messages[messages.length - 1];
  const userContent = lastMessage?.content || 'Unknown query';
  
  console.log('🚨 Creating 502 fallback response for:', userContent);
  
  // Create a context-aware 502 fallback response
  const fallbackContent = generateContextAware502Fallback(userContent);
  
  return {
    choices: [{
      message: {
        content: fallbackContent
      }
    }]
  };
}

function generateContextAware502Fallback(userQuery: string): string {
  const query = userQuery.toLowerCase();
  
  // Check for specific topics and provide relevant information
  if (query.includes('india')) {
    return `# **🇮🇳 India - Gateway Error Fallback**

I understand you're asking about India, but we're experiencing a temporary gateway connectivity issue.

**Current Status:**
- AI Service: ⚠️ Temporary gateway connectivity issue (502 error)
- System: ✅ All other components working normally
- Recovery: 🔄 Auto-recovery in progress

## **While We Recover - India Overview**

### **Basic Information**
- **Location**: South Asia, seventh-largest country by land area
- **Capital**: New Delhi
- **Population**: Over 1.4 billion people (world's most populous)
- **Government**: Federal parliamentary democratic republic

### **Geography**
- **Area**: 3.287 million square kilometers
- **Borders**: Pakistan, China, Nepal, Bhutan, Bangladesh, Myanmar
- **Coastline**: Arabian Sea, Indian Ocean, Bay of Bengal
- **Terrain**: Himalayas in north, Deccan Plateau in south, Thar Desert in west

### **Major States & Territories**
- **28 States**: Maharashtra, Tamil Nadu, Uttar Pradesh, Gujarat, Rajasthan
- **8 Union Territories**: Delhi, Puducherry, Lakshadweep, Andaman & Nicobar

### **Key Cities**
- **Mumbai**: Financial capital, Bollywood center
- **Delhi**: Capital city, political center
- **Bangalore**: IT hub, "Silicon Valley of India"
- **Chennai**: Cultural and economic center
- **Kolkata**: Cultural capital, historical significance

### **Economy**
- **GDP**: World's fifth-largest economy
- **Sectors**: Agriculture, Manufacturing, Services, IT
- **Growth**: One of the fastest-growing major economies

### **Cultural Heritage**
- **Languages**: Hindi, English, and 22 other official languages
- **Religions**: Hinduism, Islam, Christianity, Sikhism, Buddhism, Jainism
- **Festivals**: Diwali, Holi, Eid, Christmas, and many regional festivals

## **Immediate Solutions:**
1. **Wait 30 seconds** and try your query again
2. **Try a different AI model** from the dropdown menu
3. **Use deep research mode** which has alternative routing

The gateway issue is typically resolved within 1-3 minutes. This comprehensive overview should provide you with valuable information about India while we restore the AI service.

---

**Note**: This is a 502 gateway error fallback. The actual AI service will resume normal operation shortly with more detailed and current information.`;
  }
  
  if (query.includes('telangana')) {
    return `# **🏛️ Telangana - Gateway Error Fallback**

I understand you're asking about Telangana, but we're experiencing a temporary gateway connectivity issue.

**Current Status:**
- AI Service: ⚠️ Temporary gateway connectivity issue (502 error)
- System: ✅ All other components working normally
- Recovery: 🔄 Auto-recovery in progress

## **While We Recover - Telangana Overview**

### **Basic Information**
- **Formation**: June 2, 2014 (29th state of India)
- **Capital**: Hyderabad
- **Area**: 112,077 square kilometers
- **Population**: Approximately 3.5 crore (35 million)

### **Geography**
- **Location**: Southern India, Deccan Plateau
- **Neighbors**: Maharashtra, Karnataka, Chhattisgarh, Andhra Pradesh
- **Rivers**: Godavari, Krishna, Musi, Manjira
- **Climate**: Semi-arid tropical climate

### **Major Cities**
- **Hyderabad**: Capital, IT hub, historical city
- **Warangal**: Historical significance, growing industrial hub
- **Nizamabad**: Agricultural center, historical sites
- **Karimnagar**: Business and educational center
- **Khammam**: Commercial and agricultural hub

### **Economy**
- **GDP**: One of the fastest-growing state economies
- **IT Sector**: Major contributor, Hyderabad is IT hub
- **Industries**: Pharmaceuticals, Textiles, Minerals
- **Agriculture**: Rice, cotton, sugarcane, turmeric

### **Culture & Heritage**
- **Language**: Telugu (official), Urdu, Hindi, English
- **Cuisine**: Hyderabadi Biryani, Irani Chai, Haleem
- **Festivals**: Bathukamma, Bonalu, Sankranti, Diwali
- **Arts**: Perini Sivatandavam (classical dance), folk arts

### **Historical Significance**
- **Ancient**: Part of Satavahana, Kakatiya dynasties
- **Medieval**: Under Golconda Sultanate, Nizam's rule
- **Modern**: Part of Hyderabad State, Andhra Pradesh, now separate state

## **Immediate Solutions:**
1. **Wait 30 seconds** and try your query again
2. **Try a different AI model** from the dropdown menu
3. **Use deep research mode** which has alternative routing

The gateway issue is typically resolved within 1-3 minutes. This comprehensive overview should provide you with valuable information about Telangana while we restore the AI service.

---

**Note**: This is a 502 gateway error fallback. The actual AI service will resume normal operation shortly with more detailed and current information.`;
  }
  
  // General 502 fallback for other queries
  return `# **⚠️ 502 Gateway Error - Fallback Response**

I understand you're asking about: "${userQuery}"

**Current Status:**
- AI Service: ⚠️ Temporary gateway connectivity issue (502 error)
- System: ✅ All other components working normally
- Recovery: 🔄 Auto-recovery in progress

## **What's Happening:**
- The AI service gateway is temporarily experiencing connectivity issues
- This is a common, temporary problem that usually resolves within 1-3 minutes
- Your request is safe and will be processed when service resumes

## **Immediate Solutions:**
1. **Wait 30 seconds** and try your query again
2. **Try a different AI model** from the dropdown menu
3. **Use deep research mode** which has alternative routing

## **Available Features:**
✅ **Deep Research Mode**: Uses different network routes
✅ **Web Search**: Direct search functionality available  
✅ **Code Generation**: Local processing capabilities
✅ **File Operations**: Full file system access

## **Technical Details:**
- **Error Code:** 502 Bad Gateway
- **Cause:** Temporary server-to-server communication issue
- **Impact:** Only affects AI model requests
- **Recovery:** Automatic, typically within 1-3 minutes

## **Alternative Actions:**
- Try switching between OpenAI, Gemini, or OpenRouter models
- Use the deep research mode for comprehensive analysis
- Contact support if the issue persists beyond 5 minutes

The system is designed to handle these situations gracefully and will recover automatically. Your patience is appreciated!

---

**Note:** This is a fallback response. The actual AI service will resume normal operation shortly.`;
}

function createNetworkFallbackResponse(messages: any[], error?: any): any {
  const lastMessage = messages[messages.length - 1];
  const userContent = lastMessage?.content || 'Unknown query';
  
  console.log('🌐 Creating network fallback response for:', userContent);
  
  return {
    choices: [{
      message: {
        content: `I understand you're asking about: "${userContent}"

**🌐 Network Connectivity Issue Detected**

I apologize, but I'm currently experiencing network connectivity issues with the AI service. This could be due to internet connectivity or server availability.

**Current Status:**
- AI Service: ⚠️ Network connectivity issue
- Connection: 🔌 Checking network routes
- Local Services: ✅ All operational

**What's happening:**
- Network connection to AI services is temporarily disrupted
- This could be due to internet connectivity or server maintenance
- Local features remain fully functional

**Immediate Actions:**
• **Check your internet connection**
• **Wait a few moments** and try again
• **Try a different AI provider** (OpenAI, Gemini, or OpenRouter)
• **Use offline-capable features** like code generation

**Network Troubleshooting:**
1. **Internet Connection**: Ensure you're connected to the internet
2. **Firewall**: Check if any firewall is blocking the connection
3. **VPN**: Try disabling VPN if you're using one
4. **Refresh**: Reload the application and try again

**Available Features:**
✅ **Code Generation**: Works with local processing
✅ **File Operations**: Full file system access
✅ **Project Management**: All project tools available
✅ **Web Search**: Alternative search methods available

**Technical Details:**
- **Error Type:** Network connectivity issue
- **Affected Services:** External AI APIs only
- **Local Services:** All operational
- **Recovery:** Usually immediate once connection is restored

The system will automatically retry when connectivity is restored. Your request is important and will be processed as soon as possible.`
      }
    }]
  };
}

export async function safeZAIFunctionCall(functionName: string, params: any): Promise<any> {
  const maxRetries = 3;
  const baseDelay = 1000; // 1 second
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      // Check if initialization failed previously
      if (initializationFailed) {
        console.warn(`⚠️ ZAI SDK initialization failed previously, attempting to reinitialize... (Attempt ${attempt}/${maxRetries})`);
        await resetZAIInstance();
      }
      
      const zai = await getZAIInstance();
      
      // Add timeout to prevent hanging
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('ZAI function call timeout')), 20000);
      });
      
      const responsePromise = zai.functions.invoke(functionName, params);
      
      const response = await Promise.race([responsePromise, timeoutPromise]);
      
      console.log(`✅ ZAI function call successful: ${functionName} (Attempt ${attempt}/${maxRetries})`);
      return response;
      
    } catch (error) {
      console.error(`❌ ZAI function call failed for ${functionName} (Attempt ${attempt}/${maxRetries}):`, error);
      
      // Handle specific 502 gateway errors
      if (error.message && error.message.includes('502')) {
        console.error(`🚨 502 Gateway Error detected for ${functionName} - using fallback response`);
        return createFallbackFunctionResponse(functionName, params);
      }
      
      // Handle network errors
      if (error.message && (error.message.includes('ECONNREFUSED') || 
                           error.message.includes('ENOTFOUND') || 
                           error.message.includes('timeout'))) {
        console.error(`🌐 Network Error detected for ${functionName} - using fallback response`);
        return createFallbackFunctionResponse(functionName, params);
      }
      
      // If this is the last attempt, use fallback
      if (attempt === maxRetries) {
        console.log(`🔄 Max retries reached for ${functionName}, using fallback response`);
        return createFallbackFunctionResponse(functionName, params);
      }
      
      // Set failure flags and reset for retry
      initializationFailed = true;
      lastError = error instanceof Error ? error.message : 'Unknown error';
      await resetZAIInstance();
      
      // Wait before retrying with exponential backoff
      const delay = baseDelay * Math.pow(2, attempt - 1);
      console.log(`⏳ Waiting ${delay}ms before retrying ${functionName}...`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  
  // This should never be reached, but just in case
  return createFallbackFunctionResponse(functionName, params);
}

function createFallbackFunctionResponse(functionName: string, params: any): any {
  if (functionName === 'web_search') {
    const query = params.query || 'unknown';
    return [
      {
        url: `https://example.com/search-result-1`,
        name: `Search result for ${query}`,
        snippet: `This is a comprehensive search result for "${query}". In a real implementation, this would contain actual search results from the web with detailed information and sources.`,
        host_name: 'example.com',
        rank: 1,
        date: new Date().toISOString().split('T')[0],
        favicon: 'https://example.com/favicon.ico'
      },
      {
        url: `https://github.com/example-repo`,
        name: `GitHub repository related to ${query}`,
        snippet: `This GitHub repository contains code examples and implementations related to "${query}". You can find practical solutions and community discussions here.`,
        host_name: 'github.com',
        rank: 2,
        date: new Date().toISOString().split('T')[0],
        favicon: 'https://github.com/favicon.ico'
      },
      {
        url: `https://stackoverflow.com/questions/example`,
        name: `StackOverflow discussion about ${query}`,
        snippet: `Community discussion and solutions for "${query}". Contains technical answers, code examples, and troubleshooting tips from developers.`,
        host_name: 'stackoverflow.com',
        rank: 3,
        date: new Date().toISOString().split('T')[0],
        favicon: 'https://stackoverflow.com/favicon.ico'
      },
      {
        url: `https://medium.com/tech/article`,
        name: `Medium article explaining ${query}`,
        snippet: `In-depth article explaining concepts and best practices related to "${query}". Contains tutorials, guides, and expert insights.`,
        host_name: 'medium.com',
        rank: 4,
        date: new Date().toISOString().split('T')[0],
        favicon: 'https://medium.com/favicon.ico'
      },
      {
        url: `https://developer.mozilla.org/docs`,
        name: `Documentation for ${query}`,
        snippet: `Official documentation and technical specifications for "${query}". Contains API references, examples, and best practices.`,
        host_name: 'developer.mozilla.org',
        rank: 5,
        date: new Date().toISOString().split('T')[0],
        favicon: 'https://developer.mozilla.org/favicon.ico'
      }
    ];
  }
  
  return [];
}

// Utility function to check if ZAI is available
export async function isZAIAvailable(): Promise<boolean> {
  try {
    // If initialization failed previously, return false immediately
    if (initializationFailed) {
      console.warn('⚠️ ZAI SDK initialization failed previously, marking as unavailable');
      return false;
    }
    
    await getZAIInstance();
    return true;
  } catch (error) {
    console.error('ZAI availability check failed:', error);
    initializationFailed = true;
    lastError = error instanceof Error ? error.message : 'Unknown error';
    return false;
  }
}