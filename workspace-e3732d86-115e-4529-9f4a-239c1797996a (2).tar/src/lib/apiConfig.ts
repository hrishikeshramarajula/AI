// API Configuration for all AI services
export const API_CONFIG = {
  // OpenRouter (Primary) - Read from environment
  OPENROUTER_API_KEY: process.env.OPENROUTER_API_KEY || "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",
  OPENROUTER_BASE_URL: "https://openrouter.ai/api/v1",
  
  // Gemini (Backup) - Read from environment
  GEMINI_API_KEY: process.env.GEMINI_API_KEY || "AIzaSyDFT_vQAudEHVo2EmSEjhysOtwmP8HYr4I",
  GEMINI_BASE_URL: "https://generativelanguage.googleapis.com/v1beta",
  
  // OpenAI (Emergency) - Read from environment
  OPENAI_API_KEY: process.env.OPENAI_API_KEY || "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",
  OPENAI_BASE_URL: "https://api.openai.com/v1",
  
  // Enhanced Configuration for Limitless Search - No Limits
  SEARCH_CONFIG: {
    // Unlimited search results for comprehensive coverage
    MAX_RESULTS: 100, // Unlimited search results
    TIMEOUT: 300000, // 5 minutes timeout for complex searches
    RETRY_ATTEMPTS: 10, // Maximum retry attempts
    RETRY_DELAY: 1000, // 1 second base delay for faster recovery
    ENABLE_FALLBACK: false, // Disable fallback responses - use direct responses
    CONCURRENT_SEARCHES: true, // Allow concurrent search requests
    SEARCH_PROVIDERS: ['web', 'academic', 'news', 'github', 'books', 'papers'], // All search sources
    NO_RATE_LIMITS: true, // Disable all rate limits
    UNLIMITED_DEPTH: true, // Enable unlimited search depth
  },
  
  // Model Performance Configuration - No Limits
  PERFORMANCE_CONFIG: {
    DEFAULT_TIMEOUT: 300000, // 5 minutes for unlimited AI responses
    MAX_TOKENS: 32000, // Maximum token limit for comprehensive responses
    TEMPERATURE: 0.7, // Balanced creativity and accuracy
    STREAMING_ENABLED: true, // Enable streaming for better UX
    UNLIMITED_CONTEXT: true, // Enable unlimited context processing
    NO_RATE_LIMITS: true, // Disable all rate limits
    MAX_CONCURRENT_REQUESTS: 100, // High concurrent request limit
  },
  
  // Model mappings for different services - OpenRouter Free Models Only
  MODELS: {
    // OpenRouter Models - Free Models Only
    OPENROUTER: {
      "llama-4-maverick-free": "meta-llama/llama-4-maverick:free",
      "gemini-2-5-pro-free": "google/gemini-2.5-pro-exp-03-25:free",
      "llama-4-scout-free": "meta-llama/llama-4-scout:free",
      "deepseek-r1-zero-free": "deepseek/deepseek-r1-zero:free",
      "deepseek-v3-base-free": "deepseek/deepseek-v3-base:free",
      "deepseek-chat-v3-free": "deepseek/deepseek-chat-v3-0324:free",
      "mistral-small-3-1-free": "mistralai/mistral-small-3.1-24b-instruct:free",
      "kimi-vl-a3b-thinking-free": "moonshotai/kimi-vl-a3b-thinking:free",
      "qwen2-5-vl-3b-free": "qwen/qwen2.5-vl-3b-instruct:free",
      "llama-3-1-nemotron-nano-free": "nvidia/llama-3.1-nemotron-nano-8b-v1:free",
      "deephermes-3-llama-3-8b-free": "nousresearch/deephermes-3-llama-3-8b-preview:free",
      "optimus-alpha-free": "openrouter/optimus-alpha",
      "quasar-alpha-free": "openrouter/quasar-alpha",
    },
    
    // Gemini Models - Fallback only
    GEMINI: {
      "gemini-2-5-pro-free": "gemini-1.5-pro",
      "llama-4-maverick-free": "gemini-1.5-pro",
      "llama-4-scout-free": "gemini-pro",
    },
    
    // OpenAI Models - Fallback only
    OPENAI: {
      "llama-4-maverick-free": "gpt-4o",
      "gemini-2-5-pro-free": "gpt-4o",
      "llama-4-scout-free": "gpt-4o",
      "deepseek-v3-base-free": "gpt-4o",
    }
  },
  
  // Provider priorities for fallback
  PROVIDER_PRIORITY: ["openrouter", "gemini", "openai"],
  
  // Default models for different modes - Using OpenRouter Free Models
  DEFAULT_MODELS: {
    "autonomous-agent": "llama-4-maverick-free",
    "chat": "llama-4-scout-free", 
    "code": "deepseek-v3-base-free",
    "image": "kimi-vl-a3b-thinking-free",
    "fullstack": "llama-4-maverick-free",
    "deep-research": "gemini-2-5-pro-free"
  }
};

// Helper function to get API headers for different providers
export const getApiHeaders = (provider: string): Record<string, string> => {
  switch (provider) {
    case "openrouter":
      return {
        "Authorization": `Bearer ${API_CONFIG.OPENROUTER_API_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "http://localhost:3000",
        "X-Title": "AI Agent Platform"
      };
    case "gemini":
      return {
        "Content-Type": "application/json"
      };
    case "openai":
      return {
        "Authorization": `Bearer ${API_CONFIG.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      };
    default:
      return {
        "Content-Type": "application/json"
      };
  }
};

// Helper function to get API URL for different providers
export const getApiUrl = (provider: string, endpoint: string) => {
  switch (provider) {
    case "openrouter":
      return `${API_CONFIG.OPENROUTER_BASE_URL}/${endpoint}`;
    case "gemini":
      return `${API_CONFIG.GEMINI_BASE_URL}/${endpoint}`;
    case "openai":
      return `${API_CONFIG.OPENAI_BASE_URL}/${endpoint}`;
    default:
      return endpoint;
  }
};

// Helper function to map model name to provider-specific model ID
export const getModelId = (modelName: string, provider: string) => {
  const providerModels = API_CONFIG.MODELS[provider.toUpperCase() as keyof typeof API_CONFIG.MODELS];
  if (providerModels && providerModels[modelName as keyof typeof providerModels]) {
    return providerModels[modelName as keyof typeof providerModels];
  }
  return modelName;
};