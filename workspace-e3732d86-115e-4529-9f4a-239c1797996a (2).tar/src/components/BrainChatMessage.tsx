// 🧠 Brain-Enhanced Chat Message Component
// Displays AI responses with integrated brain processing analysis

'use client';

import React, { useState } from 'react';
import { 
  Brain, 
  ChevronDown, 
  ChevronRight, 
  Clock, 
  Target, 
  BookOpen, 
  Zap,
  Eye,
  EyeOff,
  Download,
  Share2,
  CheckCircle,
  AlertCircle,
  TrendingUp
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';

interface BrainProcessingData {
  actualAnswer: string;
  textAnalysis: {
    primaryIntent: string;
    confidence: number;
    domain: string;
    complexity: number;
    emotionalContext: string;
    entitiesFound: number;
  };
  goalDecomposition: {
    subGoalsGenerated: number;
    executionApproach: string;
    estimatedDuration: number;
    riskLevel: string;
  };
  knowledgeRetrieval: {
    knowledgeItems: number;
    strategies: number;
    recommendations: number;
  };
  processingMetadata: {
    totalProcessingTime: number;
    confidence: number;
    brainCapabilities: string[];
  };
}

interface BrainChatMessageProps {
  content: string;
  brainProcessing?: BrainProcessingData;
  model?: string;
  timestamp?: string;
  isUser?: boolean;
}

export default function BrainChatMessage({ 
  content, 
  brainProcessing, 
  model = '🤖 AI Assistant',
  timestamp,
  isUser = false 
}: BrainChatMessageProps) {
  const [showDetails, setShowDetails] = useState(false);
  const [showFullAnalysis, setShowFullAnalysis] = useState(false);

  if (isUser) {
    return (
      <div className="flex justify-end mb-4">
        <div className="max-w-[80%]">
          <div className="bg-blue-600 text-white p-4 rounded-lg rounded-br-none">
            <p className="text-sm">{content}</p>
          </div>
          {timestamp && (
            <p className="text-xs text-gray-500 mt-1 text-right">{timestamp}</p>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start mb-6">
      <div className="max-w-[90%]">
        {/* Model Header */}
        <div className="flex items-center gap-2 mb-2">
          <span className="font-semibold text-gray-700">{model}</span>
          {brainProcessing && (
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              <Brain className="w-3 h-3 mr-1" />
              Brain Enhanced
            </Badge>
          )}
          {timestamp && (
            <span className="text-xs text-gray-500">{timestamp}</span>
          )}
        </div>

        {/* Main Response Card */}
        <Card className="border-l-4 border-l-green-500">
          <CardContent className="p-4">
            {/* Brain Processing Indicator - Simplified */}
            {brainProcessing && (
              <div className="mb-4 p-3 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg border border-green-200">
                <div className="flex items-center gap-2 mb-2">
                  <Brain className="w-5 h-5 text-green-600" />
                  <span className="font-semibold text-green-800">🧠 Brain Enhanced</span>
                </div>
              </div>
            )}

            {/* Actual Answer */}
            <div className="mb-4">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="font-semibold text-gray-700">💡 AI Response</span>
              </div>
              <div className="prose prose-sm max-w-none">
                <div className="whitespace-pre-wrap text-gray-800 leading-relaxed">
                  {brainProcessing?.actualAnswer || content}
                </div>
              </div>
            </div>

            {/* Brain Processing Details (Collapsible) */}
            {brainProcessing && (
              <>
                <div className="flex items-center justify-between mb-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowDetails(!showDetails)}
                    className="flex items-center gap-2"
                  >
                    {showDetails ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    {showDetails ? 'Hide Details' : 'Show Brain Analysis'}
                  </Button>
                  
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" className="text-xs">
                      <Download className="w-3 h-3 mr-1" />
                      Save
                    </Button>
                    <Button variant="ghost" size="sm" className="text-xs">
                      <Share2 className="w-3 h-3 mr-1" />
                      Share
                    </Button>
                  </div>
                </div>

                {showDetails && (
                  <div className="border-t pt-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      {/* Text Analysis */}
                      <Card className="bg-blue-50 border-blue-200">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm flex items-center gap-2">
                            <Target className="w-4 h-4 text-blue-600" />
                            🔍 Text Analysis
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-3">
                          <div className="space-y-2 text-xs">
                            <div className="flex justify-between">
                              <span>Primary Intent:</span>
                              <span className="font-medium">{brainProcessing.textAnalysis?.primaryIntent || 'N/A'}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Confidence:</span>
                              <span className="font-medium">{(brainProcessing.textAnalysis?.confidence || 0 * 100).toFixed(0)}%</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Domain:</span>
                              <span className="font-medium">{brainProcessing.textAnalysis?.domain || 'N/A'}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Complexity:</span>
                              <span className="font-medium">{brainProcessing.textAnalysis?.complexity?.toFixed(2) || '0.00'}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Emotional Context:</span>
                              <span className="font-medium">{brainProcessing.textAnalysis?.emotionalContext || 'N/A'}</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      {/* Goal Decomposition */}
                      <Card className="bg-purple-50 border-purple-200">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm flex items-center gap-2">
                            <Zap className="w-4 h-4 text-purple-600" />
                            🎯 Goal Decomposition
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-3">
                          <div className="space-y-2 text-xs">
                            <div className="flex justify-between">
                              <span>Sub-Goals:</span>
                              <span className="font-medium">{brainProcessing.goalDecomposition?.subGoalsGenerated || 0}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Approach:</span>
                              <span className="font-medium">{brainProcessing.goalDecomposition?.executionApproach || 'N/A'}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Duration:</span>
                              <span className="font-medium">{brainProcessing.goalDecomposition?.estimatedDuration || 0}s</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Risk Level:</span>
                              <span className="font-medium">{brainProcessing.goalDecomposition?.riskLevel || 'N/A'}</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      {/* Knowledge Retrieval */}
                      <Card className="bg-orange-50 border-orange-200">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm flex items-center gap-2">
                            <BookOpen className="w-4 h-4 text-orange-600" />
                            🧚 Knowledge Retrieval
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-3">
                          <div className="space-y-2 text-xs">
                            <div className="flex justify-between">
                              <span>Knowledge Items:</span>
                              <span className="font-medium">{brainProcessing.knowledgeRetrieval?.knowledgeItems || 0}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Strategies:</span>
                              <span className="font-medium">{brainProcessing.knowledgeRetrieval?.strategies || 0}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Recommendations:</span>
                              <span className="font-medium">{brainProcessing.knowledgeRetrieval?.recommendations || 0}</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      {/* Processing Performance */}
                      <Card className="bg-green-50 border-green-200">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm flex items-center gap-2">
                            <TrendingUp className="w-4 h-4 text-green-600" />
                            📊 Performance
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-3">
                          <div className="space-y-2 text-xs">
                            <div className="flex justify-between">
                              <span>Total Time:</span>
                              <span className="font-medium">{brainProcessing.processingMetadata?.totalProcessingTime || 0}ms</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Confidence:</span>
                              <span className="font-medium">{(brainProcessing.processingMetadata?.confidence || 0 * 100).toFixed(0)}%</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Capabilities:</span>
                              <span className="font-medium">{brainProcessing.processingMetadata?.brainCapabilities?.length || 0}</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    {/* Brain Capabilities */}
                    <div className="mb-4">
                      <div className="text-sm font-semibold mb-2">🧠 Brain Capabilities Utilized:</div>
                      <div className="flex flex-wrap gap-1">
                        {brainProcessing.processingMetadata?.brainCapabilities && brainProcessing.processingMetadata.brainCapabilities.map((capability, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {capability.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}