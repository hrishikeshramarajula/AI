import { NextRequest, NextResponse } from 'next/server';
import { safeZAIChatCompletion } from '@/lib/zaiHelper';

export async function POST(request: NextRequest) {
  try {
    console.log('🧪 Testing AI service connectivity...');
    
    // Simple test message
    const testMessages = [
      {
        role: 'system' as const,
        content: 'You are a helpful assistant. Respond briefly to confirm you are working.'
      },
      {
        role: 'user' as const,
        content: 'Hello, are you working?'
      }
    ];
    
    console.log('📤 Sending test message to AI service...');
    
    // Test with a simple model
    const response = await safeZAIChatCompletion(testMessages, {
      model: 'llama-4-maverick-free',
      temperature: 0.7,
      max_tokens: 100
    });
    
    console.log('✅ AI service test successful');
    console.log('📝 Response:', response.choices[0]?.message?.content);
    
    return NextResponse.json({
      success: true,
      message: 'AI service is working correctly',
      response: response.choices[0]?.message?.content,
      model: response.model,
      usage: response.usage
    });
    
  } catch (error) {
    console.error('❌ AI service test failed:', error);
    
    return NextResponse.json({
      success: false,
      message: 'AI service test failed',
      error: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined
    }, { status: 500 });
  }
}