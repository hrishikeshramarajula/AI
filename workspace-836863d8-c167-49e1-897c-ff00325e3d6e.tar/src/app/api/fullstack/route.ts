import { NextRequest, NextResponse } from 'next/server';
import { FullstackGenerator } from '@/lib/fullstackGenerator';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { prompt, options = {} } = body;

    if (!prompt) {
      return NextResponse.json(
        { error: 'Prompt is required' },
        { status: 400 }
      );
    }

    console.log('🚀 Generating fullstack project for:', prompt);

    // Generate the complete fullstack project
    const fullstackProject = await FullstackGenerator.generateFullstackProject(prompt);

    // Return the project structure and files with enhanced response format
    return NextResponse.json({
      success: true,
      project: fullstackProject,
      summary: {
        name: fullstackProject.structure.name,
        description: fullstackProject.structure.description,
        files: fullstackProject.files.length,
        features: fullstackProject.structure.features,
        framework: fullstackProject.structure.framework,
        database: fullstackProject.structure.database
      },
      // Enhanced response format like my approach
      message: `🎉 **Enhanced Fullstack Application Generated!**
I've successfully created a complete fullstack application from your request: "${prompt}"
**🚀 Project Generated:**
• **Name:** ${fullstackProject.structure.name}
• **Framework:** ${fullstackProject.structure.framework.toUpperCase()}
• **Database:** ${fullstackProject.structure.database.toUpperCase()}
• **Files:** ${fullstackProject.files.length} files generated
• **Setup Time:** 3-5 minutes
**✨ AI-Powered Features:**
${fullstackProject.structure.features.map((feature, index) => `${index + 1}. ${feature.charAt(0).toUpperCase() + feature.slice(1).replace('-', ' ')}`).join('\n')}
**📦 What's Included:**
• **Frontend Components:** Modern React/Next.js UI with responsive design
• **Backend API:** Complete RESTful API endpoints with error handling
• **Database Schema:** Prisma models with proper relationships
• **Configuration:** All necessary setup and config files
• **Live Preview:** Real-time application preview and testing
**🔧 Setup Instructions:**
${fullstackProject.setupInstructions.map((instruction, index) => `${index + 1}. \`${instruction}\``).join('\n')}
**🌐 Preview:** Your application is ready to run! Open http://localhost:3000 to see it in action.
🎯 **Enhanced Fullstack Preview**: A comprehensive preview panel has been opened where you can explore all generated files, view the complete source code, and get step-by-step setup instructions!`,
      enhanced: {
        previewUrl: `http://localhost:3000`,
        setupCommands: fullstackProject.setupInstructions,
        estimatedTime: "3-5 minutes",
        features: fullstackProject.structure.features,
        filesCount: fullstackProject.files.length,
        readyToRun: true
      }
    });

  } catch (error) {
    console.error('Fullstack generation error:', error);
    
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to generate fullstack project',
        message: 'I encountered an error while generating your fullstack project. Please try again with a simpler description.',
        suggestions: [
          'Try describing your project in simpler terms',
          'Focus on the main features you need',
          'Specify the type of application (e.g., todo app, blog, e-commerce)',
          'Mention any specific technologies if preferred'
        ]
      },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    message: 'Enhanced Fullstack Generator API - Works like AI Assistant',
    capabilities: [
      'Generate complete Next.js applications',
      'Create database schemas with Prisma',
      'Build REST API endpoints',
      'Design responsive frontend components',
      'Generate configuration files',
      'Create project documentation',
      'Provide live preview functionality',
      'Show comprehensive file structure',
      'Give step-by-step setup instructions'
    ],
    examples: [
      'Create a todo list application',
      'Build a blog CMS with authentication',
      'Make an e-commerce platform',
      'Develop a real-time chat application',
      'Design me the complete frontend and backend for the todo list website'
    ],
    features: [
      '🚀 Complete fullstack generation',
      '📁 File structure viewer',
      '🔧 Setup instructions',
      '🌐 Live preview',
      '⚡ Quick setup (3-5 minutes)',
      '📱 Responsive design',
      '🗄️ Database integration',
      '🔒 Error handling'
    ]
  });
}