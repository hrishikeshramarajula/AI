// Simple in-memory rate limiter for API calls

interface RateLimitData {
  count: number
  resetTime: number
}

class RateLimiter {
  private limits = new Map<string, RateLimitData>()
  
  constructor(
    private windowMs: number = 60000, // 1 minute window
    private maxRequests: number = 20 // 20 requests per minute
  ) {}

  checkLimit(identifier: string): { allowed: boolean; remaining: number; resetTime: number } {
    const now = Date.now()
    const windowStart = now - this.windowMs
    
    // Clean up old entries
    for (const [key, data] of this.limits.entries()) {
      if (data.resetTime < now) {
        this.limits.delete(key)
      }
    }
    
    let data = this.limits.get(identifier)
    
    // If no existing data or window expired, create new entry
    if (!data || data.resetTime < now) {
      data = {
        count: 1,
        resetTime: now + this.windowMs
      }
      this.limits.set(identifier, data)
      
      return {
        allowed: true,
        remaining: this.maxRequests - 1,
        resetTime: data.resetTime
      }
    }
    
    // Check if limit exceeded
    if (data.count >= this.maxRequests) {
      return {
        allowed: false,
        remaining: 0,
        resetTime: data.resetTime
      }
    }
    
    // Increment count
    data.count++
    this.limits.set(identifier, data)
    
    return {
      allowed: true,
      remaining: this.maxRequests - data.count,
      resetTime: data.resetTime
    }
  }

  getHeaders(identifier: string): Record<string, string> {
    const result = this.checkLimit(identifier)
    
    return {
      'X-RateLimit-Limit': this.maxRequests.toString(),
      'X-RateLimit-Remaining': result.remaining.toString(),
      'X-RateLimit-Reset': result.resetTime.toString()
    }
  }
}

// Create different limiters for different use cases
export const imageGenerationLimiter = new RateLimiter(60000, 20) // 20 per minute
export const apiLimiter = new RateLimiter(60000, 100) // 100 per minute for general API

// Middleware function to check rate limits
export function checkRateLimit(limiter: RateLimiter, identifier: string) {
  const result = limiter.checkLimit(identifier)
  
  if (!result.allowed) {
    const error = new Error('Rate limit exceeded')
    error.name = 'RateLimitError'
    ;(error as any).status = 429
    ;(error as any).headers = limiter.getHeaders(identifier)
    throw error
  }
  
  return limiter.getHeaders(identifier)
}

// Get client identifier for rate limiting
export function getClientIdentifier(request: Request): string {
  // Try to get IP from various headers
  const forwarded = request.headers.get('x-forwarded-for')
  const realIp = request.headers.get('x-real-ip')
  const cfConnectingIp = request.headers.get('cf-connecting-ip')
  
  const ip = forwarded || realIp || cfConnectingIp || 'unknown'
  
  // For development, use a consistent identifier
  if (process.env.NODE_ENV === 'development') {
    return 'dev-client'
  }
  
  return ip
}