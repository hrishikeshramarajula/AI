// 📝 Natural Language Understanding (NLU) Processor
// This component handles tokenization, parsing, semantic analysis, and intent recognition

export interface NLUInput {
  text: string;
  context?: any;
}

export interface NLUResult {
  intent: string;
  entities: any[];
  confidence: number;
  sentiment: 'positive' | 'negative' | 'neutral';
  urgency: 'low' | 'medium' | 'high' | 'urgent';
  keywords: string[];
  categories: string[];
  semanticAnalysis: {
    mainAction: string;
    target: string;
    modifiers: string[];
    conditions: string[];
  };
  contextUnderstanding: {
    previousInteractions: any[];
    userPreferences: any[];
    projectContext: any;
  };
}

export interface KnowledgeBase {
  intents: IntentPattern[];
  entities: EntityPattern[];
  keywords: KeywordPattern[];
  contexts: ContextPattern[];
}

export interface IntentPattern {
  name: string;
  patterns: string[];
  confidence: number;
  category: string;
  requiredEntities: string[];
  responseTemplate?: string;
}

export interface EntityPattern {
  name: string;
  patterns: string[];
  type: 'string' | 'number' | 'date' | 'boolean' | 'custom';
  validation?: (value: any) => boolean;
}

export interface KeywordPattern {
  word: string;
  weight: number;
  category: string;
  synonyms: string[];
}

export interface ContextPattern {
  type: string;
  patterns: string[];
  weight: number;
  adaptation?: any;
}

export class NLUProcessor {
  private knowledgeBase: KnowledgeBase;
  private tokenizer: Tokenizer;
  private parser: Parser;
  private semanticAnalyzer: SemanticAnalyzer;
  private intentRecognizer: IntentRecognizer;
  private entityExtractor: EntityExtractor;
  private sentimentAnalyzer: SentimentAnalyzer;
  private contextAnalyzer: ContextAnalyzer;

  constructor() {
    this.tokenizer = new Tokenizer();
    this.parser = new Parser();
    this.semanticAnalyzer = new SemanticAnalyzer();
    this.intentRecognizer = new IntentRecognizer();
    this.entityExtractor = new EntityExtractor();
    this.sentimentAnalyzer = new SentimentAnalyzer();
    this.contextAnalyzer = new ContextAnalyzer();
    
    this.knowledgeBase = this.initializeKnowledgeBase();
  }

  public async initialize(): Promise<void> {
    // Initialize NLU components
    await this.tokenizer.initialize();
    await this.parser.initialize();
    await this.semanticAnalyzer.initialize();
    await this.intentRecognizer.initialize(this.knowledgeBase.intents);
    await this.entityExtractor.initialize(this.knowledgeBase.entities);
    await this.sentimentAnalyzer.initialize();
    await this.contextAnalyzer.initialize(this.knowledgeBase.contexts);
  }

  // 🎯 Main NLU processing method
  public async process(text: string, context?: any): Promise<NLUResult> {
    console.log('📝 Starting NLU Processing for:', text);

    try {
      // Step 1: Tokenization & Parsing
      console.log('🔤 Tokenizing and parsing...');
      const tokens = await this.tokenizer.tokenize(text);
      const parsed = await this.parser.parse(tokens);
      console.log(`✅ Tokenization complete - ${tokens.length} tokens identified`);

      // Step 2: Semantic Analysis
      console.log('🧠 Analyzing semantics...');
      const semanticResult = await this.semanticAnalyzer.analyze(parsed, text);
      console.log(`✅ Semantic analysis complete - Action: ${semanticResult.mainAction}`);

      // Step 3: Intent Recognition
      console.log('🎯 Recognizing intent...');
      const intentResult = await this.intentRecognizer.recognizeIntent(text, tokens, semanticResult);
      console.log(`✅ Intent recognized: ${intentResult.intent} (${intentResult.confidence} confidence)`);

      // Step 4: Entity Extraction
      console.log('🏷️ Extracting entities...');
      const entities = await this.entityExtractor.extractEntities(text, tokens, intentResult);
      console.log(`✅ Entities extracted: ${entities.length} found`);

      // Step 5: Sentiment Analysis
      console.log('😊 Analyzing sentiment...');
      const sentiment = await this.sentimentAnalyzer.analyzeSentiment(text, tokens);
      console.log(`✅ Sentiment analyzed: ${sentiment}`);

      // Step 6: Context Understanding
      console.log('🌐 Understanding context...');
      const contextUnderstanding = await this.contextAnalyzer.analyzeContext(text, context);
      console.log(`✅ Context analyzed`);

      // Step 7: Keyword Extraction
      console.log('🔑 Extracting keywords...');
      const keywords = await this.extractKeywords(text, tokens);
      console.log(`✅ Keywords extracted: ${keywords.length} found`);

      // Step 8: Categorization
      console.log('📂 Categorizing request...');
      const categories = await this.categorizeRequest(intentResult, entities, keywords);
      console.log(`✅ Categories identified: ${categories.join(', ')}`);

      // Step 9: Urgency Detection
      console.log('⚡ Detecting urgency...');
      const urgency = await this.detectUrgency(text, tokens, sentiment);
      console.log(`✅ Urgency detected: ${urgency}`);

      // Combine all results
      const result: NLUResult = {
        intent: intentResult.intent,
        entities,
        confidence: intentResult.confidence,
        sentiment,
        urgency,
        keywords,
        categories,
        semanticAnalysis: semanticResult,
        contextUnderstanding
      };

      console.log('🎉 NLU Processing completed successfully');
      return result;

    } catch (error) {
      console.error('❌ NLU Processing failed:', error);
      throw error;
    }
  }

  // 🏷️ Keyword extraction with knowledge base weighting
  private async extractKeywords(text: string, tokens: string[]): Promise<string[]> {
    const keywords: string[] = [];
    const keywordMap = new Map<string, number>();

    // Check each token against knowledge base
    for (const token of tokens) {
      const lowerToken = token.toLowerCase();
      
      for (const keyword of this.knowledgeBase.keywords) {
        if (keyword.word === lowerToken || keyword.synonyms.includes(lowerToken)) {
          const currentWeight = keywordMap.get(keyword.word) || 0;
          keywordMap.set(keyword.word, currentWeight + keyword.weight);
        }
      }
    }

    // Sort by weight and return top keywords
    const sortedKeywords = Array.from(keywordMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([word]) => word);

    return sortedKeywords;
  }

  // 📂 Request categorization
  private async categorizeRequest(intentResult: any, entities: any[], keywords: string[]): Promise<string[]> {
    const categories: string[] = [];
    
    // Add intent category
    if (intentResult.category) {
      categories.push(intentResult.category);
    }

    // Add entity-based categories
    for (const entity of entities) {
      if (entity.type === 'file_operation') categories.push('file_management');
      if (entity.type === 'code_generation') categories.push('development');
      if (entity.type === 'ai_request') categories.push('ai_interaction');
    }

    // Add keyword-based categories
    if (keywords.includes('urgent') || keywords.includes('quick')) categories.push('urgent');
    if (keywords.includes('delete') || keywords.includes('remove')) categories.push('deletion');
    if (keywords.includes('create') || keywords.includes('build')) categories.push('creation');
    if (keywords.includes('fix') || keywords.includes('repair')) categories.push('maintenance');

    return [...new Set(categories)]; // Remove duplicates
  }

  // ⚡ Urgency detection
  private async detectUrgency(text: string, tokens: string[], sentiment: string): Promise<'low' | 'medium' | 'high' | 'urgent'> {
    const urgencyKeywords = ['urgent', 'asap', 'immediately', 'quick', 'fast', 'now', 'ra'];
    const urgencyCount = tokens.filter(token => urgencyKeywords.includes(token.toLowerCase())).length;
    
    // Check for "ra" suffix (specific to user's style)
    const raCount = (text.match(/ra/g) || []).length;
    
    if (urgencyCount >= 2 || raCount >= 2) return 'urgent';
    if (urgencyCount >= 1 || raCount >= 1) return 'high';
    if (sentiment === 'negative') return 'medium';
    return 'low';
  }

  // 📚 Initialize knowledge base with patterns
  private initializeKnowledgeBase(): KnowledgeBase {
    return {
      intents: [
        {
          name: 'file_cleanup',
          patterns: [
            'keep only', 'delete other files', 'remove unused', 'clean up',
            'keep related files', 'delete unrelated files', 'organize files'
          ],
          confidence: 0.9,
          category: 'file_management',
          requiredEntities: ['target_files', 'operation_type']
        },
        {
          name: 'code_generation',
          patterns: [
            'create code', 'generate code', 'write code', 'build application',
            'develop system', 'implement feature', 'code the'
          ],
          confidence: 0.85,
          category: 'development',
          requiredEntities: ['target_component', 'technology']
        },
        {
          name: 'ai_agent_request',
          patterns: [
            'ai agent', 'autonomous agent', 'smart brain', 'intelligent system',
            'ai processing', 'autonomous processing', 'brain system'
          ],
          confidence: 0.95,
          category: 'ai_interaction',
          requiredEntities: ['agent_type', 'capability']
        },
        {
          name: 'system_analysis',
          patterns: [
            'analyze', 'examine', 'check', 'verify', 'diagnose',
            'investigate', 'review', 'audit'
          ],
          confidence: 0.8,
          category: 'analysis',
          requiredEntities: ['target_system']
        }
      ],
      entities: [
        {
          name: 'target_files',
          patterns: ['files', 'components', 'modules', 'code', 'source'],
          type: 'custom'
        },
        {
          name: 'operation_type',
          patterns: ['keep', 'delete', 'remove', 'create', 'modify'],
          type: 'string'
        },
        {
          name: 'target_component',
          patterns: ['component', 'system', 'feature', 'module', 'application'],
          type: 'string'
        },
        {
          name: 'technology',
          patterns: ['nextjs', 'react', 'typescript', 'tailwind', 'ai'],
          type: 'string'
        },
        {
          name: 'agent_type',
          patterns: ['ai agent', 'autonomous agent', 'brain', 'intelligence'],
          type: 'string'
        },
        {
          name: 'capability',
          patterns: ['nlu', 'planning', 'execution', 'learning', 'verification'],
          type: 'string'
        }
      ],
      keywords: [
        { word: 'autonomous', weight: 0.9, category: 'ai', synonyms: ['automatic', 'self'] },
        { word: 'agent', weight: 0.8, category: 'ai', synonyms: ['assistant', 'bot'] },
        { word: 'brain', weight: 0.9, category: 'ai', synonyms: ['intelligence', 'mind'] },
        { word: 'files', weight: 0.7, category: 'file', synonyms: ['code', 'components'] },
        { word: 'delete', weight: 0.6, category: 'operation', synonyms: ['remove', 'clean'] },
        { word: 'keep', weight: 0.6, category: 'operation', synonyms: ['maintain', 'preserve'] },
        { word: 'urgent', weight: 0.8, category: 'priority', synonyms: ['asap', 'quick'] },
        { word: 'ra', weight: 0.9, category: 'emphasis', synonyms: [] }
      ],
      contexts: [
        {
          type: 'development',
          patterns: ['code', 'development', 'programming', 'software'],
          weight: 0.8
        },
        {
          type: 'file_management',
          patterns: ['files', 'cleanup', 'organize', 'delete'],
          weight: 0.7
        },
        {
          type: 'ai_interaction',
          patterns: ['ai', 'agent', 'autonomous', 'brain'],
          weight: 0.9
        }
      ]
    };
  }

  // 📊 Get NLU processor status
  public getStatus(): any {
    return {
      initialized: true,
      knowledgeBaseSize: {
        intents: this.knowledgeBase.intents.length,
        entities: this.knowledgeBase.entities.length,
        keywords: this.knowledgeBase.keywords.length,
        contexts: this.knowledgeBase.contexts.length
      },
      components: {
        tokenizer: this.tokenizer.getStatus(),
        parser: this.parser.getStatus(),
        semanticAnalyzer: this.semanticAnalyzer.getStatus(),
        intentRecognizer: this.intentRecognizer.getStatus(),
        entityExtractor: this.entityExtractor.getStatus(),
        sentimentAnalyzer: this.sentimentAnalyzer.getStatus(),
        contextAnalyzer: this.contextAnalyzer.getStatus()
      }
    };
  }

  public async shutdown(): Promise<void> {
    console.log('🛑 Shutting down NLU Processor...');
    // Cleanup resources
  }
}

// 🔤 Tokenizer for breaking text into tokens
class Tokenizer {
  private initialized: boolean = false;

  async initialize(): Promise<void> {
    this.initialized = true;
  }

  async tokenize(text: string): Promise<string[]> {
    if (!this.initialized) throw new Error('Tokenizer not initialized');
    
    // Basic tokenization - split by spaces and punctuation
    const tokens = text
      .toLowerCase()
      .replace(/[^\w\s]/g, ' ')
      .split(/\s+/)
      .filter(token => token.length > 0);
    
    return tokens;
  }

  getStatus(): any {
    return { initialized: this.initialized };
  }
}

// 📝 Parser for grammatical analysis
class Parser {
  private initialized: boolean = false;

  async initialize(): Promise<void> {
    this.initialized = true;
  }

  async parse(tokens: string[]): Promise<any> {
    if (!this.initialized) throw new Error('Parser not initialized');
    
    // Basic parsing - identify parts of speech patterns
    return {
      tokens,
      structure: this.analyzeStructure(tokens),
      phrases: this.extractPhrases(tokens)
    };
  }

  private analyzeStructure(tokens: string[]): any {
    // Simple structural analysis
    return {
      hasQuestion: tokens.includes('?') || tokens.some(t => ['what', 'how', 'why', 'when', 'where'].includes(t)),
      hasCommand: tokens.some(t => ['create', 'delete', 'keep', 'build', 'make'].includes(t)),
      hasUrgency: tokens.some(t => ['urgent', 'quick', 'asap', 'ra'].includes(t))
    };
  }

  private extractPhrases(tokens: string[]): string[] {
    // Extract meaningful phrases
    const phrases: string[] = [];
    let currentPhrase: string[] = [];
    
    for (const token of tokens) {
      if (token.length > 2) {
        currentPhrase.push(token);
      } else {
        if (currentPhrase.length > 0) {
          phrases.push(currentPhrase.join(' '));
          currentPhrase = [];
        }
      }
    }
    
    if (currentPhrase.length > 0) {
      phrases.push(currentPhrase.join(' '));
    }
    
    return phrases;
  }

  getStatus(): any {
    return { initialized: this.initialized };
  }
}

// 🧠 Semantic Analyzer for meaning extraction
class SemanticAnalyzer {
  private initialized: boolean = false;

  async initialize(): Promise<void> {
    this.initialized = true;
  }

  async analyze(parsed: any, originalText: string): Promise<any> {
    if (!this.initialized) throw new Error('Semantic Analyzer not initialized');
    
    const tokens = parsed.tokens;
    
    // Extract main action
    const actionWords = ['create', 'delete', 'keep', 'build', 'make', 'analyze', 'implement', 'generate'];
    const mainAction = tokens.find(t => actionWords.includes(t)) || 'unknown';
    
    // Extract target
    const targetWords = ['files', 'code', 'system', 'agent', 'brain', 'component', 'application'];
    const target = tokens.find(t => targetWords.includes(t)) || 'general';
    
    // Extract modifiers
    const modifiers = tokens.filter(t => 
      !actionWords.includes(t) && 
      !targetWords.includes(t) && 
      t.length > 2
    );
    
    // Extract conditions
    const conditions = [];
    if (tokens.includes('only')) conditions.push('exclusive');
    if (tokens.includes('all')) conditions.push('inclusive');
    if (tokens.includes('related')) conditions.push('contextual');
    
    return {
      mainAction,
      target,
      modifiers,
      conditions,
      complexity: this.calculateComplexity(tokens),
      clarity: this.calculateClarity(parsed)
    };
  }

  private calculateComplexity(tokens: string[]): number {
    // Simple complexity calculation based on token count and variety
    return Math.min(tokens.length / 10, 1.0);
  }

  private calculateClarity(parsed: any): number {
    // Simple clarity calculation based on structure
    if (parsed.structure.hasCommand) return 0.9;
    if (parsed.structure.hasQuestion) return 0.7;
    return 0.5;
  }

  getStatus(): any {
    return { initialized: this.initialized };
  }
}

// 🎯 Intent Recognizer for understanding user intent
class IntentRecognizer {
  private intents: IntentPattern[] = [];
  private initialized: boolean = false;

  async initialize(intents: IntentPattern[]): Promise<void> {
    this.intents = intents;
    this.initialized = true;
  }

  async recognizeIntent(text: string, tokens: string[], semanticResult: any): Promise<any> {
    if (!this.initialized) throw new Error('Intent Recognizer not initialized');
    
    const scores: { [key: string]: number } = {};
    
    // Score each intent based on pattern matching
    for (const intent of this.intents) {
      scores[intent.name] = this.calculateIntentScore(text, tokens, intent, semanticResult);
    }
    
    // Find the best matching intent
    const bestIntent = Object.entries(scores)
      .sort((a, b) => b[1] - a[1])[0];
    
    return {
      intent: bestIntent[0],
      confidence: bestIntent[1],
      category: this.intents.find(i => i.name === bestIntent[0])?.category || 'unknown'
    };
  }

  private calculateIntentScore(text: string, tokens: string[], intent: IntentPattern, semanticResult: any): number {
    let score = 0;
    
    // Pattern matching
    for (const pattern of intent.patterns) {
      if (text.toLowerCase().includes(pattern.toLowerCase())) {
        score += 0.3;
      }
    }
    
    // Semantic matching
    if (semanticResult.mainAction && intent.name.includes(semanticResult.mainAction)) {
      score += 0.2;
    }
    
    // Base confidence
    score += intent.confidence * 0.3;
    
    return Math.min(score, 1.0);
  }

  getStatus(): any {
    return { initialized: this.initialized, intentsCount: this.intents.length };
  }
}

// 🏷️ Entity Extractor for identifying important elements
class EntityExtractor {
  private entities: EntityPattern[] = [];
  private initialized: boolean = false;

  async initialize(entities: EntityPattern[]): Promise<void> {
    this.entities = entities;
    this.initialized = true;
  }

  async extractEntities(text: string, tokens: string[], intentResult: any): Promise<any[]> {
    if (!this.initialized) throw new Error('Entity Extractor not initialized');
    
    const extractedEntities: any[] = [];
    
    for (const entity of this.entities) {
      const matches = this.findEntityMatches(text, tokens, entity);
      for (const match of matches) {
        extractedEntities.push({
          type: entity.name,
          value: match,
          confidence: this.calculateEntityConfidence(match, entity)
        });
      }
    }
    
    return extractedEntities;
  }

  private findEntityMatches(text: string, tokens: string[], entity: EntityPattern): string[] {
    const matches: string[] = [];
    
    for (const pattern of entity.patterns) {
      if (text.toLowerCase().includes(pattern.toLowerCase())) {
        matches.push(pattern);
      }
    }
    
    return matches;
  }

  private calculateEntityConfidence(match: string, entity: EntityPattern): number {
    // Simple confidence calculation
    return 0.8; // Base confidence for entity matches
  }

  getStatus(): any {
    return { initialized: this.initialized, entitiesCount: this.entities.length };
  }
}

// 😊 Sentiment Analyzer for emotional tone detection
class SentimentAnalyzer {
  private initialized: boolean = false;

  async initialize(): Promise<void> {
    this.initialized = true;
  }

  async analyzeSentiment(text: string, tokens: string[]): Promise<'positive' | 'negative' | 'neutral'> {
    if (!this.initialized) throw new Error('Sentiment Analyzer not initialized');
    
    const positiveWords = ['good', 'great', 'excellent', 'awesome', 'perfect', 'love', 'like'];
    const negativeWords = ['bad', 'terrible', 'awful', 'hate', 'dislike', 'wrong', 'error'];
    const urgencyWords = ['urgent', 'asap', 'quick', 'fast', 'now', 'ra'];
    
    const positiveCount = tokens.filter(t => positiveWords.includes(t)).length;
    const negativeCount = tokens.filter(t => negativeWords.includes(t)).length;
    const urgencyCount = tokens.filter(t => urgencyWords.includes(t)).length;
    
    if (urgencyCount > 0) return 'negative'; // Urgency often indicates negative sentiment
    if (positiveCount > negativeCount) return 'positive';
    if (negativeCount > positiveCount) return 'negative';
    return 'neutral';
  }

  getStatus(): any {
    return { initialized: this.initialized };
  }
}

// 🌐 Context Analyzer for understanding situation
class ContextAnalyzer {
  private contexts: ContextPattern[] = [];
  private initialized: boolean = false;

  async initialize(contexts: ContextPattern[]): Promise<void> {
    this.contexts = contexts;
    this.initialized = true;
  }

  async analyzeContext(text: string, context?: any): Promise<any> {
    if (!this.initialized) throw new Error('Context Analyzer not initialized');
    
    const contextTypes: string[] = [];
    const contextScores: { [key: string]: number } = {};
    
    // Analyze context based on patterns
    for (const contextPattern of this.contexts) {
      let score = 0;
      for (const pattern of contextPattern.patterns) {
        if (text.toLowerCase().includes(pattern.toLowerCase())) {
          score += contextPattern.weight;
        }
      }
      
      if (score > 0) {
        contextTypes.push(contextPattern.type);
        contextScores[contextPattern.type] = score;
      }
    }
    
    return {
      previousInteractions: context?.previousInteractions || [],
      userPreferences: context?.userPreferences || [],
      projectContext: context?.projectContext || {},
      identifiedContexts: contextTypes,
      contextScores
    };
  }

  getStatus(): any {
    return { initialized: this.initialized, contextsCount: this.contexts.length };
  }
}