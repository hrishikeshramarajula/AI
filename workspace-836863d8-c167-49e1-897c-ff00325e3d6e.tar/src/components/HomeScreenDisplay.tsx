'use client';

import React, { useState } from 'react';
import { Monitor, Tablet, Smartphone, X, Maximize2, Code, Play, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';

interface HomeScreenDisplayProps {
  project: any;
  isVisible: boolean;
  onClose?: () => void;
  className?: string;
}

interface PreviewDevice {
  id: string;
  name: string;
  icon: React.ReactNode;
  width: string;
  height: string;
}

export default function HomeScreenDisplay({ project, isVisible, onClose, className = '' }: HomeScreenDisplayProps) {
  console.log('🎬 HomeScreenDisplay rendered with:', { isVisible, project: project?.structure?.name });
  
  const [selectedDevice, setSelectedDevice] = useState('desktop');
  const [isFullscreen, setIsFullscreen] = useState(false);

  const previewDevices: PreviewDevice[] = [
    {
      id: 'desktop',
      name: 'Desktop',
      icon: <Monitor className="w-4 h-4" />,
      width: '100%',
      height: '600px'
    },
    {
      id: 'tablet',
      name: 'Tablet',
      icon: <Tablet className="w-4 h-4" />,
      width: '768px',
      height: '1024px'
    },
    {
      id: 'mobile',
      name: 'Mobile',
      icon: <Smartphone className="w-4 h-4" />,
      width: '375px',
      height: '667px'
    }
  ];

  const selectedDeviceConfig = previewDevices.find(device => device.id === selectedDevice);

  // Generate preview content from project files
  const generatePreviewContent = () => {
    console.log('🖥️ Generating preview content for project:', project);
    
    if (!project || !project.structure) {
      console.log('❌ No project structure found, showing welcome screen');
      return `
        <html>
          <head>
            <style>
              body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                margin: 0; 
                padding: 20px; 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
              }
              .container {
                text-align: center;
                max-width: 600px;
              }
              h1 { font-size: 2.5rem; margin-bottom: 1rem; }
              p { font-size: 1.2rem; opacity: 0.9; }
              .features {
                display: flex;
                flex-wrap: wrap;
                gap: 0.5rem;
                justify-content: center;
                margin-top: 1rem;
              }
              .feature {
                background: rgba(255,255,255,0.2);
                padding: 0.5rem 1rem;
                border-radius: 9999px;
                font-size: 0.9rem;
              }
            </style>
          </head>
          <body>
            <div class="container">
              <h1>🤖 AI Agent Demo</h1>
              <p>Your AI Assistant is ready to help you build amazing applications!</p>
              <div class="features">
                <span class="feature">🧠 Smart AI</span>
                <span class="feature">💬 Chat Interface</span>
                <span class="feature">🎨 Image Generation</span>
                <span class="feature">🔍 Web Search</span>
                <span class="feature">⚡ Autonomous Agent</span>
              </div>
            </div>
          </body>
        </html>
      `;
    }

    console.log('✅ Project structure found:', project.structure);

    // Create a comprehensive working application preview
    return `
      <html>
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>${project.structure?.name || 'Generated Application'}</title>
          <script src="https://cdn.tailwindcss.com"></script>
          <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
          <style>
            * { box-sizing: border-box; }
            body { 
              margin: 0; 
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              background: #f8fafc;
            }
            .gradient-bg {
              background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            }
            .card-hover {
              transition: all 0.3s ease;
            }
            .card-hover:hover {
              transform: translateY(-2px);
              box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            }
            .feature-icon {
              transition: all 0.3s ease;
            }
            .feature-card:hover .feature-icon {
              transform: scale(1.1);
            }
          </style>
        </head>
        <body class="bg-gray-50">
          <!-- Navigation -->
          <nav class="bg-white shadow-sm border-b">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div class="flex justify-between h-16">
                <div class="flex items-center">
                  <div class="flex-shrink-0">
                    <div class="h-8 w-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-md flex items-center justify-center">
                      <span class="text-white font-bold text-sm">AI</span>
                    </div>
                  </div>
                  <div class="ml-4">
                    <h1 class="text-xl font-bold text-gray-900">${project.structure?.name || 'AI App'}</h1>
                  </div>
                </div>
                <div class="flex items-center space-x-4">
                  <button class="text-gray-500 hover:text-gray-700">
                    <i data-lucide="settings" class="w-5 h-5"></i>
                  </button>
                  <button class="text-gray-500 hover:text-gray-700">
                    <i data-lucide="user" class="w-5 h-5"></i>
                  </button>
                </div>
              </div>
            </div>
          </nav>

          <!-- Hero Section -->
          <section class="gradient-bg text-white py-20">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
              <h2 class="text-4xl md:text-6xl font-bold mb-6">
                🚀 Welcome to ${project.structure?.name || 'Your AI App'}
              </h2>
              <p class="text-xl md:text-2xl mb-8 opacity-90">
                ${project.structure?.description || 'Experience the power of AI-driven development'}
              </p>
              <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <button class="bg-white text-purple-700 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
                  Get Started
                </button>
                <button class="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-purple-700 transition-colors">
                  Learn More
                </button>
              </div>
            </div>
          </section>

          <!-- Features Section -->
          <section class="py-20">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div class="text-center mb-16">
                <h3 class="text-3xl font-bold text-gray-900 mb-4">✨ Powerful Features</h3>
                <p class="text-xl text-gray-600">Everything you need to build amazing applications</p>
              </div>
              
              <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- Feature 1 -->
                <div class="feature-card bg-white p-8 rounded-xl shadow-lg card-hover">
                  <div class="feature-icon w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                    <i data-lucide="brain" class="w-6 h-6 text-blue-600"></i>
                  </div>
                  <h4 class="text-xl font-semibold text-gray-900 mb-3">🧠 AI Intelligence</h4>
                  <p class="text-gray-600">Advanced AI capabilities that understand and execute your requirements automatically</p>
                </div>

                <!-- Feature 2 -->
                <div class="feature-card bg-white p-8 rounded-xl shadow-lg card-hover">
                  <div class="feature-icon w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                    <i data-lucide="code" class="w-6 h-6 text-green-600"></i>
                  </div>
                  <h4 class="text-xl font-semibold text-gray-900 mb-3">💻 Code Generation</h4>
                  <p class="text-gray-600">Generate clean, production-ready code in multiple programming languages</p>
                </div>

                <!-- Feature 3 -->
                <div class="feature-card bg-white p-8 rounded-xl shadow-lg card-hover">
                  <div class="feature-icon w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                    <i data-lucide="image" class="w-6 h-6 text-purple-600"></i>
                  </div>
                  <h4 class="text-xl font-semibold text-gray-900 mb-3">🎨 Creative Tools</h4>
                  <p class="text-gray-600">Create stunning visuals and designs with AI-powered image generation</p>
                </div>

                <!-- Feature 4 -->
                <div class="feature-card bg-white p-8 rounded-xl shadow-lg card-hover">
                  <div class="feature-icon w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mb-4">
                    <i data-lucide="search" class="w-6 h-6 text-yellow-600"></i>
                  </div>
                  <h4 class="text-xl font-semibold text-gray-900 mb-3">🔍 Web Search</h4>
                  <p class="text-gray-600">Access real-time information from the web to power your applications</p>
                </div>

                <!-- Feature 5 -->
                <div class="feature-card bg-white p-8 rounded-xl shadow-lg card-hover">
                  <div class="feature-icon w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-4">
                    <i data-lucide="layers" class="w-6 h-6 text-red-600"></i>
                  </div>
                  <h4 class="text-xl font-semibold text-gray-900 mb-3">🏗️ Full Stack</h4>
                  <p class="text-gray-600">Build complete applications with frontend, backend, and database integration</p>
                </div>

                <!-- Feature 6 -->
                <div class="feature-card bg-white p-8 rounded-xl shadow-lg card-hover">
                  <div class="feature-icon w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                    <i data-lucide="zap" class="w-6 h-6 text-indigo-600"></i>
                  </div>
                  <h4 class="text-xl font-semibold text-gray-900 mb-3">⚡ Autonomous Agent</h4>
                  <p class="text-gray-600">Let AI handle complex tasks automatically with intelligent decision making</p>
                </div>
              </div>
            </div>
          </section>

          <!-- Stats Section -->
          <section class="bg-gray-900 text-white py-16">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                <div>
                  <div class="text-3xl font-bold text-blue-400 mb-2">${project.files?.length || 25}+</div>
                  <div class="text-gray-300">Files Generated</div>
                </div>
                <div>
                  <div class="text-3xl font-bold text-green-400 mb-2">${project.structure?.features?.length || 8}</div>
                  <div class="text-gray-300">Features</div>
                </div>
                <div>
                  <div class="text-3xl font-bold text-purple-400 mb-2">100%</div>
                  <div class="text-gray-300">AI Powered</div>
                </div>
                <div>
                  <div class="text-3xl font-bold text-yellow-400 mb-2">∞</div>
                  <div class="text-gray-300">Possibilities</div>
                </div>
              </div>
            </div>
          </section>

          <!-- CTA Section -->
          <section class="py-20">
            <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
              <div class="bg-gradient-to-r from-blue-50 to-purple-50 p-12 rounded-2xl">
                <h3 class="text-3xl font-bold text-gray-900 mb-4">🎯 Ready to Get Started?</h3>
                <p class="text-xl text-gray-600 mb-8">
                  Your AI-powered application is ready to deploy and use immediately
                </p>
                <div class="flex flex-col sm:flex-row gap-4 justify-center">
                  <button class="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all">
                    🚀 Launch Application
                  </button>
                  <button class="border-2 border-gray-300 text-gray-700 px-8 py-3 rounded-lg font-semibold hover:border-gray-400 transition-colors">
                    📚 View Documentation
                  </button>
                </div>
              </div>
            </div>
          </section>

          <!-- Footer -->
          <footer class="bg-gray-800 text-white py-12">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div class="grid md:grid-cols-4 gap-8">
                <div>
                  <div class="flex items-center gap-2 mb-4">
                    <div class="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-md flex items-center justify-center">
                      <span class="text-white font-bold text-sm">AI</span>
                    </div>
                    <span class="font-bold">${project.structure?.name || 'AI App'}</span>
                  </div>
                  <p class="text-gray-400 text-sm">
                    Powered by advanced AI technology
                  </p>
                </div>
                <div>
                  <h4 class="font-semibold mb-4">Product</h4>
                  <ul class="space-y-2 text-sm text-gray-400">
                    <li><a href="#" class="hover:text-white">Features</a></li>
                    <li><a href="#" class="hover:text-white">Documentation</a></li>
                    <li><a href="#" class="hover:text-white">API</a></li>
                  </ul>
                </div>
                <div>
                  <h4 class="font-semibold mb-4">Company</h4>
                  <ul class="space-y-2 text-sm text-gray-400">
                    <li><a href="#" class="hover:text-white">About</a></li>
                    <li><a href="#" class="hover:text-white">Blog</a></li>
                    <li><a href="#" class="hover:text-white">Contact</a></li>
                  </ul>
                </div>
                <div>
                  <h4 class="font-semibold mb-4">Status</h4>
                  <div class="flex items-center gap-2 text-sm">
                    <div class="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span class="text-green-400">All Systems Operational</span>
                  </div>
                  <p class="text-gray-400 text-sm mt-2">
                    Uptime: 99.9%
                  </p>
                </div>
              </div>
              <div class="border-t border-gray-700 mt-8 pt-8 text-center text-sm text-gray-400">
                <p>&copy; 2024 ${project.structure?.name || 'AI Application'}. Built with AI ❤️</p>
              </div>
            </div>
          </footer>

          <script>
            // Initialize Lucide icons
            lucide.createIcons();
            
            // Add some interactivity
            document.addEventListener('DOMContentLoaded', function() {
              // Smooth scrolling for anchor links
              document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                  e.preventDefault();
                  const target = document.querySelector(this.getAttribute('href'));
                  if (target) {
                    target.scrollIntoView({
                      behavior: 'smooth'
                    });
                  }
                });
              });

              // Add click animations to buttons
              document.querySelectorAll('button').forEach(button => {
                button.addEventListener('click', function() {
                  this.style.transform = 'scale(0.95)';
                  setTimeout(() => {
                    this.style.transform = 'scale(1)';
                  }, 100);
                });
              });

              console.log('🚀 ${project.structure?.name || 'AI Application'} loaded successfully!');
            });
          </script>
        </body>
      </html>
    `;
  };

  const previewContent = generatePreviewContent();

  if (!isVisible) {
    console.log('❌ HomeScreenDisplay not visible, returning null');
    return null;
  }

  console.log('✅ HomeScreenDisplay is visible and will render');

  return (
    <div className={`w-full ${className}`}>
      <Card className="border-2 border-blue-200 bg-blue-50">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-blue-900">
              <Eye className="w-5 h-5" />
              🖥️ Home Screen Display Preview
            </CardTitle>
            {onClose && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="w-4 h-4" />
              </Button>
            )}
          </div>
          
          {/* Device Selection */}
          <div className="flex gap-2 mt-3">
            {previewDevices.map((device) => (
              <Button
                key={device.id}
                variant={selectedDevice === device.id ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedDevice(device.id)}
                className="flex items-center gap-2"
              >
                {device.icon}
                {device.name}
              </Button>
            ))}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="flex items-center gap-2 ml-auto"
            >
              <Maximize2 className="w-4 h-4" />
              {isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="p-0">
          <div className="bg-white border-t border-gray-200">
            {/* Preview Container */}
            <div className="relative overflow-hidden" style={{ 
              height: selectedDeviceConfig?.height || '600px',
              maxHeight: isFullscreen ? '80vh' : selectedDeviceConfig?.height || '600px'
            }}>
              <iframe
                srcDoc={previewContent}
                className="w-full h-full border-0"
                style={{
                  width: selectedDeviceConfig?.width || '100%',
                  height: '100%',
                  margin: '0 auto',
                  display: 'block',
                  border: 'none',
                  borderRadius: '0'
                }}
                title="Generated Application Preview"
                sandbox="allow-same-origin allow-scripts allow-forms"
              />
            </div>
            
            {/* Project Info Footer */}
            <div className="p-4 bg-gray-50 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Code className="w-4 h-4 text-gray-500" />
                    <span className="text-sm text-gray-600">
                      {project?.structure?.name || 'Generated Project'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Play className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-gray-600">
                      {project?.files?.length || 0} files generated
                    </span>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  {project?.structure?.features?.slice(0, 3).map((feature: string, index: number) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {feature}
                    </Badge>
                  ))}
                  {(project?.structure?.features?.length || 0) > 3 && (
                    <Badge variant="outline" className="text-xs">
                      +{(project?.structure?.features?.length || 0) - 3} more
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}