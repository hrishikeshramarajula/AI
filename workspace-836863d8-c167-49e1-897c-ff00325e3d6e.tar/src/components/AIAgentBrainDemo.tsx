// 🧠 AI Agent Brain Demo Component
// This component showcases the complete AI Agent Brain system with all its capabilities

'use client';

import React, { useState, useEffect } from 'react';
import {
  Brain,
  Zap,
  Target,
  Settings,
  BarChart3,
  Shield,
  BookOpen,
  Activity,
  Lightbulb,
  CheckCircle,
  XCircle,
  Clock,
  Users,
  Cpu,
  Network,
  Database,
  FileText,
  MessageSquare,
  TrendingUp,
  AlertTriangle,
  Info,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

interface AIAgentBrainStatus {
  isProcessing: boolean;
  currentTask: string;
  performance: {
    successRate: number;
    averageExecutionTime: number;
    errorRate: number;
  };
  learning: {
    patternsCount: number;
    preferencesCount: number;
    adaptationsCount: number;
  };
  memorySize: number;
  components: {
    nlu: any;
    planner: any;
    execution: any;
    verification: any;
    learning: any;
  };
}

interface ProcessingResult {
  success: boolean;
  result: any;
  reasoning: string[];
  executionTime: number;
  errors: string[];
  learnings: string[];
  confidence: number;
}

interface AIAgentBrainDemoProps {
  isVisible: boolean;
  onToggleVisibility: () => void;
}

export default function AIAgentBrainDemo({ isVisible, onToggleVisibility }: AIAgentBrainDemoProps) {
  const [status, setStatus] = useState<AIAgentBrainStatus | null>(null);
  const [inputText, setInputText] = useState('');
  const [processingResult, setProcessingResult] = useState<ProcessingResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    fetchStatus();
  }, []);

  const fetchStatus = async () => {
    try {
      const response = await fetch('/api/ai-agent-brain');
      const data = await response.json();
      if (data.success) {
        setStatus(data.status);
      }
    } catch (error) {
      console.error('Failed to fetch AI Agent Brain status:', error);
    }
  };

  const processWithAIBrain = async () => {
    if (!inputText.trim()) return;

    setIsProcessing(true);
    setProcessingResult(null);

    try {
      const response = await fetch('/api/ai-agent-brain', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: inputText,
          priority: 'high',
          userId: 'demo_user'
        })
      });

      const data = await response.json();
      if (data.success) {
        setProcessingResult(data.result);
      } else {
        setProcessingResult({
          success: false,
          result: null,
          reasoning: [],
          executionTime: 0,
          errors: [data.error || 'Unknown error'],
          learnings: [],
          confidence: 0
        });
      }
    } catch (error) {
      setProcessingResult({
        success: false,
        result: null,
        reasoning: [],
        executionTime: 0,
        errors: ['Failed to communicate with AI Agent Brain'],
        learnings: [],
        confidence: 0
      });
    } finally {
      setIsProcessing(false);
      fetchStatus(); // Refresh status
    }
  };

  const demoInputs = [
    {
      title: 'File Cleanup Request',
      text: 'I want you to keep the related files of the autonomous agent related files and delete other files ra'
    },
    {
      title: 'Code Generation Request',
      text: 'Create a comprehensive AI agent brain system with NLU, planning, execution, and learning capabilities ra'
    },
    {
      title: 'System Analysis Request',
      text: 'Analyze the current system performance and suggest improvements for better efficiency ra'
    },
    {
      title: 'Learning Request',
      text: 'Learn from the previous executions and adapt your strategies for better performance ra'
    }
  ];

  const StatusCard = ({ title, value, icon, color = 'text-blue-600' }: {
    title: string;
    value: string | number;
    icon: React.ReactNode;
    color?: string;
  }) => (
    <Card className="h-full">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className={`text-2xl font-bold ${color}`}>{value}</p>
          </div>
          <div className={color}>{icon}</div>
        </div>
      </CardContent>
    </Card>
  );

  const ComponentStatus = ({ name, status }: { name: string; status: any }) => (
    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
      <div className="flex items-center space-x-2">
        {status.initialized ? (
          <CheckCircle className="w-4 h-4 text-green-600" />
        ) : (
          <XCircle className="w-4 h-4 text-red-600" />
        )}
        <span className="text-sm font-medium">{name}</span>
      </div>
      <Badge variant={status.initialized ? 'default' : 'destructive'}>
        {status.initialized ? 'Active' : 'Inactive'}
      </Badge>
    </div>
  );

  return (
    isVisible && (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-6xl h-[90vh] flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b">
            <div className="flex items-center space-x-3">
              <Brain className="w-6 h-6 text-purple-600" />
              <h2 className="text-xl font-bold">🧠 AI Agent Brain Demo</h2>
            </div>
            <Button variant="ghost" size="sm" onClick={onToggleVisibility}>
              <X className="w-4 h-4" />
            </Button>
          </div>
          
          {/* Content */}
          <div className="flex-1 overflow-hidden">
            <ScrollArea className="h-full p-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-3">
          <Brain className="w-8 h-8 text-purple-600" />
          <h1 className="text-3xl font-bold text-gray-900">🧠 AI Agent Brain System</h1>
        </div>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Complete intelligent processing engine with Natural Language Understanding, Task Planning, 
          Intelligent Execution, Verification, and Adaptive Learning capabilities.
        </p>
      </div>

      {/* Status Overview */}
      {status && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Activity className="w-5 h-5" />
              <span>Brain Status Overview</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <StatusCard
                title="Success Rate"
                value={`${(status.performance.successRate * 100).toFixed(1)}%`}
                icon={<TrendingUp className="w-6 h-6" />}
                color="text-green-600"
              />
              <StatusCard
                title="Avg Execution Time"
                value={`${status.performance.averageExecutionTime.toFixed(0)}ms`}
                icon={<Clock className="w-6 h-6" />}
                color="text-blue-600"
              />
              <StatusCard
                title="Error Rate"
                value={`${(status.performance.errorRate * 100).toFixed(1)}%`}
                icon={<AlertTriangle className="w-6 h-6" />}
                color="text-red-600"
              />
              <StatusCard
                title="Memory Items"
                value={status.memorySize}
                icon={<Database className="w-6 h-6" />}
                color="text-purple-600"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-3">Learning Metrics</h4>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Patterns Discovered</span>
                    <Badge variant="outline">{status.learning.patternsCount}</Badge>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>User Preferences</span>
                    <Badge variant="outline">{status.learning.preferencesCount}</Badge>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Adaptations Applied</span>
                    <Badge variant="outline">{status.learning.adaptationsCount}</Badge>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-3">Component Status</h4>
                <div className="space-y-2">
                  <ComponentStatus name="NLU Processor" status={status.components.nlu} />
                  <ComponentStatus name="Task Planner" status={status.components.planner} />
                  <ComponentStatus name="Execution Engine" status={status.components.execution} />
                  <ComponentStatus name="Verification System" status={status.components.verification} />
                  <ComponentStatus name="Learning Engine" status={status.components.learning} />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Interaction Area */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">🎯 Overview</TabsTrigger>
          <TabsTrigger value="interact">💬 Interact</TabsTrigger>
          <TabsTrigger value="capabilities">⚡ Capabilities</TabsTrigger>
          <TabsTrigger value="results">📊 Results</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Brain className="w-5 h-5" />
                  <span>Intelligent Processing</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="bg-blue-100 p-2 rounded-lg">
                    <MessageSquare className="w-4 h-4 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Natural Language Understanding</h4>
                    <p className="text-sm text-gray-600">
                      Advanced NLU with tokenization, semantic analysis, intent recognition, and context understanding
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="bg-green-100 p-2 rounded-lg">
                    <Target className="w-4 h-4 text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Task Planning</h4>
                    <p className="text-sm text-gray-600">
                      Intelligent task decomposition, dependency analysis, risk assessment, and resource optimization
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="bg-purple-100 p-2 rounded-lg">
                    <Zap className="w-4 h-4 text-purple-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Smart Execution</h4>
                    <p className="text-sm text-gray-600">
                      Self-correcting execution engine with adaptive strategies and error recovery
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BookOpen className="w-5 h-5" />
                  <span>Learning & Adaptation</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="bg-yellow-100 p-2 rounded-lg">
                    <BarChart3 className="w-4 h-4 text-yellow-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Pattern Recognition</h4>
                    <p className="text-sm text-gray-600">
                      Discovers patterns in user behavior, errors, successes, and system performance
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="bg-red-100 p-2 rounded-lg">
                    <Settings className="w-4 h-4 text-red-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Adaptive Strategies</h4>
                    <p className="text-sm text-gray-600">
                      Continuously adapts behavior based on feedback and learning outcomes
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="bg-indigo-100 p-2 rounded-lg">
                    <Lightbulb className="w-4 h-4 text-indigo-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Knowledge Growth</h4>
                    <p className="text-sm text-gray-600">
                      Builds and maintains knowledge graph for improved decision making
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="interact" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Interact with AI Agent Brain</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Enter your request:</label>
                <Textarea
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="Enter your request for the AI Agent Brain to process..."
                  className="min-h-24"
                />
              </div>
              
              <div className="flex items-center space-x-4">
                <Button 
                  onClick={processWithAIBrain} 
                  disabled={isProcessing || !inputText.trim()}
                  className="flex items-center space-x-2"
                >
                  {isProcessing ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      <span>Processing...</span>
                    </>
                  ) : (
                    <>
                      <Brain className="w-4 h-4" />
                      <span>Process with AI Brain</span>
                    </>
                  )}
                </Button>
                
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setInputText('');
                    setProcessingResult(null);
                  }}
                >
                  Clear
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quick Demo Inputs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {demoInputs.map((demo, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className="text-left justify-start h-auto p-3"
                    onClick={() => setInputText(demo.text)}
                  >
                    <div>
                      <div className="font-medium">{demo.title}</div>
                      <div className="text-xs text-gray-500 mt-1 truncate">
                        {demo.text}
                      </div>
                    </div>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="capabilities" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="text-center">
              <CardContent className="pt-6">
                <MessageSquare className="w-12 h-12 mx-auto mb-4 text-blue-600" />
                <h3 className="font-semibold mb-2">NLU Processing</h3>
                <p className="text-sm text-gray-600">
                  Tokenization, parsing, semantic analysis, intent recognition
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6">
                <Target className="w-12 h-12 mx-auto mb-4 text-green-600" />
                <h3 className="font-semibold mb-2">Task Planning</h3>
                <p className="text-sm text-gray-600">
                  Decomposition, dependencies, risk assessment, optimization
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6">
                <Zap className="w-12 h-12 mx-auto mb-4 text-purple-600" />
                <h3 className="font-semibold mb-2">Smart Execution</h3>
                <p className="text-sm text-gray-600">
                  Self-correction, adaptive strategies, error recovery
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6">
                <Shield className="w-12 h-12 mx-auto mb-4 text-red-600" />
                <h3 className="font-semibold mb-2">Verification</h3>
                <p className="text-sm text-gray-600">
                  Comprehensive testing, quality assurance, compliance
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6">
                <Network className="w-12 h-12 mx-auto mb-4 text-yellow-600" />
                <h3 className="font-semibold mb-2">API Integration</h3>
                <p className="text-sm text-gray-600">
                  Intelligent connections, data flow mapping
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6">
                <BookOpen className="w-12 h-12 mx-auto mb-4 text-indigo-600" />
                <h3 className="font-semibold mb-2">Learning</h3>
                <p className="text-sm text-gray-600">
                  Pattern recognition, adaptation, knowledge growth
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="results" className="space-y-6">
          {processingResult && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center space-x-2">
                    {processingResult.success ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-600" />
                    )}
                    <span>Processing Results</span>
                  </span>
                  <Badge variant={processingResult.success ? 'default' : 'destructive'}>
                    {processingResult.success ? 'Success' : 'Failed'}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Performance Metrics */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">
                      {processingResult.executionTime}ms
                    </div>
                    <div className="text-sm text-gray-600">Execution Time</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">
                      {(processingResult.confidence * 100).toFixed(1)}%
                    </div>
                    <div className="text-sm text-gray-600">Confidence</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">
                      {processingResult.reasoning.length}
                    </div>
                    <div className="text-sm text-gray-600">Reasoning Steps</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold text-yellow-600">
                      {processingResult.learnings.length}
                    </div>
                    <div className="text-sm text-gray-600">Learnings</div>
                  </div>
                </div>

                {/* Reasoning Steps */}
                {processingResult.reasoning.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center space-x-2">
                      <Brain className="w-4 h-4" />
                      <span>Reasoning Process</span>
                    </h4>
                    <ScrollArea className="h-32 w-full border rounded-md p-3">
                      {processingResult.reasoning.map((step, index) => (
                        <div key={index} className="text-sm py-1 border-b last:border-b-0">
                          {step}
                        </div>
                      ))}
                    </ScrollArea>
                  </div>
                )}

                {/* Learnings */}
                {processingResult.learnings.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center space-x-2">
                      <Lightbulb className="w-4 h-4" />
                      <span>Learnings & Insights</span>
                    </h4>
                    <div className="space-y-2">
                      {processingResult.learnings.map((learning, index) => (
                        <div key={index} className="flex items-start space-x-2 p-2 bg-yellow-50 rounded-lg">
                          <div className="w-2 h-2 bg-yellow-400 rounded-full mt-2 flex-shrink-0"></div>
                          <span className="text-sm">{learning}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Errors */}
                {processingResult.errors.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center space-x-2">
                      <AlertTriangle className="w-4 h-4" />
                      <span>Errors & Issues</span>
                    </h4>
                    <div className="space-y-2">
                      {processingResult.errors.map((error, index) => (
                        <div key={index} className="flex items-start space-x-2 p-2 bg-red-50 rounded-lg">
                          <div className="w-2 h-2 bg-red-400 rounded-full mt-2 flex-shrink-0"></div>
                          <span className="text-sm text-red-700">{error}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Result */}
                {processingResult.result && (
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center space-x-2">
                      <Cpu className="w-4 h-4" />
                      <span>Generated Result</span>
                    </h4>
                    <ScrollArea className="h-40 w-full border rounded-md p-3 bg-gray-50">
                      <pre className="text-sm whitespace-pre-wrap">
                        {JSON.stringify(processingResult.result, null, 2)}
                      </pre>
                    </ScrollArea>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {!processingResult && (
            <Card>
              <CardContent className="pt-6 text-center">
                <Info className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <h3 className="font-semibold mb-2">No Results Yet</h3>
                <p className="text-gray-600">
                  Interact with the AI Agent Brain to see processing results and detailed analytics.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
            </ScrollArea>
          </div>
        </div>
      </div>
    )
  );
}