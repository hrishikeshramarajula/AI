'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Send, MessageSquare, Users, Activity, Wifi, WifiOff } from 'lucide-react';

interface WebSocketMessage {
  id: string;
  type: 'user' | 'system' | 'ai';
  content: string;
  timestamp: Date;
  userId?: string;
}

interface RoomInfo {
  id: string;
  name: string;
  users: string[];
  messageCount: number;
}

export default function WebSocketExample() {
  const [isConnected, setIsConnected] = useState(false);
  const [currentRoom, setCurrentRoom] = useState('general');
  const [messages, setMessages] = useState<WebSocketMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [rooms, setRooms] = useState<RoomInfo[]>([
    { id: 'general', name: 'General Chat', users: [], messageCount: 0 },
    { id: 'ai-help', name: 'AI Help', users: [], messageCount: 0 },
    { id: 'code-review', name: 'Code Review', users: [], messageCount: 0 },
  ]);
  const [onlineUsers, setOnlineUsers] = useState(0);
  const [connectionStatus, setConnectionStatus] = useState('disconnected');
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const socketRef = useRef<WebSocket | null>(null);

  // Initialize WebSocket connection
  useEffect(() => {
    const connectWebSocket = () => {
      try {
        // For demo purposes, we'll simulate WebSocket events
        // In a real implementation, you would connect to an actual WebSocket server
        simulateWebSocketConnection();
      } catch (error) {
        console.error('Failed to connect to WebSocket:', error);
        setConnectionStatus('error');
      }
    };

    connectWebSocket();

    // Cleanup on unmount
    return () => {
      if (socketRef.current) {
        socketRef.current.close();
      }
    };
  }, []);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const simulateWebSocketConnection = () => {
    setConnectionStatus('connecting');
    
    // Simulate connection delay
    setTimeout(() => {
      setIsConnected(true);
      setConnectionStatus('connected');
      setOnlineUsers(Math.floor(Math.random() * 50) + 10);
      
      // Add welcome message
      addMessage({
        id: Date.now().toString(),
        type: 'system',
        content: 'Welcome to the WebSocket demo! You are now connected.',
        timestamp: new Date(),
      });

      // Simulate periodic AI messages
      const aiMessageInterval = setInterval(() => {
        if (Math.random() > 0.7) { // 30% chance every 10 seconds
          simulateAIMessage();
        }
      }, 10000);

      // Simulate user count changes
      const userCountInterval = setInterval(() => {
        setOnlineUsers(prev => {
          const change = Math.floor(Math.random() * 5) - 2; // -2 to +2
          return Math.max(1, prev + change);
        });
      }, 15000);

      // Store interval IDs for cleanup
      (window as any).aiMessageInterval = aiMessageInterval;
      (window as any).userCountInterval = userCountInterval;
    }, 1000);
  };

  const simulateAIMessage = () => {
    const aiMessages = [
      "🤖 AI Tip: Try asking me about code generation, image creation, or web search!",
      "🚀 Did you know? This platform supports multiple AI providers including OpenAI, Anthropic, and Google.",
      "💡 Pro tip: Use the autonomous agent mode for complex tasks that require multiple steps.",
      "🎨 You can generate images by switching to image mode and describing what you want to create.",
      "🔍 The web search mode can help you get current information on any topic.",
    ];

    const randomMessage = aiMessages[Math.floor(Math.random() * aiMessages.length)];
    
    addMessage({
      id: Date.now().toString(),
      type: 'ai',
      content: randomMessage,
      timestamp: new Date(),
    });
  };

  const addMessage = (message: WebSocketMessage) => {
    setMessages(prev => [...prev, message]);
    
    // Update room message count
    setRooms(prev => prev.map(room => 
      room.id === currentRoom 
        ? { ...room, messageCount: room.messageCount + 1 }
        : room
    ));
  };

  const sendMessage = () => {
    if (!inputMessage.trim()) return;

    const message: WebSocketMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: inputMessage,
      timestamp: new Date(),
      userId: 'current-user',
    };

    addMessage(message);
    setInputMessage('');

    // Simulate server response
    setTimeout(() => {
      if (inputMessage.toLowerCase().includes('help')) {
        addMessage({
          id: Date.now().toString(),
          type: 'system',
          content: 'I can help you with AI-powered development tasks. Try asking about code generation, image creation, or web search!',
          timestamp: new Date(),
        });
      } else if (inputMessage.toLowerCase().includes('ai')) {
        addMessage({
          id: Date.now().toString(),
          type: 'ai',
          content: '🤖 AI Assistant: I\'m here to help! What would you like to know about AI capabilities?',
          timestamp: new Date(),
        });
      }
    }, 500);
  };

  const joinRoom = (roomId: string) => {
    setCurrentRoom(roomId);
    setMessages([]); // Clear messages when switching rooms
    
    addMessage({
      id: Date.now().toString(),
      type: 'system',
      content: `You joined the ${rooms.find(r => r.id === roomId)?.name} room.`,
      timestamp: new Date(),
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const getStatusColor = () => {
    switch (connectionStatus) {
      case 'connected': return 'bg-green-500';
      case 'connecting': return 'bg-yellow-500';
      case 'error': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = () => {
    switch (connectionStatus) {
      case 'connected': return 'Connected';
      case 'connecting': return 'Connecting...';
      case 'error': return 'Connection Error';
      default: return 'Disconnected';
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-80 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center gap-3 mb-4">
            <div className={`w-3 h-3 rounded-full ${getStatusColor()}`}></div>
            <h2 className="text-lg font-semibold">WebSocket Demo</h2>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Status</span>
              <Badge variant={connectionStatus === 'connected' ? 'default' : 'secondary'}>
                {getStatusText()}
              </Badge>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Online Users</span>
              <Badge variant="outline">{onlineUsers}</Badge>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Current Room</span>
              <Badge variant="outline">{currentRoom}</Badge>
            </div>
          </div>
        </div>

        <div className="flex-1 p-6">
          <h3 className="text-sm font-semibold text-gray-900 mb-3">Chat Rooms</h3>
          <div className="space-y-2">
            {rooms.map((room) => (
              <button
                key={room.id}
                onClick={() => joinRoom(room.id)}
                className={`w-full text-left p-3 rounded-lg border transition-colors ${
                  currentRoom === room.id
                    ? 'bg-blue-50 border-blue-200 text-blue-900'
                    : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-medium">{room.name}</span>
                  <Users className="w-4 h-4 text-gray-500" />
                </div>
                <div className="text-xs text-gray-500">
                  {room.messageCount} messages
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="p-6 border-t border-gray-200">
          <div className="text-xs text-gray-500 space-y-1">
            <div className="flex items-center gap-2">
              <Activity className="w-3 h-3" />
              <span>Real-time communication</span>
            </div>
            <div className="flex items-center gap-2">
              <MessageSquare className="w-3 h-3" />
              <span>Multiple chat rooms</span>
            </div>
            <div className="flex items-center gap-2">
              <Send className="w-3 h-3" />
              <span>Instant messaging</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        <div className="bg-white border-b border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-semibold text-gray-900">
                {rooms.find(r => r.id === currentRoom)?.name}
              </h1>
              <p className="text-sm text-gray-600">
                Real-time chat with WebSocket technology
              </p>
            </div>
            <div className="flex items-center gap-2">
              {isConnected ? (
                <Wifi className="w-5 h-5 text-green-500" />
              ) : (
                <WifiOff className="w-5 h-5 text-red-500" />
              )}
              <span className="text-sm text-gray-600">
                {onlineUsers} users online
              </span>
            </div>
          </div>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-hidden">
          <ScrollArea className="h-full">
            <div className="max-w-4xl mx-auto p-6 space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-3 ${
                    message.type === 'user' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  {message.type !== 'user' && (
                    <div className="flex-shrink-0">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-medium ${
                        message.type === 'system' ? 'bg-gray-500' : 'bg-purple-500'
                      }`}>
                        {message.type === 'system' ? 'S' : 'AI'}
                      </div>
                    </div>
                  )}
                  
                  <div
                    className={`max-w-md lg:max-w-lg xl:max-w-xl rounded-lg px-4 py-3 ${
                      message.type === 'user'
                        ? 'bg-blue-500 text-white'
                        : message.type === 'ai'
                        ? 'bg-purple-100 text-purple-900'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                  >
                    <div className="text-sm">{message.content}</div>
                    <div
                      className={`text-xs mt-1 ${
                        message.type === 'user' ? 'text-blue-100' : 'text-gray-500'
                      }`}
                    >
                      {formatTime(message.timestamp)}
                    </div>
                  </div>
                  
                  {message.type === 'user' && (
                    <div className="flex-shrink-0">
                      <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white text-sm font-medium">
                        U
                      </div>
                    </div>
                  )}
                </div>
              ))}
              
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>
        </div>

        {/* Input Area */}
        <div className="bg-white border-t border-gray-200 p-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex gap-3">
              <Input
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type your message..."
                className="flex-1"
                disabled={!isConnected}
              />
              <Button
                onClick={sendMessage}
                disabled={!isConnected || !inputMessage.trim()}
                className="px-6"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            
            <div className="mt-3 text-xs text-gray-500">
              <div className="flex items-center gap-4">
                <span>Press Enter to send</span>
                <span>•</span>
                <span>Connected to WebSocket server</span>
                <span>•</span>
                <span>Real-time messaging enabled</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}