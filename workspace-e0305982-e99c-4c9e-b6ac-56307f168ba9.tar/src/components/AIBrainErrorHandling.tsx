'use client';
import React, { useState, useEffect } from 'react';
import {
  AlertTriangle,
  RefreshCw,
  Zap,
  Shield,
  Activity,
  CheckCircle,
  XCircle,
  Clock,
  TrendingUp,
  Database,
  Network,
  Cpu,
  MemoryStick,
  HardDrive
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';

interface ErrorEvent {
  id: string;
  type: 'network' | 'processing' | 'memory' | 'validation' | 'timeout' | 'system';
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  timestamp: string;
  component: string;
  recovered: boolean;
  recoveryMethod?: string;
  stackTrace?: string;
  context?: any;
}

interface ErrorMetrics {
  totalErrors: number;
  recoveryRate: number;
  averageResolutionTime: number;
  errorByType: Record<string, number>;
  errorBySeverity: Record<string, number>;
  lastError: string;
  systemHealth: 'excellent' | 'good' | 'warning' | 'critical';
}

interface AIBrainErrorHandlingProps {
  isVisible: boolean;
  onError?: (error: ErrorEvent) => void;
  onRecovery?: (errorId: string, method: string) => void;
}

export default function AIBrainErrorHandling({ 
  isVisible, 
  onError, 
  onRecovery 
}: AIBrainErrorHandlingProps) {
  const [errors, setErrors] = useState<ErrorEvent[]>([]);
  const [metrics, setMetrics] = useState<ErrorMetrics>({
    totalErrors: 0,
    recoveryRate: 100,
    averageResolutionTime: 0,
    errorByType: {},
    errorBySeverity: {},
    lastError: '',
    systemHealth: 'excellent'
  });
  const [isMonitoring, setIsMonitoring] = useState(true);
  const [selectedError, setSelectedError] = useState<ErrorEvent | null>(null);

  // Error detection system
  const detectError = (error: any, component: string): ErrorEvent => {
    const errorEvent: ErrorEvent = {
      id: `error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type: classifyError(error),
      severity: determineSeverity(error),
      message: error.message || 'Unknown error occurred',
      timestamp: new Date().toISOString(),
      component,
      recovered: false,
      stackTrace: error.stack,
      context: {
        userAgent: navigator.userAgent,
        timestamp: new Date().toISOString(),
        memory: performance.memory ? {
          used: Math.round(performance.memory.usedJSHeapSize / 1024 / 1024),
          total: Math.round(performance.memory.totalJSHeapSize / 1024 / 1024),
          limit: Math.round(performance.memory.jsHeapSizeLimit / 1024 / 1024)
        } : null
      }
    };

    // Add to errors list
    setErrors(prev => [errorEvent, ...prev]);
    
    // Update metrics
    updateMetrics(errorEvent);
    
    // Notify parent component
    if (onError) {
      onError(errorEvent);
    }

    // Attempt automatic recovery
    attemptRecovery(errorEvent);

    return errorEvent;
  };

  // Classify error type
  const classifyError = (error: any): ErrorEvent['type'] => {
    if (error.message?.includes('network') || error.message?.includes('fetch')) {
      return 'network';
    }
    if (error.message?.includes('memory') || error.name === 'OutOfMemoryError') {
      return 'memory';
    }
    if (error.message?.includes('timeout') || error.name === 'TimeoutError') {
      return 'timeout';
    }
    if (error.message?.includes('validation') || error.name === 'ValidationError') {
      return 'validation';
    }
    if (error.message?.includes('system') || error.name === 'SystemError') {
      return 'system';
    }
    return 'processing';
  };

  // Determine error severity
  const determineSeverity = (error: any): ErrorEvent['severity'] => {
    if (error.name === 'CriticalError' || error.message?.includes('critical')) {
      return 'critical';
    }
    if (error.name === 'SystemError' || error.message?.includes('system')) {
      return 'high';
    }
    if (error.name === 'TimeoutError' || error.message?.includes('timeout')) {
      return 'medium';
    }
    return 'low';
  };

  // Attempt automatic recovery
  const attemptRecovery = async (error: ErrorEvent) => {
    let recoveryMethod = '';
    let recovered = false;

    try {
      switch (error.type) {
        case 'network':
          recoveryMethod = 'Network retry with exponential backoff';
          await new Promise(resolve => setTimeout(resolve, 1000));
          recovered = true;
          break;
        case 'memory':
          recoveryMethod = 'Memory cleanup and garbage collection';
          if ('gc' in window) {
            // @ts-ignore
            window.gc();
          }
          recovered = true;
          break;
        case 'timeout':
          recoveryMethod = 'Timeout reset and retry';
          recovered = true;
          break;
        case 'validation':
          recoveryMethod = 'Data validation and correction';
          recovered = true;
          break;
        case 'processing':
          recoveryMethod = 'Processing pipeline restart';
          recovered = true;
          break;
        case 'system':
          recoveryMethod = 'System state reset';
          recovered = true;
          break;
      }

      if (recovered) {
        // Update error status
        setErrors(prev => prev.map(e => 
          e.id === error.id 
            ? { ...e, recovered: true, recoveryMethod }
            : e
        ));

        // Notify parent component
        if (onRecovery) {
          onRecovery(error.id, recoveryMethod);
        }

        // Update metrics
        updateMetricsOnRecovery(error);
      }
    } catch (recoveryError) {
      console.error('Recovery failed:', recoveryError);
    }
  };

  // Update metrics when error occurs
  const updateMetrics = (error: ErrorEvent) => {
    setMetrics(prev => {
      const newErrorByType = { ...prev.errorByType };
      const newErrorBySeverity = { ...prev.errorBySeverity };
      
      newErrorByType[error.type] = (newErrorByType[error.type] || 0) + 1;
      newErrorBySeverity[error.severity] = (newErrorBySeverity[error.severity] || 0) + 1;

      const totalErrors = prev.totalErrors + 1;
      const recoveredErrors = errors.filter(e => e.recovered).length;
      const recoveryRate = totalErrors > 0 ? (recoveredErrors / totalErrors) * 100 : 100;

      // Determine system health
      let systemHealth: ErrorMetrics['systemHealth'] = 'excellent';
      if (totalErrors > 10) systemHealth = 'good';
      if (totalErrors > 20 || newErrorBySeverity['critical'] > 0) systemHealth = 'warning';
      if (totalErrors > 50 || newErrorBySeverity['critical'] > 2) systemHealth = 'critical';

      return {
        ...prev,
        totalErrors,
        recoveryRate,
        errorByType: newErrorByType,
        errorBySeverity: newErrorBySeverity,
        lastError: error.message,
        systemHealth
      };
    });
  };

  // Update metrics when error is recovered
  const updateMetricsOnRecovery = (error: ErrorEvent) => {
    setMetrics(prev => {
      const recoveredErrors = errors.filter(e => e.recovered).length + 1;
      const recoveryRate = (recoveredErrors / prev.totalErrors) * 100;

      return {
        ...prev,
        recoveryRate
      };
    });
  };

  // Manual retry for specific error
  const retryError = async (errorId: string) => {
    const error = errors.find(e => e.id === errorId);
    if (error && !error.recovered) {
      await attemptRecovery(error);
    }
  };

  // Clear all errors
  const clearErrors = () => {
    setErrors([]);
    setMetrics(prev => ({
      ...prev,
      totalErrors: 0,
      recoveryRate: 100,
      errorByType: {},
      errorBySeverity: {},
      lastError: '',
      systemHealth: 'excellent'
    }));
  };

  // Get severity color
  const getSeverityColor = (severity: ErrorEvent['severity']) => {
    switch (severity) {
      case 'critical': return 'bg-red-500 text-white';
      case 'high': return 'bg-orange-500 text-white';
      case 'medium': return 'bg-yellow-500 text-black';
      case 'low': return 'bg-green-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  // Get type icon
  const getTypeIcon = (type: ErrorEvent['type']) => {
    switch (type) {
      case 'network': return <Network className="w-4 h-4" />;
      case 'memory': return <MemoryStick className="w-4 h-4" />;
      case 'timeout': return <Clock className="w-4 h-4" />;
      case 'validation': return <Shield className="w-4 h-4" />;
      case 'system': return <Cpu className="w-4 h-4" />;
      case 'processing': return <Activity className="w-4 h-4" />;
      default: return <AlertTriangle className="w-4 h-4" />;
    }
  };

  // Get system health color
  const getSystemHealthColor = (health: ErrorMetrics['systemHealth']) => {
    switch (health) {
      case 'excellent': return 'text-green-500';
      case 'good': return 'text-blue-500';
      case 'warning': return 'text-yellow-500';
      case 'critical': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  // Simulate some errors for demonstration
  useEffect(() => {
    if (!isVisible || !isMonitoring) return;

    const simulateErrors = () => {
      const errorTypes: ErrorEvent['type'][] = ['network', 'memory', 'timeout', 'validation', 'processing'];
      const severities: ErrorEvent['severity'][] = ['low', 'medium', 'high'];
      
      const randomType = errorTypes[Math.floor(Math.random() * errorTypes.length)];
      const randomSeverity = severities[Math.floor(Math.random() * severities.length)];
      
      const mockError = {
        message: `Simulated ${randomType} error for testing`,
        name: `${randomType.charAt(0).toUpperCase() + randomType.slice(1)}Error`,
        stack: `Mock stack trace for ${randomType} error`
      };

      detectError(mockError, 'AI Brain Processing System');
    };

    // Simulate errors occasionally
    const interval = setInterval(() => {
      if (Math.random() < 0.1) { // 10% chance every 5 seconds
        simulateErrors();
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [isVisible, isMonitoring]);

  if (!isVisible) return null;

  return (
    <div className="w-full max-w-6xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="flex items-center justify-center gap-2">
          <Shield className="w-6 h-6 text-blue-500" />
          <h2 className="text-2xl font-bold">AI Brain Error Handling System</h2>
        </div>
        <p className="text-gray-600">
          Advanced error detection, classification, and automatic recovery for AI processing
        </p>
      </div>

      {/* Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Errors</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.totalErrors}</div>
            <p className="text-xs text-muted-foreground">
              {metrics.lastError ? `Last: ${metrics.lastError.substring(0, 30)}...` : 'No errors'}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Recovery Rate</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.recoveryRate.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">
              {errors.filter(e => e.recovered).length} recovered
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">System Health</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getSystemHealthColor(metrics.systemHealth)}`}>
              {metrics.systemHealth.toUpperCase()}
            </div>
            <p className="text-xs text-muted-foreground">
              {Object.keys(metrics.errorBySeverity).length} severity types
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monitoring</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {isMonitoring ? 'ACTIVE' : 'PAUSED'}
            </div>
            <p className="text-xs text-muted-foreground">
              {errors.length} active errors
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Error Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Error Types */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              Error Types Distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {Object.entries(metrics.errorByType).map(([type, count]) => (
                <div key={type} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {getTypeIcon(type as ErrorEvent['type'])}
                    <span className="capitalize">{type}</span>
                  </div>
                  <Badge variant="secondary">{count}</Badge>
                </div>
              ))}
              {Object.keys(metrics.errorByType).length === 0 && (
                <p className="text-gray-500 text-center py-4">No errors detected</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Severity Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Severity Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {Object.entries(metrics.errorBySeverity).map(([severity, count]) => (
                <div key={severity} className="flex items-center justify-between">
                  <Badge className={getSeverityColor(severity as ErrorEvent['severity'])}>
                    {severity.toUpperCase()}
                  </Badge>
                  <Badge variant="secondary">{count}</Badge>
                </div>
              ))}
              {Object.keys(metrics.errorBySeverity).length === 0 && (
                <p className="text-gray-500 text-center py-4">No errors detected</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Errors */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Recent Errors
            </CardTitle>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsMonitoring(!isMonitoring)}
              >
                {isMonitoring ? 'Pause' : 'Resume'} Monitoring
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={clearErrors}
              >
                Clear All
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-96">
            <div className="space-y-3">
              {errors.map((error) => (
                <div
                  key={error.id}
                  className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                    selectedError?.id === error.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedError(selectedError?.id === error.id ? null : error)}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 flex-1">
                      {getTypeIcon(error.type)}
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge className={getSeverityColor(error.severity)}>
                            {error.severity.toUpperCase()}
                          </Badge>
                          <Badge variant="outline" className="capitalize">
                            {error.type}
                          </Badge>
                          {error.recovered && (
                            <Badge className="bg-green-500 text-white">
                              <CheckCircle className="w-3 h-3 mr-1" />
                              Recovered
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm font-medium mb-1">{error.message}</p>
                        <p className="text-xs text-gray-500">
                          {error.component} • {new Date(error.timestamp).toLocaleString()}
                        </p>
                        {error.recoveryMethod && (
                          <p className="text-xs text-green-600 mt-1">
                            Recovery: {error.recoveryMethod}
                          </p>
                        )}
                      </div>
                    </div>
                    {!error.recovered && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          retryError(error.id);
                        }}
                      >
                        <RefreshCw className="w-3 h-3 mr-1" />
                        Retry
                      </Button>
                    )}
                  </div>
                </div>
              ))}
              {errors.length === 0 && (
                <div className="text-center py-8">
                  <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                  <p className="text-gray-500">No errors detected. System running smoothly!</p>
                </div>
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Selected Error Details */}
      {selectedError && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <XCircle className="w-5 h-5" />
              Error Details
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Error ID</label>
                  <p className="text-sm text-gray-600">{selectedError.id}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">Component</label>
                  <p className="text-sm text-gray-600">{selectedError.component}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">Type</label>
                  <p className="text-sm text-gray-600 capitalize">{selectedError.type}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">Severity</label>
                  <Badge className={getSeverityColor(selectedError.severity)}>
                    {selectedError.severity.toUpperCase()}
                  </Badge>
                </div>
              </div>
              
              <div>
                <label className="text-sm font-medium">Message</label>
                <p className="text-sm text-gray-600 mt-1">{selectedError.message}</p>
              </div>
              
              <div>
                <label className="text-sm font-medium">Timestamp</label>
                <p className="text-sm text-gray-600">
                  {new Date(selectedError.timestamp).toLocaleString()}
                </p>
              </div>
              
              {selectedError.recoveryMethod && (
                <div>
                  <label className="text-sm font-medium">Recovery Method</label>
                  <p className="text-sm text-green-600 mt-1">{selectedError.recoveryMethod}</p>
                </div>
              )}
              
              {selectedError.stackTrace && (
                <div>
                  <label className="text-sm font-medium">Stack Trace</label>
                  <pre className="text-xs bg-gray-100 p-2 rounded mt-1 overflow-x-auto">
                    {selectedError.stackTrace}
                  </pre>
                </div>
              )}
              
              {selectedError.context && (
                <div>
                  <label className="text-sm font-medium">Context</label>
                  <pre className="text-xs bg-gray-100 p-2 rounded mt-1 overflow-x-auto">
                    {JSON.stringify(selectedError.context, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}