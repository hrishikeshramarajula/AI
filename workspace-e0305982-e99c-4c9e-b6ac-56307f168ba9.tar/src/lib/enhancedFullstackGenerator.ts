// Enhanced Fullstack Application Generator - Creates complete frontend + backend from single text prompts
import { safeZAIChatCompletion } from './zaiHelper';
import { FullstackProject, GeneratedFile, ProjectStructure } from './fullstackGenerator';

interface EnhancedFullstackRequest {
  prompt: string;
  context?: {
    userPreferences?: {
      styling?: 'tailwind' | 'bootstrap' | 'css';
      database?: 'sqlite' | 'postgresql' | 'mongodb';
      auth?: 'none' | 'simple' | 'advanced';
    };
    technicalLevel?: 'beginner' | 'intermediate' | 'advanced';
  };
}

interface LivePreviewConfig {
  port: number;
  autoRefresh: boolean;
  showCode: boolean;
  showConsole: boolean;
  previewUrl: string;
}

export class EnhancedFullstackGenerator {
  
  /**
   * Main entry point - takes single text prompt and generates complete fullstack application
   */
  static async generateFromSinglePrompt(prompt: string, context?: EnhancedFullstackRequest['context']): Promise<{
    project: FullstackProject;
    previewUrl: string;
    setupCommands: string[];
    estimatedTime: string;
    features: string[];
  }> {
    console.log('🚀 Enhanced Fullstack Generation for:', prompt);
    
    // Step 1: Analyze the prompt with AI to understand requirements
    const analysis = await this.analyzePromptWithAI(prompt, context);
    
    // Step 2: Generate complete project structure
    const project = await this.generateCompleteProject(analysis, prompt);
    
    // Step 3: Create live preview configuration
    const previewConfig = this.generatePreviewConfig(project);
    
    // Step 4: Generate setup instructions
    const setupCommands = this.generateSetupCommands(project);
    
    return {
      project,
      previewUrl: previewConfig.previewUrl,
      setupCommands,
      estimatedTime: this.estimateSetupTime(project),
      features: analysis.features
    };
  }
  
  /**
   * Use AI to deeply analyze the prompt and extract technical requirements
   */
  private static async analyzePromptWithAI(prompt: string, context?: EnhancedFullstackRequest['context']) {
    try {
      const analysisPrompt = `
You are an expert fullstack developer. Analyze this user request and extract detailed technical requirements:

User Request: "${prompt}"

Context: ${JSON.stringify(context || {})}

Please provide a JSON response with:
1. projectType: The type of application (todo, blog, ecommerce, dashboard, custom, etc.)
2. features: Array of specific features needed
3. database: Database requirements (sqlite, postgresql, mongodb, none)
4. authentication: Auth requirements (none, simple, advanced)
5. styling: Styling preference (tailwind, bootstrap, css)
6. complexity: simple, medium, or complex
7. components: Array of UI components needed
8. apiEndpoints: Array of API endpoints needed
9. pages: Array of pages/routes needed

Example response format:
{
  "projectType": "todo-app",
  "features": ["crud", "real-time", "responsive", "localStorage"],
  "database": "sqlite",
  "authentication": "simple",
  "styling": "tailwind",
  "complexity": "simple",
  "components": ["todo-list", "todo-item", "todo-form", "stats-display"],
  "apiEndpoints": ["/api/todos", "/api/todos/[id]"],
  "pages": ["/", "/stats"]
}
`;

      const messages = [
        {
          role: 'system',
          content: 'You are an expert fullstack developer who analyzes user requests and extracts detailed technical requirements in JSON format.'
        },
        {
          role: 'user',
          content: analysisPrompt
        }
      ];

      const response = await safeZAIChatCompletion(messages, {
        temperature: 0.3,
        max_tokens: 1000
      });

      let analysis;
      try {
        // Extract JSON from response
        const jsonMatch = response.choices[0].message.content.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          analysis = JSON.parse(jsonMatch[0]);
        } else {
          throw new Error('No JSON found in response');
        }
      } catch (parseError) {
        console.error('Failed to parse AI analysis:', parseError);
        // Fallback to basic analysis
        analysis = this.fallbackAnalysis(prompt, context);
      }

      return analysis;
    } catch (error) {
      console.error('AI analysis failed:', error);
      return this.fallbackAnalysis(prompt, context);
    }
  }
  
  /**
   * Fallback analysis when AI is not available
   */
  private static fallbackAnalysis(prompt: string, context?: EnhancedFullstackRequest['context']) {
    const lowerPrompt = prompt.toLowerCase();
    
    // Basic keyword detection
    const projectTypes = {
      'todo': 'todo-app',
      'task': 'todo-app',
      'blog': 'blog-cms',
      'cms': 'blog-cms',
      'ecommerce': 'ecommerce-platform',
      'shop': 'ecommerce-platform',
      'dashboard': 'admin-dashboard',
      'admin': 'admin-dashboard',
      'chat': 'chat-application',
      'messaging': 'chat-application'
    };
    
    let projectType = 'custom-web-app';
    for (const [keyword, type] of Object.entries(projectTypes)) {
      if (lowerPrompt.includes(keyword)) {
        projectType = type;
        break;
      }
    }
    
    return {
      projectType,
      features: this.extractFeatures(lowerPrompt),
      database: context?.userPreferences?.database || 'sqlite',
      authentication: context?.userPreferences?.auth || 'simple',
      styling: context?.userPreferences?.styling || 'tailwind',
      complexity: this.determineComplexity(lowerPrompt),
      components: this.suggestComponents(projectType),
      apiEndpoints: this.suggestAPIEndpoints(projectType),
      pages: this.suggestPages(projectType)
    };
  }
  
  /**
   * Extract features from prompt
   */
  private static extractFeatures(prompt: string): string[] {
    const featureMap = {
      'auth': 'authentication',
      'login': 'authentication',
      'register': 'authentication',
      'user': 'authentication',
      'real-time': 'real-time',
      'live': 'real-time',
      'websocket': 'real-time',
      'socket': 'real-time',
      'database': 'database',
      'storage': 'database',
      'persist': 'database',
      'responsive': 'responsive',
      'mobile': 'responsive',
      'api': 'api',
      'rest': 'api',
      'endpoint': 'api',
      'modern': 'modern-ui',
      'ui': 'modern-ui',
      'design': 'modern-ui',
      'chart': 'charts',
      'graph': 'charts',
      'analytics': 'charts',
      'file': 'file-upload',
      'upload': 'file-upload',
      'image': 'file-upload',
      'search': 'search',
      'filter': 'search',
      'pagination': 'pagination',
      'page': 'pagination',
      'form': 'forms',
      'input': 'forms',
      'validation': 'forms',
      'notification': 'notifications',
      'alert': 'notifications',
      'toast': 'notifications'
    };
    
    const features: string[] = [];
    for (const [keyword, feature] of Object.entries(featureMap)) {
      if (prompt.includes(keyword) && !features.includes(feature)) {
        features.push(feature);
      }
    }
    
    return features.length > 0 ? features : ['responsive', 'modern-ui'];
  }
  
  /**
   * Determine complexity based on prompt
   */
  private static determineComplexity(prompt: string): 'simple' | 'medium' | 'complex' {
    const complexKeywords = ['advanced', 'complex', 'enterprise', 'scale', 'multiple', 'integration'];
    const simpleKeywords = ['simple', 'basic', 'quick', 'easy', 'minimal'];
    
    if (complexKeywords.some(keyword => prompt.includes(keyword))) {
      return 'complex';
    } else if (simpleKeywords.some(keyword => prompt.includes(keyword))) {
      return 'simple';
    } else {
      return 'medium';
    }
  }
  
  /**
   * Suggest components based on project type
   */
  private static suggestComponents(projectType: string): string[] {
    const componentMap = {
      'todo-app': ['todo-list', 'todo-item', 'todo-form', 'stats-display', 'filter-buttons'],
      'blog-cms': ['post-list', 'post-detail', 'comment-form', 'author-profile', 'category-nav'],
      'ecommerce-platform': ['product-grid', 'product-card', 'shopping-cart', 'checkout-form', 'user-profile'],
      'admin-dashboard': ['data-table', 'chart-component', 'sidebar-nav', 'user-management', 'settings-panel'],
      'chat-application': ['message-list', 'message-input', 'user-list', 'online-status', 'typing-indicator'],
      'custom-web-app': ['main-layout', 'navigation', 'content-area', 'user-menu', 'footer']
    };
    
    return componentMap[projectType as keyof typeof componentMap] || componentMap['custom-web-app'];
  }
  
  /**
   * Suggest API endpoints based on project type
   */
  private static suggestAPIEndpoints(projectType: string): string[] {
    const endpointMap = {
      'todo-app': ['/api/todos', '/api/todos/[id]', '/api/todos/stats'],
      'blog-cms': ['/api/posts', '/api/posts/[id]', '/api/comments', '/api/users'],
      'ecommerce-platform': ['/api/products', '/api/cart', '/api/orders', '/api/users'],
      'admin-dashboard': ['/api/data', '/api/users', '/api/settings', '/api/reports'],
      'chat-application': ['/api/messages', '/api/users', '/api/rooms'],
      'custom-web-app': ['/api/items', '/api/items/[id]']
    };
    
    return endpointMap[projectType as keyof typeof endpointMap] || endpointMap['custom-web-app'];
  }
  
  /**
   * Suggest pages based on project type
   */
  private static suggestPages(projectType: string): string[] {
    const pageMap = {
      'todo-app': ['/', '/stats'],
      'blog-cms': ['/', '/post/[id]', '/admin'],
      'ecommerce-platform': ['/', '/product/[id]', '/cart', '/checkout'],
      'admin-dashboard': ['/dashboard', '/users', '/settings'],
      'chat-application': ['/', '/chat/[room]'],
      'custom-web-app': ['/', '/about']
    };
    
    return pageMap[projectType as keyof typeof pageMap] || pageMap['custom-web-app'];
  }
  
  /**
   * Generate complete project based on analysis
   */
  private static async generateCompleteProject(analysis: any, originalPrompt: string): Promise<FullstackProject> {
    const files: GeneratedFile[] = [];
    
    // Create project structure
    const projectStructure: ProjectStructure = {
      name: analysis.projectType,
      description: `A ${analysis.complexity} ${analysis.projectType} with features: ${analysis.features.join(', ')}`,
      type: 'fullstack',
      framework: 'nextjs',
      database: analysis.database,
      features: analysis.features
    };
    
    // Generate database schema
    const dbFiles = this.generateDatabaseSchema(analysis);
    files.push(...dbFiles);
    
    // Generate API routes
    const apiFiles = this.generateAPIRoutes(analysis);
    files.push(...apiFiles);
    
    // Generate frontend components
    const frontendFiles = this.generateFrontendComponents(analysis);
    files.push(...frontendFiles);
    
    // Generate main page
    const mainPage = this.generateMainPage(analysis, originalPrompt);
    files.push(mainPage);
    
    // Generate configuration files
    const configFiles = this.generateConfigFiles(analysis);
    files.push(...configFiles);
    
    // Generate documentation
    const docsFiles = this.generateDocumentation(analysis, originalPrompt);
    files.push(...docsFiles);
    
    return {
      structure: projectStructure,
      files,
      setupInstructions: this.generateSetupInstructions(analysis),
      dependencies: this.generateDependencies(analysis),
      devDependencies: this.generateDevDependencies(analysis),
      scripts: this.generateScripts(analysis)
    };
  }
  
  /**
   * Generate database schema based on analysis
   */
  private static generateDatabaseSchema(analysis: any): GeneratedFile[] {
    const files: GeneratedFile[] = [];
    
    let prismaSchema = `// This is your Prisma schema file,
// learn more about it in the docs: https://pris.ly/d/prisma-schema

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "${analysis.database === 'postgresql' ? 'postgresql' : 'sqlite'}"
  url      = env("DATABASE_URL")
}
`;
    
    // Add models based on project type
    if (analysis.projectType === 'todo-app') {
      prismaSchema += `
model Todo {
  id          String   @id @default(cuid())
  text        String
  completed   Boolean  @default(false)
  userId      String?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  
  user        User?    @relation(fields: [userId], references: [id])
  
  @@map("todos")
}

model User {
  id        String   @id @default(cuid())
  email     String   @unique
  name      String?
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  
  todos     Todo[]
  
  @@map("users")
}
`;
    } else if (analysis.projectType === 'blog-cms') {
      prismaSchema += `
model Post {
  id          String   @id @default(cuid())
  title       String
  content     String
  published   Boolean  @default(false)
  authorId    String
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  
  author      User     @relation(fields: [authorId], references: [id])
  comments    Comment[]
  
  @@map("posts")
}

model Comment {
  id        String   @id @default(cuid())
  content   String
  author    String?
  postId    String
  createdAt DateTime @default(now())
  
  post      Post     @relation(fields: [postId], references: [id])
  
  @@map("comments")
}

model User {
  id        String   @id @default(cuid())
  email     String   @unique
  name      String?
  bio       String?
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  
  posts     Post[]
  
  @@map("users")
}
`;
    } else {
      // Generic models
      prismaSchema += `
model Item {
  id          String   @id @default(cuid())
  title       String
  description String?
  completed   Boolean  @default(false)
  userId      String?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  
  user        User?    @relation(fields: [userId], references: [id])
  
  @@map("items")
}

model User {
  id        String   @id @default(cuid())
  email     String   @unique
  name      String?
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  
  items     Item[]
  
  @@map("users")
}
`;
    }
    
    files.push({
      path: 'prisma/schema.prisma',
      content: prismaSchema,
      type: 'database'
    });
    
    // Database client
    files.push({
      path: 'src/lib/db.ts',
      content: `import { PrismaClient } from '@prisma/client';

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const db = globalForPrisma.prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db;
`,
      type: 'backend'
    });
    
    return files;
  }
  
  /**
   * Generate API routes based on analysis
   */
  private static generateAPIRoutes(analysis: any): GeneratedFile[] {
    const files: GeneratedFile[] = [];
    
    if (analysis.projectType === 'todo-app') {
      files.push({
        path: 'src/app/api/todos/route.ts',
        content: `import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/todos - Fetch all todos
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const filter = searchParams.get('filter') || 'all';
    
    let whereClause = {};
    
    if (filter === 'active') {
      whereClause = { completed: false };
    } else if (filter === 'completed') {
      whereClause = { completed: true };
    }
    
    const todos = await db.todo.findMany({
      where: whereClause,
      orderBy: { createdAt: 'desc' }
    });
    
    // Calculate stats
    const stats = await db.todo.groupBy({
      by: ['completed'],
      _count: { completed: true }
    });
    
    const totalTodos = stats.reduce((sum, stat) => sum + stat._count.completed, 0);
    const completedTodos = stats.find(stat => stat.completed)?._count.completed || 0;
    const activeTodos = totalTodos - completedTodos;
    
    return NextResponse.json({
      todos,
      stats: {
        total: totalTodos,
        completed: completedTodos,
        active: activeTodos
      }
    });
    
  } catch (error) {
    console.error('Error fetching todos:', error);
    return NextResponse.json(
      { error: 'Failed to fetch todos' },
      { status: 500 }
    );
  }
}

// POST /api/todos - Create new todo
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { text } = body;
    
    if (!text || typeof text !== 'string') {
      return NextResponse.json(
        { error: 'Todo text is required' },
        { status: 400 }
      );
    }
    
    const todo = await db.todo.create({
      data: {
        text: text.trim(),
        completed: false
      }
    });
    
    return NextResponse.json(todo, { status: 201 });
    
  } catch (error) {
    console.error('Error creating todo:', error);
    return NextResponse.json(
      { error: 'Failed to create todo' },
      { status: 500 }
    );
  }
}
`,
        type: 'backend'
      });
      
      // Individual todo operations
      files.push({
        path: 'src/app/api/todos/[id]/route.ts',
        content: `import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// PUT /api/todos/[id] - Update todo
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const { text, completed } = body;
    const { id } = params;
    
    const existingTodo = await db.todo.findUnique({
      where: { id }
    });
    
    if (!existingTodo) {
      return NextResponse.json(
        { error: 'Todo not found' },
        { status: 404 }
      );
    }
    
    const updatedTodo = await db.todo.update({
      where: { id },
      data: {
        ...(text !== undefined && { text: text.trim() }),
        ...(completed !== undefined && { completed })
      }
    });
    
    return NextResponse.json(updatedTodo);
    
  } catch (error) {
    console.error('Error updating todo:', error);
    return NextResponse.json(
      { error: 'Failed to update todo' },
      { status: 500 }
    );
  }
}

// DELETE /api/todos/[id] - Delete todo
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;
    
    const existingTodo = await db.todo.findUnique({
      where: { id }
    });
    
    if (!existingTodo) {
      return NextResponse.json(
        { error: 'Todo not found' },
        { status: 404 }
      );
    }
    
    await db.todo.delete({
      where: { id }
    });
    
    return NextResponse.json({ message: 'Todo deleted successfully' });
    
  } catch (error) {
    console.error('Error deleting todo:', error);
    return NextResponse.json(
      { error: 'Failed to delete todo' },
      { status: 500 }
    );
  }
}
`,
        type: 'backend'
      });
    }
    
    return files;
  }
  
  /**
   * Generate main page component
   */
  private static generateMainPage(analysis: any, originalPrompt: string): GeneratedFile {
    let pageContent = '';
    
    if (analysis.projectType === 'todo-app') {
      pageContent = `'use client';

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Trash2, Edit2, Save, X, Plus, List, CheckCircle } from 'lucide-react';

interface Todo {
  id: string;
  text: string;
  completed: boolean;
  createdAt: string;
  updatedAt: string;
}

interface TodoStats {
  total: number;
  completed: number;
  active: number;
}

export default function TodoApp() {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [newTodo, setNewTodo] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all');
  const [stats, setStats] = useState<TodoStats>({ total: 0, completed: 0, active: 0 });
  const [isLoading, setIsLoading] = useState(false);

  // Fetch todos
  const fetchTodos = async () => {
    try {
      const response = await fetch(\`/api/todos?filter=\${filter}\`);
      const data = await response.json();
      setTodos(data.todos);
      setStats(data.stats);
    } catch (error) {
      console.error('Failed to fetch todos:', error);
    }
  };

  useEffect(() => {
    fetchTodos();
  }, [filter]);

  // Add new todo
  const addTodo = async () => {
    if (!newTodo.trim()) return;

    setIsLoading(true);
    try {
      const response = await fetch('/api/todos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: newTodo })
      });

      if (response.ok) {
        setNewTodo('');
        fetchTodos();
      }
    } catch (error) {
      console.error('Failed to add todo:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Toggle todo completion
  const toggleTodo = async (id: string) => {
    try {
      const todo = todos.find(t => t.id === id);
      if (todo) {
        const response = await fetch(\`/api/todos/\${id}\`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ completed: !todo.completed })
        });

        if (response.ok) {
          fetchTodos();
        }
      }
    } catch (error) {
      console.error('Failed to toggle todo:', error);
    }
  };

  // Update todo text
  const updateTodo = async (id: string) => {
    if (!editText.trim()) return;

    try {
      const response = await fetch(\`/api/todos/\${id}\`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: editText })
      });

      if (response.ok) {
        setEditingId(null);
        setEditText('');
        fetchTodos();
      }
    } catch (error) {
      console.error('Failed to update todo:', error);
    }
  };

  // Delete todo
  const deleteTodo = async (id: string) => {
    try {
      const response = await fetch(\`/api/todos/\${id}\`, {
        method: 'DELETE'
      });

      if (response.ok) {
        fetchTodos();
      }
    } catch (error) {
      console.error('Failed to delete todo:', error);
    }
  };

  const filteredTodos = todos.filter(todo => {
    if (filter === 'active') return !todo.completed;
    if (filter === 'completed') return todo.completed;
    return true;
  });

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">📝 Todo List</h1>
        <p className="text-gray-600">Generated from: "${originalPrompt}"</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card>
          <CardContent className="p-6 text-center">
            <List className="w-8 h-8 mx-auto mb-2 text-blue-500" />
            <h3 className="text-2xl font-bold">{stats.total}</h3>
            <p className="text-gray-600">Total Tasks</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6 text-center">
            <CheckCircle className="w-8 h-8 mx-auto mb-2 text-green-500" />
            <h3 className="text-2xl font-bold">{stats.completed}</h3>
            <p className="text-gray-600">Completed</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6 text-center">
            <div className="w-8 h-8 mx-auto mb-2 bg-orange-500 rounded-full flex items-center justify-center">
              <span className="text-white font-bold">{stats.active}</span>
            </div>
            <h3 className="text-2xl font-bold">{stats.active}</h3>
            <p className="text-gray-600">Active</p>
          </CardContent>
        </Card>
      </div>

      {/* Add Todo Form */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Add New Task</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Input
              type="text"
              value={newTodo}
              onChange={(e) => setNewTodo(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && addTodo()}
              placeholder="What needs to be done?"
              className="flex-1"
            />
            <Button onClick={addTodo} disabled={!newTodo.trim() || isLoading}>
              <Plus className="w-4 h-4" />
              {isLoading ? 'Adding...' : 'Add'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Filter Tabs */}
      <div className="flex gap-2 mb-6">
        {(['all', 'active', 'completed'] as const).map((f) => (
          <Button
            key={f}
            variant={filter === f ? 'default' : 'outline'}
            onClick={() => setFilter(f)}
            className="capitalize"
          >
            {f}
          </Button>
        ))}
      </div>

      {/* Todo List */}
      <div className="space-y-3">
        {filteredTodos.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">No todos found. Add one above!</p>
            </CardContent>
          </Card>
        ) : (
          filteredTodos.map((todo) => (
            <Card key={todo.id} className={todo.completed ? 'opacity-75' : ''}>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Checkbox
                    checked={todo.completed}
                    onCheckedChange={() => toggleTodo(todo.id)}
                  />
                  
                  <div className="flex-1">
                    {editingId === todo.id ? (
                      <div className="flex gap-2">
                        <Input
                          value={editText}
                          onChange={(e) => setEditText(e.target.value)}
                          onKeyPress={(e) => e.key === 'Enter' && updateTodo(todo.id)}
                          className="flex-1"
                          autoFocus
                        />
                        <Button size="sm" onClick={() => updateTodo(todo.id)}>
                          <Save className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => setEditingId(null)}>
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ) : (
                      <div>
                        <p className={todo.completed ? 'line-through text-gray-500' : 'text-gray-900'}>
                          {todo.text}
                        </p>
                        <p className="text-xs text-gray-400 mt-1">
                          Created: {new Date(todo.createdAt).toLocaleString()}
                        </p>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setEditingId(todo.id);
                        setEditText(todo.text);
                      }}
                      disabled={todo.completed}
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => deleteTodo(todo.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Project Info */}
      <div className="mt-8 p-4 bg-gray-50 rounded-lg">
        <h3 className="font-semibold mb-2">🚀 Project Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <strong>Generated From:</strong> "{originalPrompt}"
          </div>
          <div>
            <strong>Features:</strong> {analysis.features.join(', ')}
          </div>
          <div>
            <strong>Database:</strong> {analysis.database}
          </div>
          <div>
            <strong>Framework:</strong> Next.js with {analysis.styling}
          </div>
        </div>
      </div>
    </div>
  );
};
`;
    } else {
      // Generic page for other project types
      pageContent = `'use client';

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit2, Trash2, Save, X } from 'lucide-react';

interface Item {
  id: string;
  title: string;
  description?: string;
  completed: boolean;
  createdAt: string;
  updatedAt: string;
}

export default function ${analysis.projectType.replace(/-([a-z])/g, (g) => g[1].toUpperCase())}() {
  const [items, setItems] = useState<Item[]>([]);
  const [newItem, setNewItem] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Fetch items
  const fetchItems = async () => {
    try {
      const response = await fetch('/api/items');
      const data = await response.json();
      setItems(data);
    } catch (error) {
      console.error('Failed to fetch items:', error);
    }
  };

  useEffect(() => {
    fetchItems();
  }, []);

  // Add new item
  const addItem = async () => {
    if (!newItem.trim()) return;

    setIsLoading(true);
    try {
      const response = await fetch('/api/items', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: newItem })
      });

      if (response.ok) {
        setNewItem('');
        fetchItems();
      }
    } catch (error) {
      console.error('Failed to add item:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Update item
  const updateItem = async (id: string) => {
    if (!editText.trim()) return;

    try {
      const response = await fetch(\`/api/items/\${id}\`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: editText })
      });

      if (response.ok) {
        setEditingId(null);
        setEditText('');
        fetchItems();
      }
    } catch (error) {
      console.error('Failed to update item:', error);
    }
  };

  // Delete item
  const deleteItem = async (id: string) => {
    try {
      const response = await fetch(\`/api/items/\${id}\`, {
        method: 'DELETE'
      });

      if (response.ok) {
        fetchItems();
      }
    } catch (error) {
      console.error('Failed to delete item:', error);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">
          ${analysis.projectType.replace(/-([a-z])/g, (g) => ' ' + g[1].toUpperCase()).replace(/^./, str => str.toUpperCase())}
        </h1>
        <p className="text-gray-600">Generated from: "${originalPrompt}"</p>
      </div>

      {/* Add Item Form */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Add New Item</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Input
              type="text"
              value={newItem}
              onChange={(e) => setNewItem(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && addItem()}
              placeholder="Enter item title..."
              className="flex-1"
            />
            <Button onClick={addItem} disabled={!newItem.trim() || isLoading}>
              <Plus className="w-4 h-4" />
              {isLoading ? 'Adding...' : 'Add'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Items List */}
      <div className="space-y-3">
        {items.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">No items found. Add one above!</p>
            </CardContent>
          </Card>
        ) : (
          items.map((item) => (
            <Card key={item.id}>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex-1">
                    {editingId === item.id ? (
                      <div className="flex gap-2">
                        <Input
                          value={editText}
                          onChange={(e) => setEditText(e.target.value)}
                          onKeyPress={(e) => e.key === 'Enter' && updateItem(item.id)}
                          className="flex-1"
                          autoFocus
                        />
                        <Button size="sm" onClick={() => updateItem(item.id)}>
                          <Save className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => setEditingId(null)}>
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ) : (
                      <div>
                        <h3 className="font-medium text-gray-900">{item.title}</h3>
                        {item.description && (
                          <p className="text-gray-600 mt-1">{item.description}</p>
                        )}
                        <p className="text-xs text-gray-400 mt-1">
                          Created: {new Date(item.createdAt).toLocaleString()}
                        </p>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setEditingId(item.id);
                        setEditText(item.title);
                      }}
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => deleteItem(item.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Project Info */}
      <div className="mt-8 p-4 bg-gray-50 rounded-lg">
        <h3 className="font-semibold mb-2">🚀 Project Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <strong>Generated From:</strong> "${originalPrompt}"
          </div>
          <div>
            <strong>Features:</strong> {analysis.features.join(', ')}
          </div>
          <div>
            <strong>Database:</strong> {analysis.database}
          </div>
          <div>
            <strong>Framework:</strong> Next.js with {analysis.styling}
          </div>
        </div>
      </div>
    </div>
  );
};
`;
    }
    
    return {
      path: 'src/app/page.tsx',
      content: pageContent,
      type: 'frontend'
    };
  }
  
  /**
   * Generate frontend components based on analysis
   */
  private static generateFrontendComponents(analysis: any): GeneratedFile[] {
    const files: GeneratedFile[] = [];
    
    // Generate component files based on project type
    if (analysis.projectType === 'todo-app') {
      files.push({
        path: 'src/components/TodoItem.tsx',
        content: `'use client';

import React from 'react';
import { Todo } from '@/types/todo';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Trash2, Edit2 } from 'lucide-react';

interface TodoItemProps {
  todo: Todo;
  onToggle: (id: string) => void;
  onEdit: (id: string, text: string) => void;
  onDelete: (id: string) => void;
}

export default function TodoItem({ todo, onToggle, onEdit, onDelete }: TodoItemProps) {
  const [isEditing, setIsEditing] = React.useState(false);
  const [editText, setEditText] = React.useState(todo.text);

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(todo.id, editText);
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setIsEditing(false);
  };

  return (
    <div className=\`flex items-center gap-3 p-3 border rounded-lg \${
      todo.completed ? 'bg-gray-50 opacity-75' : 'bg-white'
    }\`>
      <Checkbox
        checked={todo.completed}
        onCheckedChange={() => onToggle(todo.id)}
        className="mt-1"
      />
      
      <div className="flex-1">
        {isEditing ? (
          <div className="flex gap-2">
            <input
              type="text"
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSave()}
              className="flex-1 px-2 py-1 border rounded"
              autoFocus
            />
            <button
              onClick={handleSave}
              className="px-2 py-1 bg-blue-500 text-white rounded text-sm"
            >
              Save
            </button>
            <button
              onClick={handleCancel}
              className="px-2 py-1 bg-gray-500 text-white rounded text-sm"
            >
              Cancel
            </button>
          </div>
        ) : (
          <div>
            <p className={\`font-medium \${
              todo.completed ? 'line-through text-gray-500' : 'text-gray-900'
            }\`}>
              {todo.text}
            </p>
            <p className="text-xs text-gray-400 mt-1">
              {new Date(todo.createdAt).toLocaleString()}
            </p>
          </div>
        )}
      </div>
      
      <div className="flex gap-1">
        {!isEditing && (
          <>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setIsEditing(true)}
              disabled={todo.completed}
            >
              <Edit2 className="w-4 h-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => onDelete(todo.id)}
              className="text-red-600 hover:text-red-700"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </>
        )}
      </div>
    </div>
  );
}
`,
        type: 'frontend'
      });
    }
    
    return files;
  }
  
  /**
   * Generate configuration files
   */
  private static generateConfigFiles(analysis: any): GeneratedFile[] {
    const files: GeneratedFile[] = [];
    
    // Package.json
    files.push({
      path: 'package.json',
      content: `{
  "name": "${analysis.projectType}",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint",
    "db:push": "prisma db push",
    "db:generate": "prisma generate"
  },
  "dependencies": {
    "@prisma/client": "^6.11.1",
    "next": "15.3.5",
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "lucide-react": "^0.525.0"
  },
  "devDependencies": {
    "@types/node": "^20",
    "@types/react": "^19",
    "@types/react-dom": "^19",
    "eslint": "^9",
    "eslint-config-next": "15.3.5",
    "prisma": "^6.11.1",
    "tailwindcss": "^4",
    "typescript": "^5"
  }
}`,
      type: 'config'
    });
    
    // Tailwind config
    files.push({
      path: 'tailwind.config.ts',
      content: `import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        chart: {
          "1": "hsl(var(--chart-1))",
          "2": "hsl(var(--chart-2))",
          "3": "hsl(var(--chart-3))",
          "4": "hsl(var(--chart-4))",
          "5": "hsl(var(--chart-5))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
    },
  },
  plugins: [],
};
export default config;`,
      type: 'config'
    });
    
    return files;
  }
  
  /**
   * Generate documentation
   */
  private static generateDocumentation(analysis: any, originalPrompt: string): GeneratedFile[] {
    const files: GeneratedFile[] = [];
    
    files.push({
      path: 'README.md',
      content: `# ${analysis.projectType.replace(/-([a-z])/g, (g) => ' ' + g[1].toUpperCase()).replace(/^./, str => str.toUpperCase())}

Generated from prompt: "${originalPrompt}"

## 🚀 Project Overview

This is a ${analysis.complexity} ${analysis.projectType} built with Next.js, featuring:

### Key Features
${analysis.features.map((feature: string, index: number) => `- ${feature}`).join('\n')}

### Tech Stack
- **Framework**: Next.js 15 with App Router
- **Database**: ${analysis.database}
- **Styling**: ${analysis.styling}
- **Language**: TypeScript
- **ORM**: Prisma

## 📋 Prerequisites

- Node.js 18+ 
- npm or yarn

## 🛠️ Installation

1. Clone or download the project files
2. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`

3. Set up the database:
   \`\`\`bash
   npx prisma db push
   \`\`\`

4. Start the development server:
   \`\`\`bash
   npm run dev
   \`\`\`

5. Open [http://localhost:3000](http://localhost:3000) in your browser

## 🏗️ Project Structure

\`\`\`
src/
├── app/
│   ├── api/           # API routes
│   ├── page.tsx       # Main page
│   └── layout.tsx     # Root layout
├── components/        # React components
├── lib/              # Utility functions
└── types/            # TypeScript definitions

prisma/
└── schema.prisma     # Database schema
\`\`\`

## 🚀 Usage

### Basic Operations

1. **Add new items**: Use the input form at the top
2. **Edit items**: Click the edit button on any item
3. **Delete items**: Click the delete button on any item
4. **Filter items**: Use the filter tabs to show all/active/completed items

### API Endpoints

- \`GET /api/items\` - Fetch all items
- \`POST /api/items\` - Create new item
- \`PUT /api/items/[id]\` - Update item
- \`DELETE /api/items/[id]\` - Delete item

## 🔧 Development

### Database Schema

The application uses Prisma with ${analysis.database}. The schema includes:

\`\`\`prisma
// See prisma/schema.prisma for complete schema
\`\`\`

### Adding New Features

1. Update the database schema in \`prisma/schema.prisma\`
2. Run \`npx prisma db push\` to apply changes
3. Add new API routes in \`src/app/api/\`
4. Update frontend components in \`src/components/\`

## 📝 Generated From

This project was automatically generated from the prompt:
**"${originalPrompt}"**

The AI analyzed this request and created a complete fullstack application with:
- Database schema and models
- RESTful API endpoints
- React frontend components
- Modern UI with ${analysis.styling}
- TypeScript for type safety
- Responsive design

## 🤝 Contributing

This is an AI-generated project. For modifications, you can:
1. Edit the source files directly
2. Use the AI assistant to generate new features
3. Extend the API with additional endpoints

## 📄 License

MIT License - Feel free to use this project for learning and development.
`,
      type: 'docs'
    });
    
    return files;
  }
  
  /**
   * Generate setup instructions
   */
  private static generateSetupInstructions(analysis: any): string[] {
    return [
      '1. Install dependencies: npm install',
      '2. Set up database: npx prisma db push',
      '3. Start development server: npm run dev',
      '4. Open http://localhost:3000 in browser',
      '5. Test the application functionality'
    ];
  }
  
  /**
   * Generate dependencies
   */
  private static generateDependencies(analysis: any): string[] {
    const baseDeps = [
      'next',
      'react',
      'react-dom',
      '@prisma/client',
      'lucide-react'
    ];
    
    if (analysis.styling === 'tailwind') {
      baseDeps.push('tailwindcss');
    }
    
    return baseDeps;
  }
  
  /**
   * Generate dev dependencies
   */
  private static generateDevDependencies(analysis: any): string[] {
    return [
      '@types/node',
      '@types/react',
      '@types/react-dom',
      'typescript',
      'prisma',
      'eslint',
      'eslint-config-next'
    ];
  }
  
  /**
   * Generate scripts
   */
  private static generateScripts(analysis: any): Record<string, string> {
    return {
      'dev': 'next dev',
      'build': 'next build',
      'start': 'next start',
      'lint': 'next lint',
      'db:push': 'prisma db push',
      'db:generate': 'prisma generate'
    };
  }
  
  /**
   * Generate preview configuration
   */
  private static generatePreviewConfig(project: FullstackProject): LivePreviewConfig {
    return {
      port: 3000,
      autoRefresh: true,
      showCode: true,
      showConsole: true,
      previewUrl: 'http://localhost:3000'
    };
  }
  
  /**
   * Generate setup commands
   */
  private static generateSetupCommands(project: FullstackProject): string[] {
    return [
      'npm install',
      'npx prisma db push',
      'npm run dev'
    ];
  }
  
  /**
   * Estimate setup time
   */
  private static estimateSetupTime(project: FullstackProject): string {
    const complexity = project.structure.features.length;
    if (complexity > 5) return '5-10 minutes';
    if (complexity > 3) return '3-5 minutes';
    return '1-2 minutes';
  }
}