// 🌐 Wikipedia API Integration Module
// High-quality data source for deep research with proper content filtering

export interface WikipediaArticle {
  title: string;
  pageid: number;
  extract: string;
  url: string;
  categories: string[];
  links: string[];
  lastmodified: string;
  lang: string;
  thumbnail?: string;
  coordinates?: {
    lat: number;
    lon: number;
  };
}

export interface WikipediaSearchResult {
  title: string;
  pageid: number;
  size: number;
  wordcount: number;
  snippet: string;
  timestamp: string;
}

export interface WikipediaCategory {
  pageid: number;
  ns: number;
  title: string;
  hidden: boolean;
}

export class WikipediaAPI {
  private baseUrl: string;
  private apiEndpoint: string;
  private watchlistToken: string;

  constructor(watchlistToken: string = '4e0888b5c6fc16e3038905f71986cd38745b8720') {
    this.baseUrl = 'https://en.wikipedia.org';
    this.apiEndpoint = 'https://en.wikipedia.org/w/api.php';
    this.watchlistToken = watchlistToken;
    console.log('🌐 Wikipedia API initialized with token:', watchlistToken.substring(0, 8) + '...');
  }

  /**
   * Search Wikipedia articles by query
   */
  async searchArticles(query: string, limit: number = 10): Promise<WikipediaSearchResult[]> {
    try {
      const params = new URLSearchParams({
        action: 'query',
        format: 'json',
        list: 'search',
        srsearch: query,
        srlimit: limit.toString(),
        srprop: 'size|wordcount|timestamp|snippet',
        origin: '*'
      });

      const response = await fetch(`${this.apiEndpoint}?${params}`);
      
      // Check if response is HTML (error page) instead of JSON
      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        console.warn('Wikipedia API returned non-JSON response, possibly blocked or rate limited');
        return [];
      }

      const data = await response.json();

      if (data.error) {
        throw new Error(`Wikipedia API Error: ${data.error.info}`);
      }

      return data.query.search || [];
    } catch (error) {
      console.error('Wikipedia search failed:', error);
      return [];
    }
  }

  /**
   * Get detailed article content by page ID
   */
  async getArticle(pageId: number): Promise<WikipediaArticle | null> {
    try {
      const params = new URLSearchParams({
        action: 'query',
        format: 'json',
        prop: 'extracts|info|links|categories|coordinates',
        pageids: pageId.toString(),
        exintro: 'true',
        explaintext: 'true',
        exsectionformat: 'plain',
        inprop: 'url|lastmodified',
        cllimit: '20',
        pllimit: '20',
        origin: '*'
      });

      const response = await fetch(`${this.apiEndpoint}?${params}`);
      
      // Check if response is HTML (error page) instead of JSON
      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        console.warn('Wikipedia API returned non-JSON response, possibly blocked or rate limited');
        return null;
      }

      const data = await response.json();

      if (data.error) {
        throw new Error(`Wikipedia API Error: ${data.error.info}`);
      }

      const page = data.query.pages[pageId.toString()];
      if (!page) return null;

      return {
        title: page.title,
        pageid: page.pageid,
        extract: page.extract || '',
        url: page.fullurl,
        categories: page.categories?.map((cat: any) => cat.title) || [],
        links: page.links?.map((link: any) => link.title) || [],
        lastmodified: page.lastmodified,
        lang: 'en',
        thumbnail: page.thumbnail?.source,
        coordinates: page.coordinates?.[0]
      };
    } catch (error) {
      console.error('Wikipedia article fetch failed:', error);
      return null;
    }
  }

  /**
   * Get multiple articles by their page IDs
   */
  async getMultipleArticles(pageIds: number[]): Promise<WikipediaArticle[]> {
    const articles: WikipediaArticle[] = [];
    
    // Process in batches to avoid API limits
    const batchSize = 5;
    for (let i = 0; i < pageIds.length; i += batchSize) {
      const batch = pageIds.slice(i, i + batchSize);
      const batchArticles = await Promise.all(
        batch.map(id => this.getArticle(id))
      );
      articles.push(...batchArticles.filter((article): article is WikipediaArticle => article !== null));
    }

    return articles;
  }

  /**
   * Get articles by title (exact match)
   */
  async getArticleByTitle(title: string): Promise<WikipediaArticle | null> {
    try {
      const params = new URLSearchParams({
        action: 'query',
        format: 'json',
        prop: 'extracts|info|links|categories|coordinates',
        titles: title,
        exintro: 'true',
        explaintext: 'true',
        exsectionformat: 'plain',
        inprop: 'url|lastmodified',
        cllimit: '20',
        pllimit: '20',
        origin: '*'
      });

      const response = await fetch(`${this.apiEndpoint}?${params}`);
      
      // Check if response is HTML (error page) instead of JSON
      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        console.warn('Wikipedia API returned non-JSON response, possibly blocked or rate limited');
        return null;
      }

      const data = await response.json();

      if (data.error) {
        throw new Error(`Wikipedia API Error: ${data.error.info}`);
      }

      const pages = data.query.pages;
      const pageId = Object.keys(pages)[0];
      const page = pages[pageId];

      if (pageId === '-1' || page.missing) {
        return null;
      }

      return {
        title: page.title,
        pageid: page.pageid,
        extract: page.extract || '',
        url: page.fullurl,
        categories: page.categories?.map((cat: any) => cat.title) || [],
        links: page.links?.map((link: any) => link.title) || [],
        lastmodified: page.lastmodified,
        lang: 'en',
        thumbnail: page.thumbnail?.source,
        coordinates: page.coordinates?.[0]
      };
    } catch (error) {
      console.error('Wikipedia article by title fetch failed:', error);
      return null;
    }
  }

  /**
   * Get categories for a specific article
   */
  async getArticleCategories(pageId: number): Promise<WikipediaCategory[]> {
    try {
      const params = new URLSearchParams({
        action: 'query',
        format: 'json',
        prop: 'categories',
        pageids: pageId.toString(),
        cllimit: '50',
        clshow: '!hidden',
        origin: '*'
      });

      const response = await fetch(`${this.apiEndpoint}?${params}`);
      const data = await response.json();

      if (data.error) {
        throw new Error(`Wikipedia API Error: ${data.error.info}`);
      }

      const page = data.query.pages[pageId.toString()];
      return page.categories || [];
    } catch (error) {
      console.error('Wikipedia categories fetch failed:', error);
      return [];
    }
  }

  /**
   * Search for articles in specific categories
   */
  async searchByCategory(category: string, limit: number = 20): Promise<WikipediaSearchResult[]> {
    try {
      const params = new URLSearchParams({
        action: 'query',
        format: 'json',
        list: 'categorymembers',
        cmtitle: `Category:${category}`,
        cmlimit: limit.toString(),
        cmprop: 'title|pageid|timestamp',
        origin: '*'
      });

      const response = await fetch(`${this.apiEndpoint}?${params}`);
      const data = await response.json();

      if (data.error) {
        throw new Error(`Wikipedia API Error: ${data.error.info}`);
      }

      return (data.query.categorymembers || []).map((member: any) => ({
        title: member.title,
        pageid: member.pageid,
        size: 0,
        wordcount: 0,
        snippet: '',
        timestamp: member.timestamp
      }));
    } catch (error) {
      console.error('Wikipedia category search failed:', error);
      return [];
    }
  }

  /**
   * Get related articles based on links from current articles
   */
  async getRelatedArticles(pageIds: number[], limit: number = 10): Promise<WikipediaArticle[]> {
    try {
      // First get links from all articles
      const allLinks = new Set<string>();
      
      for (const pageId of pageIds) {
        const article = await this.getArticle(pageId);
        if (article) {
          article.links.forEach(link => allLinks.add(link));
        }
      }

      // Search for articles with these link titles
      const searchResults: WikipediaSearchResult[] = [];
      const linkArray = Array.from(allLinks).slice(0, limit);

      for (const link of linkArray) {
        const results = await this.searchArticles(link, 1);
        searchResults.push(...results);
      }

      // Get full articles for the search results
      const articleIds = searchResults.slice(0, limit).map(result => result.pageid);
      return await this.getMultipleArticles(articleIds);
    } catch (error) {
      console.error('Wikipedia related articles fetch failed:', error);
      return [];
    }
  }

  /**
   * Extract clean research content from Wikipedia articles
   */
  extractResearchContent(articles: WikipediaArticle[]): {
    content: string;
    topics: string[];
    entities: string[];
    sources: string[];
    quality: number;
  } {
    if (articles.length === 0) {
      return {
        content: '',
        topics: [],
        entities: [],
        sources: [],
        quality: 0
      };
    }

    // Combine and clean content
    const content = articles
      .map(article => {
        // Remove Wikipedia-specific formatting and references
        let cleanContent = article.extract
          .replace(/\[\d+\]/g, '') // Remove reference markers
          .replace(/==\s*[^=]+\s*==/g, '\n\n') // Convert section headers to paragraph breaks
          .replace(/\n{3,}/g, '\n\n') // Remove excessive line breaks
          .trim();

        // Add article context
        return `=== ${article.title} ===\n${cleanContent}\n\nSource: ${article.url}\nCategories: ${article.categories.join(', ')}\n`;
      })
      .join('\n---\n');

    // Extract topics from categories and titles
    const topics = this.extractTopics(articles);
    
    // Extract entities from content
    const entities = this.extractEntities(content);
    
    // Get source URLs
    const sources = articles.map(article => article.url);

    // Calculate quality score based on article completeness
    const quality = this.calculateContentQuality(articles);

    return {
      content,
      topics,
      entities,
      sources,
      quality
    };
  }

  /**
   * Extract topics from article categories and titles
   */
  private extractTopics(articles: WikipediaArticle[]): string[] {
    const topics = new Set<string>();

    articles.forEach(article => {
      // Extract from categories
      article.categories.forEach(category => {
        const cleanCategory = category
          .replace(/^Category:/i, '')
          .replace(/_/g, ' ')
          .toLowerCase();
        
        if (cleanCategory.length > 3 && !cleanCategory.includes('articles')) {
          topics.add(cleanCategory);
        }
      });

      // Extract from title keywords
      const titleWords = article.title.toLowerCase().split(/\s+/);
      titleWords.forEach(word => {
        if (word.length > 4 && !this.isStopWord(word)) {
          topics.add(word);
        }
      });
    });

    return Array.from(topics).slice(0, 20);
  }

  /**
   * Extract entities from content using simple patterns
   */
  private extractEntities(content: string): string[] {
    const entities = new Set<string>();

    // Extract capitalized phrases (potential entities)
    const entityPattern = /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b/g;
    let match;
    
    while ((match = entityPattern.exec(content)) !== null) {
      const entity = match[1];
      if (entity.length > 2 && !this.isStopWord(entity)) {
        entities.add(entity);
      }
    }

    return Array.from(entities).slice(0, 30);
  }

  /**
   * Check if a word is a stop word
   */
  private isStopWord(word: string): boolean {
    const stopWords = new Set([
      'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by',
      'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did',
      'will', 'would', 'could', 'should', 'may', 'might', 'must', 'can', 'this', 'that', 'these', 'those',
      'from', 'about', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'up', 'down',
      'out', 'off', 'over', 'under', 'again', 'further', 'then', 'once'
    ]);

    return stopWords.has(word.toLowerCase());
  }

  /**
   * Calculate content quality score
   */
  private calculateContentQuality(articles: WikipediaArticle[]): number {
    if (articles.length === 0) return 0;

    let totalScore = 0;
    
    articles.forEach(article => {
      let score = 0;
      
      // Content length contributes to quality
      if (article.extract.length > 500) score += 0.3;
      if (article.extract.length > 1000) score += 0.2;
      
      // Categories indicate well-structured articles
      if (article.categories.length > 5) score += 0.2;
      if (article.categories.length > 10) score += 0.1;
      
      // Links indicate comprehensive coverage
      if (article.links.length > 10) score += 0.1;
      if (article.links.length > 20) score += 0.1;
      
      totalScore += Math.min(score, 1.0);
    });

    return totalScore / articles.length;
  }

  /**
   * Get watchlist changes using the provided token
   */
  async getWatchlistChanges(): Promise<any> {
    try {
      const params = new URLSearchParams({
        action: 'query',
        format: 'json',
        list: 'watchlistraw',
        wrlimit: '50',
        wrprop: 'title|timestamp|user|comment',
        origin: '*'
      });

      const response = await fetch(`${this.apiEndpoint}?${params}`, {
        headers: {
          'Authorization': `Bearer ${this.watchlistToken}`
        }
      });

      const data = await response.json();

      if (data.error) {
        console.warn('Watchlist access failed:', data.error.info);
        return null;
      }

      return data.query.watchlistraw || [];
    } catch (error) {
      console.error('Watchlist fetch failed:', error);
      return null;
    }
  }
}

// Export singleton instance
export const wikipediaAPI = new WikipediaAPI();