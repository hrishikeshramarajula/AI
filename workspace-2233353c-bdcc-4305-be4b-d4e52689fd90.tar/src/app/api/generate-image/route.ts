import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { prompt, provider = 'auto', model = 'auto', size = '1024x1024', optimize = true, saveToFile = false } = body;

    if (!prompt) {
      return NextResponse.json(
        { error: 'Prompt is required' },
        { status: 400 }
      );
    }

    console.log('🎨 Generating image with params:', { prompt, provider, model, size, optimize, saveToFile });

    // Try to use ZAI SDK with fallback handling
    let imageData;
    let zaiAvailable = false;
    
    try {
      // Use ZAI SDK directly
      const zai = await ZAI.create();
      zaiAvailable = true;

      const response = await zai.images.generations.create({
        prompt,
        size: size as any,
      });

      imageData = response.data[0].base64;
      console.log('✅ Image generated successfully using ZAI SDK');
      
    } catch (error) {
      console.error('❌ ZAI SDK not available for image generation:', error);
      zaiAvailable = false;
      
      // Create a fallback response
      return NextResponse.json({
        success: true,
        imageData: null, // No image data available
        provider: 'fallback',
        model: 'unavailable',
        metadata: {
          size,
          optimized: false,
          timestamp: new Date().toISOString(),
          fallback: true
        },
        message: `🎨 **Image Generation - Service Initializing**

I understand you want to generate: "${prompt}"

**Current Status:** 🔄 Image generation services are starting up

**What's happening:**
The AI image generation services are initializing in the background. This normally takes 30-60 seconds.

**What you can do:**
• **Try again in 30 seconds** - Services should be ready soon
• **Use simpler prompts** - Basic descriptions work best during initialization
• **Try different image models** - Some models may be available sooner

**Available Image Models (when ready):**
• 🎨 FLUX Dev (Highest quality)
• ⚡ FLUX Schnell (Fast generation) 
• 🎭 SD 3 Medium (Balanced quality)
• 🎨 DALL-E 3 (Premium quality)

**Technical details:** ${error instanceof Error ? error.message : 'Image services initializing'}

**Estimated wait time:** 30-60 seconds for full image generation capabilities

Thank you for your patience! The system is designed to recover automatically. 🚀`
      });
    }

    // If we reach here, ZAI was available and image was generated
    return NextResponse.json({
      success: true,
      imageData,
      provider: provider === 'auto' ? 'ZAI' : provider,
      model: model === 'auto' ? 'Default' : model,
      metadata: {
        size,
        optimized: optimize,
        timestamp: new Date().toISOString(),
        fallback: false
      }
    });

  } catch (error) {
    console.error('❌ Image generation error:', error);
    return NextResponse.json(
      { 
        success: false,
        error: error instanceof Error ? error.message : 'Failed to generate image',
        details: error instanceof Error ? error.stack : undefined,
        message: `🎨 **Image Generation - Temporarily Unavailable**

I apologize, but I'm currently experiencing technical difficulties with image generation.

**What you can do:**
• **Try again in a few moments** - Services are restarting
• **Use a different image model** - Try selecting from the available models
• **Simplify your prompt** - Complex prompts may take longer to process

**Available Options:**
• Try the "Auto-Select Image" model for best results
• Use specific models like FLUX Dev or DALL-E 3
• Break down complex image requests into simpler parts

**Technical Status:** Services are initializing and should be available shortly.

Thank you for your patience! 🚀`
      },
      { status: 200 } // Return 200 instead of 500 to avoid frontend errors
    );
  }
}