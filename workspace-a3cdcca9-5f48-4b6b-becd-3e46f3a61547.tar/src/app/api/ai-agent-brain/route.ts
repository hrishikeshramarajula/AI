// 🧠 AI Agent Brain API Endpoint
// This endpoint provides access to the complete AI Agent Brain system

import { NextRequest, NextResponse } from 'next/server';
import { AIAgentBrain } from '@/lib/aiAgent/brain/AIAgentBrain';

// Global instance of the AI Agent Brain
let aiAgentBrain: AIAgentBrain | null = null;

async function getAIAgentBrain(): Promise<AIAgentBrain> {
  if (!aiAgentBrain) {
    aiAgentBrain = new AIAgentBrain();
    // Wait for initialization to complete
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
  return aiAgentBrain;
}

export async function POST(request: NextRequest) {
  try {
    console.log('🧠 AI Agent Brain API called');
    
    const body = await request.json();
    const { text, context, priority, userId } = body;

    if (!text) {
      return NextResponse.json(
        { error: 'Text is required' },
        { status: 400 }
      );
    }

    // Get AI Agent Brain instance
    const brain = await getAIAgentBrain();

    // Prepare input
    const input = {
      text,
      context: context || {},
      priority: priority || 'medium',
      userId: userId || 'anonymous',
      timestamp: new Date()
    };

    // Process with AI Agent Brain
    const result = await brain.process(input);

    console.log('🎉 AI Agent Brain processing completed');

    return NextResponse.json({
      success: true,
      result,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('❌ AI Agent Brain API error:', error);
    return NextResponse.json(
      { 
        error: 'Internal server error',
        message: error.message,
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    console.log('📊 AI Agent Brain status API called');
    
    const brain = await getAIAgentBrain();
    const status = brain.getBrainStatus();

    return NextResponse.json({
      success: true,
      status,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('❌ AI Agent Brain status API error:', error);
    return NextResponse.json(
      { 
        error: 'Internal server error',
        message: error.message,
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    );
  }
}