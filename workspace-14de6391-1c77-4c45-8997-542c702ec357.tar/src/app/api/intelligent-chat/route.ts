import { NextRequest } from 'next/server';
import { IntelligentChatBot, ChatBotConfig } from '@/lib/intelligentChat/intelligentChatBot';
import { createSuccessResponse, createErrorResponse, withErrorHandling, validateRequiredFields } from '@/lib/apiUtils';

// Global chatbot instance (in production, you might want to use a proper session management)
let globalChatBot: IntelligentChatBot | null = null;

function getChatBot(config?: ChatBotConfig): IntelligentChatBot {
  if (!globalChatBot) {
    globalChatBot = new IntelligentChatBot(config);
  }
  return globalChatBot;
}

export async function POST(request: NextRequest) {
  return withErrorHandling(async () => {
    try {
      const body = await request.json();
      
      // Validate required fields
      const validation = validateRequiredFields(body, ['message']);
      if (!validation.valid) {
        return createErrorResponse(validation.error!, 400);
      }

      const { message, config, clearHistory = false } = body;
      
      console.log(`🤖 Processing intelligent chat request: ${message}`);

      // Get or create chatbot instance
      const chatBot = getChatBot(config);

      // Clear history if requested
      if (clearHistory) {
        chatBot.clearConversation();
        console.log('🗑️ Conversation history cleared by user request');
      }

      // Check for ambiguous intents
      const ambiguousIntents = chatBot['intentRecognizer'].detectAmbiguousIntents(message);
      
      let response;
      if (ambiguousIntents.length > 1) {
        console.log('🤔 Ambiguous intent detected, requesting clarification');
        response = await chatBot.handleAmbiguousIntent(message, ambiguousIntents);
      } else {
        // Process message normally
        response = await chatBot.processMessage(message);
      }

      // Format the response for the frontend
      const formattedResponse = {
        success: true,
        response: response.response,
        confidence: response.confidence,
        intent: response.intent,
        processingTime: response.processingTime,
        metadata: {
          preprocessing: {
            tokens: response.metadata.preprocessing.tokens.length,
            entities: response.metadata.preprocessing.entities.length,
            cleanedText: response.metadata.preprocessing.cleanedText
          },
          context: {
            isFollowUp: response.metadata.context.isFollowUp,
            recentTopics: response.metadata.context.summary.recentTopics,
            conversationFlow: response.metadata.context.summary.conversationFlow,
            emotionalTone: response.metadata.context.summary.emotionalTone,
            complexityLevel: response.metadata.context.summary.complexityLevel
          },
          intent: {
            intent: response.metadata.intent.intent,
            confidence: response.metadata.intent.confidence,
            action: response.metadata.intent.action,
            parameters: response.metadata.intent.parameters
          },
          knowledge: {
            itemsFound: response.metadata.knowledge.totalFound,
            searchTime: response.metadata.knowledge.searchTime,
            sources: response.metadata.knowledge.sources,
            topItems: response.metadata.knowledge.items.slice(0, 3).map(item => ({
              title: item.title,
              category: item.category,
              relevance: item.relevance
            }))
          },
          generation: {
            suggestions: response.suggestions,
            followUpQuestions: response.followUpQuestions
          },
          postProcessing: {
            wordCount: response.metadata.postProcessing.metadata.wordCount,
            readingTime: response.metadata.postProcessing.metadata.readingTime,
            complexityScore: response.metadata.postProcessing.metadata.complexityScore,
            sentimentScore: response.metadata.postProcessing.metadata.sentimentScore,
            formattingApplied: response.metadata.postProcessing.formattingApplied,
            safetyChecks: response.metadata.postProcessing.safetyChecks,
            disclaimers: response.metadata.postProcessing.disclaimers
          }
        },
        suggestions: response.suggestions,
        followUpQuestions: response.followUpQuestions,
        capabilities: chatBot.getCapabilities(),
        stats: chatBot.getProcessingStats()
      };

      console.log('✅ Intelligent chat response generated:', {
        processingTime: response.processingTime,
        confidence: response.confidence,
        intent: response.intent,
        wordCount: response.metadata.postProcessing.metadata.wordCount
      });

      return createSuccessResponse(formattedResponse.response, formattedResponse);

    } catch (error: any) {
      console.error('❌ Intelligent chat API error:', error);
      
      return createErrorResponse(
        `Intelligent chat service failed: ${error.message || 'Unknown error occurred'}`,
        500
      );
    }
  });
}

// GET endpoint for chatbot status and capabilities
export async function GET(request: NextRequest) {
  return withErrorHandling(async () => {
    try {
      const { searchParams } = new URL(request.url);
      const action = searchParams.get('action');

      const chatBot = getChatBot();

      switch (action) {
        case 'health':
          const healthCheck = chatBot.healthCheck();
          return createSuccessResponse(healthCheck);

        case 'capabilities':
          const capabilities = chatBot.getCapabilities();
          return createSuccessResponse(capabilities);

        case 'stats':
          const stats = chatBot.getProcessingStats();
          return createSuccessResponse(stats);

        case 'history':
          const history = chatBot.getConversationHistory();
          return createSuccessResponse({
            history,
            summary: chatBot.getContextSummary()
          });

        case 'intents':
          const intents = chatBot.getAvailableIntents();
          return createSuccessResponse({ intents });

        case 'categories':
          const categories = chatBot.getKnowledgeCategories();
          return createSuccessResponse({ categories });

        default:
          // Return general status
          return createSuccessResponse({
            status: 'operational',
            version: '1.0.0',
            capabilities: chatBot.getCapabilities(),
            health: chatBot.healthCheck()
          });
      }

    } catch (error: any) {
      console.error('❌ Intelligent chat GET API error:', error);
      return createErrorResponse(
        `Intelligent chat status request failed: ${error.message || 'Unknown error occurred'}`,
        500
      );
    }
  });
}

// DELETE endpoint for clearing conversation
export async function DELETE(request: NextRequest) {
  return withErrorHandling(async () => {
    try {
      const chatBot = getChatBot();
      chatBot.clearConversation();
      
      console.log('🗑️ Conversation history cleared via DELETE request');

      return createSuccessResponse({
        success: true,
        message: 'Conversation history cleared successfully',
        timestamp: new Date().toISOString()
      });

    } catch (error: any) {
      console.error('❌ Clear conversation error:', error);
      return createErrorResponse(
        `Failed to clear conversation: ${error.message || 'Unknown error occurred'}`,
        500
      );
    }
  });
}

// PUT endpoint for adding custom knowledge
export async function PUT(request: NextRequest) {
  return withErrorHandling(async () => {
    try {
      const body = await request.json();
      
      const validation = validateRequiredFields(body, ['title', 'content', 'category']);
      if (!validation.valid) {
        return createErrorResponse(validation.error!, 400);
      }

      const { title, content, category, tags = [] } = body;
      
      const chatBot = getChatBot();
      const knowledgeId = chatBot.addCustomKnowledge(title, content, category, tags);

      console.log('📚 Custom knowledge added:', { title, category, knowledgeId });

      return createSuccessResponse({
        success: true,
        knowledgeId,
        message: 'Custom knowledge added successfully',
        timestamp: new Date().toISOString()
      });

    } catch (error: any) {
      console.error('❌ Add custom knowledge error:', error);
      return createErrorResponse(
        `Failed to add custom knowledge: ${error.message || 'Unknown error occurred'}`,
        500
      );
    }
  });
}