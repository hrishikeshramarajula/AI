import { Server as ServerIO } from 'socket.io';
import { Server as NetServer } from 'http';
import { NextApiRequest } from 'next';

export type NextApiResponseServerIO = NextApiRequest & {
  socket: {
    server: NetServer & {
      io?: ServerIO;
    };
  };
};

// Socket.IO server instance
let io: ServerIO | null = null;

export function getSocketIO() {
  if (!io) {
    throw new Error('Socket.IO not initialized');
  }
  return io;
}

export function initializeSocketIO(server: NetServer) {
  if (io) {
    return io; // Already initialized
  }

  io = new ServerIO(server, {
    path: '/socket.io',
    cors: {
      origin: process.env.NODE_ENV === 'production' ? false : ['http://localhost:3000'],
      methods: ['GET', 'POST'],
    },
  });

  // Socket.IO connection handling
  io.on('connection', (socket) => {
    console.log('🔌 Socket connected:', socket.id);

    // Join room functionality
    socket.on('join-room', (roomId: string) => {
      socket.join(roomId);
      console.log(`📡 Socket ${socket.id} joined room: ${roomId}`);
      
      // Notify others in the room
      socket.to(roomId).emit('user-joined', {
        userId: socket.id,
        message: 'A new user joined the room',
        timestamp: new Date().toISOString(),
      });
    });

    // Leave room functionality
    socket.on('leave-room', (roomId: string) => {
      socket.leave(roomId);
      console.log(`📡 Socket ${socket.id} left room: ${roomId}`);
      
      // Notify others in the room
      socket.to(roomId).emit('user-left', {
        userId: socket.id,
        message: 'A user left the room',
        timestamp: new Date().toISOString(),
      });
    });

    // AI progress updates
    socket.on('ai-progress', (data: {
      roomId: string;
      progress: number;
      message: string;
      stage: string;
    }) => {
      console.log('🤖 AI Progress update:', data);
      
      // Broadcast progress to room
      io?.to(data.roomId).emit('ai-progress-update', {
        ...data,
        timestamp: new Date().toISOString(),
      });
    });

    // AI thinking updates
    socket.on('ai-thinking', (data: {
      roomId: string;
      thought: string;
      confidence: number;
    }) => {
      console.log('🧠 AI Thinking update:', data);
      
      // Broadcast thinking to room
      io?.to(data.roomId).emit('ai-thinking-update', {
        ...data,
        timestamp: new Date().toISOString(),
      });
    });

    // Code generation updates
    socket.on('code-generation', (data: {
      roomId: string;
      code: string;
      language: string;
      progress: number;
    }) => {
      console.log('💻 Code generation update:', data);
      
      // Broadcast code generation to room
      io?.to(data.roomId).emit('code-generation-update', {
        ...data,
        timestamp: new Date().toISOString(),
      });
    });

    // Image generation updates
    socket.on('image-generation', (data: {
      roomId: string;
      progress: number;
      status: string;
      imageUrl?: string;
    }) => {
      console.log('🎨 Image generation update:', data);
      
      // Broadcast image generation to room
      io?.to(data.roomId).emit('image-generation-update', {
        ...data,
        timestamp: new Date().toISOString(),
      });
    });

    // General message handling
    socket.on('message', (data: {
      roomId: string;
      message: string;
      type: string;
    }) => {
      console.log('💬 Message received:', data);
      
      // Broadcast message to room
      io?.to(data.roomId).emit('message-broadcast', {
        ...data,
        userId: socket.id,
        timestamp: new Date().toISOString(),
      });
    });

    // Error handling
    socket.on('error', (error) => {
      console.error('❌ Socket error:', error);
    });

    // Disconnect handling
    socket.on('disconnect', (reason) => {
      console.log('🔌 Socket disconnected:', socket.id, 'Reason:', reason);
      
      // Notify all rooms that the user left
      const rooms = Array.from(socket.rooms);
      rooms.forEach(roomId => {
        if (roomId !== socket.id) { // Don't broadcast to the socket's own room
          socket.to(roomId).emit('user-disconnected', {
            userId: socket.id,
            message: 'A user disconnected',
            timestamp: new Date().toISOString(),
          });
        }
      });
    });
  });

  console.log('🚀 Socket.IO server initialized');
  return io;
}

// Helper functions for emitting events
export function emitToRoom(roomId: string, event: string, data: any) {
  const socketIO = getSocketIO();
  socketIO.to(roomId).emit(event, {
    ...data,
    timestamp: new Date().toISOString(),
  });
}

export function emitToAll(event: string, data: any) {
  const socketIO = getSocketIO();
  socketIO.emit(event, {
    ...data,
    timestamp: new Date().toISOString(),
  });
}

// AI-specific event emitters
export function emitAIProgress(roomId: string, progress: number, message: string, stage: string) {
  emitToRoom(roomId, 'ai-progress-update', {
    progress,
    message,
    stage,
  });
}

export function emitAIThinking(roomId: string, thought: string, confidence: number) {
  emitToRoom(roomId, 'ai-thinking-update', {
    thought,
    confidence,
  });
}

export function emitCodeGeneration(roomId: string, code: string, language: string, progress: number) {
  emitToRoom(roomId, 'code-generation-update', {
    code,
    language,
    progress,
  });
}

export function emitImageGeneration(roomId: string, progress: number, status: string, imageUrl?: string) {
  emitToRoom(roomId, 'image-generation-update', {
    progress,
    status,
    imageUrl,
  });
}