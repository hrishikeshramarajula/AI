// 🌟 Unified Brain Interface
// Integrates brain processing chat with enhanced AI brain display

'use client';

import React, { useState } from 'react';
import { 
  Brain, 
  MessageSquare, 
  Settings, 
  Maximize2, 
  Minimize2,
  ToggleLeft,
  ToggleRight,
  Zap,
  Target,
  BookOpen
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import BrainChatInterface from './BrainChatInterface';
import EnhancedAIBrainReal from './EnhancedAIBrainReal';

interface UnifiedBrainInterfaceProps {
  isVisible: boolean;
  onClose: () => void;
}

export default function UnifiedBrainInterface({ isVisible, onClose }: UnifiedBrainInterfaceProps) {
  const [activeView, setActiveView] = useState<'chat' | 'detailed'>('chat');
  const [isMaximized, setIsMaximized] = useState(false);
  const [showBrainProcessing, setShowBrainProcessing] = useState(true);

  if (!isVisible) return null;

  return (
    <div className={`fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 ${isMaximized ? 'p-0' : 'p-4'}`}>
      <Card className={`w-full bg-white shadow-2xl ${isMaximized ? 'h-screen rounded-none' : 'max-h-[90vh] max-w-6xl'}`}>
        {/* Header */}
        <CardHeader className="pb-3 border-b">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <Brain className="w-6 h-6 text-blue-600" />
                <CardTitle className="text-xl">🧠 Unified Brain Interface</CardTitle>
              </div>
              <Badge className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                Advanced AI Processing
              </Badge>
            </div>
            
            <div className="flex items-center gap-2">
              {/* View Toggle */}
              <div className="flex items-center gap-2 bg-gray-100 rounded-lg p-1">
                <Button
                  variant={activeView === 'chat' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setActiveView('chat')}
                  className="flex items-center gap-2"
                >
                  <MessageSquare className="w-4 h-4" />
                  Chat
                </Button>
                <Button
                  variant={activeView === 'detailed' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setActiveView('detailed')}
                  className="flex items-center gap-2"
                >
                  <Brain className="w-4 h-4" />
                  Detailed Brain
                </Button>
              </div>

              {/* Brain Processing Toggle */}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowBrainProcessing(!showBrainProcessing)}
                className="flex items-center gap-2"
              >
                {showBrainProcessing ? <ToggleRight className="w-4 h-4 text-green-600" /> : <ToggleLeft className="w-4 h-4 text-gray-400" />}
                {showBrainProcessing ? 'Brain ON' : 'Brain OFF'}
              </Button>

              {/* Maximize/Minimize */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsMaximized(!isMaximized)}
              >
                {isMaximized ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </Button>

              {/* Close */}
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
              >
                ×
              </Button>
            </div>
          </div>

          {/* Status Bar */}
          <div className="flex items-center justify-between mt-3 text-sm text-gray-600">
            <div className="flex items-center gap-4">
              {showBrainProcessing ? (
                <>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <span>Brain Processing: Active</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-blue-600" />
                    <span>Real-time Analysis</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-purple-600" />
                    <span>Knowledge Integration</span>
                  </div>
                </>
              ) : (
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                  <span>Brain Processing: Disabled</span>
                </div>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              <Badge variant="outline">Mode: {activeView === 'chat' ? 'Conversation' : 'Detailed Analysis'}</Badge>
              <Badge variant="outline">Processing: {showBrainProcessing ? 'Enhanced' : 'Standard'}</Badge>
            </div>
          </div>
        </CardHeader>

        {/* Content */}
        <CardContent className="p-0 h-full overflow-hidden">
          {activeView === 'chat' ? (
            <BrainChatInterface />
          ) : (
            <EnhancedAIBrainReal 
              isVisible={true} 
              onClose={() => {}} 
            />
          )}
        </CardContent>

        {/* Footer */}
        <div className="border-t p-4 bg-gray-50">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-yellow-600" />
              <div>
                <div className="font-semibold">Lightning Fast</div>
                <div className="text-xs text-gray-600">Real-time brain processing</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4 text-blue-600" />
              <div>
                <div className="font-semibold">Intelligent Analysis</div>
                <div className="text-xs text-gray-600">Multi-step cognitive processing</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-green-600" />
              <div>
                <div className="font-semibold">Goal-Oriented</div>
                <div className="text-xs text-gray-600">Strategic response generation</div>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}