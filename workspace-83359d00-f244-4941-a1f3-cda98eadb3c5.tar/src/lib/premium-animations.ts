// Premium Animations System 3.0 - Advanced Scroll-Triggered, 3D Effects & Particle Systems
// This system creates premium animations that bring websites to life

export interface AnimationConfig {
  scrollTriggered: boolean
  threeDEffects: boolean
  particleSystems: boolean
  morphingShapes: boolean
  parallaxIntensity: 'low' | 'medium' | 'high'
  interactionLevel: 'subtle' | 'moderate' | 'intense'
}

export class PremiumAnimationSystem {
  private config: AnimationConfig
  private animations: Map<string, Animation> = new Map()
  private observers: Map<string, IntersectionObserver> = new Map()

  constructor(config: AnimationConfig) {
    this.config = config
  }

  // Initialize all premium animations
  initializeAnimations() {
    if (typeof window === 'undefined') return

    this.initializeScrollTriggeredAnimations()
    this.initialize3DEffects()
    this.initializeParticleSystems()
    this.initializeMorphingShapes()
    this.initializeParallaxEffects()
    this.initializeAdvancedInteractions()
    this.initializePerformanceOptimizations()
  }

  // Scroll-Triggered Animations
  private initializeScrollTriggeredAnimations() {
    if (!this.config.scrollTriggered) return

    const animationTypes = [
      'fadeInUp',
      'fadeInDown',
      'fadeInLeft',
      'fadeInRight',
      'slideInUp',
      'slideInDown',
      'slideInLeft',
      'slideInRight',
      'zoomIn',
      'zoomOut',
      'rotateIn',
      'flipIn',
      'bounceIn',
      'elasticIn'
    ]

    animationTypes.forEach(type => {
      this.createScrollTriggeredAnimation(type)
    })

    // Stagger animations for multiple elements
    this.initializeStaggerAnimations()
  }

  private createScrollTriggeredAnimation(type: string) {
    const elements = document.querySelectorAll(`[data-animate="${type}"]`)
    
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const element = entry.target as HTMLElement
          this.triggerAnimation(element, type)
          observer.unobserve(element)
        }
      })
    }, {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    })

    elements.forEach(element => {
      observer.observe(element)
    })

    this.observers.set(type, observer)
  }

  private triggerAnimation(element: HTMLElement, type: string) {
    const animation = this.getAnimationKeyframes(type)
    const duration = this.getAnimationDuration(type)
    const easing = this.getAnimationEasing(type)
    
    element.style.animation = `${type} ${duration} ${easing} forwards`
    
    // Add animation styles if not already present
    if (!document.querySelector(`#animation-styles-${type}`)) {
      this.addAnimationStyles(type, animation)
    }
  }

  private getAnimationKeyframes(type: string): Keyframe[] {
    const keyframes: Record<string, Keyframe[]> = {
      fadeInUp: [
        { opacity: 0, transform: 'translateY(50px)' },
        { opacity: 1, transform: 'translateY(0)' }
      ],
      fadeInDown: [
        { opacity: 0, transform: 'translateY(-50px)' },
        { opacity: 1, transform: 'translateY(0)' }
      ],
      fadeInLeft: [
        { opacity: 0, transform: 'translateX(-50px)' },
        { opacity: 1, transform: 'translateX(0)' }
      ],
      fadeInRight: [
        { opacity: 0, transform: 'translateX(50px)' },
        { opacity: 1, transform: 'translateX(0)' }
      ],
      slideInUp: [
        { transform: 'translateY(100%)' },
        { transform: 'translateY(0)' }
      ],
      slideInDown: [
        { transform: 'translateY(-100%)' },
        { transform: 'translateY(0)' }
      ],
      slideInLeft: [
        { transform: 'translateX(-100%)' },
        { transform: 'translateX(0)' }
      ],
      slideInRight: [
        { transform: 'translateX(100%)' },
        { transform: 'translateX(0)' }
      ],
      zoomIn: [
        { opacity: 0, transform: 'scale(0.5)' },
        { opacity: 1, transform: 'scale(1)' }
      ],
      zoomOut: [
        { opacity: 0, transform: 'scale(1.5)' },
        { opacity: 1, transform: 'scale(1)' }
      ],
      rotateIn: [
        { opacity: 0, transform: 'rotate(-180deg) scale(0.5)' },
        { opacity: 1, transform: 'rotate(0deg) scale(1)' }
      ],
      flipIn: [
        { opacity: 0, transform: 'perspective(400px) rotateY(90deg)' },
        { opacity: 1, transform: 'perspective(400px) rotateY(0deg)' }
      ],
      bounceIn: [
        { opacity: 0, transform: 'scale(0.3)' },
        { opacity: 1, transform: 'scale(1.05)' },
        { transform: 'scale(0.9)' },
        { transform: 'scale(1)' }
      ],
      elasticIn: [
        { opacity: 0, transform: 'scale(0)' },
        { opacity: 1, transform: 'scale(1.3)' },
        { transform: 'scale(0.9)' },
        { transform: 'scale(1)' }
      ]
    }

    return keyframes[type] || keyframes.fadeInUp
  }

  private getAnimationDuration(type: string): string {
    const durations: Record<string, string> = {
      fadeInUp: '0.8s',
      fadeInDown: '0.8s',
      fadeInLeft: '0.8s',
      fadeInRight: '0.8s',
      slideInUp: '0.6s',
      slideInDown: '0.6s',
      slideInLeft: '0.6s',
      slideInRight: '0.6s',
      zoomIn: '0.8s',
      zoomOut: '0.8s',
      rotateIn: '1s',
      flipIn: '1s',
      bounceIn: '1.2s',
      elasticIn: '1.5s'
    }

    return durations[type] || '0.8s'
  }

  private getAnimationEasing(type: string): string {
    const easings: Record<string, string> = {
      fadeInUp: 'cubic-bezier(0.4, 0, 0.2, 1)',
      fadeInDown: 'cubic-bezier(0.4, 0, 0.2, 1)',
      fadeInLeft: 'cubic-bezier(0.4, 0, 0.2, 1)',
      fadeInRight: 'cubic-bezier(0.4, 0, 0.2, 1)',
      slideInUp: 'cubic-bezier(0.4, 0, 0.2, 1)',
      slideInDown: 'cubic-bezier(0.4, 0, 0.2, 1)',
      slideInLeft: 'cubic-bezier(0.4, 0, 0.2, 1)',
      slideInRight: 'cubic-bezier(0.4, 0, 0.2, 1)',
      zoomIn: 'cubic-bezier(0.4, 0, 0.2, 1)',
      zoomOut: 'cubic-bezier(0.4, 0, 0.2, 1)',
      rotateIn: 'cubic-bezier(0.4, 0, 0.2, 1)',
      flipIn: 'cubic-bezier(0.4, 0, 0.2, 1)',
      bounceIn: 'cubic-bezier(0.68, -0.55, 0.265, 1.55)',
      elasticIn: 'cubic-bezier(0.68, -0.55, 0.265, 1.55)'
    }

    return easings[type] || 'cubic-bezier(0.4, 0, 0.2, 1)'
  }

  private addAnimationStyles(type: string, keyframes: Keyframe[]) {
    const style = document.createElement('style')
    style.id = `animation-styles-${type}`
    style.textContent = `
      @keyframes ${type} {
        ${keyframes.map((keyframe, index) => {
          const percentage = (index / (keyframes.length - 1)) * 100
          return `${percentage}% { ${Object.entries(keyframe).map(([key, value]) => `${key}: ${value}`).join('; ')} }`
        }).join('\n        ')}
      }
    `
    document.head.appendChild(style)
  }

  private initializeStaggerAnimations() {
    const staggerElements = document.querySelectorAll('[data-stagger]')
    
    staggerElements.forEach(container => {
      const children = container.children
      const delay = parseFloat(container.getAttribute('data-stagger-delay') || '0.1')
      
      Array.from(children).forEach((child, index) => {
        const element = child as HTMLElement
        const animationType = element.getAttribute('data-animate') || 'fadeInUp'
        element.style.animationDelay = `${index * delay}s`
      })
    })
  }

  // 3D Effects
  private initialize3DEffects() {
    if (!this.config.threeDEffects) return

    this.initialize3DCards()
    this.initialize3DNavigation()
    this.initialize3DBackgrounds()
  }

  private initialize3DCards() {
    const cards = document.querySelectorAll('[data-3d-card]')
    
    cards.forEach(card => {
      const element = card as HTMLElement
      
      element.addEventListener('mousemove', (e) => {
        const rect = element.getBoundingClientRect()
        const x = e.clientX - rect.left
        const y = e.clientY - rect.top
        
        const centerX = rect.width / 2
        const centerY = rect.height / 2
        
        const rotateX = ((y - centerY) / centerY) * 15
        const rotateY = ((centerX - x) / centerX) * 15
        
        element.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(20px)`
      })
      
      element.addEventListener('mouseleave', () => {
        element.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) translateZ(0)'
      })
    })
  }

  private initialize3DNavigation() {
    const navItems = document.querySelectorAll('[data-3d-nav]')
    
    navItems.forEach(item => {
      const element = item as HTMLElement
      
      element.addEventListener('mouseenter', () => {
        element.style.transform = 'translateZ(20px) scale(1.05)'
        element.style.boxShadow = '0 10px 40px rgba(0,0,0,0.3)'
      })
      
      element.addEventListener('mouseleave', () => {
        element.style.transform = 'translateZ(0) scale(1)'
        element.style.boxShadow = 'none'
      })
    })
  }

  private initialize3DBackgrounds() {
    const backgrounds = document.querySelectorAll('[data-3d-background]')
    
    backgrounds.forEach(bg => {
      const element = bg as HTMLElement
      
      // Create 3D floating elements
      for (let i = 0; i < 5; i++) {
        const floatingElement = document.createElement('div')
        floatingElement.className = 'floating-3d-element'
        floatingElement.style.cssText = `
          position: absolute;
          width: ${Math.random() * 100 + 50}px;
          height: ${Math.random() * 100 + 50}px;
          background: linear-gradient(45deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05));
          border-radius: 50%;
          top: ${Math.random() * 100}%;
          left: ${Math.random() * 100}%;
          animation: float3d ${Math.random() * 20 + 10}s infinite linear;
          animation-delay: ${Math.random() * 5}s;
        `
        element.appendChild(floatingElement)
      }
    })
  }

  // Particle Systems
  private initializeParticleSystems() {
    if (!this.config.particleSystems) return

    const particleContainers = document.querySelectorAll('[data-particles]')
    
    particleContainers.forEach(container => {
      this.createParticleSystem(container as HTMLElement)
    })
  }

  private createParticleSystem(container: HTMLElement) {
    const particleCount = parseInt(container.getAttribute('data-particle-count') || '50')
    const particleSize = parseFloat(container.getAttribute('data-particle-size') || '2')
    const particleColor = container.getAttribute('data-particle-color') || '#ffffff'
    
    for (let i = 0; i < particleCount; i++) {
      const particle = document.createElement('div')
      particle.className = 'premium-particle'
      
      const size = Math.random() * particleSize + 1
      const x = Math.random() * 100
      const y = Math.random() * 100
      const duration = Math.random() * 20 + 10
      const delay = Math.random() * 5
      
      particle.style.cssText = `
        position: absolute;
        width: ${size}px;
        height: ${size}px;
        background: ${particleColor};
        border-radius: 50%;
        left: ${x}%;
        top: ${y}%;
        opacity: ${Math.random() * 0.5 + 0.2};
        animation: particleFloat ${duration}s infinite linear;
        animation-delay: ${delay}s;
        pointer-events: none;
      `
      
      container.appendChild(particle)
    }
    
    // Add particle animation styles
    if (!document.querySelector('#particle-styles')) {
      const style = document.createElement('style')
      style.id = 'particle-styles'
      style.textContent = `
        @keyframes particleFloat {
          0% {
            transform: translateY(0) translateX(0) rotate(0deg);
            opacity: 0;
          }
          10% {
            opacity: 1;
          }
          90% {
            opacity: 1;
          }
          100% {
            transform: translateY(-100vh) translateX(${Math.random() * 200 - 100}px) rotate(360deg);
            opacity: 0;
          }
        }
        
        @keyframes float3d {
          0% {
            transform: translateY(0) translateX(0) rotate(0deg) scale(1);
          }
          33% {
            transform: translateY(-30px) translateX(30px) rotate(120deg) scale(1.1);
          }
          66% {
            transform: translateY(30px) translateX(-30px) rotate(240deg) scale(0.9);
          }
          100% {
            transform: translateY(0) translateX(0) rotate(360deg) scale(1);
          }
        }
      `
      document.head.appendChild(style)
    }
  }

  // Morphing Shapes
  private initializeMorphingShapes() {
    if (!this.config.morphingShapes) return

    const morphContainers = document.querySelectorAll('[data-morphing]')
    
    morphContainers.forEach(container => {
      this.createMorphingShapes(container as HTMLElement)
    })
  }

  private createMorphingShapes(container: HTMLElement) {
    const shapeCount = parseInt(container.getAttribute('data-morph-count') || '3')
    
    for (let i = 0; i < shapeCount; i++) {
      const shape = document.createElement('div')
      shape.className = 'morphing-shape'
      
      const size = Math.random() * 300 + 200
      const duration = Math.random() * 20 + 15
      const delay = Math.random() * 5
      
      shape.style.cssText = `
        position: absolute;
        width: ${size}px;
        height: ${size}px;
        background: linear-gradient(45deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05));
        border-radius: 30% 70% 70% 30% / 30% 30% 70% 70%;
        top: ${Math.random() * 100}%;
        left: ${Math.random() * 100}%;
        animation: morph ${duration}s infinite ease-in-out;
        animation-delay: ${delay}s;
        filter: blur(40px);
        pointer-events: none;
      `
      
      container.appendChild(shape)
    }
    
    // Add morphing animation styles
    if (!document.querySelector('#morphing-styles')) {
      const style = document.createElement('style')
      style.id = 'morphing-styles'
      style.textContent = `
        @keyframes morph {
          0%, 100% {
            border-radius: 30% 70% 70% 30% / 30% 30% 70% 70%;
            transform: scale(1) rotate(0deg);
          }
          25% {
            border-radius: 58% 42% 75% 25% / 76% 24% 26% 74%;
            transform: scale(1.1) rotate(90deg);
          }
          50% {
            border-radius: 50% 50% 33% 67% / 55% 27% 73% 45%;
            transform: scale(0.9) rotate(180deg);
          }
          75% {
            border-radius: 33% 67% 58% 42% / 63% 68% 32% 37%;
            transform: scale(1.05) rotate(270deg);
          }
        }
      `
      document.head.appendChild(style)
    }
  }

  // Parallax Effects
  private initializeParallaxEffects() {
    const parallaxElements = document.querySelectorAll('[data-parallax]')
    
    parallaxElements.forEach(element => {
      const speed = parseFloat(element.getAttribute('data-parallax-speed') || '0.5')
      this.createParallaxEffect(element as HTMLElement, speed)
    })
  }

  private createParallaxEffect(element: HTMLElement, speed: number) {
    const initialTop = element.offsetTop
    const initialLeft = element.offsetLeft
    
    const handleScroll = () => {
      const scrolled = window.pageYOffset
      const rate = scrolled * -speed
      
      if (element.getAttribute('data-parallax-direction') === 'horizontal') {
        element.style.transform = `translateX(${rate}px)`
      } else {
        element.style.transform = `translateY(${rate}px)`
      }
    }
    
    window.addEventListener('scroll', this.debounce(handleScroll, 10))
  }

  // Advanced Interactions
  private initializeAdvancedInteractions() {
    this.initializeMagneticButtons()
    this.initializeGlowEffects()
    this.initializeTextReveal()
    this.initializeImageReveal()
  }

  private initializeMagneticButtons() {
    const magneticButtons = document.querySelectorAll('[data-magnetic]')
    
    magneticButtons.forEach(button => {
      const element = button as HTMLElement
      
      element.addEventListener('mousemove', (e) => {
        const rect = element.getBoundingClientRect()
        const x = e.clientX - rect.left - rect.width / 2
        const y = e.clientY - rect.top - rect.height / 2
        
        const distance = Math.sqrt(x * x + y * y)
        const maxDistance = 100
        
        if (distance < maxDistance) {
          const force = (maxDistance - distance) / maxDistance
          const moveX = (x / distance) * force * 20
          const moveY = (y / distance) * force * 20
          
          element.style.transform = `translate(${moveX}px, ${moveY}px)`
        }
      })
      
      element.addEventListener('mouseleave', () => {
        element.style.transform = 'translate(0, 0)'
      })
    })
  }

  private initializeGlowEffects() {
    const glowElements = document.querySelectorAll('[data-glow]')
    
    glowElements.forEach(element => {
      const el = element as HTMLElement
      const color = el.getAttribute('data-glow-color') || '#ffffff'
      const intensity = parseFloat(el.getAttribute('data-glow-intensity') || '0.5')
      
      el.addEventListener('mouseenter', () => {
        el.style.boxShadow = `0 0 ${intensity * 40}px ${color}, 0 0 ${intensity * 80}px ${color}`
        el.style.textShadow = `0 0 ${intensity * 20}px ${color}`
      })
      
      el.addEventListener('mouseleave', () => {
        el.style.boxShadow = ''
        el.style.textShadow = ''
      })
    })
  }

  private initializeTextReveal() {
    const revealElements = document.querySelectorAll('[data-text-reveal]')
    
    revealElements.forEach(element => {
      const el = element as HTMLElement
      const text = el.textContent || ''
      el.innerHTML = ''
      
      text.split('').forEach((char, index) => {
        const span = document.createElement('span')
        span.textContent = char
        span.style.cssText = `
          display: inline-block;
          opacity: 0;
          transform: translateY(20px);
          transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
          transition-delay: ${index * 0.05}s;
        `
        el.appendChild(span)
      })
      
      // Trigger reveal when element is in viewport
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const spans = el.querySelectorAll('span')
            spans.forEach(span => {
              span.style.opacity = '1'
              span.style.transform = 'translateY(0)'
            })
            observer.unobserve(el)
          }
        })
      }, { threshold: 0.5 })
      
      observer.observe(el)
    })
  }

  private initializeImageReveal() {
    const revealImages = document.querySelectorAll('[data-image-reveal]')
    
    revealImages.forEach(image => {
      const img = image as HTMLImageElement
      
      img.style.opacity = '0'
      img.style.transform = 'scale(1.1)'
      img.style.transition = 'all 1s cubic-bezier(0.4, 0, 0.2, 1)'
      
      img.addEventListener('load', () => {
        const observer = new IntersectionObserver((entries) => {
          entries.forEach(entry => {
            if (entry.isIntersecting) {
              img.style.opacity = '1'
              img.style.transform = 'scale(1)'
              observer.unobserve(img)
            }
          })
        }, { threshold: 0.1 })
        
        observer.observe(img)
      })
    })
  }

  // Performance Optimizations
  private initializePerformanceOptimizations() {
    // Reduce motion for users who prefer it
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)')
    if (prefersReducedMotion.matches) {
      document.body.classList.add('reduce-motion')
    }
    
    // Optimize scroll events
    let ticking = false
    const optimizedScroll = () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          ticking = false
        })
        ticking = true
      }
    }
    
    window.addEventListener('scroll', optimizedScroll, { passive: true })
    
    // Lazy load animations
    this.lazyLoadAnimations()
  }

  private lazyLoadAnimations() {
    const lazyElements = document.querySelectorAll('[data-lazy-animate]')
    
    const lazyObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const element = entry.target as HTMLElement
          const animationType = element.getAttribute('data-lazy-animate')
          
          if (animationType) {
            this.triggerAnimation(element, animationType)
          }
          
          lazyObserver.unobserve(element)
        }
      })
    }, {
      rootMargin: '50px'
    })
    
    lazyElements.forEach(element => {
      lazyObserver.observe(element)
    })
  }

  // Utility methods
  private debounce(func: Function, wait: number): Function {
    let timeout: number
    return function executedFunction(...args: any[]) {
      const later = () => {
        clearTimeout(timeout)
        func(...args)
      }
      clearTimeout(timeout)
      timeout = window.setTimeout(later, wait)
    }
  }

  // Public methods for controlling animations
  pauseAnimation(element: HTMLElement, animationName: string) {
    element.style.animationPlayState = 'paused'
  }

  resumeAnimation(element: HTMLElement, animationName: string) {
    element.style.animationPlayState = 'running'
  }

  restartAnimation(element: HTMLElement, animationName: string) {
    element.style.animation = 'none'
    element.offsetHeight // Trigger reflow
    element.style.animation = ''
    this.triggerAnimation(element, animationName)
  }

  // Cleanup
  destroy() {
    this.observers.forEach(observer => {
      observer.disconnect()
    })
    this.observers.clear()
    this.animations.clear()
  }

  // Generate CSS for all animations
  generateAnimationCSS(): string {
    return `
    /* Premium Animation System 3.0 */
    
    /* Reduce motion support */
    .reduce-motion *,
    .reduce-motion *::before,
    .reduce-motion *::after {
      animation-duration: 0.01ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.01ms !important;
      scroll-behavior: auto !important;
    }
    
    /* Base animation classes */
    [data-animate] {
      opacity: 0;
      will-change: transform, opacity;
    }
    
    /* 3D Effects */
    [data-3d-card] {
      transform-style: preserve-3d;
      transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    [data-3d-nav] {
      transform-style: preserve-3d;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    /* Particle system base styles */
    .premium-particle {
      will-change: transform, opacity;
    }
    
    /* Morphing shapes base styles */
    .morphing-shape {
      will-change: border-radius, transform;
    }
    
    /* Parallax base styles */
    [data-parallax] {
      will-change: transform;
    }
    
    /* Magnetic buttons */
    [data-magnetic] {
      transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    /* Glow effects */
    [data-glow] {
      transition: box-shadow 0.3s cubic-bezier(0.4, 0, 0.2, 1), text-shadow 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    /* Text reveal */
    [data-text-reveal] {
      overflow: hidden;
    }
    
    /* Image reveal */
    [data-image-reveal] {
      overflow: hidden;
      border-radius: inherit;
    }
    
    /* Performance optimizations */
    .animate-on-demand {
      will-change: transform, opacity;
    }
    
    /* Smooth scrolling for parallax */
    html {
      scroll-behavior: smooth;
    }
    
    /* Hardware acceleration */
    .gpu-accelerated {
      transform: translateZ(0);
      backface-visibility: hidden;
      perspective: 1000px;
    }
    `
  }
}

// Export the premium animation system
export default PremiumAnimationSystem