import { NextRequest, NextResponse } from 'next/server';

interface Task {
  id: string;
  status: 'needs-review' | 'completed';
  timestamp: string;
  content: string;
}

// Mock tasks data - in a real app, this would come from a database
const mockTasks: Task[] = [
  {
    id: '1',
    status: 'needs-review',
    timestamp: new Date(Date.now() - 3600000).toISOString(), // 1 hour ago
    content: 'Review user authentication implementation'
  },
  {
    id: '2',
    status: 'needs-review',
    timestamp: new Date(Date.now() - 7200000).toISOString(), // 2 hours ago
    content: 'Optimize database queries for better performance'
  },
  {
    id: '3',
    status: 'completed',
    timestamp: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
    content: 'Setup project structure and initial configuration'
  }
];

export async function GET(request: NextRequest) {
  try {
    // In a real application, you would fetch tasks from a database
    // For now, we'll return mock data
    return NextResponse.json({
      success: true,
      tasks: mockTasks
    });

  } catch (error) {
    console.error('Error fetching tasks:', error);
    return NextResponse.json(
      { 
        error: error instanceof Error ? error.message : 'Failed to fetch tasks',
        details: error instanceof Error ? error.stack : undefined
      },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { content, status = 'needs-review' } = body;

    if (!content) {
      return NextResponse.json(
        { error: 'Task content is required' },
        { status: 400 }
      );
    }

    // In a real application, you would save the task to a database
    const newTask: Task = {
      id: Date.now().toString(),
      status,
      timestamp: new Date().toISOString(),
      content
    };

    // Add to mock tasks (in real app, this would be a database insert)
    mockTasks.unshift(newTask);

    return NextResponse.json({
      success: true,
      task: newTask
    });

  } catch (error) {
    console.error('Error creating task:', error);
    return NextResponse.json(
      { 
        error: error instanceof Error ? error.message : 'Failed to create task',
        details: error instanceof Error ? error.stack : undefined
      },
      { status: 500 }
    );
  }
}