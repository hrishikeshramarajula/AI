/** @type {import('next').NextConfig} */
const nextConfig = {
  // Increase timeout for API routes
  experimental: {
    // Allow longer serverless function execution time
    serverComponentsExternalPackages: [],
  },
  
  // Configure headers for long-running requests
  async headers() {
    return [
      {
        source: '/api/:path*',
        headers: [
          {
            key: 'Cache-Control',
            value: 'no-cache, no-store, must-revalidate',
          },
          {
            key: 'Pragma',
            value: 'no-cache',
          },
          {
            key: 'Expires',
            value: '0',
          },
        ],
      },
    ];
  },

  // Optimize for long-running API routes
  async rewrites() {
    return [
      {
        source: '/api/deep-research',
        destination: '/api/deep-research',
      },
    ];
  },

  // Increase body size limit for large research responses
  api: {
    bodyParser: {
      sizeLimit: '10mb',
    },
  },

  // Enable compression for better performance
  compress: true,

  // Optimize builds
  swcMinify: true,

  // Configure webpack for better performance
  webpack: (config, { dev, isServer }) => {
    // Increase timeout for development
    if (dev) {
      config.devServer = {
        ...config.devServer,
        client: {
          ...config.devServer?.client,
          overlay: {
            ...config.devServer?.client?.overlay,
            runtimeErrors: (error) => {
              // Don't show overlay for timeout errors
              if (error.message.includes('timeout')) {
                return false;
              }
              return true;
            },
          },
        },
      };
    }

    // Optimize for long-running operations
    if (isServer) {
      config.performance = {
        ...config.performance,
        maxEntrypointSize: 512000,
        maxAssetSize: 512000,
      };
    }

    return config;
  },
};

module.exports = nextConfig;