# Complete Guide to Permanently Solving 502 Bad Gateway Errors

## What is a 502 Error?

A **502 Bad Gateway** error occurs when a server acting as a gateway or proxy receives an invalid response from an upstream server. It's like a middleman telling you: "I tried to get the information you requested, but the server I'm talking to isn't responding properly."

## Common Causes of 502 Errors

### 1. **Server Overload**
- Upstream server is down or overloaded
- Too many concurrent requests
- Server resources exhausted (CPU, memory, disk space)

### 2. **Network Issues**
- DNS resolution problems
- Firewall blocking connections
- Network connectivity issues
- Timeouts between servers

### 3. **Proxy/Load Balancer Issues**
- Misconfigured reverse proxy (Nginx, Apache, etc.)
- Load balancer health check failures
- SSL/TLS certificate problems
- Incorrect proxy settings

### 4. **Application Issues**
- Application crashes or freezes
- Database connection problems
- Memory leaks
- Unhandled exceptions

## Permanent Solutions by Context

### 🖥️ **For Server Administrators**

#### **1. Server Resource Management**
```bash
# Monitor server resources
top -c
htop
free -h
df -h

# Check server logs
tail -f /var/log/nginx/error.log
tail -f /var/log/apache2/error.log
journalctl -u your-service -f
```

**Permanent Fix:**
- Increase server resources (CPU, RAM, storage)
- Implement auto-scaling for traffic spikes
- Set up resource monitoring alerts
- Optimize application performance

#### **2. Reverse Proxy Configuration (Nginx)**
```nginx
# /etc/nginx/nginx.conf
http {
    # Increase timeouts
    proxy_connect_timeout 600;
    proxy_send_timeout 600;
    proxy_read_timeout 600;
    send_timeout 600;
    
    # Buffer optimization
    proxy_buffer_size 128k;
    proxy_buffers 4 256k;
    proxy_busy_buffers_size 256k;
    
    # Health checks
    upstream backend {
        server backend1.example.com;
        server backend2.example.com;
        keepalive 32;
    }
    
    server {
        location / {
            proxy_pass http://backend;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_cache_bypass $http_upgrade;
        }
    }
}
```

#### **3. Application Server Optimization**
```javascript
// Node.js example with cluster and proper error handling
const cluster = require('cluster');
const os = require('os');

if (cluster.isMaster) {
    const cpuCount = os.cpus().length;
    for (let i = 0; i < cpuCount; i++) {
        cluster.fork();
    }
    
    cluster.on('exit', (worker) => {
        console.log(`Worker ${worker.id} died. Restarting...`);
        cluster.fork();
    });
} else {
    const express = require('express');
    const app = express();
    
    // Error handling middleware
    app.use((err, req, res, next) => {
        console.error(err.stack);
        res.status(500).send('Something broke!');
    });
    
    // Graceful shutdown
    process.on('SIGTERM', () => {
        console.log('SIGTERM received, shutting down gracefully');
        server.close(() => {
            console.log('Process terminated');
        });
    });
    
    const server = app.listen(3000, () => {
        console.log(`Worker ${process.pid} started`);
    });
}
```

### 🌐 **For Network Engineers**

#### **1. DNS Configuration**
```bash
# Check DNS resolution
nslookup your-domain.com
dig your-domain.com
ping your-domain.com

# Use reliable DNS servers
# /etc/resolv.conf
nameserver 8.8.8.8
nameserver 8.8.4.4
nameserver 1.1.1.1
```

#### **2. Firewall and Security Groups**
```bash
# Check firewall rules
sudo ufw status
sudo iptables -L

# Allow necessary ports
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 3000/tcp
```

#### **3. Load Balancer Configuration**
```yaml
# AWS Application Load Balancer example
TargetGroup:
  HealthCheckEnabled: true
  HealthCheckIntervalSeconds: 30
  HealthCheckPath: /health
  HealthCheckPort: traffic-port
  HealthCheckProtocol: HTTP
  HealthCheckTimeoutSeconds: 5
  HealthyThresholdCount: 3
  UnhealthyThresholdCount: 3
```

### 📱 **For Developers**

#### **1. Application Health Checks**
```javascript
// Express health check endpoint
app.get('/health', (req, res) => {
    const health = {
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        status: 'OK',
        timestamp: Date.now()
    };
    
    // Check database connection
    try {
        // Add your database health check here
        health.database = 'connected';
    } catch (error) {
        health.database = 'disconnected';
        return res.status(503).json(health);
    }
    
    res.json(health);
});
```

#### **2. Circuit Breaker Pattern**
```javascript
const CircuitBreaker = require('opossum');

const options = {
    timeout: 5000, // If function takes longer than 5 seconds, trigger a failure
    errorThresholdPercentage: 50, // When 50% of requests fail, trip the circuit
    resetTimeout: 30000 // After 30 seconds, try again.
};

const breaker = new CircuitBreaker(asyncFunction, options);

breaker.fallback(() => {
    // Return cached data or default response
    return { data: 'Service temporarily unavailable', cached: true };
});

breaker.on('open', () => {
    console.log('Circuit breaker opened');
});

breaker.on('close', () => {
    console.log('Circuit breaker closed');
});
```

#### **3. Retry Logic with Exponential Backoff**
```javascript
async function fetchWithRetry(url, options = {}, maxRetries = 3) {
    let retryCount = 0;
    
    while (retryCount < maxRetries) {
        try {
            const response = await fetch(url, options);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            retryCount++;
            
            if (retryCount === maxRetries) {
                throw new Error(`Max retries (${maxRetries}) reached. Last error: ${error.message}`);
            }
            
            // Exponential backoff
            const delay = Math.pow(2, retryCount) * 1000;
            console.log(`Retry ${retryCount}/${maxRetries} after ${delay}ms`);
            
            await new Promise(resolve => setTimeout(resolve, delay));
        }
    }
}
```

### 🔄 **For DevOps Engineers**

#### **1. Container Orchestration (Docker/Kubernetes)**
```yaml
# docker-compose.yml
version: '3.8'
services:
  web:
    image: your-app
    deploy:
      replicas: 3
      update_config:
        parallelism: 1
        delay: 10s
      restart_policy:
        condition: on-failure
        max_attempts: 3
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s
```

#### **2. Monitoring and Alerting**
```yaml
# Prometheus configuration
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'nginx'
    static_configs:
      - targets: ['localhost:9113']
  
  - job_name: 'node-exporter'
    static_configs:
      - targets: ['localhost:9100']

# Alertmanager rules
groups:
  - name: http_errors
    rules:
      - alert: High502ErrorRate
        expr: rate(nginx_http_requests_total{status="502"}[5m]) > 0.1
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "High 502 error rate detected"
          description: "502 error rate is {{ $value }} requests per second"
```

## Permanent Prevention Strategies

### 🛡️ **1. Redundancy and High Availability**
- **Multiple servers**: Use at least 2 servers behind a load balancer
- **Geographic distribution**: Deploy across multiple data centers
- **Database replication**: Master-slave or multi-master replication
- **CDN integration**: Use Content Delivery Networks for static assets

### 📊 **2. Monitoring and Proactive Detection**
```javascript
// Comprehensive monitoring setup
const monitoring = {
    // Track 502 errors
    track502Errors: () => {
        const errorCount = get502ErrorCount();
        if (errorCount > threshold) {
            alertAdmin(`High 502 error count: ${errorCount}`);
        }
    },
    
    // Monitor server resources
    monitorResources: () => {
        const cpuUsage = getCpuUsage();
        const memoryUsage = getMemoryUsage();
        
        if (cpuUsage > 80 || memoryUsage > 80) {
            scaleUp();
        }
    },
    
    // Health check all services
    healthCheck: async () => {
        const services = ['database', 'cache', 'api', 'storage'];
        
        for (const service of services) {
            const isHealthy = await checkServiceHealth(service);
            if (!isHealthy) {
                await handleServiceFailure(service);
            }
        }
    }
};
```

### 🔄 **3. Auto-scaling Configuration**
```json
{
  "AutoScalingGroupName": "my-app-asg",
  "MinSize": 2,
  "MaxSize": 10,
  "DesiredCapacity": 2,
  "TargetTrackingConfigurations": [
    {
      "TargetValue": 70.0,
      "PredefinedMetricSpecification": {
        "PredefinedMetricType": "ASGAverageCPUUtilization"
      }
    }
  ]
}
```

### 🚨 **4. Emergency Response Plan**
1. **Immediate Actions**:
   - Check server status and logs
   - Verify network connectivity
   - Test upstream servers directly
   - Check load balancer health

2. **Communication Protocol**:
   - Alert stakeholders immediately
   - Provide status updates every 15 minutes
   - Document root cause and resolution

3. **Post-Incident Review**:
   - Analyze root cause
   - Update monitoring thresholds
   - Implement preventive measures
   - Update runbooks

## Quick Troubleshooting Checklist

### 🔍 **Immediate Diagnostic Steps**
```bash
# 1. Check if upstream server is running
systemctl status nginx
systemctl status apache2
systemctl status your-app

# 2. Check server logs
tail -f /var/log/nginx/error.log
tail -f /var/log/apache2/error.log
journalctl -u your-app -n 100

# 3. Test upstream server directly
curl -I http://localhost:3000/health
curl -I http://upstream-server:port/health

# 4. Check network connectivity
ping upstream-server
telnet upstream-server port
nslookup upstream-server

# 5. Check proxy configuration
nginx -t
apache2ctl configtest
```

### 🛠️ **Common Permanent Fixes**

#### **Fix 1: Increase Timeouts**
```nginx
# Add to nginx configuration
proxy_connect_timeout 600;
proxy_send_timeout 600;
proxy_read_timeout 600;
```

#### **Fix 2: Implement Health Checks**
```nginx
upstream backend {
    server backend1.example.com max_fails=3 fail_timeout=30s;
    server backend2.example.com max_fails=3 fail_timeout=30s;
}
```

#### **Fix 3: Optimize Application Performance**
```javascript
// Add proper error handling and timeouts
const axios = require('axios');

const api = axios.create({
    timeout: 30000,
    maxRedirects: 5,
    httpAgent: new http.Agent({ keepAlive: true }),
    httpsAgent: new https.Agent({ keepAlive: true })
});

// Add retry logic
api.interceptors.response.use(undefined, async (error) => {
    const config = error.config;
    if (!config || !config.retry) return Promise.reject(error);
    
    config.retryCount = config.retryCount || 0;
    if (config.retryCount >= config.retry) {
        return Promise.reject(error);
    }
    
    config.retryCount += 1;
    const delay = new Promise(resolve => setTimeout(resolve, 1000));
    await delay;
    return api(config);
});
```

## Conclusion

**Permanent 502 error prevention requires:**

1. **Infrastructure Redundancy**: Multiple servers, load balancers, and data centers
2. **Robust Monitoring**: Real-time alerts and proactive detection
3. **Proper Configuration**: Adequate timeouts, health checks, and resource limits
4. **Application Resilience**: Error handling, retries, and circuit breakers
5. **Automated Scaling**: Respond to traffic changes automatically
6. **Comprehensive Logging**: Detailed logs for troubleshooting
7. **Regular Maintenance**: Updates, patches, and performance optimization

By implementing these strategies systematically, you can reduce 502 errors by 90-95% and ensure your applications remain highly available and performant.