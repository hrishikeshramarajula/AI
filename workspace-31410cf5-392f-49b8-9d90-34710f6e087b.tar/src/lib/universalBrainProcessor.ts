// 🌟 Universal Brain Processor - Integrates Brain Processing into ALL Modes
// This system ensures every mode (chat, image, code, fullstack, deep-research, autonomous-agent) uses brain processing

import { realBrainIntegration, BrainProcessingInput } from './brain/brainIntegration';

export interface UniversalBrainProcessingResult {
  success: boolean;
  originalResponse: any;
  brainEnhancedResponse?: any;
  brainProcessingData?: any;
  processingTime: number;
  mode: string;
  brainCapabilities: string[];
}

export interface ModeSpecificConfig {
  mode: string;
  brainProcessingEnabled: boolean;
  processingDepth: 'basic' | 'detailed' | 'comprehensive';
  responseEnhancement: boolean;
  analysisDisplay: boolean;
}

export class UniversalBrainProcessor {
  private modeConfigs: Record<string, ModeSpecificConfig> = {
    'chat': {
      mode: 'chat',
      brainProcessingEnabled: true,
      processingDepth: 'comprehensive',
      responseEnhancement: true,
      analysisDisplay: true
    },
    'image': {
      mode: 'image',
      brainProcessingEnabled: true,
      processingDepth: 'detailed',
      responseEnhancement: true,
      analysisDisplay: true
    },
    'code': {
      mode: 'code',
      brainProcessingEnabled: true,
      processingDepth: 'detailed',
      responseEnhancement: true,
      analysisDisplay: true
    },
    'fullstack': {
      mode: 'fullstack',
      brainProcessingEnabled: true,
      processingDepth: 'comprehensive',
      responseEnhancement: true,
      analysisDisplay: true
    },
    'deep-research': {
      mode: 'deep-research',
      brainProcessingEnabled: true,
      processingDepth: 'comprehensive',
      responseEnhancement: true,
      analysisDisplay: true
    },
    'autonomous-agent': {
      mode: 'autonomous-agent',
      brainProcessingEnabled: true,
      processingDepth: 'comprehensive',
      responseEnhancement: true,
      analysisDisplay: true
    }
  };

  // Process any request with universal brain integration
  public async processWithUniversalBrain(
    input: string,
    mode: string,
    originalResponse: any,
    context?: any
  ): Promise<UniversalBrainProcessingResult> {
    const startTime = Date.now();
    const config = this.modeConfigs[mode] || this.modeConfigs['chat'];
    
    console.log(`🌟 Universal Brain Processing activated for ${mode} mode...`);
    console.log('📝 Input:', input.substring(0, 100) + (input.length > 100 ? '...' : ''));
    
    try {
      if (!config.brainProcessingEnabled) {
        console.log('⚠️ Brain processing disabled for this mode');
        return {
          success: true,
          originalResponse,
          processingTime: Date.now() - startTime,
          mode,
          brainCapabilities: []
        };
      }

      // Prepare brain input with mode-specific context
      const brainInput: BrainProcessingInput = {
        text: input,
        context: {
          ...context,
          mode,
          originalResponse: originalResponse,
          processingDepth: config.processingDepth,
          timestamp: new Date().toISOString()
        },
        preferences: {
          approach: this.getModeApproach(mode),
          priority: config.processingDepth,
          style: this.getModeStyle(mode)
        }
      };

      console.log('🧠 Processing with universal brain integration...');
      const brainResult = await realBrainIntegration.processWithRealBrain(brainInput);
      console.log('✅ Universal brain processing completed:', brainResult);

      // Create brain processing data for display
      const brainProcessingData = this.createBrainProcessingData(brainResult, mode, originalResponse);

      // Enhance original response if needed
      let finalResponse = originalResponse;
      if (config.responseEnhancement && brainResult.actualAnswer) {
        finalResponse = this.enhanceResponse(originalResponse, brainResult, mode);
      }

      const processingTime = Date.now() - startTime;

      return {
        success: true,
        originalResponse,
        brainEnhancedResponse: finalResponse,
        brainProcessingData,
        processingTime,
        mode,
        brainCapabilities: brainResult.processingMetadata.brainCapabilities
      };

    } catch (error) {
      console.error('❌ Universal brain processing failed:', error);
      
      return {
        success: false,
        originalResponse,
        processingTime: Date.now() - startTime,
        mode,
        brainCapabilities: []
      };
    }
  }

  // Get mode-specific approach
  private getModeApproach(mode: string): 'conservative' | 'aggressive' | 'balanced' {
    const approachMap: Record<string, 'conservative' | 'aggressive' | 'balanced'> = {
      'chat': 'balanced',
      'image': 'creative',
      'code': 'aggressive',
      'fullstack': 'aggressive',
      'deep-research': 'conservative',
      'autonomous-agent': 'balanced'
    };
    
    return approachMap[mode] || 'balanced';
  }

  // Get mode-specific style
  private getModeStyle(mode: string): 'detailed' | 'concise' | 'creative' | 'analytical' {
    const styleMap: Record<string, 'detailed' | 'concise' | 'creative' | 'analytical'> = {
      'chat': 'detailed',
      'image': 'creative',
      'code': 'analytical',
      'fullstack': 'analytical',
      'deep-research': 'analytical',
      'autonomous-agent': 'detailed'
    };
    
    return styleMap[mode] || 'detailed';
  }

  // Create brain processing data for display
  private createBrainProcessingData(brainResult: any, mode: string, originalResponse: any) {
    return {
      mode,
      actualAnswer: brainResult.actualAnswer || this.generateModeSpecificAnswer(mode, originalResponse),
      textAnalysis: {
        primaryIntent: brainResult.textAnalysis.intent.primaryIntent,
        confidence: brainResult.textAnalysis.intent.confidence,
        domain: brainResult.textAnalysis.entities.domain,
        complexity: brainResult.textAnalysis.complexity.overallComplexity,
        emotionalContext: brainResult.textAnalysis.emotional.primaryEmotion,
        entitiesFound: brainResult.textAnalysis.entities.entities.length
      },
      goalDecomposition: {
        subGoalsGenerated: brainResult.goalDecomposition.processingMetadata.subGoalsGenerated,
        executionApproach: brainResult.goalDecomposition.hierarchy.executionPlan.approach,
        estimatedDuration: brainResult.goalDecomposition.processingMetadata.estimatedTotalDuration,
        riskLevel: brainResult.goalDecomposition.hierarchy.riskAssessment.overallRiskLevel,
        modeSpecificGoals: this.generateModeSpecificGoals(mode)
      },
      knowledgeRetrieval: {
        knowledgeItems: brainResult.knowledgeRetrieval.knowledgeItems.length,
        strategies: brainResult.knowledgeRetrieval.strategies.length,
        recommendations: brainResult.knowledgeRetrieval.recommendations.length,
        modeSpecificKnowledge: this.generateModeSpecificKnowledge(mode)
      },
      processingMetadata: {
        totalProcessingTime: brainResult.processingMetadata.totalProcessingTime,
        confidence: brainResult.processingMetadata.confidence,
        brainCapabilities: brainResult.processingMetadata.brainCapabilities,
        mode: mode,
        processingDepth: brainResult.processingMetadata.processingDepth
      },
      originalResponse: originalResponse
    };
  }

  // Generate mode-specific answer enhancements
  private generateModeSpecificAnswer(mode: string, originalResponse: any): string {
    const answerTemplates: Record<string, string> = {
      'image': `🎨 **Image Generation Analysis**\n\nThe AI has analyzed your image generation request and is preparing to create a visual representation based on your description. The brain processing has identified key visual elements, artistic style preferences, and composition requirements.\n\n**Analysis Summary:**\n- Visual intent identified and processed\n- Artistic style requirements analyzed\n- Composition elements mapped\n- Color palette and mood assessed\n\n**Processing Status:** Ready for generation`,
      
      'code': `💻 **Code Generation Analysis**\n\nThe AI has processed your coding request and is preparing to generate high-quality, functional code. Brain processing has analyzed the requirements, identified the best programming approach, and structured the solution architecture.\n\n**Technical Analysis:**\n- Programming language and framework identified\n- Algorithm complexity assessed\n- Best practices and patterns applied\n- Error handling and optimization considered\n\n**Code Generation Status:** Ready to generate`,
      
      'fullstack': `🚀 **Fullstack Project Analysis**\n\nThe AI is processing your fullstack development request with comprehensive brain analysis. This involves frontend architecture, backend design, database schema, and deployment strategy planning.\n\n**Project Architecture Analysis:**\n- Frontend framework and components planned\n- Backend API structure designed\n- Database schema and relationships mapped\n- DevOps and deployment strategy assessed\n\n**Project Generation Status:** Architecture ready`,
      
      'deep-research': `🔬 **Deep Research Analysis**\n\nThe AI is conducting comprehensive research on your topic using advanced brain processing. This involves information retrieval, source evaluation, synthesis of knowledge, and insight generation.\n\n**Research Process:**\n- Research question analyzed and refined\n- Knowledge domains identified\n- Source credibility assessment initiated\n- Information synthesis framework established\n\n**Research Status:** Deep analysis in progress`,
      
      'autonomous-agent': `🤖 **Autonomous Agent Analysis**\n\nThe AI agent is processing your request with autonomous brain capabilities. This involves goal decomposition, strategy formulation, resource planning, and execution sequencing.\n\n**Agent Processing:**\n- Primary objectives identified and prioritized\n- Execution strategy formulated\n- Resource requirements assessed\n- Success criteria and metrics defined\n\n**Agent Status:** Autonomous processing active`,
      
      'chat': `💬 **Conversation Analysis**\n\nThe AI is processing your message with advanced conversational brain capabilities. This includes intent understanding, context analysis, knowledge retrieval, and response generation.\n\n**Conversation Processing:**\n- User intent and context analyzed\n- Relevant knowledge retrieved\n- Response strategy formulated\n- Engagement and clarity optimized\n\n**Response Status:** Processing complete`
    };

    return answerTemplates[mode] || answerTemplates['chat'];
  }

  // Generate mode-specific goals
  private generateModeSpecificGoals(mode: string): string[] {
    const goalMap: Record<string, string[]> = {
      'image': ['Analyze visual requirements', 'Determine artistic style', 'Plan composition', 'Generate image'],
      'code': ['Understand coding requirements', 'Design architecture', 'Write clean code', 'Add documentation'],
      'fullstack': ['Analyze project requirements', 'Design system architecture', 'Implement frontend', 'Implement backend'],
      'deep-research': ['Define research scope', 'Gather information', 'Analyze sources', 'Synthesize insights'],
      'autonomous-agent': ['Understand objectives', 'Plan execution strategy', 'Gather resources', 'Execute plan'],
      'chat': ['Understand user intent', 'Retrieve relevant knowledge', 'Formulate response', 'Ensure clarity']
    };

    return goalMap[mode] || goalMap['chat'];
  }

  // Generate mode-specific knowledge
  private generateModeSpecificKnowledge(mode: string): string[] {
    const knowledgeMap: Record<string, string[]> = {
      'image': ['Visual arts principles', 'Color theory', 'Composition techniques', 'Style guidelines'],
      'code': ['Programming patterns', 'Best practices', 'Framework knowledge', 'Testing strategies'],
      'fullstack': ['Web architecture', 'Database design', 'API development', 'Deployment strategies'],
      'deep-research': ['Research methodology', 'Source evaluation', 'Domain expertise', 'Analytical techniques'],
      'autonomous-agent': ['Goal planning', 'Resource management', 'Execution strategies', 'Problem solving'],
      'chat': ['Communication principles', 'Knowledge domains', 'Context understanding', 'Response optimization']
    };

    return knowledgeMap[mode] || knowledgeMap['chat'];
  }

  // Enhance response based on brain processing
  private enhanceResponse(originalResponse: any, brainResult: any, mode: string): any {
    // For different response types, enhance differently
    if (typeof originalResponse === 'string') {
      return this.enhanceTextResponse(originalResponse, brainResult, mode);
    } else if (originalResponse && typeof originalResponse === 'object') {
      return this.enhanceObjectResponse(originalResponse, brainResult, mode);
    }
    
    return originalResponse;
  }

  // Enhance text responses
  private enhanceTextResponse(originalText: string, brainResult: any, mode: string): string {
    const brainHeader = `🧠 **UNIVERSAL BRAIN ENHANCED** (${mode.toUpperCase()} Mode)\n\n`;
    const analysisSection = `---\n\n📊 **Brain Processing Analysis**\n`;
    const processingInfo = [
      `• Mode: ${mode}`,
      `• Intent: ${brainResult.textAnalysis.intent.primaryIntent}`,
      `• Confidence: ${(brainResult.textAnalysis.intent.confidence * 100).toFixed(0)}%`,
      `• Processing Time: ${brainResult.processingMetadata.totalProcessingTime}ms`,
      `• Brain Capabilities: ${brainResult.processingMetadata.brainCapabilities.length} activated`
    ].join('\n');

    return `${brainHeader}${brainResult.actualAnswer || originalText}\n\n${analysisSection}${processingInfo}`;
  }

  // Enhance object responses (like code, image data, etc.)
  private enhanceObjectResponse(originalObject: any, brainResult: any, mode: string): any {
    return {
      ...originalObject,
      brainEnhanced: true,
      brainProcessing: {
        mode,
        analysis: brainResult.textAnalysis.intent.primaryIntent,
        confidence: brainResult.processingMetadata.confidence,
        processingTime: brainResult.processingMetadata.totalProcessingTime,
        capabilities: brainResult.processingMetadata.brainCapabilities
      },
      enhancedTimestamp: new Date().toISOString()
    };
  }
}

// Export singleton instance
export const universalBrainProcessor = new UniversalBrainProcessor();