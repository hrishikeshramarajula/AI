// ZAI SDK Initializer - Ensures proper initialization on startup
import { getZAIInstance, resetZAIInstance, isZAIAvailable } from './zaiHelper';

let initializationAttempted = false;
let initializationComplete = false;

export async function initializeZAIOnStartup(): Promise<void> {
  if (initializationAttempted) {
    return;
  }

  initializationAttempted = true;
  
  try {
    console.log('🚀 Starting ZAI SDK initialization on startup...');
    
    // Attempt to initialize ZAI SDK
    const zai = await getZAIInstance();
    
    if (zai) {
      console.log('✅ ZAI SDK initialized successfully on startup');
      initializationComplete = true;
    } else {
      console.warn('⚠️ ZAI SDK initialization returned null instance');
      initializationComplete = false;
    }
    
  } catch (error) {
    console.error('❌ ZAI SDK initialization failed on startup:', error);
    initializationComplete = false;
    
    // Don't throw the error - allow the application to continue running
    // The fallback mechanisms will handle ZAI unavailability
  }
}

export async function checkZAIStatus(): Promise<{
  available: boolean;
  initialized: boolean;
  error?: string;
}> {
  try {
    const available = await isZAIAvailable();
    
    return {
      available,
      initialized: initializationComplete,
      error: available ? undefined : 'ZAI SDK not available'
    };
  } catch (error) {
    return {
      available: false,
      initialized: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}

export async function retryZAIInitialization(): Promise<boolean> {
  try {
    console.log('🔄 Retrying ZAI SDK initialization...');
    
    // Reset the instance to force fresh initialization
    await resetZAIInstance();
    
    // Attempt initialization again
    const zai = await getZAIInstance();
    
    if (zai) {
      console.log('✅ ZAI SDK re-initialization successful');
      initializationComplete = true;
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('❌ ZAI SDK re-initialization failed:', error);
    return false;
  }
}

// Initialize on module load (but don't block)
if (typeof window === 'undefined') {
  // Only run on server side
  initializeZAIOnStartup().catch(console.error);
}