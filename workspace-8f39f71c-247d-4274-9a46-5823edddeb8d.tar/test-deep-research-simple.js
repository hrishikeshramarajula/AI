// Simple test for deep research API
const fetch = require('node-fetch');

async function testDeepResearch() {
  try {
    console.log('Testing deep research API...');
    
    const response = await fetch('http://localhost:3000/api/deep-research', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message: 'What is artificial intelligence?',
        config: {
          researchDepth: 'basic',
          includeWebSearch: false // Disable web search for faster testing
        }
      }),
    });

    console.log('Response status:', response.status);
    
    if (response.ok) {
      const data = await response.json();
      console.log('Response data:', JSON.stringify(data, null, 2));
    } else {
      const errorText = await response.text();
      console.log('Error response:', errorText);
    }
  } catch (error) {
    console.error('Test failed:', error.message);
  }
}

testDeepResearch();