import { NextRequest } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  const encoder = new TextEncoder();
  const stream = new TransformStream();
  const writer = stream.writable.getWriter();
  let streamClosed = false;
  let isProcessing = true;
  
  // Extended timeout for thorough research (3+ minutes)
  const STREAM_TIMEOUT = 300000; // Increased to 300 seconds (5 minutes) for better reliability
  let timeoutId: NodeJS.Timeout;
  
  // Track start time for processing
  const startTime = Date.now();

  const closeStream = async () => {
    if (!streamClosed) {
      try {
        // Clear timeout if stream is closing
        if (timeoutId) {
          clearTimeout(timeoutId);
        }
        isProcessing = false;
        await writer.close();
        streamClosed = true;
        console.log('✅ Deep research stream closed successfully');
      } catch (error) {
        console.warn('⚠️ Deep research stream already closed or error closing:', error);
        streamClosed = true;
        isProcessing = false;
      }
    }
  };

  const writeToStream = async (data: string) => {
    if (!streamClosed && isProcessing) {
      try {
        await writer.write(encoder.encode(data));
      } catch (error) {
        console.warn('⚠️ Error writing to deep research stream:', error);
        if (error.message.includes('ResponseAborted') || error.message.includes('closed') || error.message.includes('aborted')) {
          console.log('🔄 Connection aborted, closing stream gracefully...');
          streamClosed = true;
          isProcessing = false;
          return; // Don't throw, just exit gracefully
        }
      }
    }
  };

  // Set up extended timeout
  timeoutId = setTimeout(() => {
    console.warn('⚠️ Deep research stream timeout reached, closing connection...');
    closeStream();
  }, STREAM_TIMEOUT);

  try {
    console.log('🚀 Direct Deep Research API: Processing request...');
    
    const body = await request.json();
    const { 
      message, 
      config = {},
      model = 'sonar-deep-research' 
    } = body;

    if (!message || !message.trim()) {
      await writeToStream(`data: ${JSON.stringify({ type: 'error', error: 'Research query is required' })}\n\n`);
      await closeStream();
      return new Response(stream.readable, {
        headers: {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive',
        },
      });
    }

    console.log('🚀 Direct Deep Research Query:', message.substring(0, 100) + (message.length > 100 ? '...' : ''));

    // Start streaming response - DIRECT AI DEEP RESEARCH
    (async () => {
      try {
        // Send initial status
        if (isProcessing) {
          await writeToStream(`data: ${JSON.stringify({ type: 'start', message: 'Initiating deep research...' })}\n\n`);
        }

        console.log('🧠 Starting direct AI deep research...');
        
        // Send keep-alive message every 10 seconds to maintain connection
        const keepAliveInterval = setInterval(() => {
          if (isProcessing) {
            writeToStream(`data: ${JSON.stringify({ type: 'keepalive' })}\n\n`).catch(() => {
              clearInterval(keepAliveInterval);
            });
          } else {
            clearInterval(keepAliveInterval);
          }
        }, 10000);
        
        // DIRECT AI DEEP RESEARCH - No more multi-stage processing
        try {
          await performDirectDeepResearch(writeToStream, message, model, config, isProcessing);
        } catch (error) {
          console.error('❌ Direct deep research failed:', error);
          if (isProcessing) {
            const errorLine = `\n\n❌ Research encountered an error: ${error.message}`;
            await writeToStream(`data: ${JSON.stringify({ type: 'chunk', line: errorLine, lineNumber: -1 })}\n\n`);
          }
          throw error; // Re-throw to trigger completion with error
        }
        
        // Clear keep-alive interval
        clearInterval(keepAliveInterval);
        
        console.log('✅ Direct deep research completed successfully');
        
        // Send completion signal
        if (isProcessing) {
          const completionData = {
            type: 'complete',
            confidence: 0.98,
            intent: 'direct_deep_research',
            processingTime: Date.now() - startTime,
            metadata: {
              model: model,
              query: message,
              researchMethod: 'direct_ai_deep_research',
              researchDepth: 'comprehensive'
            }
          };
          
          await writeToStream(`data: ${JSON.stringify(completionData)}\n\n`);
        }
        
        // Add a small delay to ensure the completion data is sent
        await new Promise(resolve => setTimeout(resolve, 100));
        
        // Ensure the stream is properly closed after completion
        console.log('✅ Direct deep research completed successfully, closing stream...');
        await closeStream();
        return; // Exit the function to ensure no further processing
        
      } catch (error) {
        console.error('❌ Direct deep research error:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        
        // Send error chunk
        if (isProcessing) {
          const errorLine = `\n\n❌ Research encountered an error: ${errorMessage}`;
          await writeToStream(`data: ${JSON.stringify({ type: 'chunk', line: errorLine, lineNumber: -1 })}\n\n`);
        }
        
        // Send completion signal with error info
        if (isProcessing) {
          const errorCompletionData = {
            type: 'complete',
            confidence: 0,
            intent: 'error',
            processingTime: Date.now() - startTime,
            metadata: {
              error: errorMessage,
              model: model,
              researchMethod: 'direct_ai_deep_research'
            }
          };
          
          await writeToStream(`data: ${JSON.stringify(errorCompletionData)}\n\n`);
        }
        
        // Add a small delay to ensure the error data is sent
        await new Promise(resolve => setTimeout(resolve, 100));
      } finally {
        console.log('🔄 Direct deep research process ended, ensuring stream is closed...');
        await closeStream();
      }
    })();

    return new Response(stream.readable, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });

  } catch (error) {
    console.error('❌ Outer direct deep research error:', error);
    isProcessing = false;
    const errorData = {
      type: 'error',
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
    
    try {
      await writeToStream(`data: ${JSON.stringify(errorData)}\n\n`);
    } catch (streamError) {
      console.error('❌ Error writing to direct deep research stream in outer catch:', streamError);
    }
    
    try {
      await closeStream();
    } catch (closeError) {
      console.error('❌ Error closing direct deep research stream in outer catch:', closeError);
    }
    
    return new Response(stream.readable, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });
  }
}

// DIRECT AI DEEP RESEARCH - Single call to powerful AI models
async function performDirectDeepResearch(
  writeToStream: (data: string) => Promise<void>,
  query: string,
  model: string,
  config: any,
  isProcessing: boolean
): Promise<void> {
  try {
    console.log(`🧠 Using ${model} for direct deep research on: ${query.substring(0, 50)}...`);
    
    // Initialize ZAI SDK
    const zai = await ZAI.create();
    
    // Map user-friendly model names to actual API model names with better fallback handling
    const modelMapping: Record<string, string> = {
      'sonar-deep-research': 'perplexity/sonar-deep-research',
      'sonar-reasoning-pro': 'perplexity/sonar-reasoning-pro',
      'scout-llama4': 'scout-llama-4',
      'moe': 'moe',
      'gemini-2.5-pro': 'google/gemini-2.5-pro',
      'deepseek-r1': 'deepseek/deepseek-r1',
      'deepseek-r1-zero': 'deepseek/deepseek-r1-zero',
      'gpt-4o': 'openai/gpt-4o',
      'claude-3.5-sonnet': 'anthropic/claude-3.5-sonnet',
      // Add fallback models
      'fallback-1': 'meta-llama/llama-4-maverick:free',
      'fallback-2': 'google/gemini-2-5-pro-exp-03-25:free',
      'fallback-3': 'deepseek/deepseek-v3-base:free'
    };
    
    // Try to get the primary model, but have fallbacks ready
    let apiModel = modelMapping[model] || modelMapping['sonar-deep-research'];
    const fallbackModels = [
      modelMapping['fallback-1'],
      modelMapping['fallback-2'],
      modelMapping['fallback-3'],
      'openai/gpt-4-turbo'
    ];
    
    // Create comprehensive deep research prompt
    const deepResearchPrompt = `You are an expert research AI. Conduct a thorough analysis of the following topic:

**TOPIC:** ${query}

**REQUIREMENTS:**
1. Provide a well-structured research analysis
2. Include key information and insights
3. Structure with clear sections
4. Generate comprehensive content
5. Use professional tone with proper formatting

**STRUCTURE:**
# Research Analysis: ${query}

## Introduction
- Background and significance
- Key focus areas

## Main Analysis
- Current status and developments
- Key aspects and characteristics
- Important insights and findings

## Conclusion
- Summary of key points
- Overall assessment

Provide a thorough, well-researched response with proper formatting and structure.`;
    
    // Make the direct AI call with retry logic
    let completion = null;
    let lastError = null;
    
    // Try primary model first, then fallbacks
    const modelsToTry = [apiModel, ...fallbackModels];
    
    for (const currentModel of modelsToTry) {
      try {
        console.log(`🧠 Trying model: ${currentModel} for deep research on: ${query.substring(0, 50)}...`);
        
        // Add timeout for this specific attempt
        const modelTimeoutPromise = new Promise((_, reject) => {
          setTimeout(() => reject(new Error('Model request timeout')), 60000); // 60 second timeout per model
        });
        
        const completionPromise = zai.chat.completions.create({
          messages: [
            {
              role: "system",
              content: "You are an expert deep research AI with comprehensive knowledge and advanced research capabilities. You provide thorough, well-structured, and insightful research analysis on any topic."
            },
            {
              role: "user",
              content: deepResearchPrompt
            }
          ],
          model: currentModel,
          temperature: 0.1,
          max_tokens: 2500, // Reduced from 3000 to 2500 for faster responses
          stream: false // Get complete response at once for better reliability
        });
        
        completion = await Promise.race([completionPromise, modelTimeoutPromise]);
        
        if (completion && completion.choices && completion.choices[0]?.message?.content) {
          console.log(`✅ Successfully used model: ${currentModel}`);
          apiModel = currentModel; // Update the model that worked
          break; // Success, exit the retry loop
        }
      } catch (modelError) {
        console.warn(`⚠️ Model ${currentModel} failed:`, modelError.message);
        lastError = modelError;
        // Wait before trying next model
        await new Promise(resolve => setTimeout(resolve, 2000));
        continue;
      }
    }
    
    if (!completion) {
      throw new Error(`All models failed. Last error: ${lastError?.message || 'Unknown error'}`);
    }
    
    const content = completion.choices[0]?.message?.content || '';
    
    if (content && content.trim()) {
      console.log(`✅ ${model} generated ${content.length} characters of research content`);
      
      // Send initial header
      if (isProcessing) {
        await writeToStream(`data: ${JSON.stringify({ type: 'chunk', line: `# Deep Research Analysis: ${query}`, lineNumber: -1 })}\n\n`);
        await new Promise(resolve => setTimeout(resolve, 100)); // Reduced from 200ms to 100ms
      }
      
      // Stream content paragraph by paragraph for better UX
      const paragraphs = content.split('\n\n');
      for (const paragraph of paragraphs) {
        if (paragraph.trim() && isProcessing) {
          try {
            await writeToStream(`data: ${JSON.stringify({ type: 'chunk', line: paragraph, lineNumber: -1 })}\n\n`);
            // Reduced delay for faster streaming effect
            await new Promise(resolve => setTimeout(resolve, 100)); // Reduced from 150ms to 100ms
          } catch (error) {
            console.log('Error streaming research paragraph, continuing...');
            break;
          }
        }
      }
      
      console.log(`✅ Successfully streamed research content using ${model}`);
      return;
    } else {
      throw new Error(`No content generated by ${model}`);
    }
    
  } catch (error) {
    console.error(`❌ Direct deep research failed with ${model}:`, error);
    throw error; // Re-throw to trigger fallback
  }
}