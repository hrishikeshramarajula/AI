import { NextRequest, NextResponse } from 'next/server';
import { getZAIInstance } from '@/lib/zaiHelper';

export async function POST(request: NextRequest) {
  try {
    const { prompt, model = 'flux-dev', size = '1024x1024' } = await request.json();
    
    if (!prompt) {
      return NextResponse.json({ error: 'Prompt is required' }, { status: 400 });
    }

    console.log('🎨 Generating image with prompt:', prompt);
    console.log('🎨 Using model:', model);
    console.log('🎨 Using size:', size);

    // Initialize ZAI SDK
    const zai = await getZAIInstance();
    
    // Generate image using ZAI SDK
    const response = await zai.images.generations.create({
      prompt: prompt,
      size: size as any // Type assertion to avoid TypeScript errors
    });

    // Get the base64 image data
    const imageBase64 = response.data[0]?.base64;
    
    if (!imageBase64) {
      throw new Error('No image data received from the API');
    }

    console.log('✅ Image generated successfully');

    return NextResponse.json({
      success: true,
      imageData: imageBase64,
      prompt,
      model,
      size,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('🚨 Image Generation Error:', error);
    return NextResponse.json({
      success: false,
      error: 'Failed to generate image',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}