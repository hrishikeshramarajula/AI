import { NextRequest, NextResponse } from 'next/server';
import { DeepResearchLogger, PerformanceMonitor, ErrorTracker } from '@/lib/monitoring';
import { isZAIAvailable } from '@/lib/zaiHelper';

export async function GET(request: NextRequest) {
  try {
    const logger = DeepResearchLogger.getInstance();
    const healthCheckId = `health_${Date.now()}`;
    
    logger.info('HealthCheck', 'Starting health check', { healthCheckId });
    
    // Overall health status
    let isHealthy = true;
    const checks = {
      overall: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      version: process.env.npm_package_version || '1.0.0',
      environment: process.env.NODE_ENV || 'development',
      checks: {} as Record<string, any>
    };

    // Check 1: ZAI SDK Availability
    try {
      PerformanceMonitor.startTimer('health-zai-check', { healthCheckId });
      const zaiAvailable = await isZAIAvailable();
      const zaiDuration = PerformanceMonitor.endTimer('health-zai-check');
      
      checks.checks.zai_sdk = {
        status: zaiAvailable ? 'healthy' : 'unhealthy',
        response_time: zaiDuration,
        message: zaiAvailable ? 'ZAI SDK is available' : 'ZAI SDK is not available'
      };
      
      if (!zaiAvailable) {
        isHealthy = false;
      }
      
      logger.info('HealthCheck', 'ZAI SDK check completed', { 
        healthCheckId, 
        available: zaiAvailable, 
        duration: zaiDuration 
      });
    } catch (error) {
      checks.checks.zai_sdk = {
        status: 'unhealthy',
        error: (error as Error).message,
        message: 'Failed to check ZAI SDK availability'
      };
      isHealthy = false;
      logger.error('HealthCheck', 'ZAI SDK check failed', { 
        healthCheckId, 
        error: (error as Error).message 
      });
    }

    // Check 2: Memory Usage
    try {
      const memoryUsage = process.memoryUsage();
      const memoryThreshold = 500 * 1024 * 1024; // 500MB threshold
      
      checks.checks.memory = {
        status: memoryUsage.heapUsed < memoryThreshold ? 'healthy' : 'warning',
        rss: `${Math.round(memoryUsage.rss / 1024 / 1024)}MB`,
        heap_used: `${Math.round(memoryUsage.heapUsed / 1024 / 1024)}MB`,
        heap_total: `${Math.round(memoryUsage.heapTotal / 1024 / 1024)}MB`,
        external: `${Math.round(memoryUsage.external / 1024 / 1024)}MB`,
        threshold: `${Math.round(memoryThreshold / 1024 / 1024)}MB`
      };
      
      if (memoryUsage.heapUsed > memoryThreshold) {
        isHealthy = false;
      }
    } catch (error) {
      checks.checks.memory = {
        status: 'unhealthy',
        error: (error as Error).message,
        message: 'Failed to check memory usage'
      };
      isHealthy = false;
    }

    // Check 3: System Resources
    try {
      const cpuUsage = process.cpuUsage();
      checks.checks.system = {
        status: 'healthy',
        cpu_user: cpuUsage.user,
        cpu_system: cpuUsage.system,
        platform: process.platform,
        arch: process.arch,
        node_version: process.version
      };
    } catch (error) {
      checks.checks.system = {
        status: 'unhealthy',
        error: (error as Error).message,
        message: 'Failed to check system resources'
      };
      isHealthy = false;
    }

    // Check 4: Logging System
    try {
      const recentLogs = logger.getRecentLogs(10);
      const errorLogs = logger.getErrorLogs();
      
      checks.checks.logging = {
        status: 'healthy',
        total_logs: logger.getRecentLogs().length,
        recent_errors: errorLogs.slice(-5).length,
        log_sample: recentLogs.slice(-3).map(log => ({
          timestamp: log.timestamp.toISOString(),
          level: log.level,
          component: log.component,
          message: log.message
        }))
      };
    } catch (error) {
      checks.checks.logging = {
        status: 'unhealthy',
        error: (error as Error).message,
        message: 'Failed to check logging system'
      };
      isHealthy = false;
    }

    // Check 5: Error Tracking
    try {
      const errors = ErrorTracker.getErrors();
      const unhandledErrors = ErrorTracker.getUnhandledErrors();
      
      checks.checks.error_tracking = {
        status: unhandledErrors.length === 0 ? 'healthy' : 'warning',
        total_errors: errors.length,
        unhandled_errors: unhandledErrors.length,
        recent_errors: errors.slice(-3).map(error => ({
          timestamp: error.timestamp.toISOString(),
          component: error.component,
          error: error.error.message,
          handled: error.handled
        }))
      };
      
      if (unhandledErrors.length > 0) {
        isHealthy = false;
      }
    } catch (error) {
      checks.checks.error_tracking = {
        status: 'unhealthy',
        error: (error as Error).message,
        message: 'Failed to check error tracking'
      };
      isHealthy = false;
    }

    // Check 6: Performance Monitoring
    try {
      const activeTimers = PerformanceMonitor.getActiveTimers();
      
      checks.checks.performance = {
        status: 'healthy',
        active_timers: activeTimers.length,
        active_timer_names: activeTimers
      };
    } catch (error) {
      checks.checks.performance = {
        status: 'unhealthy',
        error: (error as Error).message,
        message: 'Failed to check performance monitoring'
      };
      isHealthy = false;
    }

    // Set overall status
    checks.overall = isHealthy ? 'healthy' : 'unhealthy';

    // Determine HTTP status code
    const statusCode = isHealthy ? 200 : 503;

    logger.info('HealthCheck', 'Health check completed', { 
      healthCheckId, 
      isHealthy, 
      statusCode,
      checks_count: Object.keys(checks.checks).length 
    });

    return NextResponse.json(checks, { 
      status: statusCode,
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      }
    });

  } catch (error) {
    // If health check itself fails, return a basic error response
    console.error('Health check endpoint failed:', error);
    
    return NextResponse.json({
      overall: 'unhealthy',
      timestamp: new Date().toISOString(),
      error: 'Health check endpoint failed',
      message: (error as Error).message
    }, { 
      status: 503,
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      }
    });
  }
}

// Simple HEAD endpoint for load balancers
export async function HEAD(request: NextRequest) {
  try {
    // Quick health check without detailed diagnostics
    const zaiAvailable = await isZAIAvailable();
    const memoryUsage = process.memoryUsage();
    const memoryThreshold = 500 * 1024 * 1024; // 500MB threshold
    
    const isHealthy = zaiAvailable && memoryUsage.heapUsed < memoryThreshold;
    
    return new NextResponse(null, {
      status: isHealthy ? 200 : 503,
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      }
    });
  } catch (error) {
    return new NextResponse(null, { status: 503 });
  }
}