import { NextRequest, NextResponse } from 'next/server';

// Template system for code generation
const TEMPLATES = [
  {
    id: 'react-component-ts',
    name: 'React Component (TypeScript)',
    description: 'Basic React component with TypeScript and proper typing',
    language: 'typescript',
    code: `import React from 'react';

interface Props {
  title: string;
  onAction?: () => void;
  className?: string;
}

const Component: React.FC<Props> = ({ 
  title, 
  onAction, 
  className = '' 
}) => {
  const handleClick = () => {
    if (onAction) {
      onAction();
    }
  };

  return (
    <div className={\`component \${className}\`}>
      <h2>{title}</h2>
      {onAction && (
        <button onClick={handleClick}>
          Action
        </button>
      )}
    </div>
  );
};

export default Component;`,
    dependencies: ['react'],
    tags: ['react', 'component', 'typescript', 'ui']
  },
  {
    id: 'express-api-route',
    name: 'Express API Route',
    description: 'Express.js API route with error handling and validation',
    language: 'javascript',
    code: `const express = require('express');
const router = express.Router();

// GET /api/resource
router.get('/', async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    
    // Validate query parameters
    if (page < 1 || limit < 1 || limit > 100) {
      return res.status(400).json({
        success: false,
        error: 'Invalid pagination parameters'
      });
    }

    // Your business logic here
    const data = [];
    const total = 0;

    res.json({
      success: true,
      data,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (error) {
    console.error('Error in GET /api/resource:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// POST /api/resource
router.post('/', async (req, res) => {
  try {
    const { name, value } = req.body;

    // Validate request body
    if (!name || !value) {
      return res.status(400).json({
        success: false,
        error: 'Name and value are required'
      });
    }

    // Your business logic here
    const result = { name, value, id: Date.now() };

    res.status(201).json({
      success: true,
      data: result
    });
  } catch (error) {
    console.error('Error in POST /api/resource:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

module.exports = router;`,
    dependencies: ['express'],
    tags: ['api', 'express', 'route', 'error-handling']
  },
  {
    id: 'python-function',
    name: 'Python Function',
    description: 'Python function with error handling and documentation',
    language: 'python',
    code: `def process_data(data: dict, config: dict = None) -> dict:
    """
    Process input data and return structured results.
    
    Args:
        data (dict): Input data to process
        config (dict, optional): Configuration parameters. Defaults to None.
    
    Returns:
        dict: Processed data with metadata
    
    Raises:
        ValueError: If input data is invalid
        TypeError: If data types are incorrect
    """
    if config is None:
        config = {}
    
    try:
        # Validate input
        if not isinstance(data, dict):
            raise TypeError("Input data must be a dictionary")
        
        if not data:
            raise ValueError("Input data cannot be empty")
        
        # Extract configuration
        validate = config.get('validate', True)
        max_items = config.get('max_items', 1000)
        
        # Process data
        result = {
            'processed': True,
            'items': [],
            'metadata': {
                'timestamp': datetime.now().isoformat(),
                'config': config
            }
        }
        
        # Your processing logic here
        for key, value in data.items():
            if validate:
                # Validation logic
                if not isinstance(value, (str, int, float, bool)):
                    raise ValueError(f"Invalid value type for key '{key}'")
            
            processed_item = {
                'key': key,
                'value': value,
                'processed_at': datetime.now().isoformat()
            }
            
            result['items'].append(processed_item)
            
            # Check limits
            if len(result['items']) >= max_items:
                break
        
        result['metadata']['total_items'] = len(result['items'])
        result['metadata']['success'] = True
        
        return result
        
    except Exception as e:
        print(f"Error processing data: {e}")
        raise`,
    dependencies: ['datetime'],
    tags: ['python', 'function', 'error-handling', 'validation']
  },
  {
    id: 'java-class',
    name: 'Java Class',
    description: 'Java class with proper structure and methods',
    language: 'java',
    code: `import java.util.ArrayList;
import java.util.List;
import java.time.LocalDateTime;

/**
 * Represents a data processor with comprehensive functionality.
 */
public class DataProcessor {
    private String name;
    private List<String> items;
    private LocalDateTime createdAt;
    
    /**
     * Constructs a new DataProcessor with the specified name.
     * 
     * @param name The name of the processor
     * @throws IllegalArgumentException if name is null or empty
     */
    public DataProcessor(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name cannot be null or empty");
        }
        this.name = name;
        this.items = new ArrayList<>();
        this.createdAt = LocalDateTime.now();
    }
    
    /**
     * Adds an item to the processor.
     * 
     * @param item The item to add
     * @return true if the item was added successfully
     * @throws IllegalArgumentException if item is null or empty
     */
    public boolean addItem(String item) {
        if (item == null || item.trim().isEmpty()) {
            throw new IllegalArgumentException("Item cannot be null or empty");
        }
        
        return items.add(item.trim());
    }
    
    /**
     * Processes all items and returns the result.
     * 
     * @return Processing result containing processed items
     */
    public ProcessingResult processItems() {
        ProcessingResult result = new ProcessingResult();
        
        for (String item : items) {
            try {
                String processed = processSingleItem(item);
                result.addProcessedItem(processed);
            } catch (Exception e) {
                result.addError(item, e.getMessage());
            }
        }
        
        result.setProcessedAt(LocalDateTime.now());
        return result;
    }
    
    /**
     * Processes a single item.
     * 
     * @param item The item to process
     * @return Processed item
     */
    private String processSingleItem(String item) {
        // Your processing logic here
        return item.toUpperCase().trim();
    }
    
    // Getters and setters
    public String getName() {
        return name;
    }
    
    public List<String> getItems() {
        return new ArrayList<>(items); // Return copy for encapsulation
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    /**
     * Inner class for processing results.
     */
    public static class ProcessingResult {
        private List<String> processedItems;
        private List<String> errors;
        private LocalDateTime processedAt;
        
        public ProcessingResult() {
            this.processedItems = new ArrayList<>();
            this.errors = new ArrayList<>();
        }
        
        public void addProcessedItem(String item) {
            processedItems.add(item);
        }
        
        public void addError(String item, String error) {
            errors.add(String.format("Error processing '%s': %s", item, error));
        }
        
        // Getters
        public List<String> getProcessedItems() {
            return new ArrayList<>(processedItems);
        }
        
        public List<String> getErrors() {
            return new ArrayList<>(errors);
        }
        
        public LocalDateTime getProcessedAt() {
            return processedAt;
        }
        
        public void setProcessedAt(LocalDateTime processedAt) {
            this.processedAt = processedAt;
        }
        
        public boolean hasErrors() {
            return !errors.isEmpty();
        }
        
        public int getSuccessCount() {
            return processedItems.size();
        }
        
        public int getErrorCount() {
            return errors.size();
        }
    }
}`,
    dependencies: [],
    tags: ['java', 'class', 'oop', 'error-handling']
  }
];

// GET /api/code-templates - Get all templates or filtered by language
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const language = searchParams.get('language');
    const tag = searchParams.get('tag');

    let filteredTemplates = TEMPLATES;

    // Filter by language if specified
    if (language) {
      filteredTemplates = filteredTemplates.filter(
        template => template.language.toLowerCase() === language.toLowerCase()
      );
    }

    // Filter by tag if specified
    if (tag) {
      filteredTemplates = filteredTemplates.filter(
        template => template.tags.some(t => t.toLowerCase().includes(tag.toLowerCase()))
      );
    }

    return NextResponse.json({
      success: true,
      templates: filteredTemplates,
      total: filteredTemplates.length
    });

  } catch (error) {
    console.error('Error fetching templates:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to fetch templates' 
      },
      { status: 500 }
    );
  }
}

// POST /api/code-templates - Create a new template (admin only)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, description, language, code, dependencies = [], tags = [] } = body;

    // Validate required fields
    if (!name || !description || !language || !code) {
      return NextResponse.json(
        { 
          success: false, 
          error: 'Missing required fields: name, description, language, code' 
        },
        { status: 400 }
      );
    }

    // Create new template
    const newTemplate = {
      id: `template-${Date.now()}`,
      name,
      description,
      language: language.toLowerCase(),
      code,
      dependencies: Array.isArray(dependencies) ? dependencies : [],
      tags: Array.isArray(tags) ? tags : []
    };

    // In a real application, you would save this to a database
    // For now, we'll just return success
    console.log('New template created:', newTemplate);

    return NextResponse.json({
      success: true,
      template: newTemplate,
      message: 'Template created successfully'
    });

  } catch (error) {
    console.error('Error creating template:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to create template' 
      },
      { status: 500 }
    );
  }
}