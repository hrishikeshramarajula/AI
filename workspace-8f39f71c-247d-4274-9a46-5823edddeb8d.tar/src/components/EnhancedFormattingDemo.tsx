'use client';

import React from 'react';
import MarkdownRenderer from './MarkdownRenderer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

const sampleResearchContent = `# Research Analysis: India

## Introduction
India, officially known as the Republic of India, is a sovereign nation located in South Asia. It is the seventh-largest country by land area and the second-most populous country in the world, with over 1.3 billion people.

## Overview

### Current Status
As of 2023, India stands as a rapidly developing nation with a robust economic growth trajectory. It is classified as a newly industrialized country and is part of the G20 group of major economies.

### Key Information
- **Geography**: India shares its borders with Pakistan to the west, China, Nepal, and Bhutan to the north-east, and Bangladesh and Myanmar to the east.
- **Population**: With over 1.3 billion people, India is characterized by significant linguistic, religious, and cultural diversity.
- **Government**: India is a federal republic with a parliamentary system.
- **Economy**: India's economy is diverse, encompassing agriculture, manufacturing, and services.

## Key Details

### Demographics and Society
India's demographic landscape is incredibly diverse. The country is home to numerous ethnic groups, languages, and religions.

> The Indian economy's transformation from primarily agrarian to service-oriented represents one of the most significant economic shifts of the 21st century.

### Political Dynamics
India's political landscape is dominated by two major parties: the Bharatiya Janata Party (BJP) and the Indian National Congress (INC).

## Challenges and Opportunities

### Major Challenges
1. Environmental degradation and climate change
2. Income inequality and poverty
3. Infrastructure development needs

### Growth Opportunities
1. Renewable energy sector expansion
2. Digital transformation and technology adoption
3. Manufacturing growth through "Make in India"

## Conclusion

India's multifaceted identity as a nation of vast diversity, rapid economic growth, and significant geopolitical influence makes it a subject of immense interest and importance.`;

export default function EnhancedFormattingDemo() {
  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">Enhanced Research Formatting Demo</h1>
        <p className="text-gray-600">Improved spacing, structure, and visual hierarchy for research content</p>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <span>Enhanced Features</span>
            <Badge variant="secondary">New</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-semibold mb-2">Visual Improvements:</h4>
              <ul className="space-y-1 text-sm">
                <li>• Enhanced header styling with borders</li>
                <li>• Improved paragraph spacing and text justification</li>
                <li>• Better list formatting with visual containers</li>
                <li>• Enhanced blockquote styling with background</li>
                <li>• Improved code block presentation</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Readability Features:</h4>
              <ul className="space-y-1 text-sm">
                <li>• Better visual hierarchy</li>
                <li>• Enhanced spacing between sections</li>
                <li>• Improved typography and contrast</li>
                <li>• Responsive design considerations</li>
                <li>• Dark mode compatibility</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Sample Research Content with Enhanced Formatting</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="prose prose-sm dark:prose-invert max-w-none">
            <MarkdownRenderer content={sampleResearchContent} />
          </div>
        </CardContent>
      </Card>

      <Separator className="my-6" />

      <Card>
        <CardHeader>
          <CardTitle>Formatting Comparison</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-3 text-gray-600">Before (Basic)</h4>
              <div className="p-4 bg-gray-50 rounded-lg border">
                <div className="space-y-2">
                  <h3 className="text-lg font-bold">Research Analysis: India</h3>
                  <p className="text-sm">India, officially known as the Republic of India, is a sovereign nation...</p>
                  <ul className="text-sm space-y-1">
                    <li>• Geography: India shares its borders...</li>
                    <li>• Population: With over 1.3 billion people...</li>
                  </ul>
                </div>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-3 text-green-600">After (Enhanced)</h4>
              <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                <div className="space-y-3">
                  <h3 className="text-xl font-bold border-b border-green-300 pb-2">Research Analysis: India</h3>
                  <p className="text-sm leading-relaxed text-justify">India, officially known as the Republic of India, is a sovereign nation...</p>
                  <ul className="text-sm space-y-2 border-l-2 border-green-300 pl-4 py-2 bg-green-100/30 rounded-r-lg">
                    <li className="leading-relaxed">• Geography: India shares its borders...</li>
                    <li className="leading-relaxed">• Population: With over 1.3 billion people...</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}