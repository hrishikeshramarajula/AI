'use client';

import React from 'react';
import MarkdownRenderer from './MarkdownRenderer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { 
  BookOpen, 
  Globe, 
  Users, 
  TrendingUp, 
  MapPin, 
  Building,
  Download,
  Share2,
  RefreshCw
} from 'lucide-react';

const indiaResearchContent = `# Research Analysis: India

## Introduction
India, officially known as the Republic of India, is a sovereign nation located in South Asia. It is the seventh-largest country by land area and the second-most populous country in the world, with over 1.3 billion people. India's historical significance spans millennia, encompassing a rich tapestry of cultures, religions, and empires. Its strategic location, diverse demographics, and burgeoning economy make it a pivotal player on the global stage.

## Overview

### Current Status
As of 2023, India stands as a rapidly developing nation with a robust economic growth trajectory. It is classified as a newly industrialized country and is part of the G20 group of major economies. India's GDP is the fifth-largest in the world in terms of nominal value and the third-largest when measured by purchasing power parity (PPP).

### Key Information
- **Geography**: India shares its borders with Pakistan to the west, China, Nepal, and Bhutan to the north-east, and Bangladesh and Myanmar to the east. The Indian Ocean lies to the south.
- **Population**: With over 1.3 billion people, India is characterized by significant linguistic, religious, and cultural diversity.
- **Government**: India is a federal republic with a parliamentary system. It operates under the framework of the Constitution of India, which came into effect in 1950.
- **Economy**: India's economy is diverse, encompassing agriculture, manufacturing, and services. Key sectors include information technology, textiles, and pharmaceuticals.

## Key Details

### Demographics and Society
India's demographic landscape is incredibly diverse. The country is home to numerous ethnic groups, languages, and religions. Hinduism is the predominant religion, followed by Islam, Christianity, Sikhism, Buddhism, and Jainism. This religious diversity contributes to a rich cultural mosaic but also poses challenges in terms of social cohesion and governance.

### Economic Landscape
India's economy has witnessed significant growth over the past few decades. The service sector, particularly IT and outsourcing, has been a major driver of this growth. Bangalore, often referred to as the "Silicon Valley of India," is a hub for technological innovation. Additionally, initiatives like "Make in India" aim to boost manufacturing and attract foreign investment.

> The Indian economy's transformation from primarily agrarian to service-oriented represents one of the most significant economic shifts of the 21st century, positioning India as a global leader in technology and innovation.

However, economic disparities remain a pressing issue. While urban areas and certain sectors flourish, rural regions and traditional industries lag behind. Income inequality and poverty continue to be significant challenges.

### Political Dynamics
India's political landscape is dominated by two major parties: the Bharatiya Janata Party (BJP) and the Indian National Congress (INC). The BJP, currently in power under Prime Minister Narendra Modi, advocates for a Hindu nationalist agenda, while the INC champions secularism and social welfare.

The political environment is often characterized by vibrant but sometimes contentious debates on issues ranging from economic policies to social reforms. The recent implementation of policies like the Citizenship Amendment Act (CAA) and the Goods and Services Tax (GST) has sparked widespread discussion and protest.

### Foreign Relations
India's foreign policy is guided by its strategic interests, economic goals, and historical ties. It maintains strong relationships with major powers like the United States, Russia, and China, albeit with complexities in the latter case due to border disputes and geopolitical rivalries.

India is also a key player in regional organizations such as the South Asian Association for Regional Cooperation (SAARC) and the BRICS grouping. Its "Act East Policy" aims to strengthen ties with Southeast Asian nations, reflecting its growing influence in the Indo-Pacific region.

## Challenges and Opportunities

### Major Challenges
1. **Environmental degradation**: Rapid industrialization has led to significant environmental challenges
2. **Water scarcity**: Many regions face severe water shortages and pollution issues
3. **Public health infrastructure**: The COVID-19 pandemic exposed vulnerabilities in healthcare systems
4. **Economic inequality**: Disparities between urban and rural populations remain significant
5. **Educational access**: Quality education remains inaccessible to many rural populations

### Growth Opportunities
1. **Renewable energy**: India has ambitious targets for solar and wind energy development
2. **Digital transformation**: The Digital India initiative is driving technological adoption
3. **Manufacturing growth**: "Make in India" is boosting domestic manufacturing capabilities
4. **Demographic dividend**: A young population offers significant economic potential
5. **Service sector innovation**: Continued growth in IT, healthcare, and financial services

## Conclusion

India's multifaceted identity as a nation of vast diversity, rapid economic growth, and significant geopolitical influence makes it a subject of immense interest and importance. While it grapples with internal challenges such as economic inequality, social unrest, and environmental issues, its potential for continued development and global impact remains undiminished.

The key to India's future lies in its ability to balance economic growth with social inclusivity, manage its complex political dynamics, and navigate the intricacies of international relations. As it continues to evolve, India's trajectory will undoubtedly shape not only the destiny of its billion-plus citizens but also the broader global landscape.

In summary, India stands at a critical juncture, poised with both the challenges and opportunities that will define its path forward in the 21st century. Its success in addressing current challenges while leveraging its demographic and economic advantages will determine its role as a leading global power in the decades to come.`;

export default function IndiaResearchDisplay() {
  const handleDownload = () => {
    const content = `Research Analysis: India

${indiaResearchContent}

---
Generated with Enhanced Research Formatting System
${new Date().toISOString()}`;
    
    const blob = new Blob([content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'india-research-analysis-enhanced.md';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleRefresh = () => {
    // In a real implementation, this would trigger a new research request
    window.location.reload();
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      {/* Header Section */}
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-3 mb-4">
          <Globe className="h-8 w-8 text-blue-600" />
          <h1 className="text-4xl font-bold text-gray-900 dark:text-gray-100">
            India Research Analysis
          </h1>
        </div>
        <p className="text-lg text-gray-600 dark:text-gray-400 mb-4">
          Comprehensive Research Analysis with Enhanced Formatting
        </p>
        <div className="flex items-center justify-center gap-4">
          <Badge variant="secondary" className="flex items-center gap-1">
            <BookOpen className="h-4 w-4" />
            Enhanced Research
          </Badge>
          <Badge variant="outline" className="flex items-center gap-1">
            <TrendingUp className="h-4 w-4" />
            Professional Formatting
          </Badge>
          <Badge variant="outline" className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            1.3B+ Population
          </Badge>
        </div>
      </div>

      {/* Quick Stats */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Key Facts at a Glance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-blue-50 dark:bg-blue-950/30 rounded-lg">
              <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">7th</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Largest Country</div>
            </div>
            <div className="text-center p-4 bg-green-50 dark:bg-green-950/30 rounded-lg">
              <div className="text-2xl font-bold text-green-600 dark:text-green-400">2nd</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Most Populous</div>
            </div>
            <div className="text-center p-4 bg-purple-50 dark:bg-purple-950/30 rounded-lg">
              <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">5th</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Largest GDP</div>
            </div>
            <div className="text-center p-4 bg-orange-50 dark:bg-orange-950/30 rounded-lg">
              <div className="text-2xl font-bold text-orange-600 dark:text-orange-400">28</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">States & UTs</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex flex-wrap gap-3 justify-center mb-6">
        <Button onClick={handleDownload} className="flex items-center gap-2">
          <Download className="h-4 w-4" />
          Download Research
        </Button>
        <Button onClick={handleRefresh} variant="outline" className="flex items-center gap-2">
          <RefreshCw className="h-4 w-4" />
          Refresh Analysis
        </Button>
        <Button variant="outline" className="flex items-center gap-2">
          <Share2 className="h-4 w-4" />
          Share
        </Button>
      </div>

      {/* Enhanced Formatting Features */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building className="h-5 w-5" />
            Enhanced Formatting Features
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <h4 className="font-semibold text-green-600">Visual Hierarchy</h4>
              <ul className="text-sm space-y-1 text-gray-600 dark:text-gray-400">
                <li>• Enhanced header styling</li>
                <li>• Clear section separation</li>
                <li>• Professional borders</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold text-blue-600">Improved Readability</h4>
              <ul className="text-sm space-y-1 text-gray-600 dark:text-gray-400">
                <li>• Text justification</li>
                <li>• Enhanced spacing</li>
                <li>• Better line height</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold text-purple-600">Professional Design</h4>
              <ul className="text-sm space-y-1 text-gray-600 dark:text-gray-400">
                <li>• Visual containers</li>
                <li>• Enhanced blockquotes</li>
                <li>• Dark mode support</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      <Separator className="my-6" />

      {/* Main Research Content */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            Complete Research Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="prose prose-sm dark:prose-invert max-w-none">
            <MarkdownRenderer content={indiaResearchContent} />
          </div>
        </CardContent>
      </Card>

      {/* Footer */}
      <div className="text-center mt-8 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
        <p className="text-sm text-gray-600 dark:text-gray-400">
          This research analysis demonstrates the enhanced formatting capabilities implemented for improved readability and professional presentation.
        </p>
        <p className="text-xs text-gray-500 dark:text-gray-500 mt-2">
          Generated with Enhanced Research Formatting System • {new Date().toLocaleDateString()}
        </p>
      </div>
    </div>
  );
}