'use client';
import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  Brain,
  Zap,
  Target,
  BarChart3,
  PieChart,
  Activity,
  RefreshCw,
  Download,
  Upload,
  Lightbulb,
  Award,
  Rocket,
  Settings,
  Database,
  Network,
  Cpu,
  MemoryStick,
  HardDrive,
  Clock,
  CheckCircle,
  AlertTriangle,
  Info
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface PerformanceMetrics {
  executionSpeed: number;
  successRate: number;
  efficiency: number;
  userSatisfaction: number;
  responseTime: number;
  memoryUsage: number;
  cpuUsage: number;
  networkLatency: number;
}

interface KnowledgeUpdate {
  id: string;
  type: 'pattern' | 'error' | 'optimization' | 'preference';
  category: string;
  content: string;
  timestamp: string;
  impact: 'low' | 'medium' | 'high';
  source: 'auto' | 'manual' | 'feedback';
}

interface StrategyEvolution {
  id: string;
  method: string;
  oldApproach: string;
  newApproach: string;
  improvement: number;
  timestamp: string;
  status: 'testing' | 'implemented' | 'deprecated';
}

interface CapabilityExpansion {
  id: string;
  capability: string;
  description: string;
  status: 'developing' | 'testing' | 'deployed' | 'optimizing';
  progress: number;
  timestamp: string;
  dependencies: string[];
}

interface LearningInsight {
  id: string;
  insight: string;
  category: string;
  confidence: number;
  timestamp: string;
  actionable: boolean;
  priority: 'low' | 'medium' | 'high';
}

interface AIBrainContinuousImprovementProps {
  isVisible: boolean;
  onOptimization?: (insights: LearningInsight[]) => void;
  onStrategyUpdate?: (strategies: StrategyEvolution[]) => void;
}

export default function AIBrainContinuousImprovement({ 
  isVisible, 
  onOptimization, 
  onStrategyUpdate 
}: AIBrainContinuousImprovementProps) {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    executionSpeed: 95,
    successRate: 98,
    efficiency: 92,
    userSatisfaction: 94,
    responseTime: 150,
    memoryUsage: 65,
    cpuUsage: 45,
    networkLatency: 25
  });

  const [knowledgeUpdates, setKnowledgeUpdates] = useState<KnowledgeUpdate[]>([]);
  const [strategyEvolutions, setStrategyEvolutions] = useState<StrategyEvolution[]>([]);
  const [capabilityExpansions, setCapabilityExpansions] = useState<CapabilityExpansion[]>([]);
  const [learningInsights, setLearningInsights] = useState<LearningInsight[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(true);
  const [lastAnalysis, setLastAnalysis] = useState<string>('');

  // Simulate performance analysis
  const analyzePerformance = () => {
    const newMetrics: PerformanceMetrics = {
      executionSpeed: Math.max(70, Math.min(100, metrics.executionSpeed + (Math.random() - 0.5) * 5)),
      successRate: Math.max(80, Math.min(100, metrics.successRate + (Math.random() - 0.3) * 3)),
      efficiency: Math.max(75, Math.min(100, metrics.efficiency + (Math.random() - 0.4) * 4)),
      userSatisfaction: Math.max(70, Math.min(100, metrics.userSatisfaction + (Math.random() - 0.3) * 3)),
      responseTime: Math.max(50, Math.min(500, metrics.responseTime + (Math.random() - 0.5) * 20)),
      memoryUsage: Math.max(30, Math.min(90, metrics.memoryUsage + (Math.random() - 0.5) * 10)),
      cpuUsage: Math.max(20, Math.min(80, metrics.cpuUsage + (Math.random() - 0.5) * 8)),
      networkLatency: Math.max(10, Math.min(100, metrics.networkLatency + (Math.random() - 0.5) * 5))
    };

    setMetrics(newMetrics);
    setLastAnalysis(new Date().toISOString());

    // Generate knowledge updates based on performance
    generateKnowledgeUpdates(newMetrics);
    
    // Generate learning insights
    generateLearningInsights(newMetrics);
  };

  // Generate knowledge updates
  const generateKnowledgeUpdates = (currentMetrics: PerformanceMetrics) => {
    const updates: KnowledgeUpdate[] = [];

    // Pattern recognition updates
    if (currentMetrics.executionSpeed > 90) {
      updates.push({
        id: `pattern_${Date.now()}_1`,
        type: 'pattern',
        category: 'Performance',
        content: 'High execution speed patterns identified in processing workflows',
        timestamp: new Date().toISOString(),
        impact: 'high',
        source: 'auto'
      });
    }

    if (currentMetrics.successRate > 95) {
      updates.push({
        id: `pattern_${Date.now()}_2`,
        type: 'pattern',
        category: 'Reliability',
        content: 'Consistent success patterns in task completion',
        timestamp: new Date().toISOString(),
        impact: 'high',
        source: 'auto'
      });
    }

    // Optimization updates
    if (currentMetrics.responseTime < 100) {
      updates.push({
        id: `optimization_${Date.now()}_1`,
        type: 'optimization',
        category: 'Response Time',
        content: 'Response time optimization through caching strategies',
        timestamp: new Date().toISOString(),
        impact: 'medium',
        source: 'auto'
      });
    }

    if (currentMetrics.memoryUsage < 50) {
      updates.push({
        id: `optimization_${Date.now()}_2`,
        type: 'optimization',
        category: 'Memory',
        content: 'Memory usage optimization through efficient data structures',
        timestamp: new Date().toISOString(),
        impact: 'medium',
        source: 'auto'
      });
    }

    setKnowledgeUpdates(prev => [...updates.slice(0, 5), ...prev].slice(0, 20));
  };

  // Generate learning insights
  const generateLearningInsights = (currentMetrics: PerformanceMetrics) => {
    const insights: LearningInsight[] = [];

    // Performance insights
    if (currentMetrics.executionSpeed > 95) {
      insights.push({
        id: `insight_${Date.now()}_1`,
        insight: 'Execution speed is excellent, consider expanding to more complex tasks',
        category: 'Performance',
        confidence: 0.9,
        timestamp: new Date().toISOString(),
        actionable: true,
        priority: 'high'
      });
    }

    if (currentMetrics.successRate < 90) {
      insights.push({
        id: `insight_${Date.now()}_2`,
        insight: 'Success rate could be improved with better error handling',
        category: 'Reliability',
        confidence: 0.8,
        timestamp: new Date().toISOString(),
        actionable: true,
        priority: 'medium'
      });
    }

    if (currentMetrics.memoryUsage > 80) {
      insights.push({
        id: `insight_${Date.now()}_3`,
        insight: 'High memory usage detected, consider memory optimization',
        category: 'Resource',
        confidence: 0.95,
        timestamp: new Date().toISOString(),
        actionable: true,
        priority: 'high'
      });
    }

    if (currentMetrics.userSatisfaction > 90) {
      insights.push({
        id: `insight_${Date.now()}_4`,
        insight: 'User satisfaction is high, current approach is working well',
        category: 'User Experience',
        confidence: 0.85,
        timestamp: new Date().toISOString(),
        actionable: false,
        priority: 'low'
      });
    }

    setLearningInsights(prev => [...insights.slice(0, 3), ...prev].slice(0, 15));
  };

  // Generate strategy evolutions
  const generateStrategyEvolutions = () => {
    const strategies: StrategyEvolution[] = [
      {
        id: `strategy_${Date.now()}_1`,
        method: 'Task Processing',
        oldApproach: 'Sequential processing',
        newApproach: 'Parallel processing with prioritization',
        improvement: 35,
        timestamp: new Date().toISOString(),
        status: 'implemented'
      },
      {
        id: `strategy_${Date.now()}_2`,
        method: 'Error Recovery',
        oldApproach: 'Basic retry mechanism',
        newApproach: 'Intelligent error classification and adaptive recovery',
        improvement: 60,
        timestamp: new Date().toISOString(),
        status: 'testing'
      },
      {
        id: `strategy_${Date.now()}_3`,
        method: 'Memory Management',
        oldApproach: 'Manual garbage collection',
        newApproach: 'Predictive memory allocation and cleanup',
        improvement: 25,
        timestamp: new Date().toISOString(),
        status: 'deployed'
      }
    ];

    setStrategyEvolutions(prev => [...strategies, ...prev].slice(0, 10));
  };

  // Generate capability expansions
  const generateCapabilityExpansions = () => {
    const capabilities: CapabilityExpansion[] = [
      {
        id: `capability_${Date.now()}_1`,
        capability: 'Advanced Natural Language Understanding',
        description: 'Enhanced context understanding and semantic analysis',
        status: 'testing',
        progress: 75,
        timestamp: new Date().toISOString(),
        dependencies: ['Language Model', 'Context Analysis']
      },
      {
        id: `capability_${Date.now()}_2`,
        capability: 'Real-time Learning',
        description: 'Continuous learning from user interactions',
        status: 'developing',
        progress: 45,
        timestamp: new Date().toISOString(),
        dependencies: ['Memory System', 'Pattern Recognition']
      },
      {
        id: `capability_${Date.now()}_3`,
        capability: 'Cross-domain Knowledge Transfer',
        description: 'Apply knowledge from one domain to another',
        status: 'optimizing',
        progress: 90,
        timestamp: new Date().toISOString(),
        dependencies: ['Knowledge Base', 'Transfer Learning']
      }
    ];

    setCapabilityExpansions(prev => [...capabilities, ...prev].slice(0, 8));
  };

  // Apply optimization insights
  const applyOptimizations = () => {
    const actionableInsights = learningInsights.filter(insight => insight.actionable);
    if (actionableInsights.length > 0 && onOptimization) {
      onOptimization(actionableInsights);
    }
  };

  // Update strategies
  const updateStrategies = () => {
    const activeStrategies = strategyEvolutions.filter(s => s.status === 'implemented');
    if (activeStrategies.length > 0 && onStrategyUpdate) {
      onStrategyUpdate(activeStrategies);
    }
  };

  // Get performance color
  const getPerformanceColor = (value: number, type: keyof PerformanceMetrics) => {
    const thresholds = {
      executionSpeed: { good: 80, excellent: 95 },
      successRate: { good: 85, excellent: 95 },
      efficiency: { good: 75, excellent: 90 },
      userSatisfaction: { good: 80, excellent: 95 },
      responseTime: { good: 200, excellent: 100 },
      memoryUsage: { good: 70, excellent: 50 },
      cpuUsage: { good: 60, excellent: 40 },
      networkLatency: { good: 50, excellent: 20 }
    };

    const threshold = thresholds[type];
    if (type === 'responseTime' || type === 'memoryUsage' || type === 'cpuUsage' || type === 'networkLatency') {
      if (value <= threshold.excellent) return 'text-green-500';
      if (value <= threshold.good) return 'text-yellow-500';
      return 'text-red-500';
    } else {
      if (value >= threshold.excellent) return 'text-green-500';
      if (value >= threshold.good) return 'text-yellow-500';
      return 'text-red-500';
    }
  };

  // Get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'deployed':
      case 'implemented':
        return 'bg-green-500 text-white';
      case 'testing':
        return 'bg-blue-500 text-white';
      case 'developing':
        return 'bg-yellow-500 text-black';
      case 'optimizing':
        return 'bg-purple-500 text-white';
      case 'deprecated':
        return 'bg-red-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  // Initialize data
  useEffect(() => {
    if (!isVisible) return;

    // Generate initial data
    generateStrategyEvolutions();
    generateCapabilityExpansions();
    analyzePerformance();

    // Set up periodic analysis
    const interval = setInterval(() => {
      if (isAnalyzing) {
        analyzePerformance();
      }
    }, 10000);

    return () => clearInterval(interval);
  }, [isVisible, isAnalyzing]);

  if (!isVisible) return null;

  return (
    <div className="w-full max-w-6xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="flex items-center justify-center gap-2">
          <Brain className="w-6 h-6 text-purple-500" />
          <h2 className="text-2xl font-bold">AI Brain Continuous Improvement</h2>
        </div>
        <p className="text-gray-600">
          Self-learning, optimization, and capability expansion for intelligent processing
        </p>
      </div>

      {/* Control Panel */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Improvement Control Center
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full ${isAnalyzing ? 'bg-green-500' : 'bg-red-500'}`} />
              <span className="text-sm">
                Analysis: {isAnalyzing ? 'Active' : 'Paused'}
              </span>
            </div>
            <div className="text-sm text-gray-500">
              Last Analysis: {lastAnalysis ? new Date(lastAnalysis).toLocaleTimeString() : 'Never'}
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsAnalyzing(!isAnalyzing)}
              >
                {isAnalyzing ? 'Pause' : 'Resume'} Analysis
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={analyzePerformance}
              >
                <RefreshCw className="w-4 h-4 mr-1" />
                Analyze Now
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={applyOptimizations}
              >
                <Zap className="w-4 h-4 mr-1" />
                Apply Optimizations
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="performance" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="knowledge">Knowledge</TabsTrigger>
          <TabsTrigger value="strategy">Strategy</TabsTrigger>
          <TabsTrigger value="capabilities">Capabilities</TabsTrigger>
        </TabsList>

        {/* Performance Analysis */}
        <TabsContent value="performance" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Execution Speed</CardTitle>
                <Zap className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${getPerformanceColor(metrics.executionSpeed, 'executionSpeed')}`}>
                  {metrics.executionSpeed}%
                </div>
                <p className="text-xs text-muted-foreground">
                  Tasks per minute
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
                <CheckCircle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${getPerformanceColor(metrics.successRate, 'successRate')}`}>
                  {metrics.successRate}%
                </div>
                <p className="text-xs text-muted-foreground">
                  Completed successfully
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Efficiency</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${getPerformanceColor(metrics.efficiency, 'efficiency')}`}>
                  {metrics.efficiency}%
                </div>
                <p className="text-xs text-muted-foreground">
                  Resource utilization
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">User Satisfaction</CardTitle>
                <Award className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${getPerformanceColor(metrics.userSatisfaction, 'userSatisfaction')}`}>
                  {metrics.userSatisfaction}%
                </div>
                <p className="text-xs text-muted-foreground">
                  User feedback score
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Resource Usage */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MemoryStick className="w-5 h-5" />
                  Memory Usage
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`text-3xl font-bold ${getPerformanceColor(metrics.memoryUsage, 'memoryUsage')}`}>
                  {metrics.memoryUsage}%
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full" 
                    style={{ width: `${metrics.memoryUsage}%` }}
                  ></div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Cpu className="w-5 h-5" />
                  CPU Usage
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`text-3xl font-bold ${getPerformanceColor(metrics.cpuUsage, 'cpuUsage')}`}>
                  {metrics.cpuUsage}%
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                  <div 
                    className="bg-green-600 h-2 rounded-full" 
                    style={{ width: `${metrics.cpuUsage}%` }}
                  ></div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Network className="w-5 h-5" />
                  Network Latency
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`text-3xl font-bold ${getPerformanceColor(metrics.networkLatency, 'networkLatency')}`}>
                  {metrics.networkLatency}ms
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                  <div 
                    className="bg-purple-600 h-2 rounded-full" 
                    style={{ width: `${Math.min(100, metrics.networkLatency)}%` }}
                  ></div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Learning Insights */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="w-5 h-5" />
                Learning Insights
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                <div className="space-y-3">
                  {learningInsights.map((insight) => (
                    <div key={insight.id} className="p-3 border rounded-lg">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge variant="outline">{insight.category}</Badge>
                            <Badge className={insight.priority === 'high' ? 'bg-red-500 text-white' : 
                                           insight.priority === 'medium' ? 'bg-yellow-500 text-black' : 
                                           'bg-green-500 text-white'}>
                              {insight.priority}
                            </Badge>
                            {insight.actionable && (
                              <Badge className="bg-blue-500 text-white">Actionable</Badge>
                            )}
                          </div>
                          <p className="text-sm">{insight.insight}</p>
                          <p className="text-xs text-gray-500 mt-1">
                            Confidence: {(insight.confidence * 100).toFixed(0)}% • 
                            {new Date(insight.timestamp).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                  {learningInsights.length === 0 && (
                    <div className="text-center py-8">
                      <Info className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                      <p className="text-gray-500">No insights generated yet. Analysis in progress...</p>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Knowledge Updates */}
        <TabsContent value="knowledge" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5" />
                Knowledge Base Updates
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-3">
                  {knowledgeUpdates.map((update) => (
                    <div key={update.id} className="p-4 border rounded-lg">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="outline" className="capitalize">{update.type}</Badge>
                            <Badge>{update.category}</Badge>
                            <Badge className={update.impact === 'high' ? 'bg-red-500 text-white' : 
                                           update.impact === 'medium' ? 'bg-yellow-500 text-black' : 
                                           'bg-green-500 text-white'}>
                              {update.impact} impact
                            </Badge>
                            <Badge variant="outline">{update.source}</Badge>
                          </div>
                          <p className="text-sm mb-2">{update.content}</p>
                          <p className="text-xs text-gray-500">
                            {new Date(update.timestamp).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                  {knowledgeUpdates.length === 0 && (
                    <div className="text-center py-8">
                      <Brain className="w-12 h-12 text-purple-500 mx-auto mb-4" />
                      <p className="text-gray-500">No knowledge updates yet. Learning in progress...</p>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Strategy Evolution */}
        <TabsContent value="strategy" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5" />
                Strategy Evolution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {strategyEvolutions.map((strategy) => (
                    <div key={strategy.id} className="p-4 border rounded-lg">
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-medium">{strategy.method}</h3>
                            <Badge className={getStatusColor(strategy.status)}>
                              {strategy.status}
                            </Badge>
                            <Badge className="bg-green-500 text-white">
                              +{strategy.improvement}% improvement
                            </Badge>
                          </div>
                          <div className="space-y-2 text-sm">
                            <div>
                              <span className="font-medium text-red-600">Old:</span> {strategy.oldApproach}
                            </div>
                            <div>
                              <span className="font-medium text-green-600">New:</span> {strategy.newApproach}
                            </div>
                          </div>
                          <p className="text-xs text-gray-500 mt-2">
                            {new Date(strategy.timestamp).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                  {strategyEvolutions.length === 0 && (
                    <div className="text-center py-8">
                      <Target className="w-12 h-12 text-green-500 mx-auto mb-4" />
                      <p className="text-gray-500">No strategy evolutions yet. Optimization in progress...</p>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Capability Expansion */}
        <TabsContent value="capabilities" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Rocket className="w-5 h-5" />
                Capability Expansion
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {capabilityExpansions.map((capability) => (
                    <div key={capability.id} className="p-4 border rounded-lg">
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-medium">{capability.capability}</h3>
                            <Badge className={getStatusColor(capability.status)}>
                              {capability.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-3">{capability.description}</p>
                          
                          <div className="mb-3">
                            <div className="flex items-center justify-between text-sm mb-1">
                              <span>Progress</span>
                              <span>{capability.progress}%</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-blue-600 h-2 rounded-full" 
                                style={{ width: `${capability.progress}%` }}
                              ></div>
                            </div>
                          </div>
                          
                          <div className="flex flex-wrap gap-1">
                            {capability.dependencies.map((dep, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {dep}
                              </Badge>
                            ))}
                          </div>
                          
                          <p className="text-xs text-gray-500 mt-2">
                            {new Date(capability.timestamp).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                  {capabilityExpansions.length === 0 && (
                    <div className="text-center py-8">
                      <Rocket className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                      <p className="text-gray-500">No capability expansions in progress...</p>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}