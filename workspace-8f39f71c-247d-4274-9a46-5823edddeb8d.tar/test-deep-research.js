// Test script using built-in fetch (Node.js 18+)

async function testDeepResearch() {
  console.log('🧪 Testing Deep Research API with Sonar Deep Research (default)...');
  
  const startTime = Date.now();
  let responseReceived = false;
  let chunksReceived = 0;
  let lastChunkTime = startTime;
  
  const testQuery = 'What are the latest developments in quantum computing?';
  
  try {
    const response = await fetch('http://localhost:3000/api/deep-research-streaming', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message: testQuery,
        model: 'sonar-deep-research', // Test with default Sonar Deep Research
        config: {}
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    console.log('✅ Connection established, waiting for stream...');
    
    // Set up timeout for the entire test
    const testTimeout = setTimeout(() => {
      if (!responseReceived) {
        console.log('⏰ Test timeout reached (120 seconds)');
        process.exit(1);
      }
    }, 120000);

    // Read the stream
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    
    let buffer = '';
    
    while (true) {
      const { done, value } = await reader.read();
      
      if (done) {
        console.log('📡 Stream ended');
        break;
      }
      
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';
      
      for (const line of lines) {
        if (line.startsWith('data: ')) {
          try {
            const data = JSON.parse(line.slice(6));
            
            if (data.type === 'start') {
              console.log('🚀 Research started:', data.message);
              responseReceived = true;
            } else if (data.type === 'chunk') {
              chunksReceived++;
              lastChunkTime = Date.now();
              if (chunksReceived === 1) {
                console.log('📝 First chunk received at:', (lastChunkTime - startTime) / 1000, 'seconds');
              }
              if (chunksReceived % 10 === 0) {
                console.log(`📊 Progress: ${chunksReceived} chunks received`);
              }
            } else if (data.type === 'complete') {
              const totalTime = Date.now() - startTime;
              console.log('✅ Research completed!');
              console.log('📊 Total time:', totalTime / 1000, 'seconds');
              console.log('📝 Total chunks received:', chunksReceived);
              console.log('🧠 Model used:', data.metadata?.model);
              console.log('🔬 Research method:', data.metadata?.researchMethod);
              console.log('⏱️ Processing time:', data.processingTime / 1000, 'seconds');
              
              clearTimeout(testTimeout);
              return;
            } else if (data.type === 'error') {
              console.log('❌ Error received:', data.error);
              clearTimeout(testTimeout);
              return;
            } else if (data.type === 'keepalive') {
              console.log('💓 Keepalive received at:', (Date.now() - startTime) / 1000, 'seconds');
            }
          } catch (e) {
            console.log('⚠️ Failed to parse line:', line);
          }
        }
      }
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    process.exit(1);
  }
}

// Run the test
testDeepResearch();