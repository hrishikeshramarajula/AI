// Direct ZAI SDK script to get Jeep Compass information
import ZAI from 'z-ai-web-dev-sdk';

async function getJeepCompassInfo() {
  try {
    console.log('🚀 Initializing ZAI SDK...');
    const zai = await ZAI.create();
    console.log('✅ ZAI SDK initialized successfully');

    console.log('🔍 Researching Jeep Compass SUV...');
    
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an expert automotive analyst providing detailed, comprehensive information about vehicles. Provide specific facts, specifications, and expert analysis.'
        },
        {
          role: 'user',
          content: 'provide me detailed information of the jeep compass suv including specifications, features, pricing, engine options, trim levels, fuel economy, safety features, and competitive analysis'
        }
      ],
      temperature: 0.3,
      max_tokens: 8000,
      model: 'claude-3-5-sonnet'
    });

    const content = completion.choices[0]?.message?.content;
    
    if (content) {
      console.log('📋 Jeep Compass Information Generated:');
      console.log('=' .repeat(50));
      console.log(content);
      console.log('=' .repeat(50));
      console.log(`📝 Content length: ${content.length} characters`);
    } else {
      console.log('❌ No content received from ZAI');
    }

  } catch (error) {
    console.error('❌ Error:', error.message);
    
    // Try with fallback model
    console.log('🔄 Trying with fallback model...');
    try {
      const zai = await ZAI.create();
      
      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an expert automotive analyst providing detailed, comprehensive information about vehicles. Provide specific facts, specifications, and expert analysis.'
          },
          {
            role: 'user',
            content: 'provide me detailed information of the jeep compass suv including specifications, features, pricing, engine options, trim levels, fuel economy, safety features, and competitive analysis'
          }
        ],
        temperature: 0.3,
        max_tokens: 6000,
        model: 'gpt-4o'
      });

      const content = completion.choices[0]?.message?.content;
      if (content) {
        console.log('📋 Jeep Compass Information (Fallback):');
        console.log('=' .repeat(50));
        console.log(content);
        console.log('=' .repeat(50));
      }
    } catch (fallbackError) {
      console.error('❌ Fallback also failed:', fallbackError.message);
    }
  }
}

getJeepCompassInfo();