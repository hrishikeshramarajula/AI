'use client';

import React from 'react';
import HTMLRenderer from './HTMLRenderer';

interface MarkdownRendererProps {
  content: string | undefined | null;
  className?: string;
}

export default function MarkdownRenderer({ content, className = '' }: MarkdownRendererProps) {
  // Clean up unwanted # symbols while preserving proper Markdown headers
  const cleanContent = (markdown: string | undefined | null) => {
    // Add this line to prevent the error - ensure we always have a string
    let cleaned = markdown || '';
    
    // First, preserve proper headers by temporarily replacing them
    const headerMap = new Map();
    let headerIndex = 0;
    
    // Preserve proper headers (# Header at beginning of line)
    cleaned = cleaned.replace(/^# (.+)$/gm, (match, content) => {
      const placeholder = `__HEADER_${headerIndex}__`;
      headerMap.set(placeholder, `# ${content}`);
      headerIndex++;
      return placeholder;
    });
    
    // Preserve proper subheaders (## Subheader at beginning of line)
    cleaned = cleaned.replace(/^## (.+)$/gm, (match, content) => {
      const placeholder = `__SUBHEADER_${headerIndex}__`;
      headerMap.set(placeholder, `## ${content}`);
      headerIndex++;
      return placeholder;
    });
    
    // Preserve proper subsubheaders (### Subsubheader at beginning of line)
    cleaned = cleaned.replace(/^### (.+)$/gm, (match, content) => {
      const placeholder = `__SUBSUBHEADER_${headerIndex}__`;
      headerMap.set(placeholder, `### ${content}`);
      headerIndex++;
      return placeholder;
    });
    
    // Now remove unwanted # symbols (completion markers, standalone symbols, etc.)
    
    // Remove # symbols at end of lines (completion markers)
    cleaned = cleaned.replace(/#\s*$/gm, '');
    
    // Remove ## symbols at end of lines (section completion markers)
    cleaned = cleaned.replace(/##\s*$/gm, '');
    
    // Remove # symbols that appear alone between text (not at beginning of line)
    cleaned = cleaned.replace(/([^#\n])\s*#\s*([^#\n])/g, '$1 $2');
    
    // Remove ## symbols that appear alone between text (not at beginning of line)
    cleaned = cleaned.replace(/([^#\n])\s*##\s*([^#\n])/g, '$1 $2');
    
    // Remove standalone # symbols on their own lines
    cleaned = cleaned.replace(/^\s*#\s*$/gm, '');
    
    // Remove standalone ## symbols on their own lines
    cleaned = cleaned.replace(/^\s*##\s*$/gm, '');
    
    // Remove # symbols that appear before proper punctuation
    cleaned = cleaned.replace(/#\s*([.,;:!])/g, '$1');
    
    // Remove # symbols that appear after proper punctuation
    cleaned = cleaned.replace(/([.,;:!])\s*#/g, '$1');
    
    // Remove # symbols attached to words (like word# or #word)
    cleaned = cleaned.replace(/(\w)#/g, '$1');
    cleaned = cleaned.replace(/#(\w)/g, '$1');
    
    // Remove ## symbols attached to words (like word## or ##word)
    cleaned = cleaned.replace(/(\w)##/g, '$1');
    cleaned = cleaned.replace(/##(\w)/g, '$1');
    
    // Remove any remaining stray # symbols
    cleaned = cleaned.replace(/\s*#\s*/g, ' ');
    cleaned = cleaned.replace(/\s*##\s*/g, ' ');
    
    // Clean up multiple spaces
    cleaned = cleaned.replace(/\s+/g, ' ');
    
    // Clean up excessive line breaks
    cleaned = cleaned.replace(/\n\s*\n\s*\n/g, '\n\n');
    cleaned = cleaned.replace(/\n\s*\n\s*\n\s*\n/g, '\n\n');
    
    // Clean up spaces at beginning or end of lines
    cleaned = cleaned.replace(/^\s+/gm, '');
    cleaned = cleaned.replace(/\s+$/gm, '');
    
    // Restore preserved headers
    headerMap.forEach((original, placeholder) => {
      cleaned = cleaned.replace(placeholder, original);
    });
    
    return cleaned.trim();
  };

  // Convert Markdown to HTML
  const markdownToHTML = (markdown: string | undefined | null) => {
    // First clean the content
    let html = cleanContent(markdown);
    
    // Headers (# Header, ## Subheader, etc.) - Enhanced for research content
    html = html.replace(/^# (.*$)/gim, '<h1 class="text-3xl font-bold my-6 text-gray-900 dark:text-gray-100 border-b-2 border-gray-200 dark:border-gray-700 pb-3">$1</h1>');
    html = html.replace(/^## (.*$)/gim, '<h2 class="text-2xl font-bold my-5 text-gray-900 dark:text-gray-100 border-b border-gray-200 dark:border-gray-700 pb-2">$1</h2>');
    html = html.replace(/^### (.*$)/gim, '<h3 class="text-xl font-semibold my-4 text-gray-900 dark:text-gray-100 ml-4">$1</h3>');
    html = html.replace(/^#### (.*$)/gim, '<h4 class="text-lg font-semibold my-3 text-gray-900 dark:text-gray-100 ml-6">$1</h4>');
    
    // Bold text (**bold**) - Enhanced for research content but reduced emphasis
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong class="font-normal text-gray-800 dark:text-gray-200 text-sm">$1</strong>');
    
    // Italic text (*italic*)
    html = html.replace(/\*(.*?)\*/g, '<em class="italic text-gray-700 dark:text-gray-300">$1</em>');
    
    // Enhanced bullet points (* item) - Better spacing and hierarchy
    html = html.replace(/^\* (.*$)/gim, '<li class="ml-6 my-2 text-gray-700 dark:text-gray-300 leading-relaxed text-sm">• $1</li>');
    
    // Enhanced numbered lists (1. item) - Better spacing and hierarchy
    html = html.replace(/^\d+\. (.*$)/gim, '<li class="ml-6 my-2 text-gray-700 dark:text-gray-300 leading-relaxed text-sm">$1</li>');
    
    // Inline code (`code`) - Enhanced styling
    html = html.replace(/`([^`]+)`/g, '<code class="bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded text-xs font-mono text-gray-800 dark:text-gray-200 border border-gray-200 dark:border-gray-700">$1</code>');
    
    // Links [text](url) - Enhanced styling
    html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 underline text-sm">$1</a>');
    
    // Blockquotes (> quote) - Enhanced for research content
    html = html.replace(/^> (.*$)/gim, '<blockquote class="border-l-4 border-blue-500 dark:border-blue-400 pl-6 my-6 italic text-gray-600 dark:text-gray-400 bg-blue-50 dark:bg-blue-950/30 py-3 pr-4 rounded-r-lg">$1</blockquote>');
    
    // Enhanced line breaks and paragraph spacing for research content
    html = html.replace(/\n\n/g, '</p><p class="my-3 text-gray-700 dark:text-gray-300 leading-relaxed text-justify">');
    html = html.replace(/\n/g, '<br class="my-1" />');
    
    // Wrap in paragraphs with enhanced styling
    html = '<p class="my-3 text-gray-700 dark:text-gray-300 leading-relaxed text-justify">' + html + '</p>';
    
    // Fix multiple paragraph tags and add section spacing
    html = html.replace(/<p class="my-3 text-gray-700 dark:text-gray-300 leading-relaxed text-justify"><\/p>/g, '');
    html = html.replace(/<p class="my-3 text-gray-700 dark:text-gray-300 leading-relaxed text-justify"><p class="my-3 text-gray-700 dark:text-gray-300 leading-relaxed text-justify">/g, '<p class="my-3 text-gray-700 dark:text-gray-300 leading-relaxed text-justify">');
    
    // Add section dividers for major content blocks
    html = html.replace(/(<h[1-6][^>]*>.*?<\/h[1-6]>)/g, '$1<div class="my-2"></div>');
    
    return html;
  };

  const htmlContent = markdownToHTML(content);

  return (
    <HTMLRenderer 
      content={htmlContent} 
      className={className}
    />
  );
}