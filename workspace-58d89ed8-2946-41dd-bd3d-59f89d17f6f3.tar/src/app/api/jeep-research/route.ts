import { NextRequest, NextResponse } from 'next/server';
import { getZAIInstance, safeZAIChatCompletion } from '@/lib/zaiHelper';
import { ContentFormatter } from '@/lib/contentFormatter';

export async function POST(request: NextRequest) {
  const startTime = Date.now();
  
  try {
    console.log('🚗 Jeep Research API: Processing Jeep Compass SUV research request...');
    
    const body = await request.json();
    const query = body?.query || 'provide me detailed information of the jeep compass suv';

    console.log('🔬 Jeep Research Query:', query);

    // Generate comprehensive Jeep Compass information using AI
    console.log('🚀 Jeep Research: Starting AI-powered research...');
    const researchResponse = await generateJeepCompassResearch(query);
    
    console.log('✅ Jeep research completed successfully');
    console.log(`📝 Generated content length: ${researchResponse.length} characters`);

    // Create research output
    const researchOutput = {
      success: true,
      query: query,
      response: researchResponse,
      _metadata: {
        processingTime: Date.now() - startTime,
        model: 'claude-3-5-sonnet',
        timestamp: new Date().toISOString(),
        researchMode: 'jeep-comprehensive-research',
        processingMethod: 'ai-generated',
        researchStages: ['AI Content Generation']
      }
    };

    console.log('✅ Jeep Research API: Processing completed successfully');

    return NextResponse.json(researchOutput);

  } catch (error) {
    console.error('❌ Jeep Research API Error:', error);
    
    const processingTime = Date.now() - startTime;
    
    // Generate fallback content
    const fallbackContent = generateJeepCompassFallbackContent(query);
    
    return NextResponse.json({
      success: true,
      query: query || 'Jeep Compass SUV',
      response: fallbackContent,
      _metadata: {
        processingTime,
        error: true,
        errorMessage: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString(),
        researchMode: 'fallback-research',
        processingMethod: 'fallback-content'
      }
    }, { status: 200 });
  }
}

// Generate comprehensive Jeep Compass research content
async function generateJeepCompassResearch(query: string): Promise<string> {
  const maxRetries = 3;
  const retryDelay = 3000;
  
  const researchModels = [
    'claude-3-5-sonnet',
    'gpt-4o',
    'claude-3-opus',
    'gemini-2.5-pro-free'
  ];
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      console.log(`🧠 Jeep research attempt ${attempt}/${maxRetries} using model: claude-3-5-sonnet`);
      
      const zai = await getZAIInstance();
      
      // Create comprehensive Jeep Compass research prompt
      const researchPrompt = `You are an expert automotive analyst providing comprehensive, in-depth analysis of the Jeep Compass SUV. Generate a detailed research report covering all aspects of this vehicle:

TOPIC: ${query}

REQUIREMENTS:
1. Generate 3000-5000 words of comprehensive, well-researched content
2. Include specific facts, dates, statistics, specifications, and features
3. Provide historical context and background information
4. Present multiple perspectives with verifiable information
5. Use clean formatting with proper structure and spacing
6. Include specific examples and detailed analysis
7. Ensure complete coverage with no generic content
8. Provide actionable insights and expert analysis

STRUCTURE:
Jeep Compass SUV Comprehensive Analysis

INTRODUCTION (400-600 words)
- Clear definition and significance of the Jeep Compass in the automotive market
- Key focus areas and importance
- Overview of what will be covered
- Research methodology and approach

HISTORICAL BACKGROUND AND DEVELOPMENT (600-800 words)
- Origins and historical context of the Jeep Compass
- Key historical milestones and events
- Evolution and major developments over time
- Important historical figures and contributions
- Timeline of key developments

CURRENT STATUS AND STRUCTURE (600-800 words)
- Current state and key characteristics of 2024 Jeep Compass
- Major components, features, and specifications
- Recent developments and important trends
- Market position and competitive landscape

DETAILED ANALYSIS AND SUB-TOPICS (800-1000 words)
- In-depth examination of core aspects (engine, transmission, drivetrain)
- Sub-topic analysis with supporting evidence
- Comparative analysis with related compact SUVs
- Data-driven insights and specifications

MAJOR ACHIEVEMENTS AND IMPACT (500-700 words)
- Significant accomplishments and breakthroughs
- Real-world impact and applications
- Notable case studies or examples
- Recognition and importance in the Jeep lineup

CHALLENGES AND LIMITATIONS (400-600 words)
- Current challenges and limitations
- Analysis of constraints and barriers
- Critical evaluation of shortcomings
- Risk assessment and mitigation strategies

FUTURE OUTLOOK AND TRENDS (500-700 words)
- Future trends and potential developments
- Opportunities and growth areas
- Expert predictions and analysis
- Long-term implications and projections

CONCLUSION AND RECOMMENDATIONS (400-600 words)
- Summary of key findings
- Overall significance and implications
- Final insights and recommendations
- Actionable suggestions for potential buyers

Provide thorough, expert-level analysis with specific, verifiable information. Avoid generic statements and provide concrete details. Ensure the content is comprehensive, well-structured, and meets the 3000-5000 word requirement.`;
      
      // Make AI call with extended timeout
      const completion = await Promise.race([
        safeZAIChatCompletion([
          {
            role: "system",
            content: "You are an expert automotive analyst providing comprehensive, accurate, and in-depth analysis on vehicles. You provide specific facts, detailed specifications, and expert-level insights."
          },
          {
            role: "user",
            content: researchPrompt
          }
        ], {
          model: 'claude-3-5-sonnet',
          temperature: 0.3,
          max_tokens: 12000
        }),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Research timeout')), 120000)
        )
      ]);
      
      const content = completion.choices[0]?.message?.content || '';
      
      if (content && content.trim() && content.length > 3000) {
        console.log(`✅ Jeep research attempt ${attempt} successful - ${content.length} characters`);
        
        // Apply content formatting for clean output
        return ContentFormatter.formatContentAggressively(content);
      } else {
        throw new Error(`Insufficient content generated: ${content.length} characters`);
      }
      
    } catch (error) {
      console.error(`❌ Jeep research attempt ${attempt} failed:`, error.message);
      
      if (attempt === maxRetries) {
        throw new Error('Jeep research failed after multiple attempts');
      }
      
      // Wait before retrying
      console.log(`⏳ Waiting ${retryDelay}ms before retry...`);
      await new Promise(resolve => setTimeout(resolve, retryDelay));
    }
  }
  
  throw new Error('Jeep research generation failed after all attempts');
}

// Generate fallback content when AI research fails
function generateJeepCompassFallbackContent(query: string): string {
  return `# Jeep Compass SUV - Comprehensive Analysis

## Introduction
The Jeep Compass stands as a compact SUV that combines Jeep's legendary off-road heritage with modern urban efficiency. Positioned as the smallest SUV in Jeep's lineup, it offers an accessible entry point into the brand's renowned off-road capabilities while maintaining practical everyday usability.

## Historical Background and Development
The Jeep Compass was first introduced for the 2007 model year as Jeep's attempt to enter the compact SUV market. It represented a significant departure from traditional Jeep designs, aiming to attract younger buyers and those transitioning from sedans to SUVs. The first generation (2007-2016) faced criticism for its lack of authentic Jeep off-road credentials but established a foothold in the compact segment.

The second generation, launched for 2017, marked a dramatic improvement with more authentic Jeep styling, better off-road capabilities, and improved build quality. This generation solidified the Compass's position in the market and led to its current success. For 2024, the Compass received significant updates including refreshed styling, enhanced technology, and improved powertrains.

## Current Status and Structure
The 2024 Jeep Compass represents a mature, refined compact SUV that successfully balances on-road comfort with off-road capability. It's built on Fiat Chrysler's Small Wide platform and offers multiple powertrain options across various trim levels.

### Key Specifications:
- **Engine Options**: 2.4L Tigershark I4 (180 hp), 1.3L Turbo I4 (177 hp)
- **Transmission**: 9-speed automatic (standard)
- **Drive Systems**: Front-wheel drive, 4x4 with Active Drive system
- **Seating**: 5 passengers
- **Towing Capacity**: Up to 2,000 lbs

### Trim Levels:
1. **Sport**: Base trim with essential features
2. **Latitude**: Mid-range with enhanced comfort and technology
3. **Trailhawk**: Off-road oriented with enhanced capabilities
4. **Limited**: Premium trim with luxury features

## Detailed Analysis and Sub-topics

### Engine Performance
The 2.4L Tigershark inline-4 engine delivers 180 horsepower and 175 lb-ft of torque, providing adequate power for daily driving. The available 1.3L turbo engine offers similar performance with better fuel efficiency. The 9-speed automatic transmission smooths out power delivery and helps optimize fuel economy.

### Off-Road Capability (Trailhawk Trim)
The Trailhawk trim represents the pinnacle of Jeep's off-road prowess in the compact segment:
- **Selec-Terrain traction control**: Multiple terrain modes (Auto, Snow, Sand, Mud)
- **Jeep Active Drive Low**: 4WD Low range for extreme off-road situations
- **Ground Clearance**: 8.6 inches (Trailhawk: 8.7 inches)
- **Approach/Departure Angles**: 29.6°/20.2° (Trailhawk: 30.2°/25.7°)
- **Water Fording**: Up to 19 inches (Trailhawk: 24 inches)

### Interior and Technology
The 2024 Compass features a modern interior with available premium materials:
- **Uconnect 5**: 10.1" or 12.3" touchscreen with Apple CarPlay/Android Auto
- **Dual-zone automatic climate control**: Available on higher trims
- **Available leather upholstery**: Premium feel on Limited trim
- **Advanced safety features**: Forward collision warning, automatic emergency braking, blind-spot monitoring

### Fuel Economy
- **FWD**: 25-30 mpg combined
- **4WD**: 23-28 mpg combined
- **Fuel Tank**: 13.5 gallons
- **Range**: Approximately 330-405 miles on a full tank

## Major Achievements and Impact
The Jeep Compass has achieved significant success in the compact SUV market:
- **Sales Success**: Consistently strong sales numbers globally
- **Brand Accessibility**: Provides entry-level access to Jeep brand
- **Off-Road Credibility**: Offers genuine off-road capability in a compact package
- **Value Proposition**: Competitive pricing with good feature content
- **Global Presence**: Manufactured and sold in multiple markets worldwide

## Challenges and Limitations
Despite its success, the Compass faces several challenges:
- **Interior Space**: Limited rear passenger and cargo space compared to competitors
- **Engine Performance**: Some critics note the base engine feels underpowered
- **Fuel Economy**: Not the most efficient in its class
- **Brand Perception**: Some still view it as "not a real Jeep" compared to Wrangler or Grand Cherokee

## Future Outlook and Trends
The Jeep Compass is expected to continue evolving with:
- **Electrification**: Potential hybrid or plug-in hybrid options
- **Technology Updates**: Enhanced connectivity and driver assistance features
- **Design Refinements**: Continued styling updates to maintain freshness
- **Market Expansion**: Growth in emerging markets with increased demand for compact SUVs

## Conclusion and Recommendations
The Jeep Compass successfully fulfills its mission as an accessible, capable compact SUV that offers genuine Jeep off-road credentials while maintaining everyday practicality. It represents an excellent choice for buyers who want Jeep's brand reputation and off-road capability without the size or cost of larger models.

For potential buyers:
- **Best For**: Urban dwellers who occasionally venture off-road, value-conscious buyers, Jeep brand enthusiasts
- **Consider If**: You want authentic Jeep capability in a compact, affordable package
- **Look Elsewhere If**: Maximum interior space or fuel efficiency are top priorities

The Compass continues to prove that Jeep's off-road DNA can successfully translate to the compact SUV segment while maintaining the brand's core values and capabilities.`;
}