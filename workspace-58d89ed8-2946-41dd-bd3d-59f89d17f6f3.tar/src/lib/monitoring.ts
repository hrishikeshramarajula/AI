// Enhanced logging utility for deep research operations
export class DeepResearchLogger {
  private static instance: DeepResearchLogger;
  private logs: Array<{
    timestamp: Date;
    level: 'info' | 'warn' | 'error' | 'debug';
    component: string;
    message: string;
    metadata?: any;
  }> = [];

  static getInstance(): DeepResearchLogger {
    if (!DeepResearchLogger.instance) {
      DeepResearchLogger.instance = new DeepResearchLogger();
    }
    return DeepResearchLogger.instance;
  }

  log(level: 'info' | 'warn' | 'error' | 'debug', component: string, message: string, metadata?: any) {
    const logEntry = {
      timestamp: new Date(),
      level,
      component,
      message,
      metadata
    };

    this.logs.push(logEntry);
    
    // Keep only last 1000 logs in memory
    if (this.logs.length > 1000) {
      this.logs = this.logs.slice(-1000);
    }

    // Console output with colors
    const colors = {
      info: '\x1b[36m',    // Cyan
      warn: '\x1b[33m',    // Yellow
      error: '\x1b[31m',   // Red
      debug: '\x1b[90m'    // Gray
    };
    const reset = '\x1b[0m';

    console.log(`${colors[level]}[${level.toUpperCase()}]${reset} [${component}] ${message}`, metadata || '');
  }

  info(component: string, message: string, metadata?: any) {
    this.log('info', component, message, metadata);
  }

  warn(component: string, message: string, metadata?: any) {
    this.log('warn', component, message, metadata);
  }

  error(component: string, message: string, metadata?: any) {
    this.log('error', component, message, metadata);
  }

  debug(component: string, message: string, metadata?: any) {
    this.log('debug', component, message, metadata);
  }

  getRecentLogs(count: number = 50) {
    return this.logs.slice(-count);
  }

  getLogsByComponent(component: string) {
    return this.logs.filter(log => log.component === component);
  }

  getErrorLogs() {
    return this.logs.filter(log => log.level === 'error');
  }

  clear() {
    this.logs = [];
  }

  exportLogs() {
    return {
      exported_at: new Date().toISOString(),
      total_logs: this.logs.length,
      logs: this.logs
    };
  }
}

// Performance monitoring utility
export class PerformanceMonitor {
  private static timers: Map<string, { start: number; metadata?: any }> = new Map();

  static startTimer(operation: string, metadata?: any) {
    this.timers.set(operation, {
      start: performance.now(),
      metadata
    });
  }

  static endTimer(operation: string): number | null {
    const timer = this.timers.get(operation);
    if (!timer) return null;

    const duration = performance.now() - timer.start;
    this.timers.delete(operation);

    DeepResearchLogger.getInstance().debug('Performance', `${operation} completed in ${duration.toFixed(2)}ms`, {
      operation,
      duration,
      metadata: timer.metadata
    });

    return duration;
  }

  static getActiveTimers() {
    return Array.from(this.timers.keys());
  }
}

// Error tracking utility
export class ErrorTracker {
  private static errors: Array<{
    timestamp: Date;
    error: Error;
    component: string;
    context?: any;
    handled: boolean;
  }> = [];

  static trackError(error: Error, component: string, context?: any, handled: boolean = true) {
    const errorEntry = {
      timestamp: new Date(),
      error,
      component,
      context,
      handled
    };

    this.errors.push(errorEntry);
    
    // Keep only last 100 errors
    if (this.errors.length > 100) {
      this.errors = this.errors.slice(-100);
    }

    DeepResearchLogger.getInstance().error(component, error.message, {
      errorName: error.name,
      stack: error.stack,
      context,
      handled
    });
  }

  static getErrors() {
    return this.errors;
  }

  static getUnhandledErrors() {
    return this.errors.filter(entry => !entry.handled);
  }

  static clear() {
    this.errors = [];
  }
}

// Circuit breaker pattern for external services
export class CircuitBreaker {
  private failureCount = 0;
  private lastFailureTime = 0;
  private state: 'CLOSED' | 'OPEN' | 'HALF_OPEN' = 'CLOSED';
  
  constructor(
    private readonly name: string,
    private readonly failureThreshold = 5,
    private readonly resetTimeout = 60000, // 1 minute
    private readonly monitoringPeriod = 300000 // 5 minutes
  ) {}

  async execute<T>(operation: () => Promise<T>): Promise<T> {
    if (this.state === 'OPEN') {
      if (Date.now() - this.lastFailureTime > this.resetTimeout) {
        this.state = 'HALF_OPEN';
        DeepResearchLogger.getInstance().info('CircuitBreaker', `${this.name} moving to HALF_OPEN state`);
      } else {
        throw new Error(`Circuit breaker for ${this.name} is OPEN`);
      }
    }

    try {
      const result = await operation();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure(error as Error);
      throw error;
    }
  }

  private onSuccess() {
    this.failureCount = 0;
    this.state = 'CLOSED';
    DeepResearchLogger.getInstance().debug('CircuitBreaker', `${this.name} operation successful, state: ${this.state}`);
  }

  private onFailure(error: Error) {
    this.failureCount++;
    this.lastFailureTime = Date.now();
    
    if (this.failureCount >= this.failureThreshold) {
      this.state = 'OPEN';
      DeepResearchLogger.getInstance().warn('CircuitBreaker', `${this.name} circuit OPEN after ${this.failureCount} failures`);
    } else {
      DeepResearchLogger.getInstance().warn('CircuitBreaker', `${this.name} operation failed, failure count: ${this.failureCount}`);
    }
  }

  getState() {
    return {
      state: this.state,
      failureCount: this.failureCount,
      lastFailureTime: this.lastFailureTime
    };
  }
}

// Retry utility with exponential backoff
export class RetryHandler {
  static async execute<T>(
    operation: () => Promise<T>,
    options: {
      maxRetries?: number;
      baseDelay?: number;
      maxDelay?: number;
      backoffFactor?: number;
      retryableErrors?: string[];
    } = {}
  ): Promise<T> {
    const {
      maxRetries = 3,
      baseDelay = 1000,
      maxDelay = 30000,
      backoffFactor = 2,
      retryableErrors = ['ECONNRESET', 'ETIMEDOUT', 'ENOTFOUND', 'EAI_AGAIN']
    } = options;

    let lastError: Error;

    for (let attempt = 1; attempt <= maxRetries + 1; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error as Error;
        
        if (attempt > maxRetries || !retryableErrors.some(errCode => error.message.includes(errCode))) {
          throw error;
        }

        const delay = Math.min(baseDelay * Math.pow(backoffFactor, attempt - 1), maxDelay);
        
        DeepResearchLogger.getInstance().warn('RetryHandler', 
          `Attempt ${attempt} failed, retrying in ${delay}ms`, 
          { error: error.message, attempt, delay }
        );

        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }

    throw lastError!;
  }
}