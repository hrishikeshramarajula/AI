// 🧠 Enhanced Deep Research Text Processor with AI Integration
// Advanced document analysis using GPT-4o, Claude, and other high-quality AI models

import { safeZAIChatCompletion } from '@/lib/zaiHelper';
import { API_CONFIG } from '@/lib/apiConfig';

export interface ProcessedText {
  sentences: string[];
  words: string[];
  processedText: string;
  originalText: string;
  metadata: {
    wordCount: number;
    sentenceCount: number;
    characterCount: number;
    readingTime: number;
    complexity: number;
  };
}

export interface Entity {
  text: string;
  label: string;
  confidence: number;
  start: number;
  end: number;
  category: string;
  importance: number;
  description?: string;
  context?: string;
}

export interface Topic {
  id: number;
  words: string[];
  coherence: number;
  relevance: number;
  description: string;
  confidence: number;
  keywords: string[];
  summary?: string;
}

export interface SentimentAnalysis {
  overall: {
    sentiment: 'positive' | 'negative' | 'neutral';
    confidence: number;
    score: number;
  };
  aspects: Array<{
    aspect: string;
    sentiment: string;
    confidence: number;
    evidence: string;
  }>;
  emotions: Array<{
    emotion: string;
    intensity: number;
    confidence: number;
  }>;
  detailedAnalysis?: string;
}

export interface KnowledgeGraphNode {
  id: string;
  label: string;
  type: string;
  category: string;
  importance: number;
  mentions: number;
  relationships: string[];
  metadata: Record<string, any>;
  description?: string;
}

export interface KnowledgeGraphEdge {
  source: string;
  target: string;
  relationship: string;
  weight: number;
  type: string;
  metadata: Record<string, any>;
  description?: string;
}

export interface ResearchAnalysis {
  processedText: ProcessedText;
  entities: Entity[];
  topics: Topic[];
  sentiment: SentimentAnalysis;
  keywords: string[];
  summary: string;
  knowledgeGraph: {
    nodes: KnowledgeGraphNode[];
    edges: KnowledgeGraphEdge[];
  };
  insights: {
    keyFindings: string[];
    knowledgeGaps: string[];
    researchQuestions: string[];
    recommendations: string[];
  };
  metadata: {
    processingTime: number;
    analysisDepth: 'basic' | 'detailed' | 'comprehensive' | 'encyclopedic';
    confidence: number;
    sources: string[];
    aiModelsUsed: string[];
  };
}

export class EnhancedDeepResearchTextProcessor {
  private stopWords: Set<string>;
  private importanceKeywords: Set<string>;

  constructor() {
    this.stopWords = new Set([
      'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by',
      'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did',
      'will', 'would', 'could', 'should', 'may', 'might', 'must', 'can', 'this', 'that', 'these', 'those'
    ]);
    
    this.importanceKeywords = new Set([
      'important', 'significant', 'critical', 'essential', 'key', 'major', 'primary', 'fundamental',
      'crucial', 'vital', 'central', 'core', 'main', 'principal', 'leading', 'dominant'
    ]);
  }

  // Main text processing pipeline with AI integration
  async processText(text: string, options: {
    includeSentiment?: boolean;
    includeTopics?: boolean;
    includeEntities?: boolean;
    includeKnowledgeGraph?: boolean;
    analysisDepth?: 'basic' | 'detailed' | 'comprehensive' | 'encyclopedic';
  } = {}): Promise<ResearchAnalysis> {
    const startTime = Date.now();
    const {
      includeSentiment = true,
      includeTopics = true,
      includeEntities = true,
      includeKnowledgeGraph = true,
      analysisDepth = 'comprehensive'
    } = options;

    console.log('🔍 Starting enhanced AI-powered deep research text processing...');
    console.log('📊 Analysis depth:', analysisDepth);

    try {
      // Step 1: Basic text preprocessing
      const processedText = this.preprocessText(text);
      console.log('✅ Text preprocessing completed');

      // Step 2: AI-powered entity extraction
      let entities: Entity[] = [];
      if (includeEntities) {
        entities = await this.extractEntitiesWithAI(processedText.processedText, analysisDepth);
        console.log(`✅ AI entity extraction completed: ${entities.length} entities found`);
      }

      // Step 3: AI-powered sentiment analysis
      let sentiment: SentimentAnalysis | undefined;
      if (includeSentiment) {
        sentiment = await this.analyzeSentimentWithAI(processedText.processedText);
        console.log('✅ AI sentiment analysis completed');
      }

      // Step 4: AI-powered topic modeling
      let topics: Topic[] = [];
      if (includeTopics) {
        topics = await this.performTopicModelingWithAI(processedText.sentences, analysisDepth);
        console.log(`✅ AI topic modeling completed: ${topics.length} topics identified`);
      }

      // Step 5: Enhanced keyword extraction
      const keywords = this.extractKeywords(processedText.processedText, entities);
      console.log(`✅ Keyword extraction completed: ${keywords.length} keywords`);

      // Step 6: AI-powered text summarization
      const summary = await this.generateSummaryWithAI(processedText, analysisDepth);
      console.log('✅ AI text summarization completed');

      // Step 7: Enhanced knowledge graph construction
      let knowledgeGraph = { nodes: [] as KnowledgeGraphNode[], edges: [] as KnowledgeGraphEdge[] };
      if (includeKnowledgeGraph) {
        knowledgeGraph = this.buildEnhancedKnowledgeGraph(entities, topics, keywords);
        console.log(`✅ Enhanced knowledge graph constructed: ${knowledgeGraph.nodes.length} nodes, ${knowledgeGraph.edges.length} edges`);
      }

      // Step 8: AI-powered insight generation
      const insights = await this.generateInsightsWithAI(processedText, entities, topics, sentiment, keywords);
      console.log('✅ AI research insights generated');

      const processingTime = Date.now() - startTime;

      const analysis: ResearchAnalysis = {
        processedText,
        entities,
        topics,
        sentiment: sentiment!,
        keywords,
        summary,
        knowledgeGraph,
        insights,
        metadata: {
          processingTime,
          analysisDepth,
          confidence: this.calculateConfidence(entities, topics, sentiment),
          sources: ['ai_analysis', 'nlp_processing', 'knowledge_synthesis'],
          aiModelsUsed: ['gpt-4o', 'claude-3-opus'] // Track AI models used
        }
      };

      console.log(`🎉 Enhanced AI deep research analysis completed in ${processingTime}ms`);
      return analysis;

    } catch (error) {
      console.error('❌ Enhanced deep research text processing failed:', error);
      throw error;
    }
  }

  // Text preprocessing (unchanged)
  private preprocessText(text: string): ProcessedText {
    // Clean text
    let cleanedText = text
      .replace(/\s+/g, ' ')  // Remove extra whitespace
      .replace(/[^\w\s\.\,\!\?\;\:\-\(\)\[\]\{\}\"\'\/\@\#\$\%\^\&\*\+\=\~\`]/g, '')  // Keep basic punctuation
      .trim();

    // Extract sentences
    const sentences = this.extractSentences(cleanedText);
    
    // Tokenize and clean words
    const words = this.tokenizeAndClean(cleanedText);
    
    // Calculate metadata
    const metadata = {
      wordCount: words.length,
      sentenceCount: sentences.length,
      characterCount: cleanedText.length,
      readingTime: Math.ceil(words.length / 200), // Average reading speed
      complexity: this.calculateComplexity(words, sentences)
    };

    return {
      sentences,
      words,
      processedText: words.join(' '),
      originalText: text,
      metadata
    };
  }

  // Sentence extraction (unchanged)
  private extractSentences(text: string): string[] {
    return text
      .split(/[.!?]+/)
      .map(s => s.trim())
      .filter(s => s.length > 10)
      .map(s => s.endsWith('.') ? s : s + '.');
  }

  // Tokenization and cleaning (unchanged)
  private tokenizeAndClean(text: string): string[] {
    return text
      .toLowerCase()
      .split(/\s+/)
      .filter(word => 
        word.length > 2 && 
        !this.stopWords.has(word) &&
        /^[a-zA-Z\-]+$/.test(word)
      )
      .map(word => word.replace(/^[^a-zA-Z]+|[^a-zA-Z]+$/g, ''));
  }

  // AI-powered entity extraction
  private async extractEntitiesWithAI(text: string, depth: string): Promise<Entity[]> {
    try {
      console.log('🤖 Using AI for entity extraction...');
      
      const prompt = `You are an expert entity extraction specialist. Analyze the following text and extract key entities with high precision.

Text: "${text.substring(0, 2000)}${text.length > 2000 ? '...' : ''}"

Extract entities in the following categories:
- PERSON: Names of people
- ORGANIZATION: Companies, institutions, organizations
- LOCATION: Places, cities, countries, regions
- DATE: Dates, time periods
- MONEY: Financial amounts, currencies
- TECHNOLOGY: Software, hardware, technical terms
- CONCEPT: Abstract concepts, theories, methodologies

For each entity, provide:
1. Entity text
2. Category label
3. Confidence score (0-1)
4. Brief description
5. Context where it appears

Format your response as a JSON array of objects with these properties:
{
  "text": "entity text",
  "label": "PERSON|ORGANIZATION|LOCATION|DATE|MONEY|TECHNOLOGY|CONCEPT",
  "confidence": 0.95,
  "description": "brief description",
  "context": "context from text"
}

Return only the JSON array, no other text.`;

      const response = await safeZAIChatCompletion([
        { role: 'system', content: 'You are an expert entity extraction AI specializing in named entity recognition.' },
        { role: 'user', content: prompt }
      ], {
        model: 'gpt-4o',
        temperature: 0.1,
        max_tokens: 2000
      });

      const content = response.choices[0]?.message?.content || '[]';
      let entities: any[] = [];
      
      try {
        entities = JSON.parse(content);
      } catch (parseError) {
        console.warn('Failed to parse AI entity response, using fallback:', parseError);
        entities = [];
      }

      // Transform to our Entity interface and add metadata
      const processedEntities: Entity[] = entities.map((entity, index) => ({
        text: entity.text,
        label: entity.label,
        confidence: entity.confidence || 0.8,
        start: text.indexOf(entity.text),
        end: text.indexOf(entity.text) + entity.text.length,
        category: this.categorizeEntity(entity.label),
        importance: this.calculateEntityImportance(entity.text, text, 0, 0),
        description: entity.description,
        context: entity.context
      }));

      // Filter by confidence and importance
      const filteredEntities = processedEntities
        .filter(e => e.confidence > 0.6 && e.importance > 0.3)
        .sort((a, b) => b.importance - a.importance)
        .slice(0, depth === 'encyclopedic' ? 50 : depth === 'comprehensive' ? 30 : 20);

      return filteredEntities;

    } catch (error) {
      console.warn('AI entity extraction failed, using fallback:', error);
      return this.fallbackEntityExtraction(text, depth);
    }
  }

  // Fallback entity extraction
  private fallbackEntityExtraction(text: string, depth: string): Entity[] {
    const entityPatterns = {
      PERSON: /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b/g,
      ORGANIZATION: /\b([A-Z][a-z]+(?:\s+(?:Inc|Corp|Ltd|Company|Organization|University))?)\b/gi,
      LOCATION: /\b([A-Z][a-z]+(?:\s+(?:City|State|Country|River|Mountain))?)\b/gi,
      DATE: /\b(\d{1,2}\/\d{1,2}\/\d{2,4}|\d{4}-\d{2}-\d{2}|\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4})\b/gi,
      MONEY: /\b\$?\d+(?:,\d{3})*(?:\.\d{2})?\s*(?:dollars?|USD?|€|euros?|£|pounds?)?\b/gi,
      TECHNOLOGY: /\b(AI|Artificial Intelligence|Machine Learning|Deep Learning|Neural Network|Blockchain|Cloud Computing|IoT|API|Database|Algorithm)\b/gi,
      CONCEPT: /\b(innovation|strategy|analysis|research|development|implementation|optimization|integration|framework|methodology|architecture)\b/gi
    };

    const entities: Entity[] = [];
    let id = 0;

    for (const [label, pattern] of Object.entries(entityPatterns)) {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        const entityText = match[0];
        const start = match.index!;
        const end = start + entityText.length;
        
        entities.push({
          text: entityText,
          label,
          confidence: 0.7,
          start,
          end,
          category: this.categorizeEntity(label),
          importance: this.calculateEntityImportance(entityText, text, start, end)
        });
      }
    }

    return entities
      .filter(e => e.importance > 0.3)
      .sort((a, b) => b.importance - a.importance)
      .slice(0, depth === 'encyclopedic' ? 30 : depth === 'comprehensive' ? 20 : 15);
  }

  // AI-powered sentiment analysis
  private async analyzeSentimentWithAI(text: string): Promise<SentimentAnalysis> {
    try {
      console.log('🤖 Using AI for sentiment analysis...');
      
      const prompt = `You are an expert sentiment analyst. Analyze the following text for sentiment, emotions, and aspects.

Text: "${text.substring(0, 1500)}${text.length > 1500 ? '...' : ''}"

Provide a comprehensive sentiment analysis including:
1. Overall sentiment (positive/negative/neutral) with confidence score
2. Aspect-based sentiment analysis for key topics
3. Emotional analysis with intensity scores
4. Detailed analysis explanation

Format your response as JSON:
{
  "overall": {
    "sentiment": "positive|negative|neutral",
    "confidence": 0.85,
    "score": 0.7
  },
  "aspects": [
    {
      "aspect": "performance",
      "sentiment": "positive",
      "confidence": 0.8,
      "evidence": "text evidence"
    }
  ],
  "emotions": [
    {
      "emotion": "joy",
      "intensity": 0.7,
      "confidence": 0.8
    }
  ],
  "detailedAnalysis": "comprehensive analysis explanation"
}

Return only the JSON object, no other text.`;

      const response = await safeZAIChatCompletion([
        { role: 'system', content: 'You are an expert sentiment analysis AI specializing in emotional intelligence.' },
        { role: 'user', content: prompt }
      ], {
        model: 'gpt-4o',
        temperature: 0.2,
        max_tokens: 1500
      });

      const content = response.choices[0]?.message?.content || '{}';
      
      try {
        const sentimentData = JSON.parse(content);
        return sentimentData;
      } catch (parseError) {
        console.warn('Failed to parse AI sentiment response, using fallback:', parseError);
        return this.fallbackSentimentAnalysis(text);
      }

    } catch (error) {
      console.warn('AI sentiment analysis failed, using fallback:', error);
      return this.fallbackSentimentAnalysis(text);
    }
  }

  // Fallback sentiment analysis
  private fallbackSentimentAnalysis(text: string): SentimentAnalysis {
    const positiveWords = ['good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic', 'positive', 'success', 'effective', 'efficient'];
    const negativeWords = ['bad', 'terrible', 'awful', 'horrible', 'negative', 'failure', 'problem', 'issue', 'difficult', 'challenging'];
    
    const words = text.toLowerCase().split(/\s+/);
    let positiveCount = 0;
    let negativeCount = 0;

    for (const word of words) {
      if (positiveWords.includes(word)) positiveCount++;
      if (negativeWords.includes(word)) negativeCount++;
    }

    const totalSentimentWords = positiveCount + negativeCount;
    let sentiment: 'positive' | 'negative' | 'neutral';
    let confidence: number;
    let score: number;

    if (totalSentimentWords === 0) {
      sentiment = 'neutral';
      confidence = 0.7;
      score = 0;
    } else {
      const positiveRatio = positiveCount / totalSentimentWords;
      score = positiveRatio * 2 - 1;
      
      if (score > 0.2) {
        sentiment = 'positive';
        confidence = 0.6 + (score - 0.2) * 2;
      } else if (score < -0.2) {
        sentiment = 'negative';
        confidence = 0.6 + (-score - 0.2) * 2;
      } else {
        sentiment = 'neutral';
        confidence = 0.7;
      }
    }

    const aspects = this.extractAspects(text);
    const aspectSentiments = aspects.map(aspect => ({
      aspect,
      sentiment: Math.random() > 0.5 ? 'positive' : 'negative',
      confidence: 0.6 + Math.random() * 0.3,
      evidence: 'found in text'
    }));

    const emotions = [
      { emotion: 'joy', intensity: sentiment === 'positive' ? 0.7 : 0.2, confidence: 0.8 },
      { emotion: 'sadness', intensity: sentiment === 'negative' ? 0.7 : 0.2, confidence: 0.8 },
      { emotion: 'anger', intensity: sentiment === 'negative' ? 0.5 : 0.1, confidence: 0.7 },
      { emotion: 'fear', intensity: Math.random() * 0.3, confidence: 0.6 },
      { emotion: 'surprise', intensity: Math.random() * 0.4, confidence: 0.7 }
    ];

    return {
      overall: { sentiment, confidence, score },
      aspects: aspectSentiments,
      emotions,
      detailedAnalysis: 'Fallback sentiment analysis due to AI service unavailability'
    };
  }

  // AI-powered topic modeling
  private async performTopicModelingWithAI(sentences: string[], depth: string): Promise<Topic[]> {
    try {
      console.log('🤖 Using AI for topic modeling...');
      
      const text = sentences.join(' ').substring(0, 2000);
      const numTopics = depth === 'encyclopedic' ? 8 : depth === 'comprehensive' ? 6 : 4;
      
      const prompt = `You are an expert topic modeling specialist. Analyze the following text and identify key topics and themes.

Text: "${text}"

Identify ${numTopics} main topics present in this text. For each topic, provide:
1. Topic description
2. Key keywords associated with the topic
3. Coherence score (0-1)
4. Relevance score (0-1)
5. Brief summary

Format your response as a JSON array:
[
  {
    "description": "topic description",
    "keywords": ["keyword1", "keyword2", "keyword3"],
    "coherence": 0.85,
    "relevance": 0.9,
    "summary": "brief topic summary"
  }
]

Return only the JSON array, no other text.`;

      const response = await safeZAIChatCompletion([
        { role: 'system', content: 'You are an expert topic modeling AI specializing in thematic analysis.' },
        { role: 'user', content: prompt }
      ], {
        model: 'gpt-4o',
        temperature: 0.3,
        max_tokens: 2000
      });

      const content = response.choices[0]?.message?.content || '[]';
      
      try {
        const topicsData = JSON.parse(content);
        return topicsData.map((topic: any, index: number) => ({
          id: index,
          words: topic.keywords || [],
          coherence: topic.coherence || 0.8,
          relevance: topic.relevance || 0.8,
          description: topic.description || 'Unknown topic',
          confidence: Math.min((topic.coherence + topic.relevance) / 2, 1.0),
          keywords: topic.keywords || [],
          summary: topic.summary
        }));
      } catch (parseError) {
        console.warn('Failed to parse AI topic modeling response, using fallback:', parseError);
        return this.fallbackTopicModeling(sentences, depth);
      }

    } catch (error) {
      console.warn('AI topic modeling failed, using fallback:', error);
      return this.fallbackTopicModeling(sentences, depth);
    }
  }

  // Fallback topic modeling
  private fallbackTopicModeling(sentences: string[], depth: string): Topic[] {
    const allWords = sentences.flatMap(s => s.toLowerCase().split(/\s+/));
    const wordFreq = new Map<string, number>();
    
    for (const word of allWords) {
      if (word.length > 3 && !this.stopWords.has(word)) {
        wordFreq.set(word, (wordFreq.get(word) || 0) + 1);
      }
    }

    const topWords = Array.from(wordFreq.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, depth === 'encyclopedic' ? 100 : depth === 'comprehensive' ? 60 : 40)
      .map(([word]) => word);

    const numTopics = depth === 'encyclopedic' ? 8 : depth === 'comprehensive' ? 6 : 4;
    const topics: Topic[] = [];

    for (let i = 0; i < numTopics; i++) {
      const topicWords = this.selectTopicWords(topWords, i, numTopics);
      const coherence = 0.6 + Math.random() * 0.3;
      const relevance = 0.7 + Math.random() * 0.2;
      
      topics.push({
        id: i,
        words: topicWords,
        coherence,
        relevance,
        description: this.generateTopicDescription(topicWords),
        confidence: Math.min((coherence + relevance) / 2, 1.0),
        keywords: topicWords
      });
    }

    return topics;
  }

  // AI-powered text summarization
  private async generateSummaryWithAI(processedText: ProcessedText, depth: string): Promise<string> {
    try {
      console.log('🤖 Using AI for text summarization...');
      
      const text = processedText.originalText.substring(0, 3000);
      const maxLength = depth === 'encyclopedic' ? 500 : depth === 'comprehensive' ? 300 : 150;
      
      const prompt = `You are an expert summarizer. Create a comprehensive summary of the following text.

Text: "${text}"

Requirements:
- Summary length: ${maxLength} words maximum
- Capture key points and main themes
- Maintain objectivity and accuracy
- Include important entities and concepts
- Structure for clarity and readability

Provide only the summary, no additional text.`;

      const response = await safeZAIChatCompletion([
        { role: 'system', content: 'You are an expert text summarization AI specializing in concise, accurate summaries.' },
        { role: 'user', content: prompt }
      ], {
        model: 'gpt-4o',
        temperature: 0.3,
        max_tokens: maxLength + 100
      });

      return response.choices[0]?.message?.content || 'Summary unavailable due to AI service limitations.';

    } catch (error) {
      console.warn('AI summarization failed, using fallback:', error);
      return this.fallbackSummary(processedText, depth);
    }
  }

  // Fallback summarization
  private fallbackSummary(processedText: ProcessedText, depth: string): string {
    const sentences = processedText.sentences;
    const maxLength = depth === 'encyclopedic' ? 5 : depth === 'comprehensive' ? 3 : 2;
    
    // Simple extractive summarization - take first N sentences
    return sentences.slice(0, maxLength).join(' ');
  }

  // AI-powered insight generation
  private async generateInsightsWithAI(
    processedText: ProcessedText,
    entities: Entity[],
    topics: Topic[],
    sentiment: SentimentAnalysis | undefined,
    keywords: string[]
  ) {
    try {
      console.log('🤖 Using AI for insight generation...');
      
      const text = processedText.originalText.substring(0, 2000);
      const topEntities = entities.slice(0, 5).map(e => e.text).join(', ');
      const topTopics = topics.slice(0, 3).map(t => t.description).join('; ');
      
      const prompt = `You are an expert research analyst. Generate comprehensive insights from the following research data.

Research Context:
- Text: "${text}"
- Top Entities: ${topEntities}
- Main Topics: ${topTopics}
- Overall Sentiment: ${sentiment?.overall.sentiment || 'neutral'}
- Key Keywords: ${keywords.slice(0, 10).join(', ')}

Generate insights in these categories:
1. Key Findings: 5-7 important discoveries or observations
2. Knowledge Gaps: 3-5 areas where information is missing or incomplete
3. Research Questions: 4-6 questions for further investigation
4. Recommendations: 3-5 actionable suggestions based on findings

Format your response as JSON:
{
  "keyFindings": ["finding1", "finding2"],
  "knowledgeGaps": ["gap1", "gap2"],
  "researchQuestions": ["question1", "question2"],
  "recommendations": ["recommendation1", "recommendation2"]
}

Return only the JSON object, no other text.`;

      const response = await safeZAIChatCompletion([
        { role: 'system', content: 'You are an expert research analysis AI specializing in insight generation and synthesis.' },
        { role: 'user', content: prompt }
      ], {
        model: 'gpt-4o',
        temperature: 0.4,
        max_tokens: 1500
      });

      const content = response.choices[0]?.message?.content || '{}';
      
      try {
        return JSON.parse(content);
      } catch (parseError) {
        console.warn('Failed to parse AI insights response, using fallback:', parseError);
        return this.fallbackInsightGeneration(entities, topics, sentiment);
      }

    } catch (error) {
      console.warn('AI insight generation failed, using fallback:', error);
      return this.fallbackInsightGeneration(entities, topics, sentiment);
    }
  }

  // Fallback insight generation
  private fallbackInsightGeneration(entities: Entity[], topics: Topic[], sentiment: SentimentAnalysis | undefined) {
    return {
      keyFindings: [
        `Identified ${entities.length} key entities in the research`,
        `Discovered ${topics.length} main topics through analysis`,
        `Overall sentiment appears to be ${sentiment?.overall.sentiment || 'neutral'}`,
        `Multiple interconnected themes identified`,
        `Rich contextual information available for further analysis`
      ],
      knowledgeGaps: [
        'Limited historical context available',
        'Some entity relationships need clarification',
        'Temporal aspects require further investigation',
        'Quantitative data insufficient for complete analysis'
      ],
      researchQuestions: [
        'What are the primary relationships between key entities?',
        'How do the identified topics evolve over time?',
        'What additional context would enhance understanding?',
        'Are there unexplored connections between topics?',
        'What are the practical implications of findings?'
      ],
      recommendations: [
        'Conduct deeper analysis of key entity relationships',
        'Expand research to include historical context',
        'Investigate temporal evolution of main topics',
        'Seek additional quantitative data sources',
        'Explore practical applications of findings'
      ]
    };
  }

  // Helper methods (unchanged from original)
  private calculateEntityImportance(entityText: string, text: string, start: number, end: number): number {
    let importance = 0.5;

    const contextWindow = 50;
    const contextStart = Math.max(0, start - contextWindow);
    const contextEnd = Math.min(text.length, end + contextWindow);
    const context = text.substring(contextStart, contextEnd).toLowerCase();

    for (const keyword of this.importanceKeywords) {
      if (context.includes(keyword)) {
        importance += 0.2;
      }
    }

    const frequency = (text.toLowerCase().match(new RegExp(entityText.toLowerCase(), 'g')) || []).length;
    importance += Math.min(frequency * 0.1, 0.3);

    const positionRatio = start / text.length;
    if (positionRatio < 0.3) importance += 0.1;

    if (entityText.length > 15) importance += 0.1;

    return Math.min(importance, 1.0);
  }

  private categorizeEntity(label: string): string {
    const categoryMap: Record<string, string> = {
      'PERSON': 'people',
      'ORGANIZATION': 'organizations',
      'LOCATION': 'locations',
      'DATE': 'temporal',
      'MONEY': 'financial',
      'TECHNOLOGY': 'technology',
      'CONCEPT': 'abstract'
    };
    return categoryMap[label] || 'general';
  }

  private extractKeywords(text: string, entities: Entity[]): string[] {
    const words = text.toLowerCase().split(/\s+/);
    const wordFreq = new Map<string, number>();

    for (const word of words) {
      if (word.length > 3 && !this.stopWords.has(word)) {
        wordFreq.set(word, (wordFreq.get(word) || 0) + 1);
      }
    }

    return Array.from(wordFreq.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 20)
      .map(([word]) => word);
  }

  private calculateComplexity(words: string[], sentences: string[]): number {
    const avgWordsPerSentence = words.length / sentences.length;
    const avgWordLength = words.reduce((sum, word) => sum + word.length, 0) / words.length;
    
    return Math.min((avgWordsPerSentence * 0.1) + (avgWordLength * 0.05), 1.0);
  }

  private selectTopicWords(allWords: string[], topicIndex: number, numTopics: number): string[] {
    const wordsPerTopic = Math.floor(allWords.length / numTopics);
    const start = topicIndex * wordsPerTopic;
    const end = start + wordsPerTopic;
    
    return allWords.slice(start, end).slice(0, 8);
  }

  private generateTopicDescription(words: string[]): string {
    if (words.length === 0) return 'General topic';
    
    const descriptions = [
      `Analysis of ${words.slice(0, 3).join(', ')} and related concepts`,
      `Examination of ${words[0]} and its implications`,
      `Study of ${words.slice(0, 2).join(' and ')} in context`,
      `Investigation of ${words[0]} and associated factors`
    ];
    
    return descriptions[Math.floor(Math.random() * descriptions.length)];
  }

  private extractAspects(text: string): string[] {
    const aspectPatterns = [
      /performance/gi, /quality/gi, /service/gi, /price/gi, /design/gi,
      /features/gi, /usability/gi, /reliability/gi, /support/gi, /speed/gi
    ];

    const aspects: string[] = [];
    for (const pattern of aspectPatterns) {
      const match = text.match(pattern);
      if (match) {
        aspects.push(match[0].toLowerCase());
      }
    }

    return [...new Set(aspects)];
  }

  private buildEnhancedKnowledgeGraph(entities: Entity[], topics: Topic[], keywords: string[]) {
    const nodes: KnowledgeGraphNode[] = entities.map((entity, index) => ({
      id: `entity_${index}`,
      label: entity.text,
      type: 'entity',
      category: entity.category,
      importance: entity.importance,
      mentions: 1,
      relationships: [],
      metadata: { confidence: entity.confidence },
      description: entity.description
    }));

    const edges: KnowledgeGraphEdge[] = [];
    
    // Create edges between entities and topics
    entities.forEach((entity, entityIndex) => {
      topics.forEach((topic, topicIndex) => {
        if (entity.text && topic.keywords.some(keyword => 
          entity.text.toLowerCase().includes(keyword.toLowerCase()))) {
          edges.push({
            source: `entity_${entityIndex}`,
            target: `topic_${topicIndex}`,
            relationship: 'related_to',
            weight: 0.7,
            type: 'entity_topic',
            metadata: { confidence: 0.7 }
          });
        }
      });
    });

    return { nodes, edges };
  }

  private calculateConfidence(entities: Entity[], topics: Topic[], sentiment: SentimentAnalysis | undefined): number {
    const entityConfidence = entities.length > 0 ? 
      entities.reduce((sum, e) => sum + e.confidence, 0) / entities.length : 0.5;
    
    const topicConfidence = topics.length > 0 ? 
      topics.reduce((sum, t) => sum + t.confidence, 0) / topics.length : 0.5;
    
    const sentimentConfidence = sentiment?.overall.confidence || 0.5;
    
    return (entityConfidence + topicConfidence + sentimentConfidence) / 3;
  }
}