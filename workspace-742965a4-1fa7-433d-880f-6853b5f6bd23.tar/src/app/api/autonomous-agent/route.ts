import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const { message } = await request.json();
    
    if (!message) {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 });
    }

    // Initialize ZAI SDK
    const zai = await ZAI.create();
    
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an autonomous AI agent with advanced capabilities. Analyze the user\'s request, understand the underlying goals, and provide comprehensive solutions with actionable steps. Break down complex tasks into manageable components and provide clear execution strategies.'
        },
        {
          role: 'user',
          content: message
        }
      ],
      max_tokens: 1500,
      temperature: 0.7
    });

    const response = completion.choices[0]?.message?.content || 'No response generated';

    return NextResponse.json({
      success: true,
      response,
      understanding: {
        primaryGoal: 'Execute user request autonomously',
        complexity: 'medium',
        estimatedSteps: 3
      },
      actions: [
        'Analyze request',
        'Generate solution',
        'Provide actionable steps'
      ],
      results: [response],
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Autonomous Agent API Error:', error);
    return NextResponse.json({
      success: false,
      error: 'Failed to process autonomous agent request',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}