import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    return NextResponse.json({ 
      status: 'healthy',
      message: 'AI services are available',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    return NextResponse.json({ 
      status: 'unhealthy',
      message: 'AI services are unavailable',
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}