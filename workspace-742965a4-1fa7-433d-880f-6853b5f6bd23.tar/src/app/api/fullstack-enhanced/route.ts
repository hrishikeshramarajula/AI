import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const { message } = await request.json();
    
    if (!message) {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 });
    }

    // Initialize ZAI SDK
    const zai = await ZAI.create();
    
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a full-stack development expert. Generate complete web applications with frontend, backend, and database components. Provide comprehensive solutions including file structure, code examples, setup instructions, and deployment guidance.'
        },
        {
          role: 'user',
          content: message
        }
      ],
      max_tokens: 2000,
      temperature: 0.7
    });

    const response = completion.choices[0]?.message?.content || 'No response generated';

    // Generate a sample fullstack project structure
    const projectStructure = {
      name: "Generated Fullstack Application",
      description: "AI-generated fullstack web application",
      type: "fullstack",
      framework: "nextjs",
      database: "sqlite",
      features: ["frontend", "backend", "database", "api"],
      files: [
        {
          path: "src/app/page.tsx",
          content: "// Generated frontend page",
          type: "frontend"
        },
        {
          path: "src/lib/db.ts",
          content: "// Generated database configuration",
          type: "backend"
        }
      ],
      setupInstructions: [
        "Install dependencies",
        "Configure database",
        "Run development server"
      ]
    };

    return NextResponse.json({
      success: true,
      response,
      fullstackProject: projectStructure,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Fullstack Enhanced API Error:', error);
    return NextResponse.json({
      success: false,
      error: 'Failed to process fullstack request',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}