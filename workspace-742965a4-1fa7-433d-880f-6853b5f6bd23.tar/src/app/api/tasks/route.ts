import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    // Return sample tasks
    const tasks = [
      {
        id: '1',
        title: 'Initialize project',
        status: 'completed',
        description: 'Project setup and configuration'
      },
      {
        id: '2',
        title: 'Setup AI integration',
        status: 'in-progress',
        description: 'Configure AI services and endpoints'
      },
      {
        id: '3',
        title: 'Test all modes',
        status: 'pending',
        description: 'Verify all AI modes are working correctly'
      }
    ];

    return NextResponse.json({
      success: true,
      tasks,
      total: tasks.length,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Tasks API Error:', error);
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch tasks',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const { title, description } = await request.json();
    
    if (!title) {
      return NextResponse.json({ error: 'Task title is required' }, { status: 400 });
    }

    const newTask = {
      id: Date.now().toString(),
      title,
      description: description || '',
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    return NextResponse.json({
      success: true,
      task: newTask,
      message: 'Task created successfully',
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Create Task API Error:', error);
    return NextResponse.json({
      success: false,
      error: 'Failed to create task',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}