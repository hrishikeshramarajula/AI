import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const { message, mode } = await request.json();
    
    if (!message) {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 });
    }

    // Initialize ZAI SDK
    const zai = await ZAI.create();
    
    // Create a simple response based on the mode
    let systemPrompt = 'You are a helpful AI assistant.';
    if (mode === 'code') {
      systemPrompt = 'You are an expert programmer. Provide code solutions with explanations.';
    } else if (mode === 'image') {
      systemPrompt = 'You are an AI image generation assistant. Describe images creatively.';
    } else if (mode === 'fullstack') {
      systemPrompt = 'You are a full-stack development expert. Provide comprehensive solutions.';
    } else if (mode === 'deep-research') {
      systemPrompt = 'You are a research assistant. Provide detailed, well-researched responses.';
    } else if (mode === 'autonomous-agent') {
      systemPrompt = 'You are an autonomous AI agent. Understand and execute tasks independently.';
    }

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: systemPrompt
        },
        {
          role: 'user',
          content: message
        }
      ],
      max_tokens: 1000,
      temperature: 0.7
    });

    const response = completion.choices[0]?.message?.content || 'No response generated';

    return NextResponse.json({
      success: true,
      response,
      mode,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('AI API Error:', error);
    return NextResponse.json({
      success: false,
      error: 'Failed to process AI request',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}