// Test script to verify AI generation is working
const testPrompt = "Create a simple cafe website with menu and contact information";

async function testAI() {
  try {
    console.log('Testing AI generation with prompt:', testPrompt);
    
    const response = await fetch('http://localhost:3000/api/ai-prompt', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: testPrompt,
        type: 'complete-webpage'
      })
    });

    const data = await response.json();
    console.log('Response:', JSON.stringify(data, null, 2));
    
    if (data.success && data.files) {
      console.log('\n=== GENERATED FILES ===');
      data.files.forEach((file, index) => {
        console.log(`\n${index + 1}. ${file.name} (${file.language}):`);
        console.log('Content preview:', file.content.substring(0, 200) + '...');
      });
    } else {
      console.log('Error:', data.error);
    }
    
  } catch (error) {
    console.error('Test failed:', error);
  }
}

testAI();