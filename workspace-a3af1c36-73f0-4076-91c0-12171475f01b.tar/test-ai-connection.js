// Test script to check z-ai-web-dev-sdk connection
const testAIConnection = async () => {
  console.log('🧪 Testing z-ai-web-dev-sdk Connection...');
  
  try {
    // Try to import and use the SDK
    const ZAI = await import('z-ai-web-dev-sdk');
    console.log('✅ z-ai-web-dev-sdk imported successfully');
    
    const zai = await ZAI.create();
    console.log('✅ ZAI client created successfully');
    
    // Test a simple completion
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a helpful assistant.'
        },
        {
          role: 'user',
          content: 'Hello! Can you help me test this connection?'
        }
      ],
      temperature: 0.7,
      max_tokens: 100
    });
    
    console.log('✅ AI completion successful');
    console.log('Response:', completion.choices[0]?.message?.content);
    
    return true;
    
  } catch (error) {
    console.error('❌ AI Connection Test Failed:');
    console.error('Error:', error.message);
    console.error('Stack:', error.stack);
    return false;
  }
};

// Run the test
testAIConnection().then(success => {
  if (success) {
    console.log('🎉 AI Connection Test PASSED!');
  } else {
    console.log('💥 AI Connection Test FAILED!');
  }
});