import { NextRequest, NextResponse } from 'next/server'

interface CodeQualityReport {
  score: number
  grade: 'A' | 'B' | 'C' | 'D' | 'F'
  metrics: {
    complexity: number
    maintainability: number
    reliability: number
    security: number
    performance: number
  }
  issues: {
    critical: CodeIssue[]
    major: CodeIssue[]
    minor: CodeIssue[]
    info: CodeIssue[]
  }
  suggestions: string[]
  improvements: string[]
}

interface CodeIssue {
  id: string
  type: 'syntax' | 'logic' | 'security' | 'performance' | 'style' | 'best-practice'
  severity: 'critical' | 'major' | 'minor' | 'info'
  message: string
  line?: number
  column?: number
  suggestion?: string
  fix?: string
}

export async function POST(request: NextRequest) {
  try {
    const { code, language } = await request.json()
    
    const report = await analyzeCodeQuality(code, language)
    
    return NextResponse.json({
      success: true,
      report,
      message: 'Code analysis completed successfully'
    })
    
  } catch (error) {
    console.error('Code analysis error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to analyze code' },
      { status: 500 }
    )
  }
}

async function analyzeCodeQuality(code: string, language: string): Promise<CodeQualityReport> {
  const lines = code.split('\n')
  
  // Initialize report
  const report: CodeQualityReport = {
    score: 0,
    grade: 'F',
    metrics: {
      complexity: 0,
      maintainability: 0,
      reliability: 0,
      security: 0,
      performance: 0
    },
    issues: {
      critical: [],
      major: [],
      minor: [],
      info: []
    },
    suggestions: [],
    improvements: []
  }

  // Analyze different aspects
  const complexityAnalysis = analyzeComplexity(code, language)
  const securityAnalysis = analyzeSecurity(code, language)
  const performanceAnalysis = analyzePerformance(code, language)
  const styleAnalysis = analyzeStyle(code, language)
  const syntaxAnalysis = analyzeSyntax(code, language)

  // Combine all issues
  report.issues.critical = [
    ...syntaxAnalysis.critical,
    ...securityAnalysis.critical,
    ...performanceAnalysis.critical
  ]
  report.issues.major = [
    ...syntaxAnalysis.major,
    ...securityAnalysis.major,
    ...performanceAnalysis.major,
    ...complexityAnalysis.major
  ]
  report.issues.minor = [
    ...styleAnalysis.major,
    ...complexityAnalysis.minor
  ]
  report.issues.info = [
    ...styleAnalysis.minor,
    ...complexityAnalysis.info
  ]

  // Calculate metrics
  report.metrics.complexity = calculateComplexityScore(complexityAnalysis)
  report.metrics.security = calculateSecurityScore(securityAnalysis)
  report.metrics.performance = calculatePerformanceScore(performanceAnalysis)
  report.metrics.maintainability = calculateMaintainabilityScore(styleAnalysis)
  report.metrics.reliability = calculateReliabilityScore(syntaxAnalysis)

  // Calculate overall score
  report.score = Math.round((
    report.metrics.complexity +
    report.metrics.security +
    report.metrics.performance +
    report.metrics.maintainability +
    report.metrics.reliability
  ) / 5)

  // Determine grade
  report.grade = getGrade(report.score)

  // Generate suggestions and improvements
  report.suggestions = generateSuggestions(report.issues, language)
  report.improvements = generateImprovements(report.metrics, language)

  return report
}

function analyzeComplexity(code: string, language: string): any {
  const issues: CodeIssue[] = []
  
  // Cyclomatic complexity calculation
  const functions = (code.match(/function\s+\w+|=>/g) || []).length
  const loops = (code.match(/(for|while)\s*\(/g) || []).length
  const conditionals = (code.match(/(if|else|switch)\s*\(/g) || []).length
  const tryCatch = (code.match(/(try|catch)\s*\{/g) || []).length
  
  const complexity = functions + loops + conditionals + tryCatch
  
  if (complexity > 20) {
    issues.push({
      id: 'complexity-1',
      type: 'logic',
      severity: 'major',
      message: `High cyclomatic complexity (${complexity}). Consider breaking down into smaller functions.`,
      suggestion: 'Extract complex logic into separate functions'
    })
  }
  
  // Function length analysis
  const functionBlocks = code.split(/function\s+\w+\s*\([^)]*\)\s*\{/)
  functionBlocks.forEach((block, index) => {
    if (block.length > 500) {
      const lines = block.split('\n').length
      if (lines > 30) {
        issues.push({
          id: `function-length-${index}`,
          type: 'logic',
          severity: 'minor',
          message: `Function ${index + 1} is too long (${lines} lines). Consider breaking it down.`,
          suggestion: 'Split long functions into smaller, focused functions'
        })
      }
    }
  })
  
  return {
    complexity,
    major: issues.filter(i => i.severity === 'major'),
    minor: issues.filter(i => i.severity === 'minor'),
    info: issues.filter(i => i.severity === 'info')
  }
}

function analyzeSecurity(code: string, language: string): any {
  const issues: CodeIssue[] = []
  
  if (language === 'javascript' || language === 'typescript') {
    // Check for eval()
    if (code.includes('eval(')) {
      issues.push({
        id: 'security-1',
        type: 'security',
        severity: 'critical',
        message: 'Use of eval() detected. This can lead to code injection attacks.',
        suggestion: 'Use safer alternatives like JSON.parse() or function constructors'
      })
    }
    
    // Check for innerHTML
    if (code.includes('innerHTML')) {
      issues.push({
        id: 'security-2',
        type: 'security',
        severity: 'major',
        message: 'Use of innerHTML detected. This can lead to XSS attacks.',
        suggestion: 'Use textContent or DOM manipulation methods instead'
      })
    }
    
    // Check for hardcoded sensitive data
    const sensitivePatterns = [
      /password\s*=\s*['"][^'"]+['"]/i,
      /api_key\s*=\s*['"][^'"]+['"]/i,
      /secret\s*=\s*['"][^'"]+['"]/i
    ]
    
    sensitivePatterns.forEach((pattern, index) => {
      if (pattern.test(code)) {
        issues.push({
          id: `security-sensitive-${index}`,
          type: 'security',
          severity: 'critical',
          message: 'Potential hardcoded sensitive data detected.',
          suggestion: 'Move sensitive data to environment variables or secure configuration'
        })
      }
    })
  }
  
  return {
    critical: issues.filter(i => i.severity === 'critical'),
    major: issues.filter(i => i.severity === 'major'),
    minor: issues.filter(i => i.severity === 'minor'),
    info: issues.filter(i => i.severity === 'info')
  }
}

function analyzePerformance(code: string, language: string): any {
  const issues: CodeIssue[] = []
  
  if (language === 'javascript') {
    // Check for DOM manipulation in loops
    const domInLoops = code.match(/for\s*\([^)]*\)\s*{[^}]*\.(innerHTML|appendChild|removeChild)/g)
    if (domInLoops) {
      issues.push({
        id: 'performance-1',
        type: 'performance',
        severity: 'major',
        message: 'DOM manipulation inside loops detected. This can cause performance issues.',
        suggestion: 'Batch DOM operations or use document fragments'
      })
    }
    
    // Check for expensive operations
    const expensiveOps = code.match(/(document\.querySelectorAll|document\.getElementsByTagName)\(/g)
    if (expensiveOps && expensiveOps.length > 3) {
      issues.push({
        id: 'performance-2',
        type: 'performance',
        severity: 'minor',
        message: 'Multiple expensive DOM queries detected.',
        suggestion: 'Cache DOM queries or use more specific selectors'
      })
    }
    
    // Check for synchronous operations
    if (code.includes('setTimeout(') || code.includes('setInterval(')) {
      issues.push({
        id: 'performance-3',
        type: 'performance',
        severity: 'info',
        message: 'Timer functions detected. Ensure proper cleanup.',
        suggestion: 'Clear timers when they are no longer needed'
      })
    }
  }
  
  return {
    critical: issues.filter(i => i.severity === 'critical'),
    major: issues.filter(i => i.severity === 'major'),
    minor: issues.filter(i => i.severity === 'minor'),
    info: issues.filter(i => i.severity === 'info')
  }
}

function analyzeStyle(code: string, language: string): any {
  const issues: CodeIssue[] = []
  
  if (language === 'javascript') {
    // Check for var usage
    const varUsage = (code.match(/\bvar\b/g) || []).length
    if (varUsage > 0) {
      issues.push({
        id: 'style-1',
        type: 'style',
        severity: 'minor',
        message: `Found ${varUsage} uses of 'var'. Use 'const' or 'let' instead.`,
        suggestion: 'Replace var with const or let for better scoping'
      })
    }
    
    // Check for missing semicolons
    const lines = code.split('\n')
    lines.forEach((line, index) => {
      const trimmed = line.trim()
      if (trimmed && 
          !trimmed.endsWith(';') && 
          !trimmed.endsWith('{') && 
          !trimmed.endsWith('}') && 
          !trimmed.startsWith('//') && 
          !trimmed.startsWith('/*') && 
          !trimmed.includes('return') &&
          !trimmed.includes('function') &&
          !trimmed.includes('if') &&
          !trimmed.includes('for') &&
          !trimmed.includes('while') &&
          !trimmed.includes('switch') &&
          trimmed.length > 0) {
        issues.push({
          id: `style-semicolon-${index}`,
          type: 'style',
          severity: 'minor',
          message: `Missing semicolon on line ${index + 1}`,
          suggestion: 'Add semicolons for consistency'
        })
      }
    })
    
    // Check for naming conventions
    const camelCaseCheck = code.match(/\b[A-Z][a-zA-Z0-9]*\b/g)
    if (camelCaseCheck && camelCaseCheck.length > 0) {
      issues.push({
        id: 'style-naming',
        type: 'style',
        severity: 'info',
        message: 'Consider using camelCase for variable names.',
        suggestion: 'Follow consistent naming conventions'
      })
    }
  }
  
  return {
    major: issues.filter(i => i.severity === 'major'),
    minor: issues.filter(i => i.severity === 'minor'),
    info: issues.filter(i => i.severity === 'info')
  }
}

function analyzeSyntax(code: string, language: string): any {
  const issues: CodeIssue[] = []
  
  if (language === 'javascript') {
    // Basic syntax checks
    try {
      // This is a very basic syntax check
      new Function(code)
    } catch (error) {
      issues.push({
        id: 'syntax-1',
        type: 'syntax',
        severity: 'critical',
        message: `Syntax error: ${error}`,
        suggestion: 'Fix syntax errors before running'
      })
    }
    
    // Check for unmatched brackets
    const openBraces = (code.match(/\{/g) || []).length
    const closeBraces = (code.match(/\}/g) || []).length
    const openParens = (code.match(/\(/g) || []).length
    const closeParens = (code.match(/\)/g) || []).length
    const openBrackets = (code.match(/\[/g) || []).length
    const closeBrackets = (code.match(/\]/g) || []).length
    
    if (openBraces !== closeBraces) {
      issues.push({
        id: 'syntax-braces',
        type: 'syntax',
        severity: 'critical',
        message: `Unmatched braces: ${openBraces} open, ${closeBraces} close`,
        suggestion: 'Check for missing or extra braces'
      })
    }
    
    if (openParens !== closeParens) {
      issues.push({
        id: 'syntax-parens',
        type: 'syntax',
        severity: 'critical',
        message: `Unmatched parentheses: ${openParens} open, ${closeParens} close`,
        suggestion: 'Check for missing or extra parentheses'
      })
    }
    
    if (openBrackets !== closeBrackets) {
      issues.push({
        id: 'syntax-brackets',
        type: 'syntax',
        severity: 'critical',
        message: `Unmatched brackets: ${openBrackets} open, ${closeBrackets} close`,
        suggestion: 'Check for missing or extra brackets'
      })
    }
  }
  
  return {
    critical: issues.filter(i => i.severity === 'critical'),
    major: issues.filter(i => i.severity === 'major'),
    minor: issues.filter(i => i.severity === 'minor'),
    info: issues.filter(i => i.severity === 'info')
  }
}

function calculateComplexityScore(complexityAnalysis: any): number {
  const baseScore = 100
  const deductions = complexityAnalysis.major.length * 15 + complexityAnalysis.minor.length * 5
  return Math.max(0, baseScore - deductions)
}

function calculateSecurityScore(securityAnalysis: any): number {
  const baseScore = 100
  const deductions = securityAnalysis.critical.length * 30 + securityAnalysis.major.length * 20
  return Math.max(0, baseScore - deductions)
}

function calculatePerformanceScore(performanceAnalysis: any): number {
  const baseScore = 100
  const deductions = performanceAnalysis.major.length * 15 + performanceAnalysis.minor.length * 8
  return Math.max(0, baseScore - deductions)
}

function calculateMaintainabilityScore(styleAnalysis: any): number {
  const baseScore = 100
  const deductions = styleAnalysis.major.length * 10 + styleAnalysis.minor.length * 5
  return Math.max(0, baseScore - deductions)
}

function calculateReliabilityScore(syntaxAnalysis: any): number {
  const baseScore = 100
  const deductions = syntaxAnalysis.critical.length * 40 + syntaxAnalysis.major.length * 20
  return Math.max(0, baseScore - deductions)
}

function getGrade(score: number): 'A' | 'B' | 'C' | 'D' | 'F' {
  if (score >= 90) return 'A'
  if (score >= 80) return 'B'
  if (score >= 70) return 'C'
  if (score >= 60) return 'D'
  return 'F'
}

function generateSuggestions(issues: any, language: string): string[] {
  const suggestions: string[] = []
  
  if (issues.critical.length > 0) {
    suggestions.push('Fix critical issues immediately - they may cause security vulnerabilities or crashes')
  }
  
  if (issues.major.length > 0) {
    suggestions.push('Address major issues to improve code quality and maintainability')
  }
  
  if (issues.minor.length > 0) {
    suggestions.push('Consider fixing minor issues to enhance code readability')
  }
  
  if (language === 'javascript') {
    suggestions.push('Use modern JavaScript features (ES6+) for better code quality')
    suggestions.push('Add proper error handling with try-catch blocks')
    suggestions.push('Consider using TypeScript for better type safety')
  }
  
  return suggestions
}

function generateImprovements(metrics: any, language: string): string[] {
  const improvements: string[] = []
  
  if (metrics.complexity < 80) {
    improvements.push('Break down complex functions into smaller, focused units')
  }
  
  if (metrics.security < 90) {
    improvements.push('Review security practices and implement secure coding standards')
  }
  
  if (metrics.performance < 80) {
    improvements.push('Optimize performance-critical sections of code')
  }
  
  if (metrics.maintainability < 80) {
    improvements.push('Improve code organization and follow consistent styling')
  }
  
  if (metrics.reliability < 90) {
    improvements.push('Add comprehensive error handling and input validation')
  }
  
  return improvements
}

export async function GET() {
  return NextResponse.json({
    message: 'Code Quality Analysis API is running',
    endpoints: {
      analyze: 'POST /api/code-quality - Analyze code quality',
      health: 'GET /api/code-quality - Health check'
    }
  })
}