import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

interface PromptRequest {
  prompt: string
  type: 'complete-webpage' | 'component' | 'feature'
  context?: string
}

interface PromptResponse {
  success: boolean
  files?: {
    name: string
    content: string
    language: string
  }[]
  explanation?: string
  error?: string
}

// Helper function to extract HTML, CSS, and JavaScript from AI response
function extractFilesFromResponse(content: string, prompt: string) {
  const files = []
  
  // Try to find HTML code block
  const htmlMatch = content.match(/```html\n([\s\S]*?)\n```/) || 
                   content.match(/```HTML\n([\s\S]*?)\n```/)
  
  // Try to find CSS code block
  const cssMatch = content.match(/```css\n([\s\S]*?)\n```/) || 
                  content.match(/```CSS\n([\s\S]*?)\n```/)
  
  // Try to find JavaScript code block
  const jsMatch = content.match(/```javascript\n([\s\S]*?)\n```/) || 
                 content.match(/```js\n([\s\S]*?)\n```/) ||
                 content.match(/```JavaScript\n([\s\S]*?)\n```/)
  
  if (htmlMatch && htmlMatch[1]) {
    files.push({
      name: 'index.html',
      content: htmlMatch[1].trim(),
      language: 'html'
    })
  } else {
    // If no HTML found, create from the entire content
    files.push({
      name: 'index.html',
      content: content.trim(),
      language: 'html'
    })
  }
  
  if (cssMatch && cssMatch[1]) {
    files.push({
      name: 'styles.css',
      content: cssMatch[1].trim(),
      language: 'css'
    })
  }
  
  if (jsMatch && jsMatch[1]) {
    files.push({
      name: 'script.js',
      content: jsMatch[1].trim(),
      language: 'javascript'
    })
  }
  
  return files
}

// Simple, reliable webpage generator
class WebpageGenerator {
  async generateWebpage(prompt: string) {
    console.log(`[AI-Prompt API] Starting webpage generation for: "${prompt}"`)
    
    try {
      console.log('[AI-Prompt API] 🚀 Using ZAI SDK...')
      const zai = await ZAI.create()
      
      const webpagePrompt = `Create a complete, modern webpage for: "${prompt}"

Generate THREE separate files:

1. HTML file (index.html) with:
- Complete HTML5 structure with proper doctype
- Meta tags for SEO and responsiveness
- Navigation bar with the site name
- Hero section with compelling headline
- Main content sections specific to "${prompt}"
- Contact form with name, email, message fields
- Footer with copyright info
- Links to external CSS and JavaScript files

2. CSS file (styles.css) with:
- Modern, responsive design using CSS Grid/Flexbox
- Professional color scheme suitable for "${prompt}"
- Smooth animations and hover effects
- Mobile-first responsive design
- Clean typography and spacing

3. JavaScript file (script.js) with:
- Smooth scrolling navigation
- Form validation and submission handling
- Interactive elements and event listeners
- Any functionality specific to "${prompt}"

IMPORTANT: Make the content SPECIFIC to "${prompt}" - not generic content. Use real details, services, and features relevant to this type of business/website.

Return your response in this exact format:
\`\`\`html
[HTML code here]
\`\`\`

\`\`\`css
[CSS code here]
\`\`\`

\`\`\`javascript
[JavaScript code here]
\`\`\``

      console.log('[AI-Prompt API] 🤖 Sending request to ZAI SDK...')
      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an expert web developer who creates complete, modern, and functional webpages. Generate clean, well-structured code with proper functionality and beautiful design.'
          },
          {
            role: 'user',
            content: webpagePrompt
          }
        ],
        temperature: 0.8,
        max_tokens: 4000
      })

      const content = completion.choices[0]?.message?.content || ''
      
      if (!content) {
        throw new Error('Empty response from ZAI SDK')
      }
      
      console.log('[AI-Prompt API] 📝 ZAI SDK response received, parsing files...')
      const files = extractFilesFromResponse(content, prompt)
      
      if (files.length === 0) {
        throw new Error('No files were generated from ZAI SDK')
      }
      
      return {
        files: files,
        explanation: `Generated a complete webpage specifically for: "${prompt}" using ZAI SDK`
      }
      
    } catch (error) {
      console.error('[AI-Prompt API] ❌ ZAI SDK error:', error)
      throw error
    }
  }
  
  createFallbackWebpage(prompt: string) {
    console.log('[AI-Prompt API] 🛠️ Creating professional fallback webpage...')
    
    return {
      files: [
        {
          name: 'index.html',
          content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${prompt.charAt(0).toUpperCase() + prompt.slice(1)} - Professional Website</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-logo">${prompt.charAt(0).toUpperCase() + prompt.slice(1)}</div>
            <ul class="nav-menu">
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#services">Services</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </div>
    </nav>

    <section id="home" class="hero">
        <div class="hero-content">
            <h1 class="hero-title">Welcome to ${prompt.charAt(0).toUpperCase() + prompt.slice(1)}</h1>
            <p class="hero-subtitle">Professional services tailored to your needs</p>
            <a href="#contact" class="cta-button">Get Started</a>
        </div>
    </section>

    <section id="about" class="about">
        <div class="container">
            <h2>About Us</h2>
            <p>We are dedicated to providing exceptional ${prompt} services with a focus on quality, innovation, and customer satisfaction.</p>
        </div>
    </section>

    <section id="services" class="services">
        <div class="container">
            <h2>Our Services</h2>
            <div class="services-grid">
                <div class="service-card">
                    <h3>Professional Service</h3>
                    <p>Expert ${prompt} solutions delivered with precision and care.</p>
                </div>
                <div class="service-card">
                    <h3>Quality Assurance</h3>
                    <p>Committed to delivering the highest quality ${prompt} services.</p>
                </div>
                <div class="service-card">
                    <h3>Customer Support</h3>
                    <p>24/7 support for all your ${prompt} needs.</p>
                </div>
            </div>
        </div>
    </section>

    <section id="contact" class="contact">
        <div class="container">
            <h2>Contact Us</h2>
            <form class="contact-form">
                <input type="text" placeholder="Your Name" required>
                <input type="email" placeholder="Your Email" required>
                <textarea placeholder="Your Message" rows="5" required></textarea>
                <button type="submit">Send Message</button>
            </form>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <p>&copy; 2024 ${prompt.charAt(0).toUpperCase() + prompt.slice(1)}. All rights reserved.</p>
        </div>
    </footer>

    <script src="script.js"></script>
</body>
</html>`,
          language: 'html'
        },
        {
          name: 'styles.css',
          content: `/* Modern styling for ${prompt} */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    line-height: 1.6;
    color: #333;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

/* Navigation */
.navbar {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    padding: 1rem 0;
    position: fixed;
    width: 100%;
    top: 0;
    z-index: 1000;
    box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
}

.nav-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.nav-logo {
    font-size: 1.5rem;
    font-weight: bold;
    color: #667eea;
}

.nav-menu {
    display: flex;
    list-style: none;
    gap: 2rem;
}

.nav-menu a {
    text-decoration: none;
    color: #333;
    font-weight: 500;
    transition: color 0.3s ease;
}

.nav-menu a:hover {
    color: #667eea;
}

/* Hero Section */
.hero {
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    color: white;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.hero-content {
    max-width: 800px;
    padding: 0 20px;
}

.hero-title {
    font-size: 3.5rem;
    margin-bottom: 1rem;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
}

.hero-subtitle {
    font-size: 1.5rem;
    margin-bottom: 2rem;
    opacity: 0.9;
}

.cta-button {
    display: inline-block;
    padding: 15px 30px;
    background: rgba(255, 255, 255, 0.2);
    color: white;
    text-decoration: none;
    border-radius: 50px;
    font-weight: bold;
    transition: all 0.3s ease;
    border: 2px solid rgba(255, 255, 255, 0.3);
}

.cta-button:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: translateY(-2px);
}

/* Sections */
section {
    padding: 80px 0;
    background: white;
}

section h2 {
    text-align: center;
    font-size: 2.5rem;
    margin-bottom: 3rem;
    color: #333;
}

/* Services */
.services {
    background: #f8f9fa;
}

.services-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
    margin-top: 3rem;
}

.service-card {
    background: white;
    padding: 2rem;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    text-align: center;
    transition: transform 0.3s ease;
}

.service-card:hover {
    transform: translateY(-5px);
}

.service-card h3 {
    color: #667eea;
    margin-bottom: 1rem;
    font-size: 1.5rem;
}

/* Contact Form */
.contact-form {
    max-width: 600px;
    margin: 0 auto;
}

.contact-form input,
.contact-form textarea {
    width: 100%;
    padding: 15px;
    margin-bottom: 1rem;
    border: 2px solid #e9ecef;
    border-radius: 10px;
    font-size: 1rem;
    transition: border-color 0.3s ease;
}

.contact-form input:focus,
.contact-form textarea:focus {
    outline: none;
    border-color: #667eea;
}

.contact-form button {
    width: 100%;
    padding: 15px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 1.1rem;
    font-weight: bold;
    cursor: pointer;
    transition: transform 0.3s ease;
}

.contact-form button:hover {
    transform: translateY(-2px);
}

/* Footer */
.footer {
    background: #333;
    color: white;
    text-align: center;
    padding: 2rem 0;
}

/* Responsive Design */
@media (max-width: 768px) {
    .hero-title {
        font-size: 2.5rem;
    }
    
    .hero-subtitle {
        font-size: 1.2rem;
    }
    
    .nav-menu {
        gap: 1rem;
    }
    
    .services-grid {
        grid-template-columns: 1fr;
    }
    
    section {
        padding: 60px 0;
    }
}

@media (max-width: 480px) {
    .nav-container {
        flex-direction: column;
        gap: 1rem;
    }
    
    .nav-menu {
        flex-direction: column;
        text-align: center;
        gap: 0.5rem;
    }
}`,
          language: 'css'
        },
        {
          name: 'script.js',
          content: `// Interactive features for ${prompt}
document.addEventListener('DOMContentLoaded', function() {
    console.log('Website loaded successfully for: ${prompt}');
    
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Add animation to hero content
    const heroContent = document.querySelector('.hero-content');
    if (heroContent) {
        heroContent.style.opacity = '0';
        heroContent.style.transform = 'translateY(30px)';
        
        setTimeout(() => {
            heroContent.style.transition = 'all 1s ease';
            heroContent.style.opacity = '1';
            heroContent.style.transform = 'translateY(0)';
        }, 100);
    }
    
    // Add animation to service cards
    const serviceCards = document.querySelectorAll('.service-card');
    serviceCards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            card.style.transition = 'opacity 0.5s, transform 0.5s';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
    
    // Form validation and submission
    const contactForm = document.querySelector('.contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const name = this.querySelector('input[type="text"]').value;
            const email = this.querySelector('input[type="email"]').value;
            const message = this.querySelector('textarea').value;
            
            if (name && email && message) {
                // Show success message
                const successMessage = document.createElement('div');
                successMessage.style.cssText = \`
                    background: #28a745;
                    color: white;
                    padding: 15px;
                    border-radius: 10px;
                    margin-top: 20px;
                    text-align: center;
                \`;
                successMessage.textContent = 'Thank you for your message! We will get back to you soon.';
                
                this.appendChild(successMessage);
                this.reset();
                
                // Remove success message after 5 seconds
                setTimeout(() => {
                    successMessage.remove();
                }, 5000);
            }
        });
    }
    
    // Add scroll effect to navbar
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 100) {
                navbar.style.background = 'rgba(255, 255, 255, 0.98)';
                navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
            } else {
                navbar.style.background = 'rgba(255, 255, 255, 0.95)';
                navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
            }
        });
    }
    
    console.log('All interactive features initialized for ${prompt}');
});`,
          language: 'javascript'
        }
      ],
      explanation: `Created a beautiful, professional webpage for: "${prompt}" with modern design and interactive features.`
    }
  }
}

// Initialize the webpage generator
const webpageGenerator = new WebpageGenerator()

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { prompt, type, context } = body
    
    if (!prompt) {
      return NextResponse.json({
        success: false,
        error: 'Prompt is required'
      }, { status: 400 })
    }

    console.log(`[AI-Prompt API] 🚀 Processing prompt: "${prompt}"`)

    try {
      // Try to generate with ZAI SDK first
      const result = await webpageGenerator.generateWebpage(prompt)

      console.log('[AI-Prompt API] ✅ Webpage generation completed successfully')
      console.log(`[AI-Prompt API] 📁 Created ${result.files.length} files: ${result.files.map(f => f.name).join(', ')}`)

      return NextResponse.json({
        success: true,
        files: result.files,
        explanation: result.explanation
      })

    } catch (aiError) {
      console.error('[AI-Prompt API] ❌ AI generation failed:', aiError)
      
      // Always provide professional fallback
      const fallbackResult = webpageGenerator.createFallbackWebpage(prompt)
      
      return NextResponse.json({
        success: true,
        files: fallbackResult.files,
        explanation: fallbackResult.explanation + ' (Using professional fallback template)'
      })
    }

  } catch (error) {
    console.error('[AI-Prompt API] ❌ Unexpected error:', error)
    
    // Even in unexpected errors, provide fallback
    try {
      const body = await request.json()
      const prompt = body.prompt || 'website'
      const fallbackResult = webpageGenerator.createFallbackWebpage(prompt)
      
      return NextResponse.json({
        success: true,
        files: fallbackResult.files,
        explanation: fallbackResult.explanation + ' (Emergency fallback)'
      })
    } catch {
      // Ultimate fallback if even parsing fails
      return NextResponse.json({
        success: true,
        files: webpageGenerator.createFallbackWebpage('website').files,
        explanation: 'Ultimate fallback webpage created'
      })
    }
  }
}