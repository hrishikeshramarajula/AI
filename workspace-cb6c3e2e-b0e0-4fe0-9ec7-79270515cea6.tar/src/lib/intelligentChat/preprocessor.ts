// ====== 1. PREPROCESSING MODULE ======
export interface Token {
  text: string;
  type: 'word' | 'punctuation' | 'number' | 'other';
}

export class Preprocessor {
  private static readonly TYPO_CORRECTIONS: Record<string, string> = {
    'quantam': 'quantum',
    'computr': 'computer',
    'teh': 'the',
    'recieve': 'receive',
    'seperate': 'separate',
    'definately': 'definitely',
    'occured': 'occurred',
    'publically': 'publicly',
    'independant': 'independent',
    'neccessary': 'necessary',
    'maintainance': 'maintenance',
    'accomodate': 'accommodate',
    'embarass': 'embarrass',
    'existance': 'existence',
    'goverment': 'government',
    'happend': 'happened',
    'recieve': 'receive',
    'seperate': 'separate',
    'sucess': 'success',
    'untill': 'until',
    'wich': 'which',
    'woud': 'would',
    'youre': "you're",
    'dont': "don't",
    'cant': "can't",
    'wont': "won't",
    'didnt': "didn't",
    'couldnt': "couldn't",
    'shouldnt': "shouldn't",
    'wouldnt': "wouldn't",
    'isnt': "isn't",
    'arent': "aren't",
    'wasnt': "wasn't",
    'werent': "weren't",
    'hasnt': "hasn't",
    'havent': "haven't",
    'hadnt': "hadn't"
  };

  /**
   * Split text into tokens (words/subwords, punctuation, numbers)
   */
  static tokenize(text: string): Token[] {
    const tokens: Token[] = [];
    
    // Match words, numbers, and punctuation separately
    const tokenPattern = /([a-zA-Z]+(?:'[a-zA-Z]+)?)|(\d+(?:\.\d+)?)|([^\w\s])|(\s+)/g;
    let match;
    
    while ((match = tokenPattern.exec(text)) !== null) {
      const [fullMatch, word, number, punctuation, whitespace] = match;
      
      if (word) {
        tokens.push({ text: word, type: 'word' });
      } else if (number) {
        tokens.push({ text: number, type: 'number' });
      } else if (punctuation) {
        tokens.push({ text: punctuation, type: 'punctuation' });
      }
      // Skip whitespace tokens
    }
    
    return tokens;
  }

  /**
   * Clean and normalize tokens
   */
  static clean(tokens: Token[]): Token[] {
    return tokens.filter(token => {
      // Keep alphanumeric words, numbers, and common punctuation
      return token.type === 'number' || 
             token.type === 'punctuation' && ['.', '!', '?', ',', ';', ':', '(', ')', '[', ']', '{', '}', '"', "'", '-', '+', '=', '*', '/', '\\', '@', '#', '$', '%', '^', '&', '|', '~', '`'].includes(token.text) ||
             token.type === 'word' && token.text.length > 0;
    });
  }

  /**
   * Simple typo correction using dictionary
   */
  static correctTypos(tokens: Token[]): Token[] {
    return tokens.map(token => {
      if (token.type === 'word') {
        const lowerText = token.text.toLowerCase();
        const correction = this.TYPO_CORRECTIONS[lowerText];
        
        if (correction) {
          // Preserve original case if possible
          if (token.text[0] === token.text[0].toUpperCase()) {
            return { 
              text: correction.charAt(0).toUpperCase() + correction.slice(1), 
              type: 'word' 
            };
          }
          return { text: correction, type: 'word' };
        }
      }
      return token;
    });
  }

  /**
   * Extract entities from tokens (simplified NER)
   */
  static extractEntities(tokens: Token[]): Array<{ text: string; type: string; confidence: number }> {
    const entities: Array<{ text: string; type: string; confidence: number }> = [];
    const text = tokens.map(t => t.text).join(' ').toLowerCase();

    // Simple keyword-based entity recognition
    const entityPatterns = {
      technology: ['quantum', 'ai', 'artificial intelligence', 'machine learning', 'neural network', 'blockchain', 'cryptocurrency', 'cloud computing'],
      location: ['paris', 'london', 'new york', 'tokyo', 'berlin', 'france', 'england', 'america', 'europe', 'asia'],
      person: ['einstein', 'newton', 'tesla', 'curie', 'darwin', 'hawking', 'feynman'],
      organization: ['google', 'microsoft', 'apple', 'amazon', 'facebook', 'tesla', 'nasa', 'mit'],
      time: ['today', 'tomorrow', 'yesterday', 'now', 'soon', 'later', 'morning', 'afternoon', 'evening', 'night']
    };

    for (const [type, keywords] of Object.entries(entityPatterns)) {
      for (const keyword of keywords) {
        if (text.includes(keyword)) {
          entities.push({
            text: keyword,
            type,
            confidence: 0.8
          });
        }
      }
    }

    return entities;
  }

  /**
   * Complete preprocessing pipeline
   */
  static process(text: string): {
    tokens: Token[];
    entities: Array<{ text: string; type: string; confidence: number }>;
    cleanedText: string;
  } {
    const tokens = this.tokenize(text);
    const cleanedTokens = this.clean(tokens);
    const correctedTokens = this.correctTypos(cleanedTokens);
    const entities = this.extractEntities(correctedTokens);
    const cleanedText = correctedTokens.map(t => t.text).join(' ');

    return {
      tokens: correctedTokens,
      entities,
      cleanedText
    };
  }
}