'use client';

import React, { useState, useEffect } from 'react';
import { X, Brain, CheckCircle, RefreshCw, Zap, Activity, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';

interface HomeScreenDisplayProps {
  project: any;
  isVisible: boolean;
  onClose?: () => void;
  className?: string;
  aiAgentBrainData?: any;
}

export default function HomeScreenDisplay({ project, isVisible, onClose, className = '', aiAgentBrainData }: HomeScreenDisplayProps) {
  console.log('🎬 HomeScreenDisplay rendered with:', { isVisible, project: project?.structure?.name, aiAgentBrainData });
  
  const [liveUpdates, setLiveUpdates] = useState<string[]>([]);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  // Simulate real-time updates for AI Agent Brain
  useEffect(() => {
    if (aiAgentBrainData) {
      const interval = setInterval(() => {
        const now = new Date();
        const update = `[${now.toLocaleTimeString()}] 🔄 AI Agent Brain status update...`;
        setLiveUpdates(prev => [...prev.slice(-9), update]); // Keep last 10 updates
        setLastUpdate(now);
      }, 3000);

      return () => clearInterval(interval);
    }
  }, [aiAgentBrainData]);

  if (!isVisible) {
    return null;
  }

  console.log('✅ HomeScreenDisplay is visible and will render');

  return (
    <div className={`w-full ${className}`}>
      {aiAgentBrainData ? (
        <Card className="border-2 border-purple-200 bg-purple-50">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-purple-900">
                <Brain className="w-5 h-5" />
                🧠 AI Agent Brain Results
              </CardTitle>
              {onClose && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onClose}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="w-4 h-4" />
                </Button>
              )}
            </div>
            {lastUpdate && (
              <div className="flex items-center gap-1 mt-2 text-xs text-gray-500">
                <RefreshCw className="w-3 h-3 animate-spin" />
                <span>Last update: {lastUpdate.toLocaleTimeString()}</span>
              </div>
            )}
          </CardHeader>
          
          <CardContent className="p-6">
            <div className="space-y-6">
              {/* Header */}
              <div className="text-center space-y-2">
                <div className="flex items-center justify-center gap-3">
                  <Brain className="w-8 h-8 text-purple-600" />
                  <h3 className="text-2xl font-bold text-gray-900">🧠 AI Agent Brain Processing</h3>
                </div>
                <p className="text-gray-600">
                  Your request has been processed with intelligent task execution and error correction
                </p>
              </div>

              {/* Results Overview */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">{aiAgentBrainData.result?.todosCompleted || 0}</div>
                  <div className="text-sm text-gray-600">Tasks Completed</div>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{aiAgentBrainData.result?.errorsCorrected || 0}</div>
                  <div className="text-sm text-gray-600">Errors Corrected</div>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">{aiAgentBrainData.result?.iterations || 0}</div>
                  <div className="text-sm text-gray-600">Iterations</div>
                </div>
                <div className="text-center p-4 bg-yellow-50 rounded-lg">
                  <div className="text-2xl font-bold text-yellow-600">{aiAgentBrainData.result?.confidence || 0}%</div>
                  <div className="text-sm text-gray-600">Confidence</div>
                </div>
              </div>

              {/* Processing Details */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Zap className="w-4 h-4" />
                    Processing Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Status:</span>
                      <Badge variant={aiAgentBrainData.result?.status === 'completed' ? 'default' : 'secondary'}>
                        {aiAgentBrainData.result?.status || 'processing'}
                      </Badge>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Processing Time:</span>
                      <span className="font-medium">{aiAgentBrainData.result?.processingTime || 0}ms</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Strategy Used:</span>
                      <span className="font-medium">{aiAgentBrainData.result?.strategy || 'adaptive'}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Live Updates */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Activity className="w-4 h-4" />
                    Live Updates
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <ScrollArea className="h-32 w-full border rounded-md p-3">
                    {liveUpdates.length === 0 ? (
                      <div className="text-center text-gray-500 text-sm py-4">
                        Waiting for updates...
                      </div>
                    ) : (
                      liveUpdates.map((update, index) => (
                        <div key={index} className="text-xs font-mono text-gray-600">
                          {update}
                        </div>
                      ))
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* Final Output */}
              {aiAgentBrainData.result?.output && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Eye className="w-4 h-4" />
                      Final Output
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-2">
                      <p className="text-sm text-gray-700">{aiAgentBrainData.result.output.message}</p>
                      {aiAgentBrainData.result.output.results && (
                        <details className="text-xs">
                          <summary className="cursor-pointer text-blue-600 hover:text-blue-800">
                            View detailed results ({aiAgentBrainData.result.output.results.length} items)
                          </summary>
                          <div className="mt-2 p-2 bg-gray-50 rounded text-xs max-h-32 overflow-y-auto">
                            <pre>{JSON.stringify(aiAgentBrainData.result.output.results, null, 2)}</pre>
                          </div>
                        </details>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-2 border-green-200 bg-green-50">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-green-900">
                <CheckCircle className="w-5 h-5" />
                ✅ Project Execution Complete
              </CardTitle>
              {onClose && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onClose}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="w-4 h-4" />
                </Button>
              )}
            </div>
          </CardHeader>
          
          <CardContent className="p-6">
            <div className="text-center space-y-4">
              <div className="flex items-center justify-center gap-3">
                <CheckCircle className="w-8 h-8 text-green-600" />
                <h3 className="text-2xl font-bold text-gray-900">🎉 Successfully Executed!</h3>
              </div>
              
              <p className="text-gray-600">
                {project?.structure?.description || 'Your project has been successfully executed and is ready to use.'}
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{project?.files?.length || 0}</div>
                  <div className="text-sm text-gray-600">Files Generated</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">{project?.structure?.features?.length || 0}</div>
                  <div className="text-sm text-gray-600">Features</div>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">100%</div>
                  <div className="text-sm text-gray-600">Complete</div>
                </div>
              </div>
              
              {project?.structure?.features && (
                <div className="mt-6">
                  <h4 className="font-semibold text-gray-900 mb-3">✨ Features Included:</h4>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {project.structure.features.map((feature: string, index: number) => (
                      <Badge key={index} variant="secondary" className="text-sm">
                        {feature}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}