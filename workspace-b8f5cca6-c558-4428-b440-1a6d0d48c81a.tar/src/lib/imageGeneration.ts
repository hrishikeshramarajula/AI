// Dedicated Image Generation Helper
// Note: Using direct API calls instead of SDKs to avoid dependency issues
import ZAI from 'z-ai-web-dev-sdk';

export interface ImageGenerationResult {
  success: boolean;
  imageData?: string;
  error?: string;
  provider: string;
  model: string;
  metadata?: {
    size: string;
    optimized: boolean;
    timestamp: string;
  };
}

export async function generateImage(
  prompt: string,
  provider: string = 'auto',
  model: string = 'auto',
  size: string = '1024x1024'
): Promise<ImageGenerationResult> {
  console.log('🎨 Generating image:', { prompt, provider, model, size });

  try {
    // For now, use ZAI SDK for image generation since it's already configured
    const zai = await ZAI.create();

    const response = await zai.images.generations.create({
      prompt,
      size: size as any,
    });

    const imageData = response.data[0].base64;

    return {
      success: true,
      imageData,
      provider: provider === 'auto' ? 'ZAI' : provider,
      model: model === 'auto' ? 'Default' : model,
      metadata: {
        size,
        optimized: true,
        timestamp: new Date().toISOString()
      }
    };

  } catch (error) {
    console.error('❌ Image generation failed:', error);
    
    // Try fallback to mock generation for testing
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      provider,
      model,
      metadata: {
        size,
        optimized: false,
        timestamp: new Date().toISOString()
      }
    };
  }
}