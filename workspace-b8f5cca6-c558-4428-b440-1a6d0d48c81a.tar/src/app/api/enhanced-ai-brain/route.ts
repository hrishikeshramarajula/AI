// 🧠 Enhanced AI Brain API Route
// This provides the API endpoint for the enhanced AI brain with analytical thinking

import { NextRequest, NextResponse } from 'next/server';
import { EnhancedAIAgentBrain } from '@/lib/aiAgent/brain/EnhancedAIAgentBrain';
import { todoManager } from '@/lib/todoManager';

// Global enhanced AI brain instance
let enhancedBrain: EnhancedAIAgentBrain | null = null;

async function getEnhancedBrain(): Promise<EnhancedAIAgentBrain> {
  if (!enhancedBrain) {
    enhancedBrain = new EnhancedAIAgentBrain();
  }
  return enhancedBrain;
}

export async function GET(request: NextRequest) {
  try {
    const brain = await getEnhancedBrain();
    const status = brain.getBrainStatus();
    
    // Get todo manager status
    const todoStatus = todoManager.getStatus();
    
    return NextResponse.json({
      success: true,
      status,
      todoStatus,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ Enhanced AI Brain status check failed:', error);
    return NextResponse.json({
      success: false,
      error: error.message,
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { text, context, priority, userId, expectedOutput } = body;
    
    if (!text || !text.trim()) {
      return NextResponse.json({
        success: false,
        error: 'Text input is required',
        timestamp: new Date().toISOString()
      }, { status: 400 });
    }

    const brain = await getEnhancedBrain();
    
    // Prepare input for enhanced processing
    const input = {
      text: text.trim(),
      context: context || {},
      priority: priority || 'medium',
      userId: userId || 'anonymous',
      timestamp: new Date(),
      expectedOutput: expectedOutput
    };

    console.log('🚀 Processing with Enhanced AI Brain:', input);

    // Process with enhanced AI brain
    const result = await brain.process(input);

    // Create todo list from the result
    if (result.success && result.analysis.todoPlan.length > 0) {
      try {
        await todoManager.TodoWrite(
          result.analysis.todoPlan,
          `Enhanced AI Brain: ${result.analysis.understanding.mainGoal}`,
          `Automatically generated todo list for enhanced AI processing`
        );
      } catch (todoError) {
        console.error('⚠️ Todo creation failed:', todoError);
        // Don't fail the whole process if todo creation fails
      }
    }

    console.log('✅ Enhanced AI Brain processing completed');

    return NextResponse.json({
      success: true,
      result,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('❌ Enhanced AI Brain processing failed:', error);
    return NextResponse.json({
      success: false,
      error: error.message,
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    // Clean up resources
    if (enhancedBrain) {
      await enhancedBrain.shutdown();
      enhancedBrain = null;
    }
    
    return NextResponse.json({
      success: true,
      message: 'Enhanced AI Brain shutdown successfully',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ Enhanced AI Brain shutdown failed:', error);
    return NextResponse.json({
      success: false,
      error: error.message,
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}