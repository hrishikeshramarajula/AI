'use client';

import { useState, useCallback, useEffect } from 'react';
import { circuitBreakers } from '@/lib/circuitBreaker';
import { gracefulDegradation } from '@/lib/gracefulDegradation';
import { useToast } from '@/hooks/use-toast';

export interface ErrorHandlerOptions {
  enableCircuitBreaker?: boolean;
  enableGracefulDegradation?: boolean;
  enableToastNotifications?: boolean;
  fallbackMessage?: string;
  maxRetries?: number;
}

export interface UseErrorHandlerReturn {
  error: Error | null;
  isLoading: boolean;
  executeWithErrorHandling: <T>(
    operation: () => Promise<T>,
    options?: ErrorHandlerOptions
  ) => Promise<T>;
  retryOperation: () => void;
  clearError: () => void;
  isServiceDegraded: boolean;
  getServiceStatus: () => any;
}

export function useErrorHandler(
  initialOptions: ErrorHandlerOptions = {}
): UseErrorHandlerReturn {
  const [error, setError] = useState<Error | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [retryOperation, setRetryOperation] = useState<(() => Promise<any>) | null>(null);
  const [isServiceDegraded, setIsServiceDegraded] = useState(false);
  const { toast } = useToast();

  const options = {
    enableCircuitBreaker: true,
    enableGracefulDegradation: true,
    enableToastNotifications: true,
    fallbackMessage: 'Operation failed. Please try again.',
    maxRetries: 3,
    ...initialOptions
  };

  // Check service status on mount
  useEffect(() => {
    const checkServices = async () => {
      try {
        const status = gracefulDegradation.getServiceStatus();
        const hasDegradedServices = status.some((s: any) => 
          s.status === 'degraded' || s.status === 'unavailable'
        );
        setIsServiceDegraded(hasDegradedServices);
        
        if (hasDegradedServices && options.enableToastNotifications) {
          toast({
            title: 'Service Notice',
            description: 'Some features may be experiencing temporary delays.',
            variant: 'default',
            duration: 5000,
          });
        }
      } catch (error) {
        console.error('Error checking service status:', error);
      }
    };

    checkServices();
  }, [options.enableToastNotifications, toast]);

  const executeWithErrorHandling = useCallback(async <T>(
    operation: () => Promise<T>,
    options: ErrorHandlerOptions = {}
  ): Promise<T> => {
    const mergedOptions = { ...this.options, ...options };
    let lastError: Error | null = null;
    let attempts = 0;

    const executeAttempt = async (): Promise<T> => {
      attempts++;
      
      try {
        setIsLoading(true);
        setError(null);

        // Check if service is degraded
        if (mergedOptions.enableGracefulDegradation) {
          const status = gracefulDegradation.getServiceStatus();
          const hasDegradedServices = status.some((s: any) => 
            s.status === 'degraded' || s.status === 'unavailable'
          );
          
          if (hasDegradedServices) {
            setIsServiceDegraded(true);
            if (mergedOptions.enableToastNotifications) {
              toast({
                title: 'Service Degraded',
                description: 'Some features may be slower than usual.',
                variant: 'secondary',
                duration: 3000,
              });
            }
          }
        }

        // Execute with circuit breaker protection
        if (mergedOptions.enableCircuitBreaker) {
          const protectedOperation = async () => {
            try {
              return await operation();
            } catch (error) {
              lastError = error instanceof Error ? error : new Error(String(error));
              throw lastError;
            }
          };

          return await protectedOperation();
        }

        return await operation();

      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
        setError(lastError);

        // Show error toast if enabled
        if (mergedOptions.enableToastNotifications) {
          toast({
            title: 'Operation Failed',
            description: lastError.message || mergedOptions.fallbackMessage,
            variant: 'destructive',
            duration: 5000,
          });
        }

        // If we have retries left, set up retry
        if (attempts < (mergedOptions.maxRetries || 3)) {
          setRetryOperation(() => executeAttempt);
          
          if (mergedOptions.enableToastNotifications) {
            toast({
              title: 'Retrying',
              description: `Attempt ${attempts + 1} of ${mergedOptions.maxRetries}`,
              variant: 'default',
              duration: 2000,
            });
          }
          
          // Wait before retrying with exponential backoff
          await new Promise(resolve => setTimeout(resolve, 1000 * Math.pow(2, attempts - 1)));
          return executeAttempt();
        }

        throw lastError;
      } finally {
        setIsLoading(false);
      }
    };

    return executeAttempt();
  }, [options, toast]);

  const retryOperationHandler = useCallback(async () => {
    if (retryOperation) {
      try {
        await retryOperation();
        setRetryOperation(null);
      } catch (error) {
        console.error('Retry failed:', error);
      }
    }
  }, [retryOperation]);

  const clearError = useCallback(() => {
    setError(null);
    setRetryOperation(null);
  }, []);

  const getServiceStatus = useCallback(() => {
    return gracefulDegradation.getServiceStatus();
  }, []);

  return {
    error,
    isLoading,
    executeWithErrorHandling,
    retryOperation: retryOperationHandler,
    clearError,
    isServiceDegraded,
    getServiceStatus
  };
}

// Specialized hooks for different API types
export function useDeepResearchHandler() {
  const { executeWithErrorHandling, ...rest } = useErrorHandler({
    enableCircuitBreaker: true,
    enableGracefulDegradation: true,
    fallbackMessage: 'Research service is temporarily unavailable. Using fallback analysis.',
  });

  const executeResearch = useCallback(async (query: string, config?: any) => {
    return executeWithErrorHandling(async () => {
      return circuitBreakers.deepResearch({ message: query, config });
    });
  }, [executeWithErrorHandling]);

  return { executeResearch, ...rest };
}

export function useImageGenerationHandler() {
  const { executeWithErrorHandling, ...rest } = useErrorHandler({
    enableCircuitBreaker: true,
    enableGracefulDegradation: true,
    fallbackMessage: 'Image generation is temporarily unavailable. Please try again later.',
  });

  const generateImage = useCallback(async (params: {
    prompt: string;
    provider?: string;
    model?: string;
    size?: string;
    asyncMode?: boolean;
  }) => {
    return executeWithErrorHandling(async () => {
      return circuitBreakers.imageGeneration(params);
    });
  }, [executeWithErrorHandling]);

  return { generateImage, ...rest };
}

export function useChatHandler() {
  const { executeWithErrorHandling, ...rest } = useErrorHandler({
    enableCircuitBreaker: true,
    enableGracefulDegradation: true,
    fallbackMessage: 'Chat service is temporarily unavailable. Please try again later.',
  });

  const sendMessage = useCallback(async (message: string, context?: any[]) => {
    return executeWithErrorHandling(async () => {
      return circuitBreakers.chat({ message, context });
    });
  }, [executeWithErrorHandling]);

  return { sendMessage, ...rest };
}

// Error boundary component for functional components
export function withErrorHandling<T extends object>(
  Component: React.ComponentType<T>,
  errorFallback?: React.ComponentType<{ error: Error; retry: () => void }>
) {
  return function WrappedComponent(props: T) {
    const { error, retryOperation, clearError } = useErrorHandler();
    const [hasError, setHasError] = useState(false);

    useEffect(() => {
      if (error) {
        setHasError(true);
      } else {
        setHasError(false);
      }
    }, [error]);

    if (hasError && errorFallback) {
      const ErrorFallbackComponent = errorFallback;
      return React.createElement(ErrorFallbackComponent, { 
        error: error as Error, 
        retry: retryOperation 
      });
    }

    if (hasError) {
      return React.createElement('div', { 
        className: 'min-h-screen flex items-center justify-center p-4' 
      }, [
        React.createElement('div', { 
          key: 'error-container',
          className: 'text-center max-w-md' 
        }, [
          React.createElement('h2', { 
            key: 'error-title',
            className: 'text-xl font-bold text-red-600 mb-4' 
          }, 'Something went wrong'),
          React.createElement('p', { 
            key: 'error-message',
            className: 'text-gray-600 mb-4' 
          }, error?.message || 'An unexpected error occurred'),
          React.createElement('div', { 
            key: 'error-actions',
            className: 'space-x-2' 
          }, [
            React.createElement('button', {
              key: 'retry-btn',
              onClick: retryOperation,
              className: 'px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700'
            }, 'Try Again'),
            React.createElement('button', {
              key: 'clear-btn',
              onClick: clearError,
              className: 'px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400'
            }, 'Clear Error')
          ])
        ])
      ]);
    }

    return React.createElement(Component, props);
  };
}