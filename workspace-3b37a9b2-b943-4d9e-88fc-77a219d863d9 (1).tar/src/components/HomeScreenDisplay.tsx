'use client';

import React, { useState, useEffect } from 'react';
import { X, Brain, CheckCircle, RefreshCw, Zap, Activity, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import DeepResearchDisplay from './DeepResearchDisplay';

interface HomeScreenDisplayProps {
  project: any;
  isVisible: boolean;
  onClose?: () => void;
  className?: string;
  aiAgentBrainData?: any;
  deepResearchData?: any;
}

export default function HomeScreenDisplay({ 
  project, 
  isVisible, 
  onClose, 
  className = '', 
  aiAgentBrainData,
  deepResearchData 
}: HomeScreenDisplayProps) {
  console.log('🎬 HomeScreenDisplay rendered with:', { 
    isVisible, 
    project: project?.structure?.name, 
    aiAgentBrainData,
    hasDeepResearch: !!deepResearchData 
  });
  
  const [liveUpdates, setLiveUpdates] = useState<string[]>([]);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [activeView, setActiveView] = useState<'project' | 'aiAgent' | 'deepResearch'>('project');

  // Auto-switch to deep research view if data is available
  useEffect(() => {
    if (deepResearchData && isVisible) {
      setActiveView('deepResearch');
    } else if (aiAgentBrainData && isVisible) {
      setActiveView('aiAgent');
    } else if (project && isVisible) {
      setActiveView('project');
    }
  }, [deepResearchData, aiAgentBrainData, project, isVisible]);

  // Simulate real-time updates for AI Agent Brain
  useEffect(() => {
    if (aiAgentBrainData && activeView === 'aiAgent') {
      const interval = setInterval(() => {
        const now = new Date();
        const update = `[${now.toISOString()}] 🔄 AI Agent Brain status update...`;
        setLiveUpdates(prev => [...prev.slice(-9), update]); // Keep last 10 updates
        setLastUpdate(now);
      }, 3000);

      return () => clearInterval(interval);
    }
  }, [aiAgentBrainData, activeView]);

  if (!isVisible) {
    return null;
  }

  console.log('✅ HomeScreenDisplay is visible and will render');

  // View selector tabs
  const renderViewSelector = () => {
    const views = [];
    
    if (project) {
      views.push({ id: 'project', label: 'Project', icon: CheckCircle });
    }
    if (aiAgentBrainData) {
      views.push({ id: 'aiAgent', label: 'AI Agent', icon: Brain });
    }
    if (deepResearchData) {
      views.push({ id: 'deepResearch', label: 'Deep Research', icon: Eye });
    }

    if (views.length <= 1) return null;

    return (
      <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg mb-4">
        {views.map((view) => {
          const Icon = view.icon;
          return (
            <Button
              key={view.id}
              variant={activeView === view.id ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveView(view.id as any)}
              className="flex-1"
            >
              <Icon className="w-4 h-4 mr-2" />
              {view.label}
            </Button>
          );
        })}
      </div>
    );
  };

  return (
    <div className={`w-full ${className}`}>
      {renderViewSelector()}
      
      {activeView === 'deepResearch' && deepResearchData ? (
        <DeepResearchDisplay
          researchData={deepResearchData}
          isVisible={true}
          onClose={onClose}
        />
      ) : activeView === 'aiAgent' && aiAgentBrainData ? (
        <Card className="border-2 border-purple-200 bg-purple-50">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-purple-900">
                <Brain className="w-5 h-5" />
                🧠 AI Agent Brain Results
              </CardTitle>
              {onClose && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onClose}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="w-4 h-4" />
                </Button>
              )}
            </div>
            {lastUpdate && (
              <div className="flex items-center gap-1 mt-2 text-xs text-gray-500">
                <RefreshCw className="w-3 h-3 animate-spin" />
                <span>Last update: {lastUpdate.toISOString()}</span>
              </div>
            )}
          </CardHeader>
          
          <CardContent className="p-6">
            <div className="space-y-6">
              {/* Header */}
              <div className="text-center space-y-2">
                <div className="flex items-center justify-center gap-3">
                  <Brain className="w-8 h-8 text-purple-600" />
                  <h3 className="text-2xl font-bold text-gray-900">🧠 AI Agent Brain Processing</h3>
                </div>
                <p className="text-gray-600">
                  Your request has been processed with intelligent task execution and error correction
                </p>
              </div>

              {/* Results Overview */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">{aiAgentBrainData.result?.todosCompleted || 0}</div>
                  <div className="text-sm text-gray-600">Tasks Completed</div>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{aiAgentBrainData.result?.errorsCorrected || 0}</div>
                  <div className="text-sm text-gray-600">Errors Corrected</div>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">{aiAgentBrainData.result?.iterations || 0}</div>
                  <div className="text-sm text-gray-600">Iterations</div>
                </div>
                <div className="text-center p-4 bg-yellow-50 rounded-lg">
                  <div className="text-2xl font-bold text-yellow-600">{aiAgentBrainData.result?.confidence || 0}%</div>
                  <div className="text-sm text-gray-600">Confidence</div>
                </div>
              </div>

              {/* Processing Details */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Zap className="w-4 h-4" />
                    Processing Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Status:</span>
                      <Badge variant={aiAgentBrainData.result?.status === 'completed' ? 'default' : 'secondary'}>
                        {aiAgentBrainData.result?.status || 'processing'}
                      </Badge>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Processing Time:</span>
                      <span className="font-medium">{aiAgentBrainData.result?.processingTime || 0}ms</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Strategy Used:</span>
                      <span className="font-medium">{aiAgentBrainData.result?.strategy || 'adaptive'}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Live Updates */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Activity className="w-4 h-4" />
                    Live Updates
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <ScrollArea className="h-32 w-full border rounded-md p-3">
                    {liveUpdates.length === 0 ? (
                      <div className="text-center text-gray-500 text-sm py-4">
                        Waiting for updates...
                      </div>
                    ) : (
                      liveUpdates.map((update, index) => (
                        <div key={index} className="text-xs font-mono text-gray-600">
                          {update}
                        </div>
                      ))
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* Final Output */}
              {aiAgentBrainData.result?.output && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Eye className="w-4 h-4" />
                      Final Output
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-2">
                      <p className="text-sm text-gray-700">{aiAgentBrainData.result.output.message}</p>
                      {aiAgentBrainData.result.output.results && (
                        <details className="text-xs">
                          <summary className="cursor-pointer text-blue-600 hover:text-blue-800">
                            View detailed results ({aiAgentBrainData.result.output.results.length} items)
                          </summary>
                          <div className="mt-2 p-2 bg-gray-50 rounded text-xs max-h-32 overflow-y-auto">
                            <pre>{JSON.stringify(aiAgentBrainData.result.output.results, null, 2)}</pre>
                          </div>
                        </details>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </CardContent>
        </Card>
      ) : project ? (
        // Show project execution display
        <Card className="border-2 border-green-200 bg-green-50">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-green-900">
                <CheckCircle className="w-5 h-5" />
                🎉 Executed Files Display
              </CardTitle>
              {onClose && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onClose}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="w-4 h-4" />
                </Button>
              )}
            </div>
            {project.executionStatus?.timestamp && (
              <div className="flex items-center gap-1 mt-2 text-xs text-gray-500">
                <RefreshCw className="w-3 h-3" />
                <span suppressHydrationWarning>
                  Executed at: {new Date(project.executionStatus.timestamp).toLocaleString()}
                </span>
              </div>
            )}
          </CardHeader>
          
          <CardContent className="p-6">
            <div className="space-y-6">
              {/* Header */}
              <div className="text-center space-y-2">
                <div className="flex items-center justify-center gap-3">
                  <CheckCircle className="w-8 h-8 text-green-600" />
                  <h3 className="text-2xl font-bold text-gray-900">🚀 Files Successfully Executed</h3>
                </div>
                <p className="text-gray-600">
                  Files from GitHub repository have been extracted and are now running on your home screen
                </p>
              </div>

              {/* Project Overview */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Zap className="w-4 h-4" />
                    Project Overview
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-3">
                    <div className="text-sm">
                      <span className="font-medium text-gray-600">Name:</span>
                      <span className="ml-2 font-medium">{project.structure?.name}</span>
                    </div>
                    <div className="text-sm">
                      <span className="font-medium text-gray-600">Description:</span>
                      <span className="ml-2">{project.structure?.description}</span>
                    </div>
                    <div className="text-sm">
                      <span className="font-medium text-gray-600">Status:</span>
                      <Badge variant="default" className="ml-2">
                        {project.executionStatus?.status || 'completed'}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Features */}
              {project.structure?.features && project.structure.features.length > 0 && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Activity className="w-4 h-4" />
                      Features
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="flex flex-wrap gap-2">
                      {project.structure.features.map((feature: string, index: number) => (
                        <Badge key={index} variant="outline" className="text-xs bg-green-100 text-green-700 border-green-200">
                          {feature}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Files */}
              {project.files && project.files.length > 0 && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Eye className="w-4 h-4" />
                      Executed Files ({project.files.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <ScrollArea className="h-32 w-full border rounded-md p-3">
                      {project.files.map((file: any, index: number) => (
                        <div key={index} className="text-xs mb-2 p-2 bg-white rounded border">
                          <div className="font-medium text-gray-700">{file.path}</div>
                          <div className="text-gray-500 mt-1">{file.content}</div>
                        </div>
                      ))}
                    </ScrollArea>
                  </CardContent>
                </Card>
              )}

              {/* Setup Instructions */}
              {project.setupInstructions && project.setupInstructions.length > 0 && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <RefreshCw className="w-4 h-4" />
                      Setup Instructions
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-1">
                      {project.setupInstructions.map((instruction: string, index: number) => (
                        <div key={index} className="text-xs text-gray-700">
                          {instruction}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Execution Message */}
              {project.executionStatus?.message && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Brain className="w-4 h-4" />
                      Execution Status
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <p className="text-sm text-gray-700">{project.executionStatus.message}</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </CardContent>
        </Card>
      ) : (
        // Empty - no data to display
        null
      )}
    </div>
  );
}