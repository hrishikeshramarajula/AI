// 📊 Live Progress Display - Shows enhanced AI brain progress on home screen
// This component provides a compact view of the AI brain's working progress

'use client';

import React, { useState, useEffect } from 'react';
import {
  Brain,
  Zap,
  Target,
  Settings,
  BarChart3,
  Shield,
  BookOpen,
  Activity,
  Lightbulb,
  CheckCircle,
  XCircle,
  Clock,
  Users,
  Cpu,
  Network,
  Database,
  FileText,
  MessageSquare,
  TrendingUp,
  AlertTriangle,
  Info,
  X,
  Play,
  Pause,
  RotateCcw,
  ChevronRight,
  ChevronDown,
  Plus,
  Minus,
  Edit3,
  Trash2,
  Eye,
  EyeOff,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';

interface Todo {
  id: string;
  content: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  priority: 'high' | 'medium' | 'low';
  estimatedTime: number;
  dependencies: string[];
  result?: any;
  error?: string;
  reasoning: string[];
  startTime?: Date;
  endTime?: Date;
  category?: 'analysis' | 'development' | 'testing' | 'validation' | 'correction' | 'general';
}

interface ExecutionLog {
  timestamp: Date;
  step: string;
  status: 'started' | 'completed' | 'failed' | 'corrected';
  details: any;
}

interface LiveProgressDisplayProps {
  data: any;
  isVisible: boolean;
  onToggleVisibility: () => void;
  onShowDetails: () => void;
  onControlAction: (action: 'play' | 'pause' | 'reset') => void;
  compact?: boolean;
}

export default function LiveProgressDisplay({ 
  data, 
  isVisible, 
  onToggleVisibility, 
  onShowDetails, 
  onControlAction,
  compact = false 
}: LiveProgressDisplayProps) {
  const [isExpanded, setIsExpanded] = useState(!compact);
  const [isLiveMode, setIsLiveMode] = useState(true);

  if (!isVisible || !data) return null;

  const {
    analysis,
    executionLog = [],
    todos = [],
    progress = { total: 0, completed: 0, percentage: 0 },
    reasoning = [],
    errors = [],
    corrections = [],
    learnings = [],
    finalOutput = ''
  } = data;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600';
      case 'in_progress': return 'text-blue-600';
      case 'failed': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4" />;
      case 'in_progress': return <div className="w-4 h-4 bg-blue-600 rounded-full animate-pulse" />;
      case 'failed': return <XCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getLatestExecutionLog = () => {
    return executionLog.length > 0 ? executionLog[executionLog.length - 1] : null;
  };

  const getActiveTodos = () => {
    return todos.filter(todo => todo.status !== 'completed');
  };

  const getLatestReasoning = () => {
    return reasoning.length > 0 ? reasoning[reasoning.length - 1] : null;
  };

  if (compact) {
    return (
      <div className="fixed bottom-4 right-4 z-40">
        <Card className="w-80 shadow-lg">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm flex items-center space-x-2">
                <Brain className="w-4 h-4 text-purple-600" />
                <span>🧠 Enhanced AI Brain</span>
                <Badge variant={isLiveMode ? "default" : "secondary"} className="text-xs">
                  {isLiveMode ? "Live" : "Paused"}
                </Badge>
              </CardTitle>
              <div className="flex items-center space-x-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsLiveMode(!isLiveMode)}
                  className="w-6 h-6 p-0"
                >
                  {isLiveMode ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onToggleVisibility}
                  className="w-6 h-6 p-0"
                >
                  <X className="w-3 h-3" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            {/* Progress */}
            {progress.total > 0 && (
              <div className="mb-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-medium">Progress</span>
                  <span className="text-xs text-gray-600">
                    {progress.completed}/{progress.total} ({progress.percentage}%)
                  </span>
                </div>
                <Progress value={progress.percentage} className="w-full h-2" />
              </div>
            )}

            {/* Latest Status */}
            {getLatestExecutionLog() && (
              <div className="mb-3">
                <div className="flex items-center space-x-2 mb-1">
                  {getStatusIcon(getLatestExecutionLog().status)}
                  <span className="text-xs font-medium truncate">
                    {getLatestExecutionLog().step}
                  </span>
                </div>
                <Badge variant="outline" className="text-xs">
                  {getLatestExecutionLog().status}
                </Badge>
              </div>
            )}

            {/* Latest Reasoning */}
            {getLatestReasoning() && (
              <div className="mb-3">
                <div className="text-xs text-gray-600 bg-gray-50 p-2 rounded">
                  {getLatestReasoning()}
                </div>
              </div>
            )}

            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-2 mb-3">
              <div className="text-center">
                <div className="text-lg font-bold text-blue-600">{getActiveTodos().length}</div>
                <div className="text-xs text-gray-600">Active</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-green-600">{progress.completed}</div>
                <div className="text-xs text-gray-600">Done</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-yellow-600">{errors.length}</div>
                <div className="text-xs text-gray-600">Errors</div>
              </div>
            </div>

            {/* Control Buttons */}
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={onShowDetails}
                className="flex-1 text-xs"
              >
                <Eye className="w-3 h-3 mr-1" />
                Details
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsExpanded(!isExpanded)}
                className="w-8 h-8 p-0"
              >
                {isExpanded ? <Minimize2 className="w-3 h-3" /> : <Maximize2 className="w-3 h-3" />}
              </Button>
            </div>

            {/* Expanded Content */}
            {isExpanded && (
              <div className="mt-3 space-y-3">
                <Separator />
                
                {/* Active Todos */}
                {getActiveTodos().length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold mb-2">Active Tasks</h4>
                    <div className="space-y-1">
                      {getActiveTodos().slice(0, 3).map((todo) => (
                        <div key={todo.id} className="flex items-center space-x-2">
                          {getStatusIcon(todo.status)}
                          <span className="text-xs truncate">{todo.content}</span>
                          <Badge className={getPriorityColor(todo.priority)} variant="secondary">
                            {todo.priority}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Recent Execution Logs */}
                {executionLog.length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold mb-2">Recent Activity</h4>
                    <div className="space-y-1 max-h-20 overflow-y-auto">
                      {executionLog.slice(-3).map((log, index) => (
                        <div key={index} className="flex items-center space-x-2 text-xs">
                          {getStatusIcon(log.status)}
                          <span className="truncate">{log.step}</span>
                          <span className="text-gray-500 text-xs">
                            {log.timestamp.toISOString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Errors */}
                {errors.length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold mb-2 text-red-600">Errors</h4>
                    <div className="space-y-1">
                      {errors.slice(0, 2).map((error, index) => (
                        <div key={index} className="text-xs text-red-600 bg-red-50 p-1 rounded">
                          {error}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center space-x-3">
            <Brain className="w-6 h-6 text-purple-600" />
            <h2 className="text-xl font-bold">🧠 Enhanced AI Brain - Live Progress</h2>
            <Badge variant={isLiveMode ? "default" : "secondary"}>
              {isLiveMode ? "Live Mode" : "Paused"}
            </Badge>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsLiveMode(!isLiveMode)}
            >
              {isLiveMode ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
              {isLiveMode ? 'Pause' : 'Resume'}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={onToggleVisibility}
            >
              <X className="w-4 h-4 mr-2" />
              Close
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden">
          <ScrollArea className="h-full p-6">
            <div className="space-y-6">
              {/* Progress Overview */}
              {progress.total > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <BarChart3 className="w-5 h-5" />
                      <span>Progress Overview</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Overall Progress</span>
                        <span className="text-sm text-gray-600">
                          {progress.completed}/{progress.total} ({progress.percentage}%)
                        </span>
                      </div>
                      <Progress value={progress.percentage} className="w-full" />
                      
                      <div className="grid grid-cols-4 gap-4 mt-4">
                        <div className="text-center">
                          <div className="text-2xl font-bold text-blue-600">{todos.length}</div>
                          <div className="text-sm text-gray-600">Total Tasks</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-green-600">{progress.completed}</div>
                          <div className="text-sm text-gray-600">Completed</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-yellow-600">{errors.length}</div>
                          <div className="text-sm text-gray-600">Errors</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-purple-600">{corrections.length}</div>
                          <div className="text-sm text-gray-600">Corrections</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Current Status */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Latest Activity */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Activity className="w-5 h-5" />
                      <span>Latest Activity</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {getLatestExecutionLog() ? (
                      <div className="space-y-3">
                        <div className="flex items-center space-x-2">
                          {getStatusIcon(getLatestExecutionLog().status)}
                          <span className="font-medium">{getLatestExecutionLog().step}</span>
                          <Badge variant="outline">{getLatestExecutionLog().status}</Badge>
                        </div>
                        <div className="text-sm text-gray-600">
                          Time: {getLatestExecutionLog().timestamp.toISOString()}
                        </div>
                        {Object.keys(getLatestExecutionLog().details).length > 0 && (
                          <details className="mt-2">
                            <summary className="text-xs cursor-pointer hover:underline">
                              View details
                            </summary>
                            <pre className="text-xs mt-1 p-2 bg-gray-50 rounded overflow-x-auto">
                              {JSON.stringify(getLatestExecutionLog().details, null, 2)}
                            </pre>
                          </details>
                        )}
                      </div>
                    ) : (
                      <div className="text-center text-gray-500 py-4">
                        No activity yet
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Current Reasoning */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Brain className="w-5 h-5" />
                      <span>Current Reasoning</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {getLatestReasoning() ? (
                      <div className="space-y-2">
                        <div className="text-sm bg-blue-50 p-3 rounded">
                          {getLatestReasoning()}
                        </div>
                        <div className="text-xs text-gray-500">
                          Total reasoning steps: {reasoning.length}
                        </div>
                      </div>
                    ) : (
                      <div className="text-center text-gray-500 py-4">
                        No reasoning available
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Active Tasks */}
              {getActiveTodos().length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Target className="w-5 h-5" />
                      <span>Active Tasks ({getActiveTodos().length})</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {getActiveTodos().map((todo) => (
                        <div key={todo.id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                          <div className="flex items-center space-x-3 flex-1">
                            {getStatusIcon(todo.status)}
                            <div className="flex-1">
                              <div className="font-medium text-sm">{todo.content}</div>
                              <div className="text-xs text-gray-600">
                                Est. time: {todo.estimatedTime}s
                              </div>
                            </div>
                            <Badge className={getPriorityColor(todo.priority)} variant="secondary">
                              {todo.priority}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Errors and Corrections */}
              {(errors.length > 0 || corrections.length > 0) && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {errors.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center space-x-2">
                          <AlertTriangle className="w-5 h-5 text-red-600" />
                          <span>Errors ({errors.length})</span>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2 max-h-40 overflow-y-auto">
                          {errors.map((error, index) => (
                            <div key={index} className="flex items-start space-x-2">
                              <XCircle className="w-4 h-4 mt-0.5 text-red-600 flex-shrink-0" />
                              <span className="text-sm text-red-700">{error}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {corrections.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center space-x-2">
                          <RotateCcw className="w-5 h-5 text-blue-600" />
                          <span>Corrections ({corrections.length})</span>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2 max-h-40 overflow-y-auto">
                          {corrections.map((correction, index) => (
                            <div key={index} className="flex items-start space-x-2">
                              <CheckCircle className="w-4 h-4 mt-0.5 text-blue-600 flex-shrink-0" />
                              <span className="text-sm text-blue-700">{correction}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}

              {/* Final Output */}
              {finalOutput && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <FileText className="w-5 h-5" />
                      <span>Final Output</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="p-4 bg-green-50 rounded-lg">
                      <pre className="whitespace-pre-wrap text-sm text-green-800">
                        {finalOutput}
                      </pre>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Control Actions */}
              <div className="flex justify-center space-x-4">
                <Button
                  variant="outline"
                  onClick={() => onControlAction('play')}
                  disabled={isLiveMode}
                >
                  <Play className="w-4 h-4 mr-2" />
                  Resume
                </Button>
                <Button
                  variant="outline"
                  onClick={() => onControlAction('pause')}
                  disabled={!isLiveMode}
                >
                  <Pause className="w-4 h-4 mr-2" />
                  Pause
                </Button>
                <Button
                  variant="outline"
                  onClick={() => onControlAction('reset')}
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Reset
                </Button>
                <Button
                  variant="default"
                  onClick={onShowDetails}
                >
                  <Eye className="w-4 h-4 mr-2" />
                  Full Details
                </Button>
              </div>
            </div>
          </ScrollArea>
        </div>
      </div>
    </div>
  );
}