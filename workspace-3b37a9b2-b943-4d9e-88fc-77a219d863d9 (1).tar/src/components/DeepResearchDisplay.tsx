'use client';

import React, { useState, useEffect } from 'react';
import { 
  Brain, 
  Search, 
  CheckCircle, 
  AlertCircle, 
  RefreshCw, 
  Zap, 
  Activity, 
  Eye, 
  Clock,
  TrendingUp,
  FileText,
  Target,
  Award,
  BookOpen,
  BarChart3,
  Globe,
  Database,
  Layers,
  Filter
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import MarkdownRenderer from './MarkdownRenderer';

interface DeepResearchDisplayProps {
  researchData: {
    query: string;
    response: string;
    sources: any[];
    _metadata: {
      processingTime: number;
      confidence: number;
      sourceCount: number;
      averageCredibility: number;
      contentQuality: string;
      reportDepth: string;
      citationCount: number;
      wordCount: number;
      researchMetrics: any;
      researchMode: string;
      timestamp: string;
    };
  };
  isVisible: boolean;
  onClose?: () => void;
  className?: string;
}

export default function DeepResearchDisplay({ 
  researchData, 
  isVisible, 
  onClose, 
  className = '' 
}: DeepResearchDisplayProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'sources' | 'metrics'>('overview');
  const [isExpanded, setIsExpanded] = useState(false);
  const [readingProgress, setReadingProgress] = useState(0);

  useEffect(() => {
    if (isVisible && researchData?.response) {
      // Simulate reading progress
      const interval = setInterval(() => {
        setReadingProgress(prev => {
          const newProgress = prev + Math.random() * 15;
          return newProgress >= 100 ? 100 : newProgress;
        });
      }, 2000);

      return () => clearInterval(interval);
    }
  }, [isVisible, researchData?.response]);

  if (!isVisible || !researchData) {
    return null;
  }

  const {
    query,
    response,
    sources,
    _metadata
  } = researchData;

  const confidencePercentage = Math.round(_metadata.confidence * 100);
  const credibilityPercentage = Math.round(_metadata.averageCredibility * 100);

  return (
    <div className={`w-full ${className}`}>
      <Card className="border-2 border-blue-200 bg-blue-50 shadow-lg">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-3 text-blue-900">
              <div className="flex items-center gap-2">
                <Brain className="w-6 h-6 text-blue-600" />
                <Search className="w-5 h-5 text-blue-500" />
              </div>
              🔬 Enhanced Deep Research Results
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge 
                variant={confidencePercentage >= 80 ? "default" : confidencePercentage >= 60 ? "secondary" : "destructive"}
                className="text-xs"
              >
                {confidencePercentage}% Confidence
              </Badge>
              {onClose && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onClose}
                  className="text-gray-500 hover:text-gray-700 h-8 w-8 p-0"
                >
                  ×
                </Button>
              )}
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="text-sm font-medium text-gray-700">
              Research Query: "{query}"
            </div>
            <div className="flex items-center gap-4 text-xs text-gray-500">
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>Processed in {_metadata.processingTime}ms</span>
              </div>
              <div className="flex items-center gap-1">
                <Activity className="w-3 h-3" />
                <span>{_metadata.timestamp}</span>
              </div>
              <div className="flex items-center gap-1">
                <RefreshCw className="w-3 h-3" />
                <span>{_metadata.researchMode}</span>
              </div>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="p-6">
          <div className="space-y-6">
            {/* Key Metrics Overview */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-white rounded-lg border border-blue-100">
                <div className="text-2xl font-bold text-blue-600">{_metadata.sourceCount}</div>
                <div className="text-sm text-gray-600">Sources</div>
                <Database className="w-4 h-4 mx-auto mt-1 text-blue-400" />
              </div>
              <div className="text-center p-4 bg-white rounded-lg border border-blue-100">
                <div className="text-2xl font-bold text-green-600">{credibilityPercentage}%</div>
                <div className="text-sm text-gray-600">Avg Credibility</div>
                <Award className="w-4 h-4 mx-auto mt-1 text-green-400" />
              </div>
              <div className="text-center p-4 bg-white rounded-lg border border-blue-100">
                <div className="text-2xl font-bold text-purple-600">{_metadata.wordCount}</div>
                <div className="text-sm text-gray-600">Words</div>
                <FileText className="w-4 h-4 mx-auto mt-1 text-purple-400" />
              </div>
              <div className="text-center p-4 bg-white rounded-lg border border-blue-100">
                <div className="text-2xl font-bold text-orange-600">{_metadata.citationCount}</div>
                <div className="text-sm text-gray-600">Citations</div>
                <Target className="w-4 h-4 mx-auto mt-1 text-orange-400" />
              </div>
            </div>

            {/* Research Quality Indicators */}
            <Card className="border border-green-200 bg-green-50">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2 text-green-800">
                  <CheckCircle className="w-4 h-4" />
                  Research Quality Assessment
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Content Quality</span>
                      <Badge variant="outline" className="text-xs bg-green-100 text-green-700">
                        {_metadata.contentQuality}
                      </Badge>
                    </div>
                    <Progress value={confidencePercentage} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Report Depth</span>
                      <Badge variant="outline" className="text-xs bg-blue-100 text-blue-700">
                        {_metadata.reportDepth}
                      </Badge>
                    </div>
                    <Progress value={Math.min(credibilityPercentage, 100)} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tabs for different views */}
            <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg">
              <Button
                variant={activeTab === 'overview' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setActiveTab('overview')}
                className="flex-1"
              >
                <Eye className="w-4 h-4 mr-2" />
                Overview
              </Button>
              <Button
                variant={activeTab === 'sources' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setActiveTab('sources')}
                className="flex-1"
              >
                <Database className="w-4 h-4 mr-2" />
                Sources ({_metadata.sourceCount})
              </Button>
              <Button
                variant={activeTab === 'metrics' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setActiveTab('metrics')}
                className="flex-1"
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                Metrics
              </Button>
            </div>

            {/* Tab Content */}
            {activeTab === 'overview' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-gray-800">Research Report</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setIsExpanded(!isExpanded)}
                    className="text-xs"
                  >
                    {isExpanded ? 'Collapse' : 'Expand'}
                  </Button>
                </div>
                
                <div className="bg-white rounded-lg border p-4">
                  <ScrollArea className={`h-${isExpanded ? '96' : '64'} w-full`}>
                    <div className="prose prose-sm max-w-none">
                      <MarkdownRenderer content={response} />
                    </div>
                  </ScrollArea>
                </div>
                
                {/* Reading Progress */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Reading Progress</span>
                    <span>{Math.round(readingProgress)}%</span>
                  </div>
                  <Progress value={readingProgress} className="h-2" />
                </div>
              </div>
            )}

            {activeTab === 'sources' && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-800">Research Sources</h3>
                <ScrollArea className="h-96 w-full">
                  <div className="space-y-3">
                    {sources.map((source, index) => (
                      <Card key={index} className="border border-gray-200">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex-1">
                              <h4 className="font-medium text-sm text-gray-800">{source.title}</h4>
                              <div className="flex items-center gap-2 mt-1">
                                <Badge variant="outline" className="text-xs">
                                  {source.source}
                                </Badge>
                                <Badge variant="outline" className="text-xs">
                                  {source.type}
                                </Badge>
                                {source.publishedDate && (
                                  <span className="text-xs text-gray-500">
                                    {source.publishedDate}
                                  </span>
                                )}
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-xs font-medium text-green-600">
                                {Math.round((source.credibility || 0.7) * 100)}%
                              </div>
                              <div className="text-xs text-gray-500">Credibility</div>
                            </div>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">{source.content}</p>
                          <a 
                            href={source.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-xs text-blue-600 hover:underline"
                          >
                            View Source →
                          </a>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            )}

            {activeTab === 'metrics' && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-800">Research Metrics</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="border border-purple-200">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm flex items-center gap-2 text-purple-800">
                        <TrendingUp className="w-4 h-4" />
                        Performance Metrics
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-0 space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Processing Time</span>
                        <span className="font-medium">{_metadata.processingTime}ms</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Content Length</span>
                        <span className="font-medium">{response.length} chars</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Word Count</span>
                        <span className="font-medium">{_metadata.wordCount}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Reading Time</span>
                        <span className="font-medium">~{Math.ceil(_metadata.wordCount / 200)} min</span>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border border-orange-200">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm flex items-center gap-2 text-orange-800">
                        <Layers className="w-4 h-4" />
                        Research Process
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-0 space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Query Expansion</span>
                        <Badge variant={_metadata.researchMetrics.queryExpansionUsed ? "default" : "secondary"} className="text-xs">
                          {_metadata.researchMetrics.queryExpansionUsed ? "Used" : "Not Used"}
                        </Badge>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Web Search</span>
                        <Badge variant={_metadata.researchMetrics.webSearchPerformed ? "default" : "secondary"} className="text-xs">
                          {_metadata.researchMetrics.webSearchPerformed ? "Performed" : "Skipped"}
                        </Badge>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Content Processing</span>
                        <Badge variant={_metadata.researchMetrics.contentProcessing ? "default" : "secondary"} className="text-xs">
                          {_metadata.researchMetrics.contentProcessing ? "Complete" : "Partial"}
                        </Badge>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Fact Checking</span>
                        <Badge variant={_metadata.researchMetrics.factChecking ? "default" : "secondary"} className="text-xs">
                          {_metadata.researchMetrics.factChecking ? "Applied" : "Skipped"}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}

            {/* Status Alert */}
            <Alert className="border-blue-200 bg-blue-50">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-800">
                <strong>Enhanced Deep Research Complete</strong> - This professional-grade research report 
                was generated using advanced AI-powered web search, multi-source synthesis, and 
                comprehensive analysis. The content includes real-time information and credible sources 
                with proper citations.
              </AlertDescription>
            </Alert>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}