import { NextRequest } from 'next/server';
import { realDeepResearchEngine } from '@/lib/realDeepResearch';

// REAL Deep Research Streaming API
// Uses actual web search and real-time information retrieval with streaming response

export async function POST(request: NextRequest) {
  const encoder = new TextEncoder();
  const stream = new TransformStream();
  const writer = stream.writable.getWriter();
  let streamClosed = false;
  let isProcessing = true;
  
  // Timeout for streaming (3 minutes total for real research)
  const STREAM_TIMEOUT = 180000; // 3 minutes for real web search + synthesis
  let timeoutId: NodeJS.Timeout;
  
  // Track start time
  const startTime = Date.now();

  const closeStream = async () => {
    if (!streamClosed) {
      try {
        if (timeoutId) clearTimeout(timeoutId);
        isProcessing = false;
        await writer.close();
        streamClosed = true;
        console.log('✅ REAL deep research stream closed successfully');
      } catch (error) {
        console.warn('⚠️ REAL research stream already closed or error closing:', error);
        streamClosed = true;
        isProcessing = false;
      }
    }
  };

  const writeToStream = async (data: string) => {
    if (!streamClosed && isProcessing) {
      try {
        await writer.write(encoder.encode(data));
      } catch (error) {
        console.warn('⚠️ Error writing to REAL research stream:', error);
        if (error.message.includes('ResponseAborted') || error.message.includes('closed') || error.message.includes('aborted')) {
          console.log('🔄 Connection aborted, closing stream gracefully...');
          streamClosed = true;
          isProcessing = false;
          return;
        }
      }
    }
  };

  // Set up timeout
  timeoutId = setTimeout(() => {
    console.warn('⚠️ REAL deep research stream timeout reached, closing connection...');
    closeStream();
  }, STREAM_TIMEOUT);

  try {
    console.log('🚀 REAL Deep Research Streaming API: Processing request...');
    
    const body = await request.json();
    const message: string = body?.message || '';
    const { 
      config = {},
      model = 'auto',
      researchId = `research_${Date.now()}`
    } = body;

    if (!message || !message.trim()) {
      await writeToStream(`data: ${JSON.stringify({ type: 'error', error: 'Research query is required' })}\n\n`);
      await closeStream();
      return new Response(stream.readable, {
        headers: {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive',
        },
      });
    }

    console.log('🚀 REAL Deep Research Streaming Query:', message.substring(0, 100) + (message.length > 100 ? '...' : ''));

    // Start streaming response - REAL DEEP RESEARCH
    (async () => {
      try {
        // Send initial status
        if (isProcessing) {
          await writeToStream(`data: ${JSON.stringify({ 
            type: 'start', 
            message: '🔬 Starting REAL deep research with web search and information retrieval...',
            researchId 
          })}\n\n`);
        }

        console.log('🧠 Starting REAL deep research with actual web search...');
        
        // Send progress updates
        const progressStages = [
          { stage: 'Query Analysis', progress: 10 },
          { stage: 'Web Search', progress: 25 },
          { stage: 'Source Processing', progress: 50 },
          { stage: 'Information Synthesis', progress: 75 },
          { stage: 'Fact Checking', progress: 90 },
          { stage: 'Finalization', progress: 100 }
        ];

        // Send progress updates
        for (const progressStage of progressStages) {
          if (!isProcessing) break;
          
          await writeToStream(`data: ${JSON.stringify({ 
            type: 'progress',
            stage: progressStage.stage,
            progress: progressStage.progress,
            message: `🔍 ${progressStage.stage}...`,
            researchId 
          })}\n\n`);
          
          // Simulate processing time for each stage
          await new Promise(resolve => setTimeout(resolve, 1000));
        }

        // Perform ACTUAL deep research with web search
        console.log('🌐 Performing REAL web search and synthesis...');
        
        let researchResult;
        try {
          const researchOptions = {
            maxResults: config.maxSources || 8,
            includeNews: config.includeWebSearch !== false,
            includeAcademic: config.includeKnowledgeGraph !== false,
            depth: config.researchDepth || 'comprehensive'
          };

          researchResult = await realDeepResearchEngine.performRealResearch(message, researchOptions);
          
          console.log('✅ REAL deep research completed successfully');
          console.log(`📝 Synthesized content length: ${researchResult.synthesizedContent.length} characters`);
          console.log(`🌐 Found ${researchResult.searchResults.length} search results`);
          console.log(`📊 Used ${researchResult.sources.length} credible sources`);

        } catch (researchError) {
          console.error('❌ REAL deep research failed:', researchError);
          throw researchError;
        }

        // Send research metadata
        if (isProcessing) {
          await writeToStream(`data: ${JSON.stringify({ 
            type: 'metadata',
            processingTime: researchResult.processingTime,
            sourceCount: researchResult.sources.length,
            averageCredibility: RealDeepResearchEngine.calculateSafeAverageCredibility(researchResult.sources),
            confidence: researchResult.confidence,
            researchStages: researchResult.researchStages,
            researchId 
          })}\n\n`);
        }

        // Send synthesized content in chunks for better UX
        if (isProcessing && researchResult.synthesizedContent) {
          const content = researchResult.synthesizedContent;
          const chunkSize = 1000; // 1000 characters per chunk
          
          for (let i = 0; i < content.length; i += chunkSize) {
            if (!isProcessing) break;
            
            const chunk = content.substring(i, i + chunkSize);
            const chunkNumber = Math.floor(i / chunkSize) + 1;
            const totalChunks = Math.ceil(content.length / chunkSize);
            
            await writeToStream(`data: ${JSON.stringify({ 
              type: 'content',
              chunk: chunk,
              chunkNumber: chunkNumber,
              totalChunks: totalChunks,
              researchId 
            })}\n\n`);
            
            // Small delay between chunks for streaming effect
            await new Promise(resolve => setTimeout(resolve, 100));
          }
        }

        // Send source information
        if (isProcessing && researchResult.sources.length > 0) {
          await writeToStream(`data: ${JSON.stringify({ 
            type: 'sources',
            sources: researchResult.sources.map(source => ({
              title: source.title,
              url: source.url,
              source: source.source,
              credibility: source.credibility,
              type: source.type
            })),
            researchId 
          })}\n\n`);
        }

        console.log('✅ REAL deep research streaming completed successfully');
        
        // Send completion signal
        if (isProcessing) {
          const completionData = {
            type: 'complete',
            confidence: researchResult.confidence,
            intent: 'real_web_search_deep_research',
            processingTime: researchResult.processingTime,
            metadata: {
              model: model,
              query: researchResult.query,
              researchMethod: 'real-web-search',
              researchDepth: 'comprehensive',
              sourceCount: researchResult.sources.length,
              averageCredibility: RealDeepResearchEngine.calculateSafeAverageCredibility(researchResult.sources),
              researchStages: researchResult.researchStages,
              researchId
            }
          };
          
          await writeToStream(`data: ${JSON.stringify(completionData)}\n\n`);
        }
        
        // Ensure the stream is properly closed after completion
        console.log('✅ REAL deep research completed successfully, closing stream...');
        await closeStream();
        return;
        
      } catch (error) {
        console.error('❌ REAL deep research streaming error:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        
        // Send error information
        if (isProcessing) {
          await writeToStream(`data: ${JSON.stringify({ 
            type: 'error', 
            error: errorMessage,
            researchId 
          })}\n\n`);
        }
        
        // Send completion signal with error info
        if (isProcessing) {
          const errorCompletionData = {
            type: 'complete',
            confidence: 0,
            intent: 'error',
            processingTime: Date.now() - startTime,
            metadata: {
              error: errorMessage,
              model: model,
              researchMethod: 'real-web-search',
              researchId
            }
          };
          
          await writeToStream(`data: ${JSON.stringify(errorCompletionData)}\n\n`);
        }
        
      } finally {
        console.log('🔄 REAL deep research streaming process ended, ensuring stream is closed...');
        await closeStream();
      }
    })();

    return new Response(stream.readable, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });

  } catch (error) {
    console.error('❌ Outer REAL deep research streaming error:', error);
    isProcessing = false;
    
    try {
      await closeStream();
    } catch (closeError) {
      console.error('❌ Error closing REAL research stream in outer catch:', closeError);
    }
    
    return new Response(stream.readable, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });
  }
}