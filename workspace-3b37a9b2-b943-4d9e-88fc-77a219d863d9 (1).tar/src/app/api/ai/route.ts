import { NextRequest } from 'next/server';
import { performWebSearch } from '@/lib/search';
import { AIMessage, AIResponse } from '@/types/ai';
import { 
  createSuccessResponse, 
  createErrorResponse, 
  withErrorHandling,
  validateRequiredFields 
} from '@/lib/apiUtils';
import { safeZAIChatCompletion } from '@/lib/zaiHelper';

async function callRealAI(messages: AIMessage[], model: string, searchType: string) {
  console.log('🤖 Calling ZAI SDK for AI processing...');
  console.log('📋 Model:', model);
  console.log('🎯 Search Type:', searchType);
  
  try {
    const completion = await safeZAIChatCompletion(messages, {
      model: model,
      temperature: 0.7,
      max_tokens: 2000
    });
    
    const content = completion.choices?.[0]?.message?.content || 'No response generated';
    console.log('✅ ZAI SDK call successful');
    console.log('📝 Response length:', content.length, 'characters');
    
    return content;
    
  } catch (error) {
    console.error('❌ ZAI SDK call failed:', error);
    throw error;
  }
}

export async function POST(request: NextRequest) {
  return withErrorHandling(async () => {
    try {
      const body = await request.json();
      
      // Validate required fields
      const validation = validateRequiredFields(body, ['message']);
      if (!validation.valid) {
        return createErrorResponse(validation.error!, 400);
      }

      const { message, model, searchType = 'chat' } = body;
      
      console.log(`Processing request: ${message} with model: ${model} and type: ${searchType}`);

      let response = '';
      let searchResults: any[] = [];
      let imageData: string | undefined;
      let imagePrompt: string | undefined;
      let usedProvider = '';

      // Handle different search types
      switch (searchType) {
        case 'search':
          // Perform web search first
          try {
            searchResults = await performWebSearch(message);
            console.log(`Web search completed with ${searchResults.length} results`);
          } catch (searchError) {
            console.warn('Web search failed, continuing without search results:', searchError);
            searchResults = [];
          }
          
          const searchContext = searchResults.map(result => 
            `Source: ${result.name}\nContent: ${result.snippet}`
          ).join('\n\n');

          const searchMessages: AIMessage[] = [
            {
              role: 'system',
              content: `You are an AI assistant that provides accurate, comprehensive answers based on search results and your knowledge. Use the search results to enhance your response.\n\nSearch Results:\n${searchContext}`
            },
            {
              role: 'user',
              content: message
            }
          ];

          try {
            response = await callRealAI(searchMessages, model, searchType);
            usedProvider = 'Real AI';
          } catch (providerError) {
            console.error('Real AI failed for search:', providerError);
            response = `🔍 Web Search Mode

I apologize, but I'm experiencing technical difficulties with search services. However, I can still help you with: "${message}"

Search Results Found: ${searchResults.length} sources

What I can provide:
• Summary of available search results
• General knowledge on the topic
• Guidance on where to find more information
• Basic explanations and concepts

Available Search Results:
${searchResults.slice(0, 3).map((result, index) => `${index + 1}. ${result.name} - ${result.snippet.substring(0, 100)}...`).join('\n')}

Technical Status: The AI services are experiencing issues. Please try again in a moment for enhanced search capabilities.`;
            usedProvider = 'partial';
          }
          break;

        case 'image':
          imagePrompt = message;
          
          try {
            // Actually call the image generation API
            console.log('🎨 Calling image generation API for:', message);
            
            const imageResponse = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000'}/api/generate-image`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                prompt: message,
                provider: 'auto',
                model: 'auto',
                size: '1024x1024',
                optimize: true,
                saveToFile: false
              }),
            });
            
            if (!imageResponse.ok) {
              const errorText = await imageResponse.text();
              console.error('Image generation API failed:', errorText);
              throw new Error(`Image generation failed: ${errorText}`);
            }
            
            const imageResult = await imageResponse.json();
            console.log('✅ Image generated successfully:', imageResult);
            
            // Check if we have actual image data
            if (imageResult.imageData && imageResult.imageData.length > 0) {
              imageData = imageResult.imageData;
              response = `🎨 Image Generated Successfully!

I've created an image based on your prompt: "${message}"

Generation Details:
- Provider: ${imageResult.provider}
- Model: ${imageResult.model}
- Size: ${imageResult.metadata?.size || '1024x1024'}
- Status: ${imageResult.success ? 'Success' : 'Failed'}
- Fallback: ${imageResult.metadata?.fallback ? 'Yes (Test Image)' : 'No'}

The image should be displayed above. If you'd like to generate a different image or make adjustments, just let me know!`;
            } else {
              // No image data returned
              response = `🎨 Image Generation Processing

I've received your request to generate: "${message}"

Status: Processing your image generation request

What's happening:
- The image generation service has been called
- ${imageResult.message || 'Your image is being generated...'}

If you don't see an image above:
• The service might be initializing
• Try again in a few moments
• Check the service status in the logs

Technical Details:
- Provider: ${imageResult.provider}
- Model: ${imageResult.model}
- Success: ${imageResult.success}

Please try again if the image doesn't appear!`;
            }
            usedProvider = imageResult.provider;
            
          } catch (imageError) {
            console.error('Image generation error:', imageError);
            response = `❌ Image Generation Failed

I apologize, but I encountered an issue while generating the image for: "${message}"

Error Details: ${imageError instanceof Error ? imageError.message : 'Unknown error'}

Possible Solutions:
• Try again in a few moments
• Check if the AI services are properly configured
• Try a different image model from the dropdown
• Simplify your image prompt

Available Image Models:
• 🎨 FLUX Dev (Hugging Face) - Highest quality
• ⚡ FLUX Schnell (Hugging Face) - Fast generation
• 🎭 SD 3 Medium (Hugging Face) - Balanced quality
• 🎨 DALL-E 3 (OpenAI) - Premium quality

Please try again or select a different image generation model.`;
            usedProvider = 'error';
          }
          break;

        case 'code':
          const codeMessages: AIMessage[] = [
            {
              role: 'system',
              content: 'You are an expert software developer and coding assistant. Provide clear, well-commented, production-ready code solutions with explanations and best practices.'
            },
            {
              role: 'user',
              content: message
            }
          ];

          try {
            response = await callRealAI(codeMessages, model, searchType);
            usedProvider = 'Real AI';
          } catch (providerError) {
            console.error('Real AI failed for code:', providerError);
            response = `💻 Code Generation

I apologize, but I'm experiencing technical difficulties with code generation. However, I can still help you with: "${message}"

What I can provide:
• Basic code structure and syntax
• Programming concepts and explanations
• Debugging tips and best practices
• Algorithm explanations

For better results, try:
• Being more specific about the programming language
• Including specific requirements or constraints
• Breaking down complex requests into smaller parts
• Providing context about your project structure

Technical Status: The AI services are experiencing issues. Please try again in a moment for full code generation capabilities.`;
            usedProvider = 'partial';
          }
          break;

        case 'analysis':
          const analysisMessages: AIMessage[] = [
            {
              role: 'system',
              content: 'You are an expert data analyst and researcher. Provide thorough, evidence-based analysis with clear insights, trends, and actionable recommendations.'
            },
            {
              role: 'user',
              content: message
            }
          ];

          try {
            response = await callRealAI(analysisMessages, model, searchType);
            usedProvider = 'Real AI';
          } catch (providerError) {
            console.error('Real AI failed for analysis:', providerError);
            response = `📊 Analysis Mode

I apologize, but I'm experiencing technical difficulties with analysis services. However, I can still provide insights on: "${message}"

What I can offer:
• General analytical frameworks and approaches
• Basic data interpretation concepts
• Research methodology suggestions
• Statistical analysis fundamentals

For better analysis results, consider:
• Providing more specific data or context
• Specifying the type of analysis you need
• Including relevant metrics or parameters
• Being clear about your analysis goals

Technical Status: The AI services are experiencing issues. Please try again in a moment for full analysis capabilities.`;
            usedProvider = 'partial';
          }
          break;

        case 'deep-research':
          const researchMessages: AIMessage[] = [
            {
              role: 'system',
              content: 'You are an expert research analyst providing comprehensive, in-depth analysis. Conduct thorough research on the topic, provide detailed insights, cite relevant sources, and offer well-reasoned conclusions. Your response should be comprehensive, evidence-based, and include multiple perspectives where applicable.'
            },
            {
              role: 'user',
              content: message
            }
          ];

          try {
            response = await callRealAI(researchMessages, 'gemini-2-5-pro-free', searchType);
            usedProvider = 'Real AI';
          } catch (providerError) {
            console.error('Real AI failed for deep research:', providerError);
            response = `🔬 Deep Research Response

I apologize, but I'm experiencing technical difficulties with deep research services. However, I can still provide research insights on: "${message}"

What I can offer:
• Comprehensive research framework and methodology
• In-depth analysis of the topic from multiple angles
• Identification of key sources and references
• Structured research approach and recommendations
• Evidence-based insights and conclusions

For better research results, consider:
• Providing more specific research questions
• Including relevant context or background information
• Specifying the depth and scope of research needed
• Mentioning any particular perspectives or sources to focus on

Technical Status: The AI services are experiencing issues. Please try again in a moment for full deep research capabilities.`;
            usedProvider = 'partial';
          }
          break;

        default: // 'chat'
          const chatMessages: AIMessage[] = [
            {
              role: 'system',
              content: 'You are a highly intelligent, helpful, and knowledgeable AI assistant. Provide accurate, detailed, and thoughtful responses. Be conversational but thorough. When appropriate, structure your responses clearly with headings, bullet points, or numbered lists. Always aim to be genuinely helpful and provide comprehensive information.'
            },
            {
              role: 'user',
              content: message
            }
          ];

          try {
            response = await callRealAI(chatMessages, model, searchType);
            usedProvider = 'Real AI';
          } catch (providerError) {
            console.error('Real AI failed for chat:', providerError);
            response = `💬 Chat Mode

I apologize, but I'm experiencing technical difficulties with chat services. However, I'm still here to help you with: "${message}"

What I can provide:
• General information and knowledge
• Basic explanations and concepts  
• Guidance on various topics
• Conversational support

This could be due to:
• Temporary AI service connectivity issues
• High demand on AI services
• Service initialization in progress

Technical Status: The AI services are experiencing issues. Please try again in a moment for full chat capabilities.`;
            usedProvider = 'partial';
          }
          break;
      }

      const aiResponse: AIResponse = {
        success: true,
        response: response + (usedProvider !== 'fallback' ? `\n\n*Powered by ${usedProvider}*` : ''),
        searchResults: searchResults.length > 0 ? searchResults : undefined,
        imageData,
        imagePrompt,
        model: `${model} (${usedProvider})`
      };

      return createSuccessResponse(aiResponse.response, aiResponse);
      
    } catch (error: any) {
      console.error('AI API error:', error);
      
      // Always return JSON, never HTML
      return createErrorResponse(
        `AI service failed: ${error.message || 'Unknown error occurred'}`,
        500
      );
    }
  });
}