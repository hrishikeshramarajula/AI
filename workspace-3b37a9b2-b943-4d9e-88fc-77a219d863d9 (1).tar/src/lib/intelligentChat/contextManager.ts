// ====== 2. CONTEXT HANDLER ======
export interface ConversationExchange {
  user: string;
  bot: string;
  timestamp: Date;
  tokens?: any[];
  entities?: Array<{ text: string; type: string; confidence: number }>;
  intent?: string;
  sentiment?: 'positive' | 'negative' | 'neutral';
}

export interface ContextSummary {
  recentTopics: string[];
  userPreferences: Record<string, any>;
  conversationFlow: 'continuing' | 'new_topic' | 'follow_up' | 'clarification';
  emotionalTone: 'positive' | 'negative' | 'neutral' | 'mixed';
  complexityLevel: 'simple' | 'moderate' | 'complex';
}

export class ContextManager {
  private history: ConversationExchange[] = [];
  private readonly maxHistory: number;
  private readonly maxContextTokens: number;
  
  // Context tracking
  private topics: Set<string> = new Set();
  private userPreferences: Record<string, any> = {};
  private sentimentHistory: ('positive' | 'negative' | 'neutral')[] = [];
  private complexityScores: number[] = [];

  constructor(maxHistory: number = 10, maxContextTokens: number = 4000) {
    this.maxHistory = maxHistory;
    this.maxContextTokens = maxContextTokens;
  }

  /**
   * Add a conversation exchange to history
   */
  addExchange(
    userInput: string, 
    botResponse: string, 
    tokens?: any[], 
    entities?: Array<{ text: string; type: string; confidence: number }>,
    intent?: string
  ): void {
    const exchange: ConversationExchange = {
      user: userInput,
      bot: botResponse,
      timestamp: new Date(),
      tokens,
      entities,
      intent,
      sentiment: this.analyzeSentiment(userInput)
    };

    this.history.push(exchange);
    
    // Maintain history size limit
    if (this.history.length > this.maxHistory) {
      this.history.shift();
    }

    // Update context tracking
    this.updateTopics(userInput, botResponse);
    this.updateSentimentHistory(exchange.sentiment);
    this.updateComplexityScore(userInput);
    this.updateUserPreferences(userInput, botResponse);
  }

  /**
   * Get formatted conversation history for model input
   */
  getContext(): string {
    if (this.history.length === 0) {
      return '';
    }

    // Create context string with recent exchanges
    const contextLines = this.history.map((exchange, index) => {
      const timeStr = exchange.timestamp.toLocaleTimeString();
      return `[${timeStr}] User: ${exchange.user}\n[${timeStr}] Assistant: ${exchange.bot}`;
    });

    let context = contextLines.join('\n\n');

    // Truncate if too long (simple token count approximation)
    const estimatedTokens = context.length / 4; // Rough estimate
    if (estimatedTokens > this.maxContextTokens) {
      // Keep only the most recent exchanges
      const recentExchanges = this.history.slice(-Math.floor(this.maxHistory / 2));
      const recentContext = recentExchanges.map((exchange, index) => {
        const timeStr = exchange.timestamp.toLocaleTimeString();
        return `[${timeStr}] User: ${exchange.user}\n[${timeStr}] Assistant: ${exchange.bot}`;
      }).join('\n\n');
      
      context = recentContext + '\n\n[Note: Earlier conversation history omitted for brevity]';
    }

    return context;
  }

  /**
   * Get structured context summary
   */
  getContextSummary(): ContextSummary {
    const recentTopics = Array.from(this.topics).slice(-5);
    const avgSentiment = this.calculateAverageSentiment();
    const avgComplexity = this.calculateAverageComplexity();
    const flow = this.analyzeConversationFlow();

    return {
      recentTopics,
      userPreferences: { ...this.userPreferences },
      conversationFlow: flow,
      emotionalTone: avgSentiment,
      complexityLevel: avgComplexity
    };
  }

  /**
   * Get the last N exchanges
   */
  getRecentExchanges(count: number = 3): ConversationExchange[] {
    return this.history.slice(-count);
  }

  /**
   * Check if user is asking about something mentioned earlier
   */
  isFollowUpQuestion(input: string): boolean {
    if (this.history.length === 0) return false;

    const lowerInput = input.toLowerCase();
    const followUpIndicators = [
      'what about', 'tell me more', 'can you explain', 'how does that',
      'why is that', 'when did', 'where is', 'who was', 'which one',
      'the one you mentioned', 'earlier you said', 'you mentioned',
      'that thing', 'it sounds like', 'so basically'
    ];

    return followUpIndicators.some(indicator => lowerInput.includes(indicator));
  }

  /**
   * Extract relevant context for current input
   */
  getRelevantContext(input: string): string {
    const lowerInput = input.toLowerCase();
    const relevantExchanges = this.history.filter(exchange => 
      exchange.user.toLowerCase().includes(lowerInput.substring(0, 20)) ||
      exchange.bot.toLowerCase().includes(lowerInput.substring(0, 20)) ||
      exchange.entities?.some(entity => 
        lowerInput.includes(entity.text.toLowerCase())
      )
    );

    if (relevantExchanges.length === 0) {
      return this.getContext(); // Fall back to full context
    }

    return relevantExchanges.map((exchange, index) => {
      const timeStr = exchange.timestamp.toLocaleTimeString();
      return `[${timeStr}] User: ${exchange.user}\n[${timeStr}] Assistant: ${exchange.bot}`;
    }).join('\n\n');
  }

  /**
   * Clear conversation history
   */
  clearHistory(): void {
    this.history = [];
    this.topics.clear();
    this.userPreferences = {};
    this.sentimentHistory = [];
    this.complexityScores = [];
  }

  /**
   * Analyze sentiment of user input (simplified)
   */
  private analyzeSentiment(text: string): 'positive' | 'negative' | 'neutral' {
    const positiveWords = ['good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic', 'love', 'like', 'thanks', 'thank you', 'awesome'];
    const negativeWords = ['bad', 'terrible', 'awful', 'hate', 'dislike', 'wrong', 'error', 'problem', 'issue', 'fail'];

    const lowerText = text.toLowerCase();
    const positiveCount = positiveWords.filter(word => lowerText.includes(word)).length;
    const negativeCount = negativeWords.filter(word => lowerText.includes(word)).length;

    if (positiveCount > negativeCount) return 'positive';
    if (negativeCount > positiveCount) return 'negative';
    return 'neutral';
  }

  /**
   * Update topics from conversation
   */
  private updateTopics(userInput: string, botResponse: string): void {
    // Simple topic extraction (in production, use NLP)
    const combinedText = (userInput + ' ' + botResponse).toLowerCase();
    
    // Extract potential topics (nouns and key phrases)
    const topicKeywords = [
      'quantum', 'computing', 'ai', 'artificial intelligence', 'machine learning',
      'programming', 'code', 'software', 'development', 'technology', 'science',
      'mathematics', 'physics', 'chemistry', 'biology', 'medicine', 'health',
      'business', 'finance', 'economics', 'education', 'learning', 'research'
    ];

    topicKeywords.forEach(keyword => {
      if (combinedText.includes(keyword)) {
        this.topics.add(keyword);
      }
    });
  }

  /**
   * Update sentiment history
   */
  private updateSentimentHistory(sentiment: 'positive' | 'negative' | 'neutral'): void {
    this.sentimentHistory.push(sentiment);
    if (this.sentimentHistory.length > 20) {
      this.sentimentHistory.shift();
    }
  }

  /**
   * Update complexity score based on input
   */
  private updateComplexityScore(input: string): void {
    // Simple complexity metrics
    const wordCount = input.split(' ').length;
    const avgWordLength = input.replace(/\s/g, '').length / wordCount;
    const questionMarks = (input.match(/\?/g) || []).length;
    const complexWords = input.match(/\b(understand|explain|analyze|compare|contrast|evaluate|synthesize)\b/gi) || [];

    let score = 0;
    if (wordCount > 15) score += 1;
    if (avgWordLength > 5) score += 1;
    if (questionMarks > 1) score += 1;
    if (complexWords.length > 0) score += 1;

    this.complexityScores.push(Math.min(score, 3));
    if (this.complexityScores.length > 10) {
      this.complexityScores.shift();
    }
  }

  /**
   * Update user preferences based on conversation
   */
  private updateUserPreferences(userInput: string, botResponse: string): void {
    // Simple preference detection
    const lowerInput = userInput.toLowerCase();
    
    if (lowerInput.includes('detailed') || lowerInput.includes('explain more')) {
      this.userPreferences.detailLevel = 'high';
    } else if (lowerInput.includes('simple') || lowerInput.includes('brief')) {
      this.userPreferences.detailLevel = 'low';
    }

    if (lowerInput.includes('example') || lowerInput.includes('show me')) {
      this.userPreferences.prefersExamples = true;
    }

    if (lowerInput.includes('technical') || lowerInput.includes('scientific')) {
      this.userPreferences.technicalLevel = 'high';
    } else if (lowerInput.includes('beginner') || lowerInput.includes('basic')) {
      this.userPreferences.technicalLevel = 'low';
    }
  }

  /**
   * Calculate average sentiment
   */
  private calculateAverageSentiment(): 'positive' | 'negative' | 'neutral' | 'mixed' {
    if (this.sentimentHistory.length === 0) return 'neutral';

    const positiveCount = this.sentimentHistory.filter(s => s === 'positive').length;
    const negativeCount = this.sentimentHistory.filter(s => s === 'negative').length;
    const neutralCount = this.sentimentHistory.filter(s => s === 'neutral').length;

    if (positiveCount > negativeCount && positiveCount > neutralCount) return 'positive';
    if (negativeCount > positiveCount && negativeCount > neutralCount) return 'negative';
    if (positiveCount === negativeCount && positiveCount > 0) return 'mixed';
    return 'neutral';
  }

  /**
   * Calculate average complexity
   */
  private calculateAverageComplexity(): 'simple' | 'moderate' | 'complex' {
    if (this.complexityScores.length === 0) return 'moderate';

    const avgScore = this.complexityScores.reduce((a, b) => a + b, 0) / this.complexityScores.length;
    
    if (avgScore < 1) return 'simple';
    if (avgScore < 2) return 'moderate';
    return 'complex';
  }

  /**
   * Analyze conversation flow
   */
  private analyzeConversationFlow(): 'continuing' | 'new_topic' | 'follow_up' | 'clarification' {
    if (this.history.length < 2) return 'new_topic';

    const lastExchange = this.history[this.history.length - 1];
    const previousExchange = this.history[this.history.length - 2];

    // Check for follow-up indicators
    if (this.isFollowUpQuestion(lastExchange.user)) {
      return 'follow_up';
    }

    // Check for clarification requests
    if (lastExchange.user.toLowerCase().includes('what do you mean') || 
        lastExchange.user.toLowerCase().includes('clarify') ||
        lastExchange.user.toLowerCase().includes('explain that again')) {
      return 'clarification';
    }

    // Check for topic change (simplified)
    const lastUserWords = new Set(lastExchange.user.toLowerCase().split(' '));
    const previousBotWords = new Set(previousExchange.bot.toLowerCase().split(' '));
    
    const commonWords = [...lastUserWords].filter(word => 
      previousBotWords.has(word) && word.length > 3
    );

    if (commonWords.length < 2) {
      return 'new_topic';
    }

    return 'continuing';
  }
}