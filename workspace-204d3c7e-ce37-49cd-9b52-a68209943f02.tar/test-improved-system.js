// Test the improved AI-IDE system with better extraction
const testImprovedSystem = async () => {
  console.log('🚀 TESTING IMPROVED AI-IDE SYSTEM');
  console.log('='.repeat(60));
  
  const testPrompt = "Create a complete Global Exports website for import and export services";
  
  console.log('📝 Test Prompt:', testPrompt);
  console.log('🔄 Generating with improved extraction...');
  
  try {
    const startTime = Date.now();
    
    const response = await fetch('http://localhost:3000/api/ai-prompt', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: testPrompt,
        type: 'complete-webpage'
      })
    });
    
    const endTime = Date.now();
    const generationTime = endTime - startTime;
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const data = await response.json();
    
    console.log(`⏱️  Generation Time: ${generationTime}ms`);
    console.log(`✅ Success: ${data.success}`);
    console.log(`📁 Files Generated: ${data.files?.length || 0}`);
    
    if (data.success && data.files && data.files.length === 3) {
      console.log('🎉 PERFECT! All 3 files generated!');
      
      const htmlFile = data.files.find(f => f.name === 'index.html');
      const cssFile = data.files.find(f => f.name === 'styles.css');
      const jsFile = data.files.find(f => f.name === 'script.js');
      
      console.log('\n📄 File Analysis:');
      console.log(`   📄 HTML: ${htmlFile.content.length} characters`);
      console.log(`   🎨 CSS: ${cssFile.content.length} characters`);
      console.log(`   ⚡ JavaScript: ${jsFile.content.length} characters`);
      
      // Check for specific content mentioned in the query
      console.log('\n🔍 Content Analysis:');
      const hasGlobalExports = htmlFile.content.includes('Global Exports') || 
                              cssFile.content.includes('Global Exports') ||
                              jsFile.content.includes('Global Exports');
      
      const hasImportExport = htmlFile.content.includes('import') && htmlFile.content.includes('export') ||
                             htmlFile.content.toLowerCase().includes('shipping') ||
                             htmlFile.content.toLowerCase().includes('logistics');
      
      const hasContactInfo = htmlFile.content.includes('+1') || 
                            htmlFile.content.includes('info@') ||
                            htmlFile.content.includes('contact');
      
      console.log(`   🏢 Contains 'Global Exports': ${hasGlobalExports ? '✅' : '❌'}`);
      console.log(`   📦 Import/Export content: ${hasImportExport ? '✅' : '❌'}`);
      console.log(`   📞 Contact information: ${hasContactInfo ? '✅' : '❌'}`);
      
      // Show content previews
      console.log('\n📝 Content Previews:');
      console.log('   HTML Preview:');
      console.log('   ' + htmlFile.content.substring(0, 200) + '...');
      console.log('');
      console.log('   CSS Preview:');
      console.log('   ' + cssFile.content.substring(0, 150) + '...');
      console.log('');
      console.log('   JavaScript Preview:');
      console.log('   ' + jsFile.content.substring(0, 150) + '...');
      
      console.log('\n✅ IMPROVED SYSTEM WORKING PERFECTLY!');
      console.log('   🌐 Complete 3-file structure generated');
      console.log('   📱 Responsive design included');
      console.log('   ⚡ Interactive functionality added');
      console.log('   🎨 Professional styling applied');
      console.log('   🏢 Business-specific content included');
      
    } else {
      console.log('❌ Still not generating 3 files properly');
      console.log(`   Expected 3 files, got ${data.files?.length || 0}`);
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
  
  console.log('\n' + '='.repeat(60));
  console.log('🏁 IMPROVED SYSTEM TEST COMPLETE');
};

testImprovedSystem();