import { NextRequest, NextResponse } from 'next/server'

interface PromptRequest {
  prompt: string
  type: 'complete-webpage' | 'component' | 'feature'
  context?: string
}

interface PromptResponse {
  success: boolean
  files?: {
    name: string
    content: string
    language: string
  }[]
  explanation?: string
  error?: string
}

// OpenRouter API configuration
const OPENROUTER_API_KEY = "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"
const OPENROUTER_MODEL = "mistralai/mistral-7b-instruct"
const OPENROUTER_API_URL = "https://openrouter.ai/api/v1/chat/completions"

// Helper function to call OpenRouter API
async function callOpenRouterAPI(prompt: string) {
  const response = await fetch(OPENROUTER_API_URL, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': 'http://localhost:3000',
      'X-Title': 'AI-IDE Webpage Generator'
    },
    body: JSON.stringify({
      model: OPENROUTER_MODEL,
      messages: [
        {
          role: 'system',
          content: `You are an elite web developer and UI/UX designer who creates stunning, premium-quality websites. Generate complete, modern, and professional webpages with the following requirements:

🎨 DESIGN EXCELLENCE:
- Use modern design frameworks (Tailwind CSS, Bootstrap, or custom premium CSS)
- Implement beautiful gradients, shadows, and animations
- Include high-quality placeholder images from Unsplash with proper attribution
- Use premium fonts (Google Fonts: Playfair Display, Inter, Montserrat, etc.)
- Create responsive, mobile-first designs
- Add micro-interactions, hover effects, and smooth transitions

📁 FILE STRUCTURE:
- Generate exactly 3 files: index.html, styles.css, script.js
- HTML: Complete semantic structure with proper meta tags, SEO optimization
- CSS: Premium styling with CSS variables, animations, and responsive design
- JavaScript: Advanced interactions, form validation, dynamic content, smooth scrolling

🚀 PREMIUM FEATURES TO INCLUDE:
- Hero section with compelling headline and call-to-action
- Services/features showcase with icons
- Portfolio/gallery section with high-quality images
- About section with company statistics
- Contact form with validation
- Professional footer with social links
- Back-to-top button
- Navigation with smooth scrolling
- Loading animations and transitions

🖼️ IMAGE INTEGRATION:
- Use Unsplash images with format: https://images.unsplash.com/photo-ID?w=600&h=400&fit=crop
- Choose relevant image IDs for professional business websites
- Include proper alt attributes and image optimization

💎 QUALITY STANDARDS:
- No placeholder content - all text must be meaningful and professional
- Include real business features and benefits
- Use professional copywriting tone
- Implement accessibility best practices
- Add loading states and error handling
- Include social proof elements (testimonials, stats)

🎯 TECHNICAL REQUIREMENTS:
- Use semantic HTML5 elements
- Implement CSS Grid and Flexbox for layouts
- Add CSS custom properties for theming
- Include JavaScript ES6+ features
- Add form validation and interactive elements
- Implement smooth animations and transitions

Generate a complete, production-ready website that looks like it was created by a high-end web design agency.`
        },
        {
          role: 'user',
          content: `Create a premium, high-quality website for: ${prompt}

Include:
1. A stunning hero section with gradient background and call-to-action
2. Services/features showcase with professional icons
3. Portfolio section with high-quality Unsplash images
4. About section with company statistics (1000+ clients, 15+ years experience, etc.)
5. Contact form with validation
6. Professional footer with social links
7. Advanced animations and interactions
8. Responsive design for all devices

Use modern design trends, premium typography, and professional color schemes. Make it look like a $10,000+ website from a top design agency.`
        }
      ],
      temperature: 0.7,
      max_tokens: 12000  // Increased for even better premium content generation
    })
  })

  if (!response.ok) {
    const errorText = await response.text()
    throw new Error(`OpenRouter API error: ${response.status} - ${errorText}`)
  }

  return await response.json()
}

// Helper function to extract HTML, CSS, and JavaScript from AI response
function extractFilesFromResponse(content: string, prompt: string) {
  const files = []
  
  console.log('[AI-Prompt API] 📝 Analyzing AI response content...')
  console.log('[AI-Prompt API] Content length:', content.length)
  
  // Method 1: Try to find code blocks with backticks (original method)
  const htmlMatch = content.match(/```html\n([\s\S]*?)\n```/) || 
                   content.match(/```HTML\n([\s\S]*?)\n```/)
  
  const cssMatch = content.match(/```css\n([\s\S]*?)\n```/) || 
                  content.match(/```CSS\n([\s\S]*?)\n```/)
  
  const jsMatch = content.match(/```javascript\n([\s\S]*?)\n```/) || 
                 content.match(/```js\n([\s\S]*?)\n```/) ||
                 content.match(/```JavaScript\n([\s\S]*?)\n```/)
  
  console.log('[AI-Prompt API] Code block detection:')
  console.log('  HTML block found:', !!htmlMatch)
  console.log('  CSS block found:', !!cssMatch)
  console.log('  JavaScript block found:', !!jsMatch)
  
  // If we found all three code blocks, use them
  if (htmlMatch && cssMatch && jsMatch) {
    console.log('[AI-Prompt API] ✅ All three code blocks found - using original method')
    
    files.push({
      name: 'index.html',
      content: htmlMatch[1].trim(),
      language: 'html'
    })
    
    files.push({
      name: 'styles.css',
      content: cssMatch[1].trim(),
      language: 'css'
    })
    
    files.push({
      name: 'script.js',
      content: jsMatch[1].trim(),
      language: 'javascript'
    })
    
    return files
  }
  
  // Method 2: Try to extract using different patterns
  console.log('[AI-Prompt API] 🔄 Trying alternative extraction methods...')
  
  // Look for HTML patterns
  const htmlPattern = /<!DOCTYPE html[\s\S]*?<\/html>/i
  const htmlMatch2 = content.match(htmlPattern)
  
  // Look for CSS patterns (style blocks or css content)
  const cssPattern = /(?:<style[^>]*>[\s\S]*?<\/style>)|(?:\.[\w\-]+\s*\{[\s\S]*?\})/g
  const cssMatches = content.match(cssPattern) || []
  
  // Look for JavaScript patterns (script blocks or js content)
  const jsPattern = /(?:<script[^>]*>[\s\S]*?<\/script>)|(?:(?:function|const|let|var|document\.|window\.|addEventListener)[\s\S]*?(?=\n\n|\n\w|\n$|$))/g
  const jsMatches = content.match(jsPattern) || []
  
  console.log('[AI-Prompt API] Pattern detection:')
  console.log('  HTML pattern found:', !!htmlMatch2)
  console.log('  CSS patterns found:', cssMatches.length)
  console.log('  JavaScript patterns found:', jsMatches.length)
  
  // Method 3: If we have HTML but no clear CSS/JS separation, try to split intelligently
  if (htmlMatch2) {
    console.log('[AI-Prompt API] 📄 Found HTML structure, attempting intelligent split...')
    
    let htmlContent = htmlMatch2[0]
    let cssContent = ''
    let jsContent = ''
    
    // Extract CSS from style tags or generate default
    const styleTags = htmlContent.match(/<style[^>]*>[\s\S]*?<\/style>/gi)
    if (styleTags) {
      cssContent = styleTags.map(tag => 
        tag.replace(/<style[^>]*>/, '').replace(/<\/style>/, '')
      ).join('\n')
      
      // Remove style tags from HTML
      htmlContent = htmlContent.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
    }
    
    // Extract JavaScript from script tags or generate default
    const scriptTags = htmlContent.match(/<script[^>]*>[\s\S]*?<\/script>/gi)
    if (scriptTags) {
      jsContent = scriptTags.map(tag => 
        tag.replace(/<script[^>]*>/, '').replace(/<\/script>/, '')
      ).join('\n')
      
      // Remove script tags from HTML
      htmlContent = htmlContent.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
    }
    
    // If no CSS found, create comprehensive CSS based on the content
    if (!cssContent.trim()) {
      cssContent = `/* Modern responsive styling for ${prompt} */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  line-height: 1.6;
  color: #333;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  min-height: 100vh;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.hero {
  text-align: center;
  padding: 60px 20px;
  color: white;
}

.hero h1 {
  font-size: 3rem;
  margin-bottom: 20px;
  text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
}

.hero p {
  font-size: 1.2rem;
  margin-bottom: 30px;
}

.btn {
  display: inline-block;
  background: #ff6b6b;
  color: white;
  padding: 12px 24px;
  text-decoration: none;
  border-radius: 25px;
  font-weight: bold;
  transition: all 0.3s ease;
  margin: 5px;
}

.btn:hover {
  background: #ff5252;
  transform: translateY(-2px);
}

.services {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 30px;
  margin: 40px 0;
}

.service-card {
  background: white;
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.1);
  text-align: center;
  transition: transform 0.3s ease;
}

.service-card:hover {
  transform: translateY(-5px);
}

.service-card h3 {
  color: #667eea;
  margin-bottom: 15px;
  font-size: 1.5rem;
}

.footer {
  background: rgba(0,0,0,0.8);
  color: white;
  text-align: center;
  padding: 20px;
  margin-top: 40px;
}

@media (max-width: 768px) {
  .hero h1 {
    font-size: 2rem;
  }
  
  .services {
    grid-template-columns: 1fr;
  }
}`
    }
    
    // If no JavaScript found, create comprehensive interactive JS
    if (!jsContent.trim()) {
      jsContent = `// Interactive functionality for ${prompt}
document.addEventListener('DOMContentLoaded', function() {
  console.log('Page loaded successfully for: ${prompt}');
  
  // Smooth scrolling for navigation links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({
          behavior: 'smooth'
        });
      }
    });
  });
  
  // Add hover effects to cards
  const cards = document.querySelectorAll('.service-card, .card');
  cards.forEach(card => {
    card.addEventListener('mouseenter', function() {
      this.style.transform = 'translateY(-5px)';
      this.style.boxShadow = '0 15px 40px rgba(0,0,0,0.15)';
    });
    
    card.addEventListener('mouseleave', function() {
      this.style.transform = 'translateY(0)';
      this.style.boxShadow = '0 10px 30px rgba(0,0,0,0.1)';
    });
  });
  
  // Add click effects to buttons
  const buttons = document.querySelectorAll('.btn');
  buttons.forEach(button => {
    button.addEventListener('click', function(e) {
      // Create ripple effect
      const ripple = document.createElement('span');
      const rect = this.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height);
      const x = e.clientX - rect.left - size / 2;
      const y = e.clientY - rect.top - size / 2;
      
      ripple.style.width = ripple.style.height = size + 'px';
      ripple.style.left = x + 'px';
      ripple.style.top = y + 'px';
      ripple.classList.add('ripple');
      
      this.appendChild(ripple);
      
      setTimeout(() => {
        ripple.remove();
      }, 600);
    });
  });
  
  // Add fade-in animation to elements
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  };
  
  const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }
    });
  }, observerOptions);
  
  // Observe all cards and sections
  document.querySelectorAll('.service-card, .card, section').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(el);
  });
  
  console.log('All interactive features initialized for ${prompt}');
});`
    }
    
    // Add the files
    files.push({
      name: 'index.html',
      content: htmlContent.trim(),
      language: 'html'
    })
    
    files.push({
      name: 'styles.css',
      content: cssContent.trim(),
      language: 'css'
    })
    
    files.push({
      name: 'script.js',
      content: jsContent.trim(),
      language: 'javascript'
    })
    
    console.log('[AI-Prompt API] ✅ Successfully extracted 3 files using intelligent split')
    return files
  }
  
  // Method 4: If no HTML structure found, create a complete webpage from the content
  console.log('[AI-Prompt API] 🛠️ No HTML structure found, creating complete webpage...')
  
  // Create a comprehensive HTML structure
  const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Professional website for ${prompt}">
    <title>${prompt.charAt(0).toUpperCase() + prompt.slice(1)} - Professional Website</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-logo">
                <h1>${prompt.charAt(0).toUpperCase() + prompt.slice(1)}</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="#home">Home</a></li>
                <li><a href="#services">Services</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </div>
    </nav>

    <section id="home" class="hero">
        <div class="hero-content">
            <h1>${prompt.charAt(0).toUpperCase() + prompt.slice(1)}</h1>
            <p>Professional services delivered with excellence</p>
            <div class="hero-buttons">
                <a href="#services" class="btn">Get Started</a>
                <a href="#contact" class="btn btn-secondary">Contact Us</a>
            </div>
        </div>
    </section>

    <section id="services" class="services">
        <div class="container">
            <h2>Our Services</h2>
            <div class="services-grid">
                <div class="service-card">
                    <h3>Professional Service</h3>
                    <p>High-quality service tailored to your needs</p>
                </div>
                <div class="service-card">
                    <h3>Expert Team</h3>
                    <p>Experienced professionals dedicated to your success</p>
                </div>
                <div class="service-card">
                    <h3>24/7 Support</h3>
                    <p>Round-the-clock assistance whenever you need it</p>
                </div>
            </div>
        </div>
    </section>

    <section id="about" class="about">
        <div class="container">
            <h2>About Us</h2>
            <p>We are dedicated to providing exceptional ${prompt} services with a focus on quality and customer satisfaction.</p>
        </div>
    </section>

    <section id="contact" class="contact">
        <div class="container">
            <h2>Contact Us</h2>
            <div class="contact-info">
                <p>📧 info@${prompt.toLowerCase().replace(/\s+/g, '')}.com</p>
                <p>📞 +1 (555) 123-4567</p>
                <p>📍 123 Business Street, City, State 12345</p>
            </div>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <p>&copy; 2024 ${prompt.charAt(0).toUpperCase() + prompt.slice(1)}. All rights reserved.</p>
        </div>
    </footer>

    <script src="script.js"></script>
</body>
</html>`

  // Create comprehensive CSS
  const cssContent = `/* Modern styling for ${prompt} */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Inter', sans-serif;
  line-height: 1.6;
  color: #333;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  min-height: 100vh;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

/* Navigation */
.navbar {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  padding: 1rem 0;
  position: fixed;
  width: 100%;
  top: 0;
  z-index: 1000;
  box-shadow: 0 2px 20px rgba(0,0,0,0.1);
}

.nav-container {
  max-width: 1200px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 20px;
}

.nav-logo h1 {
  color: #667eea;
  font-size: 1.8rem;
  font-weight: 700;
}

.nav-menu {
  display: flex;
  list-style: none;
  gap: 2rem;
}

.nav-menu a {
  text-decoration: none;
  color: #333;
  font-weight: 500;
  transition: color 0.3s ease;
}

.nav-menu a:hover {
  color: #667eea;
}

/* Hero Section */
.hero {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  color: white;
  padding-top: 80px;
}

.hero-content h1 {
  font-size: 3.5rem;
  margin-bottom: 1rem;
  text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
}

.hero-content p {
  font-size: 1.3rem;
  margin-bottom: 2rem;
  opacity: 0.9;
}

.hero-buttons {
  display: flex;
  gap: 1rem;
  justify-content: center;
}

.btn {
  display: inline-block;
  padding: 12px 30px;
  background: #ff6b6b;
  color: white;
  text-decoration: none;
  border-radius: 25px;
  font-weight: 600;
  transition: all 0.3s ease;
}

.btn:hover {
  background: #ff5252;
  transform: translateY(-2px);
}

.btn-secondary {
  background: transparent;
  border: 2px solid white;
}

.btn-secondary:hover {
  background: white;
  color: #667eea;
}

/* Services Section */
.services {
  padding: 80px 0;
  background: white;
}

.services h2 {
  text-align: center;
  font-size: 2.5rem;
  margin-bottom: 3rem;
  color: #333;
}

.services-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
}

.service-card {
  background: #f8f9fa;
  padding: 2rem;
  border-radius: 15px;
  text-align: center;
  transition: transform 0.3s ease;
  box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.service-card:hover {
  transform: translateY(-5px);
}

.service-card h3 {
  color: #667eea;
  font-size: 1.5rem;
  margin-bottom: 1rem;
}

/* About Section */
.about {
  padding: 80px 0;
  background: rgba(255, 255, 255, 0.1);
  color: white;
  text-align: center;
}

.about h2 {
  font-size: 2.5rem;
  margin-bottom: 2rem;
}

.about p {
  font-size: 1.1rem;
  max-width: 800px;
  margin: 0 auto;
  opacity: 0.9;
}

/* Contact Section */
.contact {
  padding: 80px 0;
  background: white;
}

.contact h2 {
  text-align: center;
  font-size: 2.5rem;
  margin-bottom: 2rem;
  color: #333;
}

.contact-info {
  text-align: center;
  font-size: 1.1rem;
}

.contact-info p {
  margin-bottom: 1rem;
}

/* Footer */
.footer {
  background: rgba(0, 0, 0, 0.8);
  color: white;
  text-align: center;
  padding: 2rem 0;
}

/* Responsive Design */
@media (max-width: 768px) {
  .nav-menu {
    display: none;
  }
  
  .hero-content h1 {
    font-size: 2.5rem;
  }
  
  .hero-buttons {
    flex-direction: column;
    align-items: center;
  }
  
  .services-grid {
    grid-template-columns: 1fr;
  }
}`

  // Create comprehensive JavaScript
  const jsContent = `// Interactive functionality for ${prompt}
document.addEventListener('DOMContentLoaded', function() {
  console.log('Page loaded successfully for: ${prompt}');
  
  // Smooth scrolling for navigation links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });
  
  // Navbar scroll effect
  window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
      navbar.style.background = 'rgba(255, 255, 255, 0.98)';
      navbar.style.boxShadow = '0 2px 30px rgba(0,0,0,0.15)';
    } else {
      navbar.style.background = 'rgba(255, 255, 255, 0.95)';
      navbar.style.boxShadow = '0 2px 20px rgba(0,0,0,0.1)';
    }
  });
  
  // Add hover effects to service cards
  const serviceCards = document.querySelectorAll('.service-card');
  serviceCards.forEach(card => {
    card.addEventListener('mouseenter', function() {
      this.style.transform = 'translateY(-8px)';
      this.style.boxShadow = '0 15px 40px rgba(0,0,0,0.15)';
    });
    
    card.addEventListener('mouseleave', function() {
      this.style.transform = 'translateY(0)';
      this.style.boxShadow = '0 5px 15px rgba(0,0,0,0.1)';
    });
  });
  
  // Add click effects to buttons
  const buttons = document.querySelectorAll('.btn');
  buttons.forEach(button => {
    button.addEventListener('click', function(e) {
      // Create ripple effect
      const ripple = document.createElement('span');
      const rect = this.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height);
      const x = e.clientX - rect.left - size / 2;
      const y = e.clientY - rect.top - size / 2;
      
      ripple.style.width = ripple.style.height = size + 'px';
      ripple.style.left = x + 'px';
      ripple.style.top = y + 'px';
      ripple.style.position = 'absolute';
      ripple.style.borderRadius = '50%';
      ripple.style.background = 'rgba(255, 255, 255, 0.6)';
      ripple.style.transform = 'scale(0)';
      ripple.style.animation = 'ripple 0.6s linear';
      ripple.style.pointerEvents = 'none';
      
      this.style.position = 'relative';
      this.style.overflow = 'hidden';
      this.appendChild(ripple);
      
      setTimeout(() => {
        ripple.remove();
      }, 600);
    });
  });
  
  // Add fade-in animation to elements
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  };
  
  const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }
    });
  }, observerOptions);
  
  // Observe all cards and sections
  document.querySelectorAll('.service-card, .about, .contact').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(30px)';
    el.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
    observer.observe(el);
  });
  
  // Add CSS animation for ripple effect
  const style = document.createElement('style');
  style.textContent = \`
    @keyframes ripple {
      to {
        transform: scale(4);
        opacity: 0;
      }
    }
  \`;
  document.head.appendChild(style);
  
  // Form handling (if forms exist)
  const forms = document.querySelectorAll('form');
  forms.forEach(form => {
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      
      // Simple form validation
      const inputs = form.querySelectorAll('input[required]');
      let isValid = true;
      
      inputs.forEach(input => {
        if (!input.value.trim()) {
          isValid = false;
          input.style.borderColor = '#ff6b6b';
        } else {
          input.style.borderColor = '#ddd';
        }
      });
      
      if (isValid) {
        // Show success message
        const successMsg = document.createElement('div');
        successMsg.textContent = 'Thank you! We will get back to you soon.';
        successMsg.style.background = '#4CAF50';
        successMsg.style.color = 'white';
        successMsg.style.padding = '10px';
        successMsg.style.borderRadius = '5px';
        successMsg.style.marginTop = '10px';
        
        form.appendChild(successMsg);
        form.reset();
        
        setTimeout(() => {
          successMsg.remove();
        }, 5000);
      }
    });
  });
  
  console.log('All interactive features initialized for ${prompt}');
});`

  files.push({
    name: 'index.html',
    content: htmlContent,
    language: 'html'
  })
  
  files.push({
    name: 'styles.css',
    content: cssContent,
    language: 'css'
  })
  
  files.push({
    name: 'script.js',
    content: jsContent,
    language: 'javascript'
  })
  
  console.log('[AI-Prompt API] ✅ Created complete 3-file structure from content')
  return files
}

// Simple, reliable webpage generator
class WebpageGenerator {
  async generateWebpage(prompt: string) {
    console.log(`[AI-Prompt API] Starting webpage generation for: "${prompt}"`)
    
    try {
      console.log('[AI-Prompt API] 🚀 Using OpenRouter API...')
      
      // Advanced prompt analysis and enhancement
      const enhancedPrompt = this.createEnhancedPrompt(prompt)
      
      console.log('[AI-Prompt API] 🤖 Sending enhanced request to OpenRouter API...')
      
      // Implement retry logic for better reliability
      let lastError = null
      const maxRetries = 3
      
      for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
          // Create a timeout promise for the OpenRouter API
          const timeoutPromise = new Promise((_, reject) => {
            setTimeout(() => reject(new Error('OpenRouter API timeout')), 120000) // Increased to 120 second timeout
          })
          
          // Create the OpenRouter API promise
          const apiPromise = callOpenRouterAPI(enhancedPrompt)
          
          // Race between OpenRouter API and timeout
          const completion = await Promise.race([apiPromise, timeoutPromise])

          const content = completion.choices[0]?.message?.content || ''
          
          if (!content) {
            throw new Error('Empty response from OpenRouter API')
          }
          
          console.log('[AI-Prompt API] 📝 OpenRouter API response received, parsing files...')
          const files = extractFilesFromResponse(content, prompt)
          
          if (files.length === 0) {
            throw new Error('No files were generated from OpenRouter API')
          }
          
          return {
            files: files,
            explanation: `Generated a premium, professional webpage specifically for: "${prompt}" using advanced AI analysis`
          }
          
        } catch (error) {
          lastError = error
          console.error(`[AI-Prompt API] ❌ OpenRouter API attempt ${attempt} failed:`, error.message)
          
          if (attempt < maxRetries) {
            const delay = attempt * 2000 // Exponential backoff: 2s, 4s, 6s
            console.log(`[AI-Prompt API] 🔄 Retrying in ${delay}ms...`)
            await new Promise(resolve => setTimeout(resolve, delay))
          }
        }
      }
      
      // All retries failed, throw the last error
      throw lastError || new Error('All OpenRouter API attempts failed')
      
    } catch (error) {
      console.error('[AI-Prompt API] ❌ OpenRouter API error:', error)
      throw error
    }
  }

  // Advanced prompt analysis and enhancement
  createEnhancedPrompt(prompt: string): string {
    // Analyze the prompt to understand what type of website is needed
    const lowerPrompt = prompt.toLowerCase()
    
    let websiteType = 'business'
    let specificFeatures = []
    let designStyle = 'modern'
    let colorScheme = 'professional'
    let contentFocus = []
    let businessType = ''
    let uniqueValueProp = ''
    let targetAudience = ''
    
    // Advanced business analysis
    if (lowerPrompt.includes('import') || lowerPrompt.includes('export')) {
      websiteType = 'import-export-business'
      businessType = 'Import/Export Logistics Company'
      uniqueValueProp = 'Seamless global trade solutions with end-to-end logistics management'
      targetAudience = 'Businesses needing international shipping, logistics, and supply chain solutions'
      specificFeatures = [
        'international-shipping-calculator',
        'real-time-cargo-tracking',
        'customs-clearance-assistance',
        'global-warehouse-network',
        'supply-chain-management',
        'trade-compliance-tools',
        'client-portal-access',
        'insurance-services',
        'multilingual-support',
        'mobile-logistics-app'
      ]
      designStyle = 'corporate-professional'
      colorScheme = 'trust-blue-professional'
      contentFocus = [
        'global-logistics-network',
        'shipping-solutions',
        'warehouse-facilities',
        'client-testimonials',
        'industry-expertise',
        'technology-integration',
        'sustainability-practices',
        'global-partnerships'
      ]
    }
    
    if (lowerPrompt.includes('portfolio') || lowerPrompt.includes('artist') || lowerPrompt.includes('designer')) {
      websiteType = 'portfolio'
      businessType = 'Creative Professional Portfolio'
      uniqueValueProp = 'Showcasing exceptional creative work and professional expertise'
      targetAudience = 'Potential clients, employers, and collaborators'
      specificFeatures = ['project-gallery', 'skill-showcase', 'contact-form', 'about-section', 'resume-download', 'client-testimonials', 'interactive-portfolio', 'case-studies']
      designStyle = 'creative-minimal'
      colorScheme = 'artistic'
      contentFocus = ['project-descriptions', 'skill-sets', 'experience-timeline', 'testimonials']
    }
    
    if (lowerPrompt.includes('ecommerce') || lowerPrompt.includes('shop') || lowerPrompt.includes('store')) {
      websiteType = 'ecommerce'
      businessType = 'E-commerce Platform'
      uniqueValueProp = 'Seamless online shopping experience with premium products'
      targetAudience = 'Online shoppers looking for quality products and great service'
      specificFeatures = ['product-catalog', 'shopping-cart', 'checkout-process', 'user-accounts', 'payment-integration', 'product-filters', 'wishlist', 'reviews', 'inventory-management']
      designStyle = 'clean-commercial'
      colorScheme = 'trustworthy'
      contentFocus = ['product-listings', 'pricing', 'inventory-management', 'customer-reviews']
    }
    
    if (lowerPrompt.includes('blog') || lowerPrompt.includes('news') || lowerPrompt.includes('magazine')) {
      websiteType = 'blog-magazine'
      businessType = 'Content Publishing Platform'
      uniqueValueProp = 'Engaging content and insights for informed readers'
      targetAudience = 'Readers interested in the topic, content consumers'
      specificFeatures = ['article-listings', 'category-filters', 'search-functionality', 'comment-system', 'newsletter-signup', 'author-profiles', 'social-sharing', 'related-articles']
      designStyle = 'content-focused'
      colorScheme = 'readable'
      contentFocus = ['article-content', 'author-bios', 'publication-dates', 'social-sharing']
    }
    
    // Create highly detailed, professional prompt with premium features
    return `CREATE A PREMIUM, PROFESSIONAL ${websiteType.toUpperCase()} WEBSITE

=== BUSINESS ANALYSIS ===
Business Type: ${businessType}
Unique Value Proposition: ${uniqueValueProp}
Target Audience: ${targetAudience}
Original Prompt Context: "${prompt}"

=== PREMIUM DESIGN REQUIREMENTS ===
✨ This must be a HIGH-END, PROFESSIONAL website that would impress Fortune 500 companies
🎨 Design Style: ${designStyle} with cutting-edge UI/UX principles
🎨 Color Scheme: ${colorScheme} with sophisticated color psychology
📱 Fully responsive design that works flawlessly on all devices
⚡ Advanced animations and micro-interactions throughout
🚀 Lightning-fast loading with optimized performance
🔍 SEO-optimized with proper meta tags, structured data, and schema markup
🌐 Multi-language support capabilities
♿ WCAG 2.1 AA accessibility compliance

=== ADVANCED FEATURES TO INCLUDE ===
${specificFeatures.map(feature => `• ${feature.replace('-', ' ').toUpperCase()}: Enterprise-grade implementation with best practices`).join('\n')}

=== PREMIUM CONTENT FOCUS ===
${contentFocus.map(focus => `• ${focus.replace('-', ' ').toUpperCase()}: Comprehensive, engaging content with professional copywriting`).join('\n')}

=== TECHNICAL EXANCELLIGENCE ===
• HTML5 semantic structure with proper accessibility (ARIA labels)
• CSS3 with modern features (Grid, Flexbox, Custom Properties, CSS Variables)
• Vanilla JavaScript with ES6+ features and modular architecture
• No external dependencies - everything self-contained
• Cross-browser compatible (Chrome, Firefox, Safari, Edge)
• Mobile-first responsive design with breakpoints
• Smooth scrolling and advanced navigation
• Form validation with real-time feedback
• Interactive elements with advanced functionality
• Local storage for user preferences and data persistence
• Service Worker capabilities for offline functionality
• Progressive Web App (PWA) features

=== ENTERPRISE-LEVEL DESIGN STANDARDS ===
• Professional typography with Google Fonts integration
• Consistent spacing and layout system using CSS Grid
• Beautiful hover effects, transitions, and animations
• Modern card-based layouts with advanced styling
• Professional color palette with CSS custom properties
• High-quality imagery using professional photography services
• Icon integration using Font Awesome or similar premium icon sets
• Advanced CSS animations and keyframes
• Glass-morphism and neumorphism design elements where appropriate
• Advanced gradient backgrounds and patterns
• Professional shadows and depth effects

=== PREMIUM HTML STRUCTURE REQUIRED ===
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="[Compelling, SEO-optimized description with keywords]">
    <meta name="keywords" content="[Relevant keywords for SEO optimization]">
    <meta name="author" content="[Company Name]">
    <meta property="og:title" content="[Social media title]">
    <meta property="og:description" content="[Social media description]">
    <meta property="og:image" content="[Social media image]">
    <meta property="og:url" content="[Website URL]">
    <meta name="twitter:card" content="summary_large_image">
    <title>[Professional, catchy title with branding]</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=[Appropriate Google Fonts for professional look]&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="/favicon.ico">
    <link rel="apple-touch-icon" href="/apple-touch-icon.png">
</head>
<body>
    <!-- Advanced navigation with mega menu, search, and user account -->
    <nav class="navbar">
        [Professional navigation with logo, menu items, search, and user account]
    </nav>
    
    <!-- Hero section with advanced animations and call-to-action -->
    <section class="hero">
        [Compelling hero section with background video/animations, headline, subheadline, and CTA buttons]
    </section>
    
    <!-- Features section with interactive cards -->
    <section class="features">
        [Interactive features showcasing key services with hover effects and animations]
    </section>
    
    <!-- Services section with detailed information -->
    <section class="services">
        [Detailed services section with professional descriptions and icons]
    </section>
    
    <!-- About section with company story and values -->
    <section class="about">
        [Professional about section with company history, mission, and values]
    </section>
    
    <!-- Testimonials section with client reviews -->
    <section class="testimonials">
        [Client testimonials with photos, ratings, and detailed reviews]
    </section>
    
    <!-- Contact section with advanced form and information -->
    <section class="contact">
        [Professional contact form with validation and company information]
    </section>
    
    <!-- Footer with comprehensive information -->
    <footer class="footer">
        [Professional footer with links, social media, and contact information]
    </footer>
    
    <!-- Back to top button and other interactive elements -->
    <div class="back-to-top">
        [Back to top button with smooth scrolling]
    </div>
    
    <script src="script.js"></script>
</body>
</html>

=== ENTERPRISE-GRADE CSS REQUIREMENTS ===
• CSS Custom Properties for theming and easy customization
• Modern CSS Grid and Flexbox for advanced layouts
• Advanced animations with @keyframes and transition properties
• Professional typography with font loading optimization
• Responsive design with mobile-first approach and advanced breakpoints
• Beautiful color schemes with gradients and advanced color functions
• Advanced box shadows, transforms, and filters
• CSS Filters and Blend Modes for modern effects
• Scroll-triggered animations and parallax effects
• Advanced form styling with custom checkboxes and radio buttons
• Loading animations and skeleton screens
• Dark mode support with CSS variables
• Print styles for professional document printing
• High contrast mode support for accessibility

=== ADVANCED JAVASCRIPT REQUIREMENTS ===
• ES6+ modern JavaScript with modular architecture
• Advanced DOM manipulation and event handling
• Form validation with real-time feedback and error handling
• Smooth scrolling navigation with scroll spy
• Dynamic content updates and AJAX capabilities
• Local storage for user preferences and data persistence
• Session management and user authentication features
• Interactive charts and data visualization capabilities
• Advanced animations with requestAnimationFrame
• Intersection Observer for scroll-triggered animations
• Service Worker registration for offline functionality
• Progressive Web App (PWA) features
• Advanced error handling and user feedback systems
• Performance optimization with lazy loading
• Analytics integration capabilities
• Social media integration features

=== PREMIUM QUALITY STANDARDS ===
• This must look like a $50,000+ enterprise website
• No generic templates or placeholder content
• Real, functional features that work perfectly
• Professional copywriting with compelling messaging
• Modern design trends and cutting-edge best practices
• Impressive to enterprise clients and decision-makers
• Fast loading with optimized performance (Lighthouse score 90+)
• Fully accessible with WCAG 2.1 AA compliance
• SEO-optimized with proper structured data
• Social media ready with Open Graph tags
• Mobile-optimized with touch-friendly interactions

RETURN YOUR RESPONSE IN THIS EXACT FORMAT:
\`\`\`html
[Complete, professional HTML code with enterprise-level features]
\`\`\`

\`\`\`css
[Complete, professional CSS code with advanced styling and animations]
\`\`\`

\`\`\`javascript
[Complete, professional JavaScript code with advanced functionality]
\`\`\`

REMEMBER: This is a premium enterprise website that should impress Fortune 500 companies. Make it exceptional with advanced features, professional design, and enterprise-grade functionality!`
  }
  
  createFallbackWebpage(prompt: string) {
    console.log('[AI-Prompt API] 🛠️ Creating premium professional fallback webpage...')
    
    // Advanced prompt analysis for fallback
    const lowerPrompt = prompt.toLowerCase()
    let websiteConfig = this.getEnhancedWebsiteConfig(lowerPrompt)
    
    return {
      files: [
        {
          name: 'index.html',
          content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="${websiteConfig.description}">
    <meta name="keywords" content="${websiteConfig.keywords}">
    <meta name="author" content="${websiteConfig.brandName}">
    <meta property="og:title" content="${websiteConfig.title}">
    <meta property="og:description" content="${websiteConfig.description}">
    <meta property="og:type" content="website">
    <meta name="twitter:card" content="summary_large_image">
    <title>${websiteConfig.title}</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=${websiteConfig.fontFamily}:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🏢</text></svg>
</head>
<body>
    <!-- Premium Navigation with Advanced Features -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-logo">
                <h1>${websiteConfig.brandName}</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="#home" class="nav-link">Home</a></li>
                <li><a href="#services" class="nav-link">Services</a></li>
                <li><a href="#about" class="nav-link">About</a></li>
                <li><a href="#testimonials" class="nav-link">Testimonials</a></li>
                <li><a href="#contact" class="nav-link">Contact</a></li>
            </ul>
            <div class="nav-cta">
                <a href="#contact" class="btn btn-primary">Get Started</a>
            </div>
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- Hero Section with Advanced Animations -->
    <section id="home" class="hero">
        <div class="hero-background">
            <div class="hero-overlay"></div>
        </div>
        <div class="hero-content">
            <div class="hero-text">
                <h1 class="hero-title">${websiteConfig.heroTitle}</h1>
                <p class="hero-subtitle">${websiteConfig.heroSubtitle}</p>
                <div class="hero-buttons">
                    <a href="#services" class="btn btn-primary btn-large">${websiteConfig.primaryCTA}</a>
                    <a href="#about" class="btn btn-secondary btn-large">${websiteConfig.secondaryCTA}</a>
                </div>
            </div>
            <div class="hero-visual">
                <div class="hero-card">
                    <div class="card-icon">🚀</div>
                    <h3>Premium Solutions</h3>
                    <p>Enterprise-grade services for your business</p>
                </div>
            </div>
        </div>
        <div class="hero-scroll">
            <div class="scroll-indicator">
                <span></span>
            </div>
        </div>
    </section>

    <!-- Premium Features Section -->
    <section id="features" class="features">
        <div class="container">
            <div class="section-header">
                <h2>Why Choose ${websiteConfig.brandName}</h2>
                <p>Experience the difference with our premium solutions</p>
            </div>
            <div class="features-grid">
                ${websiteConfig.premiumFeatures.map(feature => `
                <div class="feature-card">
                    <div class="feature-icon">${feature.icon}</div>
                    <h3>${feature.title}</h3>
                    <p>${feature.description}</p>
                    <div class="feature-hover">
                        <span>Learn More</span>
                    </div>
                </div>`).join('')}
            </div>
        </div>
    </section>

    <!-- Advanced Services Section -->
    <section id="services" class="services">
        <div class="container">
            <div class="section-header">
                <h2>Our Premium Services</h2>
                <p>Comprehensive solutions tailored to your needs</p>
            </div>
            <div class="services-grid">
                ${websiteConfig.services.map(service => `
                <div class="service-card">
                    <div class="service-header">
                        <div class="service-icon">${service.icon}</div>
                        <h3>${service.title}</h3>
                    </div>
                    <p>${service.description}</p>
                    <ul class="service-features">
                        ${service.features.map(feat => `<li>${feat}</li>`).join('')}
                    </ul>
                    <div class="service-footer">
                        <span class="service-price">${service.price}</span>
                        <a href="#contact" class="btn btn-service">Inquire Now</a>
                    </div>
                </div>`).join('')}
            </div>
        </div>
    </section>

    <!-- About Section with Advanced Layout -->
    <section id="about" class="about">
        <div class="container">
            <div class="about-content">
                <div class="about-text">
                    <div class="section-header">
                        <h2>About ${websiteConfig.brandName}</h2>
                        <p>${websiteConfig.aboutContent}</p>
                    </div>
                    <div class="about-stats">
                        ${websiteConfig.stats.map(stat => `
                        <div class="stat-item">
                            <div class="stat-number">${stat.number}</div>
                            <div class="stat-label">${stat.label}</div>
                        </div>`).join('')}
                    </div>
                    <div class="about-values">
                        <h3>Our Core Values</h3>
                        <div class="values-grid">
                            ${websiteConfig.values.map(value => `
                            <div class="value-item">
                                <div class="value-icon">${value.icon}</div>
                                <h4>${value.title}</h4>
                                <p>${value.description}</p>
                            </div>`).join('')}
                        </div>
                    </div>
                </div>
                <div class="about-visual">
                    <div class="about-image">
                        <img src="https://picsum.photos/seed/${websiteConfig.imageSeed}/600/800.jpg" alt="About ${websiteConfig.brandName}">
                    </div>
                    <div class="about-awards">
                        <div class="award-item">
                            <div class="award-icon">🏆</div>
                            <div class="award-text">
                                <h4>Industry Leader</h4>
                                <p>Recognized for excellence</p>
                            </div>
                        </div>
                        <div class="award-item">
                            <div class="award-icon">⭐</div>
                            <div class="award-text">
                                <h4>Top Rated</h4>
                                <p>5-star customer satisfaction</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section id="testimonials" class="testimonials">
        <div class="container">
            <div class="section-header">
                <h2>Client Testimonials</h2>
                <p>What our clients say about us</p>
            </div>
            <div class="testimonials-grid">
                ${websiteConfig.testimonials.map(testimonial => `
                <div class="testimonial-card">
                    <div class="testimonial-content">
                        <div class="testimonial-rating">
                            ${'⭐'.repeat(testimonial.rating)}
                        </div>
                        <p>"${testimonial.content}"</p>
                    </div>
                    <div class="testimonial-author">
                        <img src="https://picsum.photos/seed/${testimonial.name}/100/100.jpg" alt="${testimonial.name}">
                        <div class="author-info">
                            <h4>${testimonial.name}</h4>
                            <p>${testimonial.company}</p>
                        </div>
                    </div>
                </div>`).join('')}
            </div>
        </div>
    </section>

    <!-- Contact Section with Advanced Form -->
    <section id="contact" class="contact">
        <div class="container">
            <div class="contact-content">
                <div class="contact-info">
                    <div class="section-header">
                        <h2>Contact ${websiteConfig.brandName}</h2>
                        <p>Get in touch with our premium team</p>
                    </div>
                    <div class="contact-methods">
                        <div class="contact-method">
                            <div class="method-icon">📧</div>
                            <div class="method-info">
                                <h4>Email Us</h4>
                                <p>${websiteConfig.email}</p>
                            </div>
                        </div>
                        <div class="contact-method">
                            <div class="method-icon">📞</div>
                            <div class="method-info">
                                <h4>Call Us</h4>
                                <p>${websiteConfig.phone}</p>
                            </div>
                        </div>
                        <div class="contact-method">
                            <div class="method-icon">📍</div>
                            <div class="method-info">
                                <h4>Visit Us</h4>
                                <p>${websiteConfig.address}</p>
                            </div>
                        </div>
                    </div>
                    <div class="contact-hours">
                        <h4>Business Hours</h4>
                        <p>Monday - Friday: 9:00 AM - 6:00 PM</p>
                        <p>Saturday: 10:00 AM - 4:00 PM</p>
                        <p>Sunday: Closed</p>
                    </div>
                </div>
                <div class="contact-form">
                    <form id="contactForm">
                        <div class="form-group">
                            <label for="name">Full Name *</label>
                            <input type="text" id="name" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email Address *</label>
                            <input type="email" id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone">
                        </div>
                        <div class="form-group">
                            <label for="service">Service Interested In</label>
                            <select id="service" name="service">
                                <option value="">Select a service</option>
                                ${websiteConfig.services.map(service => `<option value="${service.title}">${service.title}</option>`).join('')}
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="message">Message *</label>
                            <textarea id="message" name="message" rows="5" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary btn-full">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Premium Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <div class="footer-logo">
                        <h3>${websiteConfig.brandName}</h3>
                        <p>${websiteConfig.tagline}</p>
                    </div>
                    <div class="footer-social">
                        <a href="#" class="social-link">📘</a>
                        <a href="#" class="social-link">🐦</a>
                        <a href="#" class="social-link">📷</a>
                        <a href="#" class="social-link">💼</a>
                    </div>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul class="footer-links">
                        <li><a href="#home">Home</a></li>
                        <li><a href="#services">Services</a></li>
                        <li><a href="#about">About</a></li>
                        <li><a href="#contact">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Services</h4>
                    <ul class="footer-links">
                        ${websiteConfig.services.slice(0, 4).map(service => `<li><a href="#services">${service.title}</a></li>`).join('')}
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Newsletter</h4>
                    <p>Stay updated with our latest news and offers</p>
                    <form class="newsletter-form">
                        <input type="email" placeholder="Your email address">
                        <button type="submit" class="btn btn-primary">Subscribe</button>
                    </form>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 ${websiteConfig.brandName}. All rights reserved. | <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <div class="back-to-top">
        <span>↑</span>
    </div>

    <script src="script.js"></script>
</body>
</html>`,
          language: 'html'
        },
        {
          name: 'styles.css',
          content: `/* Premium Enterprise-Grade CSS for ${websiteConfig.brandName} */

/* CSS Custom Properties for Advanced Theming */
:root {
  /* Color Palette */
  --primary-color: #2563eb;
  --primary-dark: #1d4ed8;
  --primary-light: #3b82f6;
  --secondary-color: #64748b;
  --accent-color: #f59e0b;
  --success-color: #10b981;
  --warning-color: #f59e0b;
  --error-color: #ef4444;
  --info-color: #3b82f6;
  
  /* Neutral Colors */
  --text-primary: #1e293b;
  --text-secondary: #64748b;
  --text-muted: #94a3b8;
  --background-primary: #ffffff;
  --background-secondary: #f8fafc;
  --background-tertiary: #f1f5f9;
  --border-color: #e2e8f0;
  --shadow-color: rgba(0, 0, 0, 0.1);
  
  /* Typography */
  --font-family: '${websiteConfig.fontFamily}', sans-serif;
  --font-size-xs: 0.75rem;
  --font-size-sm: 0.875rem;
  --font-size-base: 1rem;
  --font-size-lg: 1.125rem;
  --font-size-xl: 1.25rem;
  --font-size-2xl: 1.5rem;
  --font-size-3xl: 1.875rem;
  --font-size-4xl: 2.25rem;
  --font-size-5xl: 3rem;
  --font-size-6xl: 3.75rem;
  
  /* Spacing */
  --spacing-xs: 0.5rem;
  --spacing-sm: 0.75rem;
  --spacing-md: 1rem;
  --spacing-lg: 1.5rem;
  --spacing-xl: 2rem;
  --spacing-2xl: 3rem;
  --spacing-3xl: 4rem;
  
  /* Border Radius */
  --radius-sm: 0.375rem;
  --radius-md: 0.5rem;
  --radius-lg: 0.75rem;
  --radius-xl: 1rem;
  --radius-2xl: 1.5rem;
  
  /* Shadows */
  --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
  --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
  --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
  --shadow-2xl: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
  
  /* Transitions */
  --transition-fast: 150ms ease;
  --transition-normal: 300ms ease;
  --transition-slow: 500ms ease;
}

/* Dark Mode Support */
@media (prefers-color-scheme: dark) {
  :root {
    --text-primary: #f1f5f9;
    --text-secondary: #cbd5e1;
    --text-muted: #94a3b8;
    --background-primary: #0f172a;
    --background-secondary: #1e293b;
    --background-tertiary: #334155;
    --border-color: #475569;
    --shadow-color: rgba(0, 0, 0, 0.3);
  }
}

/* Global Reset and Base Styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html {
  scroll-behavior: smooth;
  font-size: 16px;
}

body {
  font-family: var(--font-family);
  line-height: 1.6;
  color: var(--text-primary);
  background-color: var(--background-primary);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 var(--spacing-lg);
}

/* Typography */
h1, h2, h3, h4, h5, h6 {
  font-weight: 700;
  line-height: 1.2;
  margin-bottom: var(--spacing-md);
}

h1 { font-size: var(--font-size-5xl); }
h2 { font-size: var(--font-size-4xl); }
h3 { font-size: var(--font-size-3xl); }
h4 { font-size: var(--font-size-2xl); }
h5 { font-size: var(--font-size-xl); }
h6 { font-size: var(--font-size-lg); }

p {
  margin-bottom: var(--spacing-md);
  color: var(--text-secondary);
}

a {
  color: var(--primary-color);
  text-decoration: none;
  transition: color var(--transition-fast);
}

a:hover {
  color: var(--primary-dark);
}

/* Buttons */
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: var(--spacing-md) var(--spacing-xl);
  font-family: var(--font-family);
  font-size: var(--font-size-base);
  font-weight: 600;
  line-height: 1;
  text-align: center;
  text-decoration: none;
  border: none;
  border-radius: var(--radius-md);
  cursor: pointer;
  transition: all var(--transition-normal);
  position: relative;
  overflow: hidden;
}

.btn:before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
  transition: left var(--transition-slow);
}

.btn:hover:before {
  left: 100%;
}

.btn-primary {
  background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
  color: white;
  box-shadow: var(--shadow-md);
}

.btn-primary:hover {
  background: linear-gradient(135deg, var(--primary-dark), var(--primary-color));
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg);
}

.btn-secondary {
  background: transparent;
  color: var(--primary-color);
  border: 2px solid var(--primary-color);
}

.btn-secondary:hover {
  background: var(--primary-color);
  color: white;
  transform: translateY(-2px);
}

.btn-large {
  padding: var(--spacing-lg) var(--spacing-2xl);
  font-size: var(--font-size-lg);
}

.btn-full {
  width: 100%;
}

/* Navigation */
.navbar {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border-bottom: 1px solid var(--border-color);
  z-index: 1000;
  transition: all var(--transition-normal);
}

.nav-container {
  max-width: 1200px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: var(--spacing-md) var(--spacing-lg);
}

.nav-logo h1 {
  font-size: var(--font-size-2xl);
  color: var(--primary-color);
  margin: 0;
}

.nav-menu {
  display: flex;
  list-style: none;
  gap: var(--spacing-xl);
}

.nav-link {
  color: var(--text-secondary);
  font-weight: 500;
  position: relative;
  transition: color var(--transition-fast);
}

.nav-link:after {
  content: '';
  position: absolute;
  bottom: -5px;
  left: 0;
  width: 0;
  height: 2px;
  background: var(--primary-color);
  transition: width var(--transition-normal);
}

.nav-link:hover {
  color: var(--primary-color);
}

.nav-link:hover:after {
  width: 100%;
}

.nav-cta {
  display: none;
}

.hamburger {
  display: none;
  flex-direction: column;
  cursor: pointer;
}

.hamburger span {
  width: 25px;
  height: 3px;
  background: var(--text-primary);
  margin: 3px 0;
  transition: var(--transition-normal);
}

/* Hero Section */
.hero {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  margin-top: 80px;
  overflow: hidden;
}

.hero-background {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  z-index: -2;
}

.hero-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.3);
  z-index: -1;
}

.hero-content {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 var(--spacing-lg);
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--spacing-3xl);
  align-items: center;
}

.hero-text {
  color: white;
}

.hero-title {
  font-size: var(--font-size-6xl);
  font-weight: 800;
  margin-bottom: var(--spacing-lg);
  line-height: 1.1;
  animation: fadeInUp var(--transition-slow) ease;
}

.hero-subtitle {
  font-size: var(--font-size-xl);
  margin-bottom: var(--spacing-2xl);
  opacity: 0.9;
  animation: fadeInUp var(--transition-slow) ease 0.2s both;
}

.hero-buttons {
  display: flex;
  gap: var(--spacing-lg);
  animation: fadeInUp var(--transition-slow) ease 0.4s both;
}

.hero-visual {
  display: flex;
  justify-content: center;
  align-items: center;
}

.hero-card {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: var(--radius-2xl);
  padding: var(--spacing-2xl);
  text-align: center;
  color: white;
  animation: float 3s ease-in-out infinite;
}

.card-icon {
  font-size: var(--font-size-4xl);
  margin-bottom: var(--spacing-md);
}

.hero-scroll {
  position: absolute;
  bottom: var(--spacing-xl);
  left: 50%;
  transform: translateX(-50%);
  animation: bounce 2s infinite;
}

.scroll-indicator {
  width: 30px;
  height: 50px;
  border: 2px solid rgba(255, 255, 255, 0.5);
  border-radius: 15px;
  position: relative;
}

.scroll-indicator span {
  position: absolute;
  top: 8px;
  left: 50%;
  transform: translateX(-50%);
  width: 4px;
  height: 8px;
  background: white;
  border-radius: 2px;
  animation: scroll 2s infinite;
}

/* Features Section */
.features {
  padding: var(--spacing-3xl) 0;
  background: var(--background-secondary);
}

.section-header {
  text-align: center;
  margin-bottom: var(--spacing-3xl);
}

.section-header h2 {
  color: var(--text-primary);
  margin-bottom: var(--spacing-md);
}

.features-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: var(--spacing-xl);
}

.feature-card {
  background: var(--background-primary);
  border-radius: var(--radius-xl);
  padding: var(--spacing-2xl);
  text-align: center;
  box-shadow: var(--shadow-md);
  transition: all var(--transition-normal);
  position: relative;
  overflow: hidden;
}

.feature-card:before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 4px;
  background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
  transform: scaleX(0);
  transition: transform var(--transition-normal);
}

.feature-card:hover {
  transform: translateY(-5px);
  box-shadow: var(--shadow-xl);
}

.feature-card:hover:before {
  transform: scaleX(1);
}

.feature-icon {
  font-size: var(--font-size-4xl);
  margin-bottom: var(--spacing-lg);
}

.feature-hover {
  margin-top: var(--spacing-md);
  opacity: 0;
  transform: translateY(10px);
  transition: all var(--transition-normal);
}

.feature-card:hover .feature-hover {
  opacity: 1;
  transform: translateY(0);
}

/* Services Section */
.services {
  padding: var(--spacing-3xl) 0;
  background: var(--background-primary);
}

.services-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: var(--spacing-xl);
}

.service-card {
  background: var(--background-secondary);
  border-radius: var(--radius-xl);
  padding: var(--spacing-2xl);
  box-shadow: var(--shadow-md);
  transition: all var(--transition-normal);
}

.service-card:hover {
  transform: translateY(-5px);
  box-shadow: var(--shadow-xl);
}

.service-header {
  display: flex;
  align-items: center;
  margin-bottom: var(--spacing-lg);
}

.service-icon {
  font-size: var(--font-size-2xl);
  margin-right: var(--spacing-md);
}

.service-features {
  list-style: none;
  margin: var(--spacing-lg) 0;
}

.service-features li {
  padding: var(--spacing-xs) 0;
  color: var(--text-secondary);
  position: relative;
  padding-left: var(--spacing-lg);
}

.service-features li:before {
  content: '✓';
  position: absolute;
  left: 0;
  color: var(--success-color);
  font-weight: bold;
}

.service-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: var(--spacing-lg);
  padding-top: var(--spacing-lg);
  border-top: 1px solid var(--border-color);
}

.service-price {
  font-weight: 600;
  color: var(--primary-color);
}

.btn-service {
  padding: var(--spacing-sm) var(--spacing-lg);
  font-size: var(--font-size-sm);
}

/* About Section */
.about {
  padding: var(--spacing-3xl) 0;
  background: var(--background-secondary);
}

.about-content {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--spacing-3xl);
  align-items: start;
}

.about-stats {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: var(--spacing-lg);
  margin: var(--spacing-2xl) 0;
}

.stat-item {
  text-align: center;
  padding: var(--spacing-lg);
  background: var(--background-primary);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-sm);
}

.stat-number {
  font-size: var(--font-size-4xl);
  font-weight: 800;
  color: var(--primary-color);
}

.stat-label {
  color: var(--text-secondary);
  font-weight: 500;
}

.about-values {
  margin-top: var(--spacing-2xl);
}

.values-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: var(--spacing-lg);
}

.value-item {
  background: var(--background-primary);
  padding: var(--spacing-lg);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-sm);
}

.value-icon {
  font-size: var(--font-size-xl);
  margin-bottom: var(--spacing-sm);
}

.about-visual {
  position: sticky;
  top: var(--spacing-xl);
}

.about-image {
  border-radius: var(--radius-xl);
  overflow: hidden;
  box-shadow: var(--shadow-xl);
  margin-bottom: var(--spacing-lg);
}

.about-image img {
  width: 100%;
  height: auto;
  display: block;
}

.about-awards {
  display: flex;
  flex-direction: column;
  gap: var(--spacing-md);
}

.award-item {
  display: flex;
  align-items: center;
  gap: var(--spacing-md);
  padding: var(--spacing-md);
  background: var(--background-primary);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-sm);
}

.award-icon {
  font-size: var(--font-size-xl);
}

/* Testimonials Section */
.testimonials {
  padding: var(--spacing-3xl) 0;
  background: var(--background-primary);
}

.testimonials-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: var(--spacing-xl);
}

.testimonial-card {
  background: var(--background-secondary);
  border-radius: var(--radius-xl);
  padding: var(--spacing-2xl);
  box-shadow: var(--shadow-md);
  transition: all var(--transition-normal);
}

.testimonial-card:hover {
  transform: translateY(-5px);
  box-shadow: var(--shadow-xl);
}

.testimonial-rating {
  margin-bottom: var(--spacing-md);
}

.testimonial-content {
  margin-bottom: var(--spacing-lg);
  font-style: italic;
  color: var(--text-secondary);
}

.testimonial-author {
  display: flex;
  align-items: center;
  gap: var(--spacing-md);
}

.testimonial-author img {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  object-fit: cover;
}

.author-info h4 {
  margin: 0;
  font-size: var(--font-size-base);
}

.author-info p {
  margin: 0;
  font-size: var(--font-size-sm);
}

/* Contact Section */
.contact {
  padding: var(--spacing-3xl) 0;
  background: var(--background-secondary);
}

.contact-content {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--spacing-3xl);
}

.contact-methods {
  display: flex;
  flex-direction: column;
  gap: var(--spacing-xl);
  margin-bottom: var(--spacing-2xl);
}

.contact-method {
  display: flex;
  align-items: center;
  gap: var(--spacing-lg);
  padding: var(--spacing-lg);
  background: var(--background-primary);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-sm);
}

.method-icon {
  font-size: var(--font-size-2xl);
}

.contact-hours {
  padding: var(--spacing-lg);
  background: var(--background-primary);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-sm);
}

.contact-hours h4 {
  margin-bottom: var(--spacing-md);
}

.contact-form {
  background: var(--background-primary);
  padding: var(--spacing-2xl);
  border-radius: var(--radius-xl);
  box-shadow: var(--shadow-lg);
}

.form-group {
  margin-bottom: var(--spacing-lg);
}

.form-group label {
  display: block;
  margin-bottom: var(--spacing-sm);
  font-weight: 500;
  color: var(--text-primary);
}

.form-group input,
.form-group select,
.form-group textarea {
  width: 100%;
  padding: var(--spacing-md);
  border: 2px solid var(--border-color);
  border-radius: var(--radius-md);
  font-family: var(--font-family);
  font-size: var(--font-size-base);
  transition: border-color var(--transition-fast);
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
  outline: none;
  border-color: var(--primary-color);
}

.form-group textarea {
  resize: vertical;
  min-height: 120px;
}

/* Footer */
.footer {
  background: var(--text-primary);
  color: white;
  padding: var(--spacing-3xl) 0 var(--spacing-lg);
}

.footer-content {
  display: grid;
  grid-template-columns: 2fr 1fr 1fr 1fr;
  gap: var(--spacing-2xl);
  margin-bottom: var(--spacing-2xl);
}

.footer-logo h3 {
  color: white;
  margin-bottom: var(--spacing-sm);
}

.footer-logo p {
  color: rgba(255, 255, 255, 0.8);
}

.footer-social {
  display: flex;
  gap: var(--spacing-md);
  margin-top: var(--spacing-md);
}

.social-link {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 50%;
  color: white;
  transition: all var(--transition-fast);
}

.social-link:hover {
  background: var(--primary-color);
  transform: translateY(-2px);
}

.footer-section h4 {
  color: white;
  margin-bottom: var(--spacing-lg);
}

.footer-links {
  list-style: none;
}

.footer-links li {
  margin-bottom: var(--spacing-sm);
}

.footer-links a {
  color: rgba(255, 255, 255, 0.8);
  transition: color var(--transition-fast);
}

.footer-links a:hover {
  color: white;
}

.newsletter-form {
  display: flex;
  gap: var(--spacing-sm);
  margin-top: var(--spacing-md);
}

.newsletter-form input {
  flex: 1;
  padding: var(--spacing-sm);
  border: none;
  border-radius: var(--radius-sm);
}

.newsletter-form button {
  padding: var(--spacing-sm) var(--spacing-md);
}

.footer-bottom {
  text-align: center;
  padding-top: var(--spacing-lg);
  border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.footer-bottom a {
  color: rgba(255, 255, 255, 0.8);
}

.footer-bottom a:hover {
  color: white;
}

/* Back to Top Button */
.back-to-top {
  position: fixed;
  bottom: var(--spacing-xl);
  right: var(--spacing-xl);
  width: 50px;
  height: 50px;
  background: var(--primary-color);
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  opacity: 0;
  visibility: hidden;
  transition: all var(--transition-normal);
  box-shadow: var(--shadow-lg);
}

.back-to-top.visible {
  opacity: 1;
  visibility: visible;
}

.back-to-top:hover {
  background: var(--primary-dark);
  transform: translateY(-3px);
}

/* Animations */
@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes float {
  0%, 100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-10px);
  }
}

@keyframes bounce {
  0%, 20%, 50%, 80%, 100% {
    transform: translateY(0);
  }
  40% {
    transform: translateY(-10px);
  }
  60% {
    transform: translateY(-5px);
  }
}

@keyframes scroll {
  0% {
    transform: translateX(-50%) translateY(0);
    opacity: 1;
  }
  100% {
    transform: translateX(-50%) translateY(20px);
    opacity: 0;
  }
}

/* Responsive Design */
@media (max-width: 1024px) {
  .hero-content {
    grid-template-columns: 1fr;
    text-align: center;
  }
  
  .about-content,
  .contact-content {
    grid-template-columns: 1fr;
  }
  
  .footer-content {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 768px) {
  .nav-menu {
    display: none;
  }
  
  .nav-cta {
    display: none;
  }
  
  .hamburger {
    display: flex;
  }
  
  .hero-title {
    font-size: var(--font-size-4xl);
  }
  
  .hero-buttons {
    flex-direction: column;
    align-items: center;
  }
  
  .features-grid,
  .services-grid,
  .testimonials-grid {
    grid-template-columns: 1fr;
  }
  
  .about-stats,
  .values-grid {
    grid-template-columns: 1fr;
  }
  
  .contact-methods {
    gap: var(--spacing-lg);
  }
  
  .footer-content {
    grid-template-columns: 1fr;
  }
  
  .newsletter-form {
    flex-direction: column;
  }
}

@media (max-width: 480px) {
  .container {
    padding: 0 var(--spacing-md);
  }
  
  .hero-title {
    font-size: var(--font-size-3xl);
  }
  
  .section-header h2 {
    font-size: var(--font-size-3xl);
  }
  
  .btn-large {
    padding: var(--spacing-md) var(--spacing-lg);
    font-size: var(--font-size-base);
  }
}

/* Print Styles */
@media print {
  .navbar,
  .hero,
  .footer,
  .back-to-top {
    display: none;
  }
  
  body {
    font-size: 12pt;
    line-height: 1.4;
  }
  
  .features,
  .services,
  .about,
  .testimonials,
  .contact {
    page-break-inside: avoid;
  }
}

/* High Contrast Mode */
@media (prefers-contrast: high) {
  :root {
    --border-color: #000000;
    --shadow-color: rgba(0, 0, 0, 0.3);
  }
  
  .btn {
    border: 2px solid currentColor;
  }
}

/* Reduced Motion */
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}`,
          language: 'css'
        },
        {
          name: 'script.js',
          content: `// Premium Enterprise-Grade JavaScript for ${websiteConfig.brandName}

document.addEventListener('DOMContentLoaded', function() {
  console.log('🚀 ${websiteConfig.brandName} - Premium Website Initialized');
  
  // Initialize all premium features
  initializeNavigation();
  initializeScrollEffects();
  initializeForms();
  initializeAnimations();
  initializeInteractions();
  initializePerformanceOptimizations();
  
  console.log('✅ All premium features initialized successfully');
});

// Advanced Navigation System
function initializeNavigation() {
  const navbar = document.querySelector('.navbar');
  const navLinks = document.querySelectorAll('.nav-link');
  const hamburger = document.querySelector('.hamburger');
  let lastScroll = 0;
  
  // Scroll-based navbar effects
  window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > 100) {
      navbar.style.background = 'rgba(255, 255, 255, 0.98)';
      navbar.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.1)';
    } else {
      navbar.style.background = 'rgba(255, 255, 255, 0.95)';
      navbar.style.boxShadow = 'none';
    }
    
    // Hide/show navbar on scroll
    if (currentScroll > lastScroll && currentScroll > 300) {
      navbar.style.transform = 'translateY(-100%)';
    } else {
      navbar.style.transform = 'translateY(0)';
    }
    
    lastScroll = currentScroll;
  });
  
  // Smooth scrolling for navigation links
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = link.getAttribute('href');
      const targetSection = document.querySelector(targetId);
      
      if (targetSection) {
        const offsetTop = targetSection.offsetTop - 100;
        window.scrollTo({
          top: offsetTop,
          behavior: 'smooth'
        });
        
        // Update active state
        navLinks.forEach(l => l.classList.remove('active'));
        link.classList.add('active');
      }
    });
  });
  
  // Mobile menu toggle
  hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    // Mobile menu implementation would go here
  });
  
  // Active navigation state based on scroll position
  updateActiveNavigation();
}

function updateActiveNavigation() {
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');
  
  window.addEventListener('scroll', () => {
    let current = '';
    
    sections.forEach(section => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.clientHeight;
      
      if (pageYOffset >= sectionTop - 200) {
        current = section.getAttribute('id');
      }
    });
    
    navLinks.forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href').slice(1) === current) {
        link.classList.add('active');
      }
    });
  });
}

// Advanced Scroll Effects
function initializeScrollEffects() {
  const backToTop = document.querySelector('.back-to-top');
  
  // Back to top button
  window.addEventListener('scroll', () => {
    if (window.pageYOffset > 300) {
      backToTop.classList.add('visible');
    } else {
      backToTop.classList.remove('visible');
    }
  });
  
  backToTop.addEventListener('click', () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  });
  
  // Scroll-triggered animations
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  };
  
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }
    });
  }, observerOptions);
  
  // Observe elements for animation
  document.querySelectorAll('.feature-card, .service-card, .testimonial-card, .stat-item, .value-item').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(30px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(el);
  });
}

// Advanced Form Handling
function initializeForms() {
  const contactForm = document.getElementById('contactForm');
  const newsletterForm = document.querySelector('.newsletter-form');
  
  if (contactForm) {
    contactForm.addEventListener('submit', handleContactSubmit);
    
    // Real-time validation
    const inputs = contactForm.querySelectorAll('input, textarea, select');
    inputs.forEach(input => {
      input.addEventListener('blur', () => validateField(input));
      input.addEventListener('input', () => clearFieldError(input));
    });
  }
  
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', handleNewsletterSubmit);
  }
}

function handleContactSubmit(e) {
  e.preventDefault();
  
  const form = e.target;
  const formData = new FormData(form);
  const submitBtn = form.querySelector('button[type="submit"]');
  
  // Validate all fields
  const isValid = validateForm(form);
  
  if (isValid) {
    // Show loading state
    submitBtn.disabled = true;
    submitBtn.innerHTML = 'Sending...';
    
    // Simulate form submission
    setTimeout(() => {
      showNotification('Message sent successfully! We\'ll get back to you soon.', 'success');
      form.reset();
      submitBtn.disabled = false;
      submitBtn.innerHTML = 'Send Message';
    }, 2000);
  }
}

function handleNewsletterSubmit(e) {
  e.preventDefault();
  
  const form = e.target;
  const email = form.querySelector('input[type="email"]').value;
  
  if (email && validateEmail(email)) {
    const submitBtn = form.querySelector('button');
    submitBtn.disabled = true;
    submitBtn.innerHTML = 'Subscribing...';
    
    setTimeout(() => {
      showNotification('Successfully subscribed to newsletter!', 'success');
      form.reset();
      submitBtn.disabled = false;
      submitBtn.innerHTML = 'Subscribe';
    }, 1500);
  }
}

function validateField(field) {
  const value = field.value.trim();
  const fieldName = field.name;
  let isValid = true;
  let errorMessage = '';
  
  // Clear previous error
  clearFieldError(field);
  
  // Required field validation
  if (field.hasAttribute('required') && !value) {
    isValid = false;
    errorMessage = 'This field is required';
  }
  
  // Email validation
  if (field.type === 'email' && value && !validateEmail(value)) {
    isValid = false;
    errorMessage = 'Please enter a valid email address';
  }
  
  // Phone validation
  if (field.type === 'tel' && value && !validatePhone(value)) {
    isValid = false;
    errorMessage = 'Please enter a valid phone number';
  }
  
  if (!isValid) {
    showFieldError(field, errorMessage);
  }
  
  return isValid;
}

function validateForm(form) {
  const inputs = form.querySelectorAll('input[required], textarea[required], select[required]');
  let isValid = true;
  
  inputs.forEach(input => {
    if (!validateField(input)) {
      isValid = false;
    }
  });
  
  return isValid;
}

function showFieldError(field, message) {
  field.style.borderColor = '#ef4444';
  
  const errorDiv = document.createElement('div');
  errorDiv.className = 'field-error';
  errorDiv.textContent = message;
  errorDiv.style.color = '#ef4444';
  errorDiv.style.fontSize = '0.875rem';
  errorDiv.style.marginTop = '0.25rem';
  
  field.parentNode.appendChild(errorDiv);
}

function clearFieldError(field) {
  field.style.borderColor = '';
  const errorDiv = field.parentNode.querySelector('.field-error');
  if (errorDiv) {
    errorDiv.remove();
  }
}

function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

function validatePhone(phone) {
  const re = /^[\+]?[1-9][\d]{0,15}$/;
  return re.test(phone.replace(/[\s\-\(\)]/g, ''));
}

// Advanced Animations
function initializeAnimations() {
  // Parallax effect for hero section
  const hero = document.querySelector('.hero');
  if (hero) {
    window.addEventListener('scroll', () => {
      const scrolled = window.pageYOffset;
      const parallax = document.querySelector('.hero-background');
      if (parallax) {
        parallax.style.transform = \`translateY(\${scrolled * 0.5}px)\`;
      }
    });
  }
  
  // Counter animation for statistics
  const statNumbers = document.querySelectorAll('.stat-number');
  const animateCounter = (element) => {
    const target = parseInt(element.textContent);
    const duration = 2000;
    const step = target / (duration / 16);
    let current = 0;
    
    const timer = setInterval(() => {
      current += step;
      if (current >= target) {
        current = target;
        clearInterval(timer);
      }
      element.textContent = Math.floor(current).toLocaleString();
    }, 16);
  };
  
  // Trigger counter animation when in viewport
  const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        statsObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });
  
  statNumbers.forEach(stat => {
    statsObserver.observe(stat);
  });
}

// Interactive Elements
function initializeInteractions() {
  // Advanced hover effects for cards
  const cards = document.querySelectorAll('.feature-card, .service-card, .testimonial-card');
  
  cards.forEach(card => {
    card.addEventListener('mouseenter', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      card.style.transform = 'perspective(1000px) rotateX(5deg) rotateY(5deg)';
      card.style.boxShadow = '0 20px 40px rgba(0, 0, 0, 0.2)';
    });
    
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      
      const rotateX = (y - centerY) / 10;
      const rotateY = (centerX - x) / 10;
      
      card.style.transform = \`perspective(1000px) rotateX(\${rotateX}deg) rotateY(\${rotateY}deg)\`;
    });
    
    card.addEventListener('mouseleave', () => {
      card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0)';
      card.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.1)';
    });
  });
  
  // Ripple effect for buttons
  const buttons = document.querySelectorAll('.btn');
  
  buttons.forEach(button => {
    button.addEventListener('click', function(e) {
      const ripple = document.createElement('span');
      const rect = this.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height);
      const x = e.clientX - rect.left - size / 2;
      const y = e.clientY - rect.top - size / 2;
      
      ripple.style.width = ripple.style.height = size + 'px';
      ripple.style.left = x + 'px';
      ripple.style.top = y + 'px';
      ripple.style.position = 'absolute';
      ripple.style.borderRadius = '50%';
      ripple.style.background = 'rgba(255, 255, 255, 0.6)';
      ripple.style.transform = 'scale(0)';
      ripple.style.animation = 'ripple 0.6s linear';
      ripple.style.pointerEvents = 'none';
      
      this.style.position = 'relative';
      this.style.overflow = 'hidden';
      this.appendChild(ripple);
      
      setTimeout(() => {
        ripple.remove();
      }, 600);
    });
  });
  
  // Add ripple animation CSS
  const style = document.createElement('style');
  style.textContent = \`
    @keyframes ripple {
      to {
        transform: scale(4);
        opacity: 0;
      }
    }
    
    .nav-link.active {
      color: var(--primary-color);
      font-weight: 600;
    }
    
    .nav-link.active:after {
      width: 100%;
    }
    
    .hamburger.active span:nth-child(1) {
      transform: rotate(45deg) translate(5px, 5px);
    }
    
    .hamburger.active span:nth-child(2) {
      opacity: 0;
    }
    
    .hamburger.active span:nth-child(3) {
      transform: rotate(-45deg) translate(7px, -6px);
    }
    
    .field-error {
      animation: shake 0.5s ease-in-out;
    }
    
    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      25% { transform: translateX(-5px); }
      75% { transform: translateX(5px); }
    }
  \`;
  document.head.appendChild(style);
}

// Performance Optimizations
function initializePerformanceOptimizations() {
  // Lazy loading for images
  const images = document.querySelectorAll('img');
  const imageObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        img.src = img.dataset.src || img.src;
        img.classList.add('loaded');
        observer.unobserve(img);
      }
    });
  });
  
  images.forEach(img => imageObserver.observe(img));
  
  // Debounce scroll events
  let scrollTimeout;
  window.addEventListener('scroll', () => {
    if (scrollTimeout) {
      window.cancelAnimationFrame(scrollTimeout);
    }
    scrollTimeout = window.requestAnimationFrame(() => {
      // Handle scroll events
    });
  });
  
  // Optimize animations with requestAnimationFrame
  let animationId;
  function animate() {
    // Animation loop
    animationId = requestAnimationFrame(animate);
  }
  // animate(); // Start if needed
  
  // Cleanup on page unload
  window.addEventListener('beforeunload', () => {
    if (animationId) {
      cancelAnimationFrame(animationId);
    }
  });
}

// Notification System
function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.className = \`notification notification-\${type}\`;
  notification.textContent = message;
  
  // Add notification styles
  const notificationStyles = \`
    .notification {
      position: fixed;
      top: 100px;
      right: 20px;
      padding: 16px 24px;
      border-radius: 8px;
      color: white;
      font-weight: 500;
      z-index: 10000;
      transform: translateX(400px);
      transition: transform 0.3s ease;
      max-width: 400px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    }
    
    .notification-success {
      background: linear-gradient(135deg, #10b981, #059669);
    }
    
    .notification-error {
      background: linear-gradient(135deg, #ef4444, #dc2626);
    }
    
    .notification-info {
      background: linear-gradient(135deg, #3b82f6, #2563eb);
    }
    
    .notification.show {
      transform: translateX(0);
    }
  \`;
  
  // Add styles if not already added
  if (!document.querySelector('#notification-styles')) {
    const style = document.createElement('style');
    style.id = 'notification-styles';
    style.textContent = notificationStyles;
    document.head.appendChild(style);
  }
  
  document.body.appendChild(notification);
  
  // Trigger animation
  setTimeout(() => {
    notification.classList.add('show');
  }, 100);
  
  // Remove notification
  setTimeout(() => {
    notification.classList.remove('show');
    setTimeout(() => {
      notification.remove();
    }, 300);
  }, 5000);
}

// Utility Functions
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

function throttle(func, limit) {
  let inThrottle;
  return function() {
    const args = arguments;
    const context = this;
    if (!inThrottle) {
      func.apply(context, args);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  };
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    initializeNavigation,
    initializeScrollEffects,
    initializeForms,
    initializeAnimations,
    initializeInteractions,
    initializePerformanceOptimizations,
    showNotification,
    debounce,
    throttle
  };
}`,
          language: 'javascript'
        }
      ]
    }
  }
  
  // Enhanced website configuration generator
  getEnhancedWebsiteConfig(lowerPrompt: string) {
    if (lowerPrompt.includes('import') || lowerPrompt.includes('export')) {
      return {
        brandName: 'Global Trade Solutions',
        title: 'Global Trade Solutions - Premium Import Export Services',
        description: 'Your reliable partner for seamless import and export services worldwide. Expert logistics, shipping, and warehousing solutions.',
        keywords: 'import, export, shipping, logistics, warehousing, global trade, customs clearance, supply chain',
        tagline: 'Connecting Businesses Across Borders',
        heroTitle: 'Global Trade Excellence',
        heroSubtitle: 'Your trusted partner for seamless import and export solutions worldwide',
        primaryCTA: 'Get Quote',
        secondaryCTA: 'Learn More',
        email: 'info@globaltradesolutions.com',
        phone: '+1 (555) 123-4567',
        address: '123 Commerce Street, Business District, NY 10001',
        fontFamily: 'Inter',
        imageSeed: 'global-trade-logistics',
        
        premiumFeatures: [
          {
            icon: '🌍',
            title: 'Global Network',
            description: 'Extensive network spanning 100+ countries'
          },
          {
            icon: '⚡',
            title: 'Fast Delivery',
            description: 'Express shipping with real-time tracking'
          },
          {
            icon: '🛡️',
            title: 'Secure Transport',
            description: 'Advanced security and insurance coverage'
          },
          {
            icon: '💼',
            title: 'Expert Team',
            description: 'Industry professionals with 20+ years experience'
          }
        ],
        
        services: [
          {
            icon: '📦',
            title: 'Import & Export',
            description: 'We handle all aspects of import and export, ensuring seamless transport of goods worldwide.',
            features: ['Customs clearance', 'Documentation', 'Compliance management', 'Duty optimization'],
            price: 'Contact for Quote'
          },
          {
            icon: '🚢',
            title: 'Global Shipping',
            description: 'Our network of trusted carriers guarantees fast and secure delivery, no matter the destination.',
            features: ['Air freight', 'Ocean freight', 'Ground transportation', 'Express delivery'],
            price: 'Competitive Rates'
          },
          {
            icon: '🏭',
            title: 'Warehousing & Storage',
            description: 'Our secure, climate-controlled warehouses provide a safe home for your goods during transit or long-term storage.',
            features: ['Climate control', '24/7 security', 'Inventory management', 'Distribution services'],
            price: 'Flexible Plans'
          }
        ],
        
        stats: [
          { number: '150+', label: 'Countries Served' },
          { number: '50K+', label: 'Shipments Delivered' },
          { number: '99%', label: 'On-Time Delivery' },
          { number: '24/7', label: 'Support Available' }
        ],
        
        values: [
          {
            icon: '🎯',
            title: 'Reliability',
            description: 'Consistent, dependable service you can count on'
          },
          {
            icon: '🌱',
            title: 'Sustainability',
            description: 'Eco-friendly logistics solutions'
          },
          {
            icon: '🚀',
            title: 'Innovation',
            description: 'Cutting-edge technology and processes'
          },
          {
            icon: '🤝',
            title: 'Partnership',
            description: 'Building long-term business relationships'
          }
        ],
        
        testimonials: [
          {
            name: 'Sarah Johnson',
            company: 'TechCorp Inc.',
            rating: 5,
            content: 'Outstanding service! Our imports have never been smoother. Highly recommend their expertise.'
          },
          {
            name: 'Michael Chen',
            company: 'Global Retail Ltd.',
            rating: 5,
            content: 'Professional, reliable, and cost-effective. They handle our entire supply chain seamlessly.'
          },
          {
            name: 'Emma Rodriguez',
            company: 'Fashion Forward',
            rating: 4,
            content: 'Excellent communication and tracking. Our goods always arrive on time and in perfect condition.'
          }
        ]
      }
    }
    
    // Default business configuration
    return {
      brandName: 'Premium Business Solutions',
      title: 'Premium Business Solutions - Professional Services',
      description: 'Your trusted partner for all business needs. Professional services with exceptional results.',
      keywords: 'business, services, professional, solutions, consulting',
      tagline: 'Excellence in Business',
      heroTitle: 'Premium Business Solutions',
      heroSubtitle: 'Your reliable partner for all your business needs',
      primaryCTA: 'Get Started',
      secondaryCTA: 'Learn More',
      email: 'info@premiumbusiness.com',
      phone: '+1 (555) 987-6543',
      address: '456 Business Avenue, Commerce District, NY 10002',
      fontFamily: 'Inter',
      imageSeed: 'premium-business',
      
      premiumFeatures: [
        {
          icon: '🎯',
          title: 'Expert Solutions',
          description: 'Professional expertise tailored to your needs'
        },
        {
          icon: '⚡',
          title: 'Fast Results',
          description: 'Quick turnaround with quality assurance'
        },
        {
          icon: '🛡️',
          title: 'Reliable Service',
          description: 'Dependable support and maintenance'
        },
        {
          icon: '💼',
          title: 'Professional Team',
          description: 'Experienced professionals at your service'
        }
      ],
      
      services: [
        {
          icon: '📋',
          title: 'Consulting',
          description: 'Professional consulting services for your business.',
          features: ['Strategic planning', 'Process optimization', 'Risk assessment', 'Performance analysis'],
          price: 'Contact Us'
        },
        {
          icon: '🚀',
          title: 'Implementation',
          description: 'End-to-end implementation of business solutions.',
          features: ['Project management', 'Technical support', 'Training', 'Quality assurance'],
          price: 'Custom Quotes'
        },
        {
          icon: '📊',
          title: 'Analytics',
          description: 'Data-driven insights and business intelligence.',
          features: ['Data analysis', 'Reporting', 'Forecasting', 'Optimization'],
          price: 'Competitive Rates'
        }
      ],
      
      stats: [
        { number: '500+', label: 'Clients Served' },
        { number: '10K+', label: 'Projects Completed' },
        { number: '98%', label: 'Client Satisfaction' },
        { number: '15+', label: 'Years Experience' }
      ],
      
      values: [
        {
          icon: '🎯',
          title: 'Excellence',
          description: 'Commitment to outstanding quality'
        },
        {
          icon: '🤝',
          title: 'Integrity',
          description: 'Honest and ethical business practices'
        },
        {
          icon: '🚀',
          title: 'Innovation',
          description: 'Creative solutions for modern challenges'
        },
        {
          icon: '💎',
          title: 'Quality',
          description: 'Uncompromising standards in all we do'
        }
      ],
      
      testimonials: [
        {
          name: 'David Smith',
          company: 'Startup Co.',
          rating: 5,
          content: 'Exceptional service and expertise. Transformed our business operations completely.'
        },
        {
          name: 'Lisa Wang',
          company: 'Enterprise Corp',
          rating: 5,
          content: 'Professional, reliable, and results-driven. Highly recommended for any business.'
        },
        {
          name: 'Robert Brown',
          company: 'Growth Ltd.',
          rating: 4,
          content: 'Great team and excellent service. Helped us scale our operations effectively.'
        }
      ]
    }
  }
  
  // Enhanced website configuration generator
  getEnhancedWebsiteConfig(lowerPrompt: string) {
    if (lowerPrompt.includes('import') || lowerPrompt.includes('export')) {
      return {
        brandName: 'Global Trade Solutions',
        title: 'Global Trade Solutions - Premium Import Export Services',
        description: 'Your reliable partner for seamless import and export services worldwide. Expert logistics, shipping, and warehousing solutions.',
        keywords: 'import, export, shipping, logistics, warehousing, global trade, customs clearance, supply chain',
        tagline: 'Connecting Businesses Across Borders',
        heroTitle: 'Global Trade Excellence',
        heroSubtitle: 'Your trusted partner for seamless import and export solutions worldwide',
        primaryCTA: 'Get Quote',
        secondaryCTA: 'Learn More',
        email: 'info@globaltradesolutions.com',
        phone: '+1 (555) 123-4567',
        address: '123 Commerce Street, Business District, NY 10001',
        fontFamily: 'Inter',
        imageSeed: 'global-trade-logistics',
        
        premiumFeatures: [
          {
            icon: '🌍',
            title: 'Global Network',
            description: 'Extensive network spanning 100+ countries'
          },
          {
            icon: '⚡',
            title: 'Fast Delivery',
            description: 'Express shipping with real-time tracking'
          },
          {
            icon: '🛡️',
            title: 'Secure Transport',
            description: 'Advanced security and insurance coverage'
          },
          {
            icon: '💼',
            title: 'Expert Team',
            description: 'Industry professionals with 20+ years experience'
          }
        ],
        
        services: [
          {
            icon: '📦',
            title: 'Import & Export',
            description: 'We handle all aspects of import and export, ensuring seamless transport of goods worldwide.',
            features: ['Customs clearance', 'Documentation', 'Compliance management', 'Duty optimization'],
            price: 'Contact for Quote'
          },
          {
            icon: '🚢',
            title: 'Global Shipping',
            description: 'Our network of trusted carriers guarantees fast and secure delivery, no matter the destination.',
            features: ['Air freight', 'Ocean freight', 'Ground transportation', 'Express delivery'],
            price: 'Competitive Rates'
          },
          {
            icon: '🏭',
            title: 'Warehousing & Storage',
            description: 'Our secure, climate-controlled warehouses provide a safe home for your goods during transit or long-term storage.',
            features: ['Climate control', '24/7 security', 'Inventory management', 'Distribution services'],
            price: 'Flexible Plans'
          }
        ],
        
        stats: [
          { number: '150+', label: 'Countries Served' },
          { number: '50K+', label: 'Shipments Delivered' },
          { number: '99%', label: 'On-Time Delivery' },
          { number: '24/7', label: 'Support Available' }
        ],
        
        values: [
          {
            icon: '🎯',
            title: 'Reliability',
            description: 'Consistent, dependable service you can count on'
          },
          {
            icon: '🌱',
            title: 'Sustainability',
            description: 'Eco-friendly logistics solutions'
          },
          {
            icon: '🚀',
            title: 'Innovation',
            description: 'Cutting-edge technology and processes'
          },
          {
            icon: '🤝',
            title: 'Partnership',
            description: 'Building long-term business relationships'
          }
        ],
        
        testimonials: [
          {
            name: 'Sarah Johnson',
            company: 'TechCorp Inc.',
            rating: 5,
            content: 'Outstanding service! Our imports have never been smoother. Highly recommend their expertise.'
          },
          {
            name: 'Michael Chen',
            company: 'Global Retail Ltd.',
            rating: 5,
            content: 'Professional, reliable, and cost-effective. They handle our entire supply chain seamlessly.'
          },
          {
            name: 'Emma Rodriguez',
            company: 'Fashion Forward',
            rating: 4,
            content: 'Excellent communication and tracking. Our goods always arrive on time and in perfect condition.'
          }
        ]
      }
    }
    
    // Default business configuration
    return {
      brandName: 'Premium Business Solutions',
      title: 'Premium Business Solutions - Professional Services',
      description: 'Your trusted partner for all business needs. Professional services with exceptional results.',
      keywords: 'business, services, professional, solutions, consulting',
      tagline: 'Excellence in Business',
      heroTitle: 'Premium Business Solutions',
      heroSubtitle: 'Your reliable partner for all your business needs',
      primaryCTA: 'Get Started',
      secondaryCTA: 'Learn More',
      email: 'info@premiumbusiness.com',
      phone: '+1 (555) 987-6543',
      address: '456 Business Avenue, Commerce District, NY 10002',
      fontFamily: 'Inter',
      imageSeed: 'premium-business',
      
      premiumFeatures: [
        {
          icon: '🎯',
          title: 'Expert Solutions',
          description: 'Professional expertise tailored to your needs'
        },
        {
          icon: '⚡',
          title: 'Fast Results',
          description: 'Quick turnaround with quality assurance'
        },
        {
          icon: '🛡️',
          title: 'Reliable Service',
          description: 'Dependable support and maintenance'
        },
        {
          icon: '💼',
          title: 'Professional Team',
          description: 'Experienced professionals at your service'
        }
      ],
      
      services: [
        {
          icon: '📋',
          title: 'Consulting',
          description: 'Professional consulting services for your business.',
          features: ['Strategic planning', 'Process optimization', 'Risk assessment', 'Performance analysis'],
          price: 'Contact Us'
        },
        {
          icon: '🚀',
          title: 'Implementation',
          description: 'End-to-end implementation of business solutions.',
          features: ['Project management', 'Technical support', 'Training', 'Quality assurance'],
          price: 'Custom Quotes'
        },
        {
          icon: '📊',
          title: 'Analytics',
          description: 'Data-driven insights and business intelligence.',
          features: ['Data analysis', 'Reporting', 'Forecasting', 'Optimization'],
          price: 'Competitive Rates'
        }
      ],
      
      stats: [
        { number: '500+', label: 'Clients Served' },
        { number: '10K+', label: 'Projects Completed' },
        { number: '98%', label: 'Client Satisfaction' },
        { number: '15+', label: 'Years Experience' }
      ],
      
      values: [
        {
          icon: '🎯',
          title: 'Excellence',
          description: 'Commitment to outstanding quality'
        },
        {
          icon: '🤝',
          title: 'Integrity',
          description: 'Honest and ethical business practices'
        },
        {
          icon: '🚀',
          title: 'Innovation',
          description: 'Creative solutions for modern challenges'
        },
        {
          icon: '💎',
          title: 'Quality',
          description: 'Uncompromising standards in all we do'
        }
      ],
      
      testimonials: [
        {
          name: 'David Smith',
          company: 'Startup Co.',
          rating: 5,
          content: 'Exceptional service and expertise. Transformed our business operations completely.'
        },
        {
          name: 'Lisa Wang',
          company: 'Enterprise Corp',
          rating: 5,
          content: 'Professional, reliable, and results-driven. Highly recommended for any business.'
        },
        {
          name: 'Robert Brown',
          company: 'Growth Ltd.',
          rating: 4,
          content: 'Great team and excellent service. Helped us scale our operations effectively.'
        }
      ]
    }
  }
}

// Initialize the webpage generator
const webpageGenerator = new WebpageGenerator()

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { prompt, type, context } = body
    
    if (!prompt) {
      return NextResponse.json({
        success: false,
        error: 'Prompt is required'
      }, { status: 400 })
    }

    console.log(`[AI-Prompt API] 🚀 Processing prompt: "${prompt}"`)

    try {
      // Try to generate with OpenRouter API first
      const result = await webpageGenerator.generateWebpage(prompt)

      // Check if the result contains valid content
      const hasValidContent = result.files && result.files.length > 0 && 
        result.files.some(file => file.content && file.content.trim().length > 0)

      if (!hasValidContent) {
        console.log('[AI-Prompt API] ⚠️ AI returned empty content, using fallback')
        throw new Error('AI returned empty content')
      }

      console.log('[AI-Prompt API] ✅ Webpage generation completed successfully')
      console.log(`[AI-Prompt API] 📁 Created ${result.files.length} files: ${result.files.map(f => f.name).join(', ')}`)

      return NextResponse.json({
        success: true,
        files: result.files,
        explanation: result.explanation
      })

    } catch (aiError) {
      console.error('[AI-Prompt API] ❌ AI generation failed:', aiError)
      
      // Always provide professional fallback
      const fallbackResult = webpageGenerator.createFallbackWebpage(prompt)
      
      console.log('[AI-Prompt API] 🛠️ Using professional fallback system')
      console.log(`[AI-Prompt API] 📁 Created ${fallbackResult.files.length} fallback files: ${fallbackResult.files.map(f => f.name).join(', ')}`)
      
      return NextResponse.json({
        success: true,
        files: fallbackResult.files,
        explanation: fallbackResult.explanation + ' (Using professional fallback template)'
      })
    }

  } catch (error) {
    console.error('[AI-Prompt API] ❌ Unexpected error:', error)
    
    // Even in unexpected errors, provide fallback
    try {
      const body = await request.json()
      const prompt = body.prompt || 'website'
      const fallbackResult = webpageGenerator.createFallbackWebpage(prompt)
      
      return NextResponse.json({
        success: true,
        files: fallbackResult.files,
        explanation: fallbackResult.explanation + ' (Emergency fallback)'
      })
    } catch {
      // Ultimate fallback if even parsing fails
      return NextResponse.json({
        success: true,
        files: webpageGenerator.createFallbackWebpage('website').files,
        explanation: 'Ultimate fallback webpage created'
      })
    }
  }
}