// Debug script to check what the API is returning
const testAPI = async () => {
  console.log('🔍 Debugging API Response...');
  
  try {
    const response = await fetch('http://localhost:3000/api/ai-prompt', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: "Create a simple test webpage",
        type: 'complete-webpage'
      })
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const data = await response.json();
    
    console.log('📊 Full API Response:');
    console.log(JSON.stringify(data, null, 2));
    
    if (data.files && data.files.length > 0) {
      console.log('\n📄 Generated Files:');
      data.files.forEach((file, index) => {
        console.log(`\n--- File ${index + 1}: ${file.name} (${file.language}) ---`);
        console.log(file.content.substring(0, 500) + '...');
      });
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
};

testAPI();