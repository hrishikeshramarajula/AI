// Test script to check OpenRouter API connection
const testAIConnection = async () => {
  console.log('🧪 Testing OpenRouter API Connection...');
  
  try {
    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer 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',
        'Content-Type': 'application/json',
        'HTTP-Referer': 'http://localhost:3000',
        'X-Title': 'AI-IDE Connection Test'
      },
      body: JSON.stringify({
        model: 'mistralai/mistral-7b-instruct',
        messages: [
          {
            role: 'system',
            content: 'You are a helpful assistant.'
          },
          {
            role: 'user',
            content: 'Hello! Can you help me test this connection? Just respond with "Connection test successful!"'
          }
        ],
        temperature: 0.7,
        max_tokens: 50
      })
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const data = await response.json();
    console.log('✅ OpenRouter API connection successful');
    console.log('Response:', data.choices[0]?.message?.content);
    
    return true;
    
  } catch (error) {
    console.error('❌ OpenRouter API Connection Test Failed:');
    console.error('Error:', error.message);
    
    // Try to get more error details
    if (error.message.includes('HTTP error! status:')) {
      const status = error.message.split('status: ')[1];
      console.error('Status Code:', status);
      console.error('This might indicate:');
      console.error('- Invalid API key');
      console.error('- Model not available');
      console.error('- Rate limiting');
      console.error('- Invalid request format');
    }
    return false;
  }
};

// Run the test
testAIConnection().then(success => {
  if (success) {
    console.log('🎉 OpenRouter API Connection Test PASSED!');
  } else {
    console.log('💥 OpenRouter API Connection Test FAILED!');
  }
});