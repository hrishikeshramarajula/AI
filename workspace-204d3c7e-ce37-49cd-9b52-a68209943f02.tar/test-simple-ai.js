// Simple test of enhanced AI
const testSimpleEnhancedAI = async () => {
  console.log('🧠 TESTING SIMPLE ENHANCED AI\n');
  
  try {
    const response = await fetch('http://localhost:3000/api/premium-webpage', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: 'Create a business website',
        features: ['navigation', 'hero', 'services', 'contact', 'footer']
      })
    });
    
    console.log('📊 Response status:', response.status);
    
    if (!response.ok) {
      const errorText = await response.text();
      console.log('❌ Error response:', errorText);
      return;
    }
    
    const data = await response.json();
    console.log('✅ Success:', data.success);
    console.log('📁 Files:', data.files?.length || 0);
    
    if (data.files && data.files.length > 0) {
      const htmlFile = data.files.find(f => f.language === 'html');
      if (htmlFile) {
        console.log('📝 HTML content length:', htmlFile.content.length);
        
        // Check for intelligent content
        const content = htmlFile.content.toLowerCase();
        const intelligentWords = ['elevate', 'professional', 'strategy', 'excellence', 'innovative'];
        const foundWords = intelligentWords.filter(word => content.includes(word));
        
        console.log('🧠 Intelligent words found:', foundWords.length, '/', intelligentWords.length);
        console.log('📝 Found words:', foundWords);
        
        if (foundWords.length >= 3) {
          console.log('🎉 AI is generating intelligent content!');
        } else {
          console.log('⚠️ AI content needs improvement');
        }
      }
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
};

testSimpleEnhancedAI();