// Test the fallback generation system
const testFallback = async () => {
  console.log('🛠️ Testing Fallback Generation System...');
  
  try {
    const response = await fetch('http://localhost:3000/api/ai-prompt', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: "Create a beautiful portfolio website for a web developer",
        type: 'complete-webpage'
      })
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const data = await response.json();
    
    console.log('📊 Fallback Test Results:');
    console.log(`✅ Success: ${data.success}`);
    console.log(`📁 Files Generated: ${data.files?.length || 0}`);
    
    if (data.files && data.files.length > 0) {
      data.files.forEach((file, index) => {
        console.log(`\n--- File ${index + 1}: ${file.name} ---`);
        console.log(`Language: ${file.language}`);
        console.log(`Content Length: ${file.content.length} characters`);
        if (file.content.length > 0) {
          console.log('✅ Content generated successfully');
          console.log('Preview:', file.content.substring(0, 200) + '...');
        } else {
          console.log('❌ Empty content');
        }
      });
    }
    
    console.log('\n🎯 Test Summary:');
    if (data.success && data.files && data.files.length > 0 && data.files[0].content.length > 0) {
      console.log('✅ Fallback system is working!');
      console.log('✅ Ready to demonstrate on homepage');
    } else {
      console.log('❌ Fallback system needs attention');
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
};

testFallback();