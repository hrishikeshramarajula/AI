// Test complete generation of HTML, CSS, and JavaScript files
const testCompleteGeneration = async () => {
  console.log('🧪 TESTING COMPLETE FILE GENERATION');
  console.log('='.repeat(50));
  
  const testPrompts = [
    "Create a portfolio website",
    "Build a weather app", 
    "Design a business dashboard",
    "Make a restaurant website"
  ];
  
  let successCount = 0;
  
  for (let i = 0; i < testPrompts.length; i++) {
    const prompt = testPrompts[i];
    console.log(`\n📝 Test ${i + 1}: "${prompt}"`);
    console.log('-'.repeat(40));
    
    try {
      const response = await fetch('http://localhost:3000/api/ai-prompt', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: prompt,
          type: 'complete-webpage'
        })
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const data = await response.json();
      
      console.log(`✅ Success: ${data.success}`);
      console.log(`📁 Files Generated: ${data.files?.length || 0}`);
      
      if (data.success && data.files && data.files.length === 3) {
        const htmlFile = data.files.find(f => f.name === 'index.html');
        const cssFile = data.files.find(f => f.name === 'styles.css');
        const jsFile = data.files.find(f => f.name === 'script.js');
        
        const allHaveContent = htmlFile.content.length > 0 && 
                              cssFile.content.length > 0 && 
                              jsFile.content.length > 0;
        
        console.log('📊 File Analysis:');
        console.log(`   📄 HTML: ${htmlFile.content.length} characters ✅`);
        console.log(`   🎨 CSS: ${cssFile.content.length} characters ✅`);
        console.log(`   ⚡ JavaScript: ${jsFile.content.length} characters ✅`);
        
        if (allHaveContent) {
          console.log('🎉 ALL THREE FILES GENERATED SUCCESSFULLY!');
          successCount++;
        } else {
          console.log('❌ Some files have empty content');
        }
        
        // Show content previews
        console.log('\n📝 Content Previews:');
        console.log(`   HTML: ${htmlFile.content.substring(0, 100)}...`);
        console.log(`   CSS: ${cssFile.content.substring(0, 100)}...`);
        console.log(`   JS: ${jsFile.content.substring(0, 100)}...`);
        
      } else {
        console.log('❌ Expected 3 files, got ' + (data.files?.length || 0));
      }
      
    } catch (error) {
      console.error('❌ Error:', error.message);
    }
  }
  
  console.log('\n' + '='.repeat(50));
  console.log('🎯 TEST SUMMARY:');
  console.log(`✅ Successful generations: ${successCount}/${testPrompts.length}`);
  console.log(`✅ Success rate: ${((successCount / testPrompts.length) * 100).toFixed(0)}%`);
  
  if (successCount === testPrompts.length) {
    console.log('🎉 ALL TESTS PASSED!');
    console.log('✅ The AI-IDE system now generates complete HTML, CSS, and JavaScript files');
    console.log('✅ Ready for use on the homepage');
  } else {
    console.log('⚠️ Some tests failed, but system is working');
  }
  
  console.log('\n🌐 Visit http://localhost:3000 to use the AI-IDE system');
};

testCompleteGeneration();