// 🚀 Enhanced Deep Research API Endpoint
// Comprehensive research analysis with advanced NLP, knowledge graphs, and multi-source processing

import { NextRequest, NextResponse } from 'next/server';
import { EnhancedDeepResearchTextProcessor, ResearchAnalysis } from '@/lib/deepResearch/enhancedTextProcessor';
import { KnowledgeGraphConstructor } from '@/lib/deepResearch/knowledgeGraph';
import { AdvancedTopicSentimentAnalyzer } from '@/lib/deepResearch/topicSentimentAnalyzer';
import { performWebSearch } from '@/lib/search';
import { wikipediaAPI, WikipediaArticle } from '@/lib/wikipediaAPI';
import { createSuccessResponse, createErrorResponse, withErrorHandling } from '@/lib/apiUtils';
import { safeZAIChatCompletion } from '@/lib/zaiHelper';

export interface DeepResearchRequest {
  query: string;
  researchDepth?: 'basic' | 'detailed' | 'comprehensive' | 'encyclopedic';
  includeWebSearch?: boolean;
  includeKnowledgeGraph?: boolean;
  includeTopicModeling?: boolean;
  includeSentimentAnalysis?: boolean;
  includeEmotionalIntelligence?: boolean;
  includePsychologicalProfile?: boolean;
  maxSources?: number;
  analysisType?: 'academic' | 'business' | 'technical' | 'general';
  timeFrame?: 'current' | 'historical' | 'future' | 'comparative';
  outputFormat?: 'summary' | 'detailed' | 'comprehensive' | 'executive';
}

export interface DeepResearchResponse {
  success: boolean;
  researchId: string;
  timestamp: string;
  query: string;
  processingTime: number;
  analysis: {
    textAnalysis: ResearchAnalysis;
    knowledgeGraph?: {
      nodes: any[];
      edges: any[];
      metrics: any;
      communities: any[];
      centrality: any;
    };
    topicModeling?: {
      topics: any[];
      documentTopicDistribution: number[];
      topicEvolution: any[];
      topicHierarchy: any;
      qualityMetrics: any;
    };
    sentimentAnalysis?: any;
    emotionalIntelligence?: any;
    psychologicalProfile?: any;
  };
  webSearch?: {
    results: any[];
    sources: string[];
    searchTime: number;
  };
  insights: {
    keyFindings: string[];
    knowledgeGaps: string[];
    researchQuestions: string[];
    recommendations: string[];
    nextSteps: string[];
  };
  metadata: {
    analysisDepth: string;
    processingSteps: string[];
    dataSources: string[];
    confidence: number;
    qualityScore: number;
    completeness: number;
  };
}

export class DeepResearchProcessor {
  private textProcessor: EnhancedDeepResearchTextProcessor;
  private knowledgeGraphConstructor: KnowledgeGraphConstructor;
  private topicSentimentAnalyzer: AdvancedTopicSentimentAnalyzer;

  constructor() {
    this.textProcessor = new EnhancedDeepResearchTextProcessor();
    this.knowledgeGraphConstructor = new KnowledgeGraphConstructor();
    this.topicSentimentAnalyzer = new AdvancedTopicSentimentAnalyzer();
  }

  async processDeepResearch(request: DeepResearchRequest): Promise<DeepResearchResponse> {
    const startTime = Date.now();
    const researchId = `research_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    console.log('🚀 Starting enhanced deep research processing...');
    console.log('📝 Query:', request.query);
    console.log('🔍 Research Depth:', request.researchDepth);

    try {
      const processingSteps: string[] = [];
      const dataSources: string[] = [];

      // Step 1: Enhanced Multi-Source Data Collection
      let webSearchResults: any[] = [];
      let wikipediaArticles: WikipediaArticle[] = [];
      let webSearchTime = 0;
      let wikipediaTime = 0;

      if (request.includeWebSearch) {
        processingSteps.push('Multi-Source Data Collection');
        dataSources.push('web_search', 'wikipedia_api');
        console.log('🌐 Performing enhanced multi-source data collection...');
        
        const searchStartTime = Date.now();
        
        try {
          // Parallel execution: Web Search + Wikipedia
          const [webSearchPromise, wikipediaPromise] = await Promise.allSettled([
            // Enhanced web search
            (async () => {
              try {
                const results = await performWebSearch(request.query);
                
                // If we need more sources, perform additional searches
                if (results.length < (request.maxSources || 20)) {
                  const additionalQueries = [
                    `${request.query} research analysis`,
                    `${request.query} comprehensive study`,
                    `${request.query} data statistics`
                  ];
                  
                  for (const query of additionalQueries) {
                    if (results.length >= (request.maxSources || 20)) break;
                    try {
                      const additionalResults = await performWebSearch(query);
                      results.push(...additionalResults);
                    } catch (searchError) {
                      console.warn(`Additional search failed for query "${query}":`, searchError);
                    }
                  }
                }
                
                // Remove duplicates and limit to source count
                const uniqueResults = results.filter((result, index, self) =>
                  index === self.findIndex(r => r.url === result.url)
                );
                
                return uniqueResults.slice(0, request.maxSources || 20);
              } catch (searchError) {
                console.warn('Web search failed:', searchError);
                return []; // Return empty array on failure
              }
            })(),
            
            // Wikipedia API integration
            (async () => {
              try {
                // Search Wikipedia articles
                const wikiSearchResults = await wikipediaAPI.searchArticles(request.query, 10);
                
                // Get full article content for top results
                const topArticleIds = wikiSearchResults.slice(0, 5).map(result => result.pageid);
                const articles = await wikipediaAPI.getMultipleArticles(topArticleIds);
                
                // Get related articles for broader coverage
                if (articles.length > 0) {
                  const relatedArticles = await wikipediaAPI.getRelatedArticles(
                    articles.slice(0, 3).map(a => a.pageid), 
                    5
                  );
                  articles.push(...relatedArticles);
                }
                
                return articles;
              } catch (wikiError) {
                console.warn('Wikipedia API integration failed:', wikiError);
                return []; // Return empty array on failure
              }
            })()
          ]);

          // Handle results
          if (webSearchPromise.status === 'fulfilled') {
            webSearchResults = webSearchPromise.value;
            console.log(`✅ Web search completed: ${webSearchResults.length} results`);
          } else {
            console.warn('Web search failed:', webSearchPromise.reason);
          }

          if (wikipediaPromise.status === 'fulfilled') {
            wikipediaArticles = wikipediaPromise.value;
            console.log(`✅ Wikipedia API completed: ${wikipediaArticles.length} articles`);
          } else {
            console.warn('Wikipedia API failed:', wikipediaPromise.reason);
          }

          webSearchTime = Date.now() - searchStartTime;
          console.log(`✅ Multi-source collection completed in ${webSearchTime}ms`);

        } catch (searchError) {
          console.warn('Multi-source collection failed, continuing with basic processing:', searchError);
          webSearchResults = [];
          wikipediaArticles = [];
        }
      }

      // Step 2: Enhanced Text Preparation with Quality Filtering
      processingSteps.push('Enhanced Text Preparation');
      dataSources.push('query_analysis', 'content_filtering');
      
      let researchText = request.query;
      
      // Process and integrate Wikipedia content (high-quality source)
      if (wikipediaArticles.length > 0) {
        console.log('📚 Processing Wikipedia content for high-quality research data...');
        
        const wikiContent = wikipediaAPI.extractResearchContent(wikipediaArticles);
        
        if (wikiContent.quality > 0.5) {
          researchText += '\n\n=== HIGH-QUALITY WIKIPEDIA RESEARCH ===\n';
          researchText += `Content Quality Score: ${(wikiContent.quality * 100).toFixed(1)}%\n\n`;
          researchText += wikiContent.content;
          
          // Add extracted topics and entities
          if (wikiContent.topics.length > 0) {
            researchText += '\n\n=== EXTRACTED TOPICS ===\n';
            researchText += wikiContent.topics.slice(0, 10).join(', ');
          }
          
          if (wikiContent.entities.length > 0) {
            researchText += '\n\n=== IDENTIFIED ENTITIES ===\n';
            researchText += wikiContent.entities.slice(0, 15).join(', ');
          }
          
          console.log(`✅ Wikipedia content processed: ${wikiContent.content.length} characters, quality: ${(wikiContent.quality * 100).toFixed(1)}%`);
        }
      }
      
      // Process web search results with enhanced filtering
      if (webSearchResults.length > 0) {
        console.log('🔍 Processing web search results with quality filtering...');
        
        // Enhanced text preparation with quality filtering
        const filteredSources = await this.filterAndEnhanceWebResults(webSearchResults);
        
        if (filteredSources.length > 0) {
          researchText += '\n\n=== ENHANCED WEB RESEARCH SOURCES ===\n';
          
          const enhancedSources = filteredSources
            .slice(0, request.maxSources || 15)
            .map((result, index) => {
              return `
Source ${index + 1}: ${result.name}
URL: ${result.url}
Host: ${result.host_name}
Quality Score: ${result.qualityScore || 'N/A'}
Relevance: ${result.relevanceScore || 'N/A'}
Content: ${this.cleanAndValidateSnippet(result.snippet)}
---
`;
            }).join('\n');
          
          researchText += enhancedSources;
          
          // Extract enhanced shared knowledge analysis
          const sharedKnowledge = this.extractEnhancedSharedKnowledge(filteredSources);
          researchText += '\n\n=== SHARED KNOWLEDGE ANALYSIS ===\n' + sharedKnowledge;
          
          // Add multimedia content analysis
          const multimediaContent = this.analyzeMultimediaContent(filteredSources);
          researchText += '\n\n=== MULTIMEDIA CONTENT ANALYSIS ===\n' + multimediaContent;
          
          console.log(`✅ Web search results processed: ${filteredSources.length} high-quality sources`);
        } else {
          console.log('⚠️ No high-quality web sources found after filtering');
        }
      }

      // Step 3: Advanced Text Analysis (with fallback)
      processingSteps.push('Text Analysis');
      dataSources.push('nlp_processing');
      console.log('🔍 Performing advanced text analysis...');
      
      let textAnalysis: ResearchAnalysis;
      try {
        textAnalysis = await this.textProcessor.processText(researchText, {
          includeSentiment: request.includeSentimentAnalysis,
          includeTopics: request.includeTopicModeling,
          includeEntities: true,
          includeKnowledgeGraph: request.includeKnowledgeGraph,
          analysisDepth: request.researchDepth
        });
      } catch (analysisError) {
        console.warn('Text analysis failed, using fallback analysis:', analysisError);
        // Create a minimal fallback analysis
        textAnalysis = {
          entities: [],
          topics: [],
          keywords: [],
          summary: researchText.substring(0, 500) + (researchText.length > 500 ? '...' : ''),
          sentiment: {
            overall: 'neutral',
            confidence: 0.5,
            aspects: []
          },
          qualityScore: 0.3
        } as ResearchAnalysis;
      }

      // Step 4: Knowledge Graph Construction (if enabled, with fallback)
      let knowledgeGraph: any;
      if (request.includeKnowledgeGraph) {
        try {
          processingSteps.push('Knowledge Graph');
          dataSources.push('knowledge_graph');
          console.log('🕸️ Building knowledge graph...');
          
          knowledgeGraph = this.knowledgeGraphConstructor.buildEnhancedKnowledgeGraph(
            textAnalysis.entities,
            textAnalysis.topics,
            {
              includeSemanticRelationships: true,
              includeTemporalRelationships: true,
              includeCausalRelationships: true,
              minConfidence: 0.3,
              maxNodes: request.researchDepth === 'encyclopedic' ? 200 : 100
            }
          );
          console.log(`✅ Knowledge graph built: ${knowledgeGraph.metrics.nodes} nodes, ${knowledgeGraph.metrics.edges} edges`);
        } catch (kgError) {
          console.warn('Knowledge graph construction failed:', kgError);
          // Create a minimal fallback knowledge graph
          knowledgeGraph = {
            nodes: [],
            edges: [],
            metrics: { nodes: 0, edges: 0 },
            communities: [],
            centrality: {}
          };
        }
      }

      // Step 5: Advanced Topic Modeling (if enabled, with fallback)
      let topicModeling: any;
      if (request.includeTopicModeling) {
        try {
          processingSteps.push('Topic Modeling');
          dataSources.push('topic_modeling');
          console.log('📊 Performing advanced topic modeling...');
          
          const documents = [researchText, ...webSearchResults.map(r => r.snippet)];
          topicModeling = await this.topicSentimentAnalyzer.performAdvancedTopicModeling(
            documents,
            {
              numTopics: request.researchDepth === 'encyclopedic' ? 12 : request.researchDepth === 'comprehensive' ? 8 : 6,
              algorithm: 'LDA',
              includeSentiment: request.includeSentimentAnalysis,
              temporalAnalysis: true,
              hierarchical: true
            }
          );
          console.log(`✅ Topic modeling completed: ${topicModeling.topics.length} topics`);
        } catch (tmError) {
          console.warn('Topic modeling failed:', tmError);
          // Create a minimal fallback topic modeling
          topicModeling = {
            topics: [],
            documentTopicDistribution: [],
            topicEvolution: [],
            topicHierarchy: {},
            qualityMetrics: { coherence: 0, diversity: 0 }
          };
        }
      }

      // Step 6: Advanced Sentiment Analysis (if enabled, with fallback)
      let sentimentAnalysis: any;
      let emotionalIntelligence: any;
      let psychologicalProfile: any;

      if (request.includeSentimentAnalysis) {
        try {
          processingSteps.push('Sentiment Analysis');
          dataSources.push('sentiment_analysis');
          console.log('🧠 Performing advanced sentiment analysis...');
          
          sentimentAnalysis = await this.topicSentimentAnalyzer.performAdvancedSentimentAnalysis(
            researchText,
            {
              includeEmotionalIntelligence: request.includeEmotionalIntelligence,
              includePsychologicalProfile: request.includePsychologicalProfile,
              includeConflictAnalysis: true,
              includePersuasionAnalysis: true,
              temporalAnalysis: true
            }
          );

          if (request.includeEmotionalIntelligence) {
            emotionalIntelligence = sentimentAnalysis.emotionalIntelligence;
          }

          if (request.includePsychologicalProfile) {
            psychologicalProfile = sentimentAnalysis.psychologicalProfile;
          }

          console.log('✅ Advanced sentiment analysis completed');
        } catch (saError) {
          console.warn('Sentiment analysis failed:', saError);
          // Create a minimal fallback sentiment analysis
          sentimentAnalysis = {
            overall: 'neutral',
            confidence: 0.5,
            aspects: [],
            emotionalIntelligence: request.includeEmotionalIntelligence ? {} : undefined,
            psychologicalProfile: request.includePsychologicalProfile ? {} : undefined
          };
          emotionalIntelligence = request.includeEmotionalIntelligence ? {} : undefined;
          psychologicalProfile = request.includePsychologicalProfile ? {} : undefined;
        }
      }

      // Step 7: Generate Comprehensive Insights (with fallback)
      processingSteps.push('Insight Generation');
      dataSources.push('insight_synthesis');
      console.log('💡 Generating research insights...');
      
      let insights;
      try {
        insights = this.generateComprehensiveInsights(
          textAnalysis,
          knowledgeGraph,
          topicModeling,
          sentimentAnalysis,
          request
        );
      } catch (insightError) {
        console.warn('Insight generation failed, using fallback insights:', insightError);
        // Create minimal fallback insights
        insights = {
          keyFindings: [`Research conducted on: ${request.query}`],
          knowledgeGaps: ['Further research may be needed for comprehensive analysis'],
          researchQuestions: [`What are the latest developments in ${request.query}?`],
          recommendations: ['Consider consulting additional sources for more comprehensive information'],
          nextSteps: ['Review current findings and identify areas for further investigation']
        };
      }

      // Step 8: Calculate Quality Metrics (with fallback)
      let qualityMetrics;
      try {
        qualityMetrics = this.calculateQualityMetrics(
          textAnalysis,
          knowledgeGraph,
          topicModeling,
          sentimentAnalysis,
          processingSteps.length
        );
      } catch (qmError) {
        console.warn('Quality metrics calculation failed, using fallback metrics:', qmError);
        // Create fallback quality metrics
        qualityMetrics = {
          confidence: 0.5,
          qualityScore: 0.5,
          completeness: 0.5
        };
      }

      const processingTime = Date.now() - startTime;

      console.log(`🎉 Deep research completed in ${processingTime}ms`);

      // Step 9: Format Response
      const response: DeepResearchResponse = {
        success: true,
        researchId,
        timestamp: new Date().toISOString(),
        query: request.query,
        processingTime,
        analysis: {
          textAnalysis,
          knowledgeGraph,
          topicModeling,
          sentimentAnalysis,
          emotionalIntelligence,
          psychologicalProfile
        },
        webSearch: webSearchResults.length > 0 ? {
          results: webSearchResults,
          sources: webSearchResults.map(r => r.host_name),
          searchTime: webSearchTime
        } : undefined,
        insights,
        metadata: {
          analysisDepth: request.researchDepth || 'comprehensive',
          processingSteps,
          dataSources,
          confidence: qualityMetrics.confidence,
          qualityScore: qualityMetrics.qualityScore,
          completeness: qualityMetrics.completeness
        }
      };

      return response;

    } catch (error) {
      console.error('❌ Deep research processing failed:', error);
      throw error;
    }
  }

  private generateComprehensiveInsights(
    textAnalysis: ResearchAnalysis,
    knowledgeGraph: any,
    topicModeling: any,
    sentimentAnalysis: any,
    request: DeepResearchRequest
  ) {
    const keyFindings: string[] = [];
    const knowledgeGaps: string[] = [];
    const researchQuestions: string[] = [];
    const recommendations: string[] = [];
    const nextSteps: string[] = [];

    // Generate key findings from text analysis
    if (textAnalysis.entities.length > 0) {
      const topEntities = textAnalysis.entities.slice(0, 5);
      keyFindings.push(`Identified ${textAnalysis.entities.length} key entities, including: ${topEntities.map(e => e.text).join(', ')}`);
    }

    if (textAnalysis.topics.length > 0) {
      const mainTopics = textAnalysis.topics.slice(0, 3);
      keyFindings.push(`Discovered ${textAnalysis.topics.length} thematic areas, primarily focusing on: ${mainTopics.map(t => t.description).join('; ')}`);
    }

    if (sentimentAnalysis && sentimentAnalysis.overall) {
      keyFindings.push(`Overall sentiment: ${sentimentAnalysis.overall.sentiment} (${(sentimentAnalysis.overall.confidence * 100).toFixed(0)}% confidence)`);
    }

    // Add knowledge graph insights
    if (knowledgeGraph) {
      keyFindings.push(`Knowledge graph reveals ${knowledgeGraph.metrics.nodes} interconnected concepts with ${knowledgeGraph.metrics.edges} relationships`);
      
      if (knowledgeGraph.communities.length > 0) {
        keyFindings.push(`Identified ${knowledgeGraph.communities.length} distinct knowledge communities`);
      }
    }

    // Add topic modeling insights
    if (topicModeling) {
      keyFindings.push(`Advanced topic modeling identified ${topicModeling.topics.length} sophisticated themes with ${topicModeling.qualityMetrics.overallCoherence.toFixed(2)} coherence`);
      
      if (topicModeling.topicEvolution.length > 0) {
        const evolvingTopics = topicModeling.topicEvolution.filter(te => te.trend !== 'stable');
        if (evolvingTopics.length > 0) {
          keyFindings.push(`Detected ${evolvingTopics.length} topics with significant evolutionary patterns`);
        }
      }
    }

    // Generate knowledge gaps
    knowledgeGaps.push(
      'Limited longitudinal data may restrict trend analysis',
      'Cross-cultural perspectives could provide additional insights',
      'Quantitative metrics would complement qualitative findings',
      'Real-time data integration could enhance timeliness of insights'
    );

    if (textAnalysis.entities.filter(e => e.category === 'temporal').length === 0) {
      knowledgeGaps.push('Missing temporal context may limit historical analysis');
    }

    if (sentimentAnalysis && sentimentAnalysis.emotionalIntelligence) {
      const emotionalComplexity = sentimentAnalysis.emotionalIntelligence.emotionalComplexity;
      if (emotionalComplexity < 0.5) {
        knowledgeGaps.push('Limited emotional depth analysis available');
      }
    }

    // Generate research questions
    researchQuestions.push(
      'What are the underlying causal mechanisms driving the observed patterns?',
      'How do the identified entities and concepts interact in dynamic systems?',
      'What are the long-term implications of current trends and developments?',
      'How might different contexts or environments alter these findings?',
      'What additional data sources would provide a more comprehensive understanding?',
      'How do these insights compare to established theories and frameworks?'
    );

    // Generate recommendations
    recommendations.push(
      'Implement continuous monitoring to track evolving trends and patterns',
      'Develop multi-dimensional analysis frameworks incorporating quantitative and qualitative methods',
      'Establish cross-disciplinary research teams to address complex questions',
      'Create adaptive research methodologies that can respond to emerging insights',
      'Build knowledge management systems to capture and share research findings',
      'Develop predictive models based on identified patterns and relationships'
    );

    // Generate next steps
    nextSteps.push(
      'Conduct follow-up research on high-impact entities and relationships',
      'Validate findings through expert consultation and peer review',
      'Expand analysis to include additional data sources and perspectives',
      'Develop visualizations and interactive tools for exploring knowledge graphs',
      'Create implementation roadmaps based on research insights',
      'Establish monitoring frameworks for tracking key metrics and indicators'
    );

    // Add specific recommendations based on analysis type
    switch (request.analysisType) {
      case 'academic':
        recommendations.push('Consider publication in peer-reviewed journals', 'Develop theoretical frameworks based on findings');
        break;
      case 'business':
        recommendations.push('Develop strategic initiatives based on insights', 'Create competitive intelligence frameworks');
        break;
      case 'technical':
        recommendations.push('Implement technical solutions based on findings', 'Develop prototypes and proof-of-concepts');
        break;
      case 'general':
        recommendations.push('Share insights with relevant stakeholders', 'Develop action plans for key findings');
        break;
    }

    return {
      keyFindings,
      knowledgeGaps,
      researchQuestions,
      recommendations,
      nextSteps
    };
  }

  private calculateQualityMetrics(
    textAnalysis: ResearchAnalysis,
    knowledgeGraph: any,
    topicModeling: any,
    sentimentAnalysis: any,
    processingSteps: number
  ) {
    let confidence = 0.7; // Base confidence
    let qualityScore = 0.7; // Base quality
    let completeness = 0.5; // Base completeness

    // Boost confidence based on text analysis quality
    confidence += textAnalysis.metadata.confidence * 0.2;
    qualityScore += textAnalysis.metadata.confidence * 0.2;

    // Boost metrics based on knowledge graph
    if (knowledgeGraph) {
      const graphDensity = knowledgeGraph.metrics.density;
      const avgDegree = knowledgeGraph.metrics.averageDegree;
      
      confidence += Math.min(graphDensity * 2, 0.1);
      qualityScore += Math.min(avgDegree / 10, 0.1);
      completeness += 0.2;
    }

    // Boost metrics based on topic modeling
    if (topicModeling) {
      const topicCoherence = topicModeling.qualityMetrics.overallCoherence;
      const topicDiversity = topicModeling.qualityMetrics.topicDiversity;
      
      confidence += topicCoherence * 0.1;
      qualityScore += topicDiversity * 0.1;
      completeness += 0.2;
    }

    // Boost metrics based on sentiment analysis
    if (sentimentAnalysis) {
      const sentimentConfidence = sentimentAnalysis.overall.confidence;
      confidence += sentimentConfidence * 0.1;
      qualityScore += sentimentConfidence * 0.1;
      completeness += 0.1;
    }

    // Boost based on processing completeness
    completeness += Math.min(processingSteps / 8, 0.2);

    // Normalize scores
    confidence = Math.min(confidence, 1.0);
    qualityScore = Math.min(qualityScore, 1.0);
    completeness = Math.min(completeness, 1.0);

    return {
      confidence,
      qualityScore,
      completeness
    };
  }

  private extractEnhancedSharedKnowledge(webSearchResults: any[]): string {
    console.log('🧠 Extracting enhanced shared knowledge from web search results...');
    
    const allSnippets = webSearchResults.map(r => r.snippet.toLowerCase());
    const allTitles = webSearchResults.map(r => r.name.toLowerCase());
    
    // Find common keywords across sources
    const commonKeywords = this.findCommonKeywords([...allSnippets, ...allTitles]);
    
    // Identify shared themes
    const sharedThemes = this.identifySharedThemes(allSnippets);
    
    // Extract statistical patterns
    const uniqueHosts = [...new Set(webSearchResults.map(r => r.host_name))];
    const avgSnippetLength = Math.round(allSnippets.reduce((sum, snippet) => sum + snippet.length, 0) / allSnippets.length);
    
    // Build enhanced shared knowledge summary
    const sharedKnowledge = `
**Common Keywords Across Sources:**
${commonKeywords.slice(0, 15).map((keyword, index) => `${index + 1}. ${keyword}`).join('\n')}

**Shared Themes Identified:**
${sharedThemes.slice(0, 8).map((theme, index) => `${index + 1}. ${theme}`).join('\n')}

**Statistical Analysis:**
- Total Sources Analyzed: ${webSearchResults.length}
- Average Snippet Length: ${avgSnippetLength} characters
- Unique Hosts: ${uniqueHosts.length}
- Content Overlap: ${this.calculateContentOverlap(allSnippets).toFixed(2)}%

**Cross-Source Insights:**
${this.generateCrossSourceInsights(webSearchResults)}
    `.trim();
    
    console.log('✅ Enhanced shared knowledge extraction completed');
    return sharedKnowledge;
  }

  private analyzeMultimediaContent(webSearchResults: any[]): string {
    console.log('🎨 Analyzing multimedia content in search results...');
    
    const multimediaDetection = {
      images: 0,
      videos: 0,
      audio: 0,
      documents: 0,
      interactive: 0,
      datasets: 0
    };
    
    const multimediaSources: string[] = [];
    const contentTypes: string[] = [];
    
    // Analyze each search result for multimedia indicators
    webSearchResults.forEach((result, index) => {
      const url = result.url.toLowerCase();
      const snippet = result.snippet.toLowerCase();
      const title = result.name.toLowerCase();
      
      // Detect images
      if (url.includes('image') || url.includes('img') || url.includes('photo') || 
          snippet.includes('image') || snippet.includes('photo') || snippet.includes('picture')) {
        multimediaDetection.images++;
        multimediaSources.push(`Source ${index + 1}: ${result.name} - Image Content`);
        contentTypes.push('Images');
      }
      
      // Detect videos
      if (url.includes('video') || url.includes('watch') || url.includes('youtube') || url.includes('vimeo') ||
          snippet.includes('video') || snippet.includes('watch') || snippet.includes('film')) {
        multimediaDetection.videos++;
        multimediaSources.push(`Source ${index + 1}: ${result.name} - Video Content`);
        contentTypes.push('Videos');
      }
      
      // Detect audio
      if (url.includes('audio') || url.includes('sound') || url.includes('music') || url.includes('podcast') ||
          snippet.includes('audio') || snippet.includes('sound') || snippet.includes('music')) {
        multimediaDetection.audio++;
        multimediaSources.push(`Source ${index + 1}: ${result.name} - Audio Content`);
        contentTypes.push('Audio');
      }
      
      // Detect documents
      if (url.includes('pdf') || url.includes('doc') || url.includes('document') || url.includes('report') ||
          snippet.includes('pdf') || snippet.includes('document') || snippet.includes('report')) {
        multimediaDetection.documents++;
        multimediaSources.push(`Source ${index + 1}: ${result.name} - Document Content`);
        contentTypes.push('Documents');
      }
      
      // Detect interactive content
      if (url.includes('interactive') || url.includes('simulation') || url.includes('demo') ||
          snippet.includes('interactive') || snippet.includes('simulation')) {
        multimediaDetection.interactive++;
        multimediaSources.push(`Source ${index + 1}: ${result.name} - Interactive Content`);
        contentTypes.push('Interactive');
      }
      
      // Detect datasets
      if (url.includes('data') || url.includes('dataset') || url.includes('statistics') ||
          snippet.includes('data') || snippet.includes('statistics') || snippet.includes('dataset')) {
        multimediaDetection.datasets++;
        multimediaSources.push(`Source ${index + 1}: ${result.name} - Dataset Content`);
        contentTypes.push('Datasets');
      }
    });
    
    // Generate multimedia analysis report
    const multimediaReport = `
**Multimedia Content Detection Results:**

**Content Type Distribution:**
- 📸 Images: ${multimediaDetection.images} sources
- 🎥 Videos: ${multimediaDetection.videos} sources  
- 🎵 Audio: ${multimediaDetection.audio} sources
- 📄 Documents: ${multimediaDetection.documents} sources
- 🎮 Interactive: ${multimediaDetection.interactive} sources
- 📊 Datasets: ${multimediaDetection.datasets} sources

**Multimedia-Rich Sources:**
${multimediaSources.slice(0, 10).join('\n')}

**Content Diversity Analysis:**
- Total Content Types Detected: ${[...new Set(contentTypes)].length}
- Multimedia-Rich Sources: ${multimediaSources.length} out of ${webSearchResults.length}
- Content Variety Score: ${((multimediaDetection.images + multimediaDetection.videos + multimediaDetection.audio + multimediaDetection.documents + multimediaDetection.interactive + multimediaDetection.datasets) / webSearchResults.length * 100).toFixed(1)}%

**Visual Content Availability:**
${this.generateVisualContentSummary(webSearchResults)}

**Recommended Content Formats for Enhanced Research:**
${this.generateContentFormatRecommendations(multimediaDetection)}
    `.trim();
    
    console.log('✅ Multimedia content analysis completed');
    return multimediaReport;
  }

  private findCommonKeywords(texts: string[]): string[] {
    const wordFreq: { [key: string]: number } = {};
    const stopWords = new Set(['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'must', 'can', 'this', 'that', 'these', 'those']);
    
    texts.forEach(text => {
      const words = text.toLowerCase().match(/\b\w+\b/g) || [];
      words.forEach(word => {
        if (!stopWords.has(word) && word.length > 3) {
          wordFreq[word] = (wordFreq[word] || 0) + 1;
        }
      });
    });
    
    return Object.entries(wordFreq)
      .filter(([word, freq]) => freq >= 2)
      .sort((a, b) => b[1] - a[1])
      .map(([word]) => word);
  }

  private identifySharedThemes(texts: string[]): string[] {
    const themes = [];
    
    // Look for common patterns and themes
    if (texts.some(text => text.includes('research') || text.includes('study'))) {
      themes.push('Academic Research Focus');
    }
    if (texts.some(text => text.includes('data') || text.includes('statistics'))) {
      themes.push('Data-Driven Analysis');
    }
    if (texts.some(text => text.includes('analysis') || text.includes('examination'))) {
      themes.push('Analytical Approach');
    }
    if (texts.some(text => text.includes('development') || text.includes('growth'))) {
      themes.push('Development & Progress');
    }
    if (texts.some(text => text.includes('technology') || text.includes('tech'))) {
      themes.push('Technology Integration');
    }
    if (texts.some(text => text.includes('market') || text.includes('business'))) {
      themes.push('Market & Business Perspective');
    }
    if (texts.some(text => text.includes('social') || text.includes('society'))) {
      themes.push('Social Impact');
    }
    if (texts.some(text => text.includes('global') || text.includes('international'))) {
      themes.push('Global Context');
    }
    
    return themes;
  }

  private calculateContentOverlap(texts: string[]): number {
    if (texts.length < 2) return 0;
    
    const allWords = new Set(texts.join(' ').toLowerCase().match(/\b\w+\b/g) || []);
    let totalOverlap = 0;
    let comparisons = 0;
    
    for (let i = 0; i < texts.length; i++) {
      for (let j = i + 1; j < texts.length; j++) {
        const words1 = new Set(texts[i].toLowerCase().match(/\b\w+\b/g) || []);
        const words2 = new Set(texts[j].toLowerCase().match(/\b\w+\b/g) || []);
        
        const intersection = new Set([...words1].filter(word => words2.has(word)));
        const union = new Set([...words1, ...words2]);
        
        totalOverlap += intersection.size / union.size;
        comparisons++;
      }
    }
    
    return comparisons > 0 ? totalOverlap / comparisons : 0;
  }

  private generateCrossSourceInsights(webSearchResults: any[]): string {
    const insights = [];
    
    // Check for source diversity
    const uniqueHosts = [...new Set(webSearchResults.map(r => r.host_name))];
    if (uniqueHosts.length > 5) {
      insights.push('• High source diversity with multiple perspectives');
    }
    
    // Check for recency
    const recentSources = webSearchResults.filter(r => r.date && new Date(r.date) > new Date(Date.now() - 365 * 24 * 60 * 60 * 1000));
    if (recentSources.length > webSearchResults.length * 0.5) {
      insights.push('• Predominantly recent and up-to-date sources');
    }
    
    // Check for authoritative sources
    const authoritativeHosts = ['gov', 'edu', 'org', 'ac', 'int'];
    const authoritativeCount = webSearchResults.filter(r => 
      authoritativeHosts.some(host => r.host_name.includes(host))
    ).length;
    
    if (authoritativeCount > 0) {
      insights.push(`• ${authoritativeCount} authoritative sources (.gov, .edu, .org)`);
    }
    
    return insights.join('\n');
  }

  private generateVisualContentSummary(webSearchResults: any[]): string {
    const visualIndicators = webSearchResults.filter(r => 
      r.snippet.toLowerCase().includes('image') || 
      r.snippet.toLowerCase().includes('visual') ||
      r.snippet.toLowerCase().includes('chart') ||
      r.snippet.toLowerCase().includes('graph') ||
      r.snippet.toLowerCase().includes('diagram')
    );
    
    if (visualIndicators.length === 0) {
      return 'Limited visual content detected in search results';
    }
    
    return `Visual content detected in ${visualIndicators.length} sources, including charts, graphs, and diagrams that could enhance understanding`;
  }

  private generateContentFormatRecommendations(multimediaDetection: any): string {
    const recommendations = [];
    
    if (multimediaDetection.images > 0) {
      recommendations.push('📸 Image galleries and visual documentation');
    }
    if (multimediaDetection.videos > 0) {
      recommendations.push('🎥 Video presentations and tutorials');
    }
    if (multimediaDetection.documents > 0) {
      recommendations.push('📄 Downloadable reports and documentation');
    }
    if (multimediaDetection.datasets > 0) {
      recommendations.push('📊 Data analysis and visualization tools');
    }
    if (multimediaDetection.interactive > 0) {
      recommendations.push('🎮 Interactive simulations and demos');
    }
    
    if (recommendations.length === 0) {
      return 'Standard text-based analysis recommended';
    }
    
    return recommendations.slice(0, 5).join('\n');
  }

  /**
   * Filter and enhance web search results for better data quality
   */
  private async filterAndEnhanceWebResults(webSearchResults: any[]): Promise<any[]> {
    console.log('🔍 Filtering and enhancing web search results for quality...');
    
    if (!webSearchResults || webSearchResults.length === 0) {
      return [];
    }

    // Pre-filter: Remove obviously invalid results
    const validResults = webSearchResults.filter(result => {
      return result && 
             result.url && 
             result.name && 
             result.snippet &&
             typeof result.snippet === 'string' &&
             result.snippet.length > 20 &&
             !this.isJunkContent(result.snippet);
    });

    if (validResults.length === 0) {
      console.warn('No valid web search results after pre-filtering');
      return [];
    }

    // Calculate quality scores for all results
    const enhancedResults = await Promise.all(
      validResults.map(async (result) => {
        try {
          const qualityScore = await this.calculateResultQuality(result);
          const relevanceScore = this.calculateResultRelevance(result, validResults);
          
          return {
            ...result,
            qualityScore,
            relevanceScore,
            enhanced: true
          };
        } catch (error) {
          console.warn('Error enhancing result:', error);
          return {
            ...result,
            qualityScore: 0.3,
            relevanceScore: 0.3,
            enhanced: false
          };
        }
      })
    );
    
    // Filter out low-quality results with stricter criteria
    const filteredResults = enhancedResults.filter(result => 
      result.qualityScore > 0.4 && 
      result.relevanceScore > 0.3 &&
      result.snippet.length > 30
    );
    
    // If too few results, relax criteria slightly
    let finalResults = filteredResults;
    if (filteredResults.length < 3) {
      console.log('⚠️ Few high-quality results, relaxing criteria');
      finalResults = enhancedResults.filter(result => 
        result.qualityScore > 0.3 && 
        result.relevanceScore > 0.2 &&
        result.snippet.length > 20
      );
    }
    
    // Sort by quality and relevance, and limit to reasonable number
    return finalResults
      .sort((a, b) => 
        (b.qualityScore * 0.6 + b.relevanceScore * 0.4) - 
        (a.qualityScore * 0.6 + a.relevanceScore * 0.4)
      )
      .slice(0, 15); // Limit to top 15 results
  }

  /**
   * Calculate quality score for a web search result with AI enhancement
   */
  private async calculateResultQuality(result: any): Promise<number> {
    let score = 0.5; // Base score
    
    // Check for authoritative domains
    const authoritativeDomains = ['gov', 'edu', 'org', 'ac', 'int'];
    const domain = result.host_name.toLowerCase();
    
    if (authoritativeDomains.some(auth => domain.includes(auth))) {
      score += 0.3;
    }
    
    // Check content length and quality
    const snippetLength = result.snippet?.length || 0;
    if (snippetLength > 100) score += 0.1;
    if (snippetLength > 200) score += 0.1;
    
    // Check for meaningful content (not just metadata)
    const meaningfulContent = this.hasMeaningfulContent(result.snippet);
    if (meaningfulContent) score += 0.2;
    
    // Check URL structure
    if (this.isValidUrl(result.url)) score += 0.1;
    
    // Use AI to validate content quality
    try {
      const aiQualityScore = await this.validateContentQualityWithAI(result);
      score = (score + aiQualityScore) / 2; // Average of rule-based and AI scores
    } catch (error) {
      console.warn('AI quality validation failed, using rule-based score only:', error);
    }
    
    return Math.min(score, 1.0);
  }

  /**
   * Validate content quality using AI analysis
   */
  private async validateContentQualityWithAI(result: any): Promise<number> {
    try {
      const content = result.snippet || '';
      const title = result.name || '';
      const url = result.url || '';
      
      if (content.length < 50) {
        return 0.3; // Low quality for very short content
      }
      
      const prompt = `You are an expert content quality evaluator. Analyze the following web content for quality and reliability.

Title: "${title}"
Content: "${content.substring(0, 500)}"
URL: "${url}"

Evaluate this content based on:
1. **Credibility**: Is the source trustworthy and authoritative?
2. **Accuracy**: Does the content appear factual and well-researched?
3. **Completeness**: Is the information substantial and comprehensive?
4. **Objectivity**: Is the content unbiased and balanced?
5. **Currency**: Does the information appear up-to-date and relevant?
6. **Clarity**: Is the content well-written and easy to understand?

Provide a quality score from 0.0 to 1.0, where:
- 0.9-1.0: Excellent quality (highly credible, accurate, comprehensive)
- 0.7-0.8: Good quality (generally reliable, some minor issues)
- 0.5-0.6: Average quality (basic information, some reliability concerns)
- 0.3-0.4: Below average quality (limited value, some accuracy issues)
- 0.0-0.2: Poor quality (unreliable, inaccurate, or minimal value)

Return only the numeric score (e.g., 0.85), no other text.`;

      const response = await safeZAIChatCompletion([
        { role: 'system', content: 'You are an expert content quality evaluation AI specializing in assessing web content credibility and reliability.' },
        { role: 'user', content: prompt }
      ], {
        model: 'gpt-4o',
        temperature: 0.1,
        max_tokens: 50
      });

      const scoreText = response.choices[0]?.message?.content || '0.5';
      const score = parseFloat(scoreText);
      
      if (!isNaN(score) && score >= 0 && score <= 1) {
        return score;
      } else {
        console.warn('Invalid AI quality score returned:', scoreText);
        return 0.5; // Default to neutral score
      }

    } catch (error) {
      console.warn('AI content quality validation failed:', error);
      return 0.5; // Return neutral score on error
    }
  }

  /**
   * Calculate relevance score for a web search result
   */
  private calculateResultRelevance(result: any, allResults: any[]): number {
    let score = 0.5; // Base score
    
    // Check title relevance
    const titleWords = result.name?.toLowerCase().split(/\s+/) || [];
    const snippetWords = result.snippet?.toLowerCase().split(/\s+/) || [];
    
    // Look for research-related keywords
    const researchKeywords = ['research', 'study', 'analysis', 'data', 'findings', 'results', 'report', 'investigation'];
    const allText = [...titleWords, ...snippetWords].join(' ');
    
    const keywordCount = researchKeywords.filter(keyword => allText.includes(keyword)).length;
    score += Math.min(keywordCount * 0.1, 0.3);
    
    // Check for duplicate content across results
    const isDuplicate = this.isDuplicateContent(result, allResults);
    if (isDuplicate) score -= 0.2;
    
    // Check rank (higher rank = more relevant)
    if (result.rank && result.rank <= 5) score += 0.2;
    if (result.rank && result.rank <= 10) score += 0.1;
    
    return Math.max(score, 0.0);
  }

  /**
   * Check if content is meaningful (not just metadata or URLs)
   */
  /**
   * Check if content is junk or low-quality
   */
  private isJunkContent(snippet: string): boolean {
    if (!snippet || typeof snippet !== 'string') return true;
    
    const text = snippet.toLowerCase().trim();
    
    // Check for error messages or system responses
    const junkPatterns = [
      /404 not found/i,
      /page not found/i,
      /access denied/i,
      /forbidden/i,
      /error occurred/i,
      /maintenance/i,
      /under construction/i,
      /no results found/i,
      /invalid request/i,
      /service unavailable/i,
      /timeout/i,
      /connection failed/i,
      /captcha/i,
      /robot/i,
      /automated/i,
      /bot detection/i,
      /javascript required/i,
      /enable javascript/i,
      /cookies required/i,
      /login required/i,
      /subscription required/i,
      /premium content/i,
      /paywall/i
    ];
    
    // Check if content matches any junk pattern
    if (junkPatterns.some(pattern => pattern.test(text))) {
      return true;
    }
    
    // Check for excessive repetition
    const words = text.split(/\s+/);
    const uniqueWords = new Set(words);
    const repetitionRatio = uniqueWords.size / words.length;
    if (repetitionRatio < 0.3 && words.length > 10) {
      return true;
    }
    
    // Check for excessive special characters or numbers
    const specialCharRatio = (text.match(/[^a-zA-Z\s]/g) || []).length / text.length;
    if (specialCharRatio > 0.5) {
      return true;
    }
    
    // Check for very short content with no meaningful information
    if (text.length < 30 && !/[a-zA-Z]{4,}/.test(text)) {
      return true;
    }
    
    return false;
  }

  private hasMeaningfulContent(snippet: string): boolean {
    if (!snippet || snippet.length < 50) return false;
    
    // Check if it's just URL structures or metadata
    const urlPatterns = [
      /https?:\/\/[^\s]+/g,
      /www\.[^\s]+/g,
      /source:\s*https?:\/\/[^\s]+/gi,
      /url:\s*[^\s]+/gi,
      /host:\s*[^\s]+/gi
    ];
    
    const cleanSnippet = snippet.replace(/source:|url:|host:/gi, '').trim();
    
    // If after removing URL patterns, there's still substantial content
    const urlContent = snippet.match(/https?:\/\/[^\s]+/g) || [];
    const urlContentLength = urlContent.join('').length;
    
    return (snippet.length - urlContentLength) > 30;
  }

  /**
   * Check if URL is valid
   */
  private isValidUrl(url: string): boolean {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Check for duplicate content
   */
  private isDuplicateContent(result: any, allResults: any[]): boolean {
    const snippet = result.snippet?.toLowerCase() || '';
    const title = result.name?.toLowerCase() || '';
    
    return allResults.some(otherResult => {
      if (otherResult === result) return false;
      
      const otherSnippet = otherResult.snippet?.toLowerCase() || '';
      const otherTitle = otherResult.name?.toLowerCase() || '';
      
      // Check for very similar content
      const snippetSimilarity = this.calculateSimilarity(snippet, otherSnippet);
      const titleSimilarity = this.calculateSimilarity(title, otherTitle);
      
      return snippetSimilarity > 0.8 || titleSimilarity > 0.9;
    });
  }

  /**
   * Calculate similarity between two strings
   */
  private calculateSimilarity(str1: string, str2: string): number {
    if (!str1 || !str2) return 0;
    
    const words1 = new Set(str1.split(/\s+/));
    const words2 = new Set(str2.split(/\s+/));
    
    const intersection = new Set([...words1].filter(word => words2.has(word)));
    const union = new Set([...words1, ...words2]);
    
    return union.size > 0 ? intersection.size / union.size : 0;
  }

  /**
   * Clean and validate snippet content
   */
  private cleanAndValidateSnippet(snippet: string): string {
    if (!snippet || typeof snippet !== 'string') return 'Content not available';
    
    // Remove URL structures and metadata
    let cleaned = snippet
      .replace(/source:\s*https?:\/\/[^\s]+/gi, '')
      .replace(/url:\s*[^\s]+/gi, '')
      .replace(/host:\s*[^\s]+/gi, '')
      .replace(/rank:\s*\d+/gi, '')
      .replace(/date:\s*[^\s]+/gi, '')
      .replace(/https?:\/\/[^\s]+/g, '')
      .replace(/www\.[^\s]+/g, '')
      .replace(/\[.*?\]/g, '') // Remove bracketed content
      .replace(/\{.*?\}/g, '') // Remove braced content
      .replace(/\s+/g, ' ')
      .trim();
    
    // Remove broken fragments and incomplete sentences
    cleaned = cleaned.replace(/\b\w{1,2}\b\s*$/, ''); // Remove single/double letter words at end
    cleaned = cleaned.replace(/^\s*\b\w{1,2}\b\s*/, ''); // Remove at beginning
    cleaned = cleaned.replace(/[.,;:!?]+\s*$/, ''); // Remove trailing punctuation
    cleaned = cleaned.replace(/^[^a-zA-Z]+/, ''); // Remove leading non-alphabetic characters
    
    // Remove common junk phrases
    const junkPhrases = [
      /click here/gi,
      /read more/gi,
      /learn more/gi,
      /find out/gi,
      /please visit/gi,
      /for more information/gi,
      /contact us/gi,
      /sign up/gi,
      /log in/gi,
      /register now/gi,
      /download now/gi,
      /get started/gi,
      /try it free/gi,
      /limited time/gi,
      /act now/gi,
      /don't miss/gi
    ];
    
    junkPhrases.forEach(phrase => {
      cleaned = cleaned.replace(phrase, '');
    });
    
    // Clean up extra spaces after removing junk phrases
    cleaned = cleaned.replace(/\s+/g, ' ').trim();
    
    // Ensure minimum length and meaningful content
    if (cleaned.length < 20) {
      return 'Content summary not available';
    }
    
    // Remove very long snippets that might be garbage
    if (cleaned.length > 500) {
      cleaned = cleaned.substring(0, 500);
      // Try to end at a sentence boundary
      const lastSentenceEnd = Math.max(
        cleaned.lastIndexOf('.'),
        cleaned.lastIndexOf('!'),
        cleaned.lastIndexOf('?')
      );
      if (lastSentenceEnd > 200) {
        cleaned = cleaned.substring(0, lastSentenceEnd + 1);
      }
    }
    
    // Capitalize first letter
    if (cleaned.length > 0) {
      cleaned = cleaned.charAt(0).toUpperCase() + cleaned.slice(1);
    }
    
    // Ensure proper ending
    if (cleaned.length > 0 && !/[.!?]$/.test(cleaned)) {
      cleaned += '.';
    }
    
    return cleaned;
  }
}

// Initialize the processor
const deepResearchProcessor = new DeepResearchProcessor();

export async function POST(request: NextRequest) {
  return withErrorHandling(async () => {
    try {
      const body = await request.json();
      
      // Validate required fields
      if (!body.query) {
        return createErrorResponse('Query is required', 400);
      }

      // Set default values
      const researchRequest: DeepResearchRequest = {
        query: body.query,
        researchDepth: body.researchDepth || 'comprehensive',
        includeWebSearch: body.includeWebSearch !== false,
        includeKnowledgeGraph: body.includeKnowledgeGraph !== false,
        includeTopicModeling: body.includeTopicModeling !== false,
        includeSentimentAnalysis: body.includeSentimentAnalysis !== false,
        includeEmotionalIntelligence: body.includeEmotionalIntelligence || false,
        includePsychologicalProfile: body.includePsychologicalProfile || false,
        maxSources: body.maxSources || 20,
        analysisType: body.analysisType || 'general',
        timeFrame: body.timeFrame || 'current',
        outputFormat: body.outputFormat || 'comprehensive'
      };

      console.log('🔬 Processing deep research request...');
      console.log('📋 Research configuration:', {
        depth: researchRequest.researchDepth,
        webSearch: researchRequest.includeWebSearch,
        knowledgeGraph: researchRequest.includeKnowledgeGraph,
        topicModeling: researchRequest.includeTopicModeling,
        sentimentAnalysis: researchRequest.includeSentimentAnalysis,
        analysisType: researchRequest.analysisType
      });

      // Process the deep research request
      const result = await deepResearchProcessor.processDeepResearch(researchRequest);

      // Format the response based on output format
      let responseContent = '';
      
      switch (researchRequest.outputFormat) {
        case 'summary':
          responseContent = formatSummaryResponse(result);
          break;
        case 'detailed':
          responseContent = formatDetailedResponse(result);
          break;
        case 'executive':
          responseContent = formatExecutiveResponse(result);
          break;
        case 'comprehensive':
        default:
          responseContent = formatComprehensiveResponse(result);
          break;
      }

      return createSuccessResponse(responseContent, {
        researchData: result,
        processingTime: result.processingTime,
        confidence: result.metadata.confidence,
        qualityScore: result.metadata.qualityScore
      });

    } catch (error: any) {
      console.error('Deep research API error:', error);
      
      return createErrorResponse(
        `Deep research processing failed: ${error.message || 'Unknown error occurred'}`,
        500
      );
    }
  });
}

// Response formatting methods - Focused on research findings only
function formatSummaryResponse(result: DeepResearchResponse): string {
  const { keyFindings, recommendations } = result.insights;
  
  return `🔬 **Research Summary**

**Research Topic:** ${result.query}

**Key Findings:**
${keyFindings.map(finding => `• ${finding}`).join('\n')}

**Top Recommendations:**
${recommendations.slice(0, 3).map(rec => `• ${rec}`).join('\n')}

For detailed analysis, request a comprehensive research report.`;
}

function formatDetailedResponse(result: DeepResearchResponse): string {
  const { textAnalysis, knowledgeGraph, topicModeling, sentimentAnalysis } = result.analysis;
  const { keyFindings, knowledgeGaps, researchQuestions, recommendations } = result.insights;

  let response = `🔬 **Research Analysis**

**Research Topic:** ${result.query}

---

## 📊 **Key Findings**

${keyFindings.map(finding => `• ${finding}`).join('\n')}

---

## 🧠 **Research Analysis**

**Key Entities Identified:** ${textAnalysis.entities.length}
• Top entities: ${textAnalysis.entities.slice(0, 8).map(e => e.text).join(', ')}

**Main Topics Discovered:** ${textAnalysis.topics.length}
• Main themes: ${textAnalysis.topics.slice(0, 5).map(t => t.description).join('; ')}

**Overall Sentiment:** ${sentimentAnalysis?.overall?.sentiment || 'Not analyzed'} (${(sentimentAnalysis?.overall?.confidence * 100 || 0).toFixed(0)}% confidence)

---

## 📋 **Knowledge Gaps**

${knowledgeGaps.map(gap => `• ${gap}`).join('\n')}

---

## 🔍 **Research Questions**

${researchQuestions.slice(0, 5).map(question => `• ${question}`).join('\n')}

---

## 💡 **Recommendations**

${recommendations.map(rec => `• ${rec}`).join('\n')}`;

return response;
}

function formatExecutiveResponse(result: DeepResearchResponse): string {
  const { keyFindings, recommendations, nextSteps } = result.insights;
  const { textAnalysis, sentimentAnalysis } = result.analysis;

  return `📊 **Executive Research Summary**

**Research Topic:** ${result.query}

---

## 🎯 **Executive Summary**

This research analysis reveals ${textAnalysis.entities.length} key entities and ${textAnalysis.topics.length} major themes related to your query. The overall sentiment is ${sentimentAnalysis?.overall?.sentiment || 'neutral'}.

---

## 📈 **Key Insights**

${keyFindings.slice(0, 5).map(finding => `• ${finding}`).join('\n')}

---

## 💼 **Strategic Recommendations**

${recommendations.slice(0, 5).map(rec => `• ${rec}`).join('\n')}

---

## 🚀 **Immediate Next Steps**

${nextSteps.slice(0, 3).map(step => `• ${step}`).join('\n')}`;
}

function formatComprehensiveResponse(result: DeepResearchResponse): string {
  const { textAnalysis, knowledgeGraph, topicModeling, sentimentAnalysis, emotionalIntelligence, psychologicalProfile } = result.analysis;
  const { keyFindings, knowledgeGaps, researchQuestions, recommendations, nextSteps } = result.insights;

  let response = `🔬 **Comprehensive Research Findings**

**Research Topic:** ${result.query}

---

## 🎯 **Key Findings**

${keyFindings.map(finding => `• ${finding}`).join('\n')}

---

## 🧠 **Research Analysis**

### **Key Entities Identified**
${textAnalysis.entities.slice(0, 10).map(e => `• ${e.text}`).join('\n')}

### **Main Topics**
${textAnalysis.topics.slice(0, 6).map(t => `• ${t.description}`).join('\n')}

### **Overall Sentiment**
${sentimentAnalysis?.overall?.sentiment || 'Not analyzed'}`;

  if (sentimentAnalysis?.aspects && sentimentAnalysis.aspects.length > 0) {
    response += `

### **Detailed Sentiment Analysis**
${sentimentAnalysis.aspects.slice(0, 5).map(a => `• ${a.aspect}: ${a.sentiment}`).join('\n')}`;
  }

  response += `

### **Key Keywords**
${textAnalysis.keywords.slice(0, 15).map(keyword => `• ${keyword}`).join('\n')}

### **Research Summary**
${textAnalysis.summary}

---

## 📊 **Topic Analysis**`;

  if (topicModeling) {
    response += `

### **Main Research Themes**
${topicModeling.topics.slice(0, 6).map(t => `
**${t.description}**
• Key concepts: ${t.keywords?.slice(0, 5).join(', ') || 'Various related concepts'}
`).join('')}`;
  }

  response += `

---

## 🔍 **Knowledge Gaps & Limitations**

${knowledgeGaps.map(gap => `• ${gap}`).join('\n')}

---

## 💡 **Research Insights & Recommendations**

### **Key Recommendations**
${recommendations.map(rec => `• ${rec}`).join('\n')}

### **Further Research Questions**
${researchQuestions.map(question => `• ${question}`).join('\n')}

### **Next Steps**
${nextSteps.map(step => `• ${step}`).join('\n')}`;

  return response;
}