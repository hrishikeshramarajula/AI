// 🧠 AI Agent Brain System - Complete Intelligent Processing Engine
// This is the core brain that powers the autonomous agent with NLU, planning, execution, and learning

import { NLUProcessor } from './NLUProcessor';
import { TaskPlanner } from './TaskPlanner';
import { ExecutionEngine } from './ExecutionEngine';
import { APIIntegration } from './APIIntegration';
import { VerificationSystem } from './VerificationSystem';
import { LearningEngine } from './LearningEngine';
import { Logger } from '../utils/Logger';

export interface AIAgentInput {
  text: string;
  context?: any;
  priority?: 'low' | 'medium' | 'high' | 'urgent';
  userId?: string;
  timestamp?: Date;
}

export interface AIAgentOutput {
  success: boolean;
  result: any;
  reasoning: string[];
  executionTime: number;
  errors: string[];
  learnings: string[];
  confidence: number;
}

export interface BrainState {
  currentTask: string;
  context: any;
  memory: any[];
  performance: {
    successRate: number;
    averageExecutionTime: number;
    errorRate: number;
  };
  learning: {
    patterns: any[];
    preferences: any[];
    adaptations: any[];
  };
}

export class AIAgentBrain {
  private nluProcessor: NLUProcessor;
  private taskPlanner: TaskPlanner;
  private executionEngine: ExecutionEngine;
  private apiIntegration: APIIntegration;
  private verificationSystem: VerificationSystem;
  private learningEngine: LearningEngine;
  private logger: Logger;
  
  private state: BrainState;
  private isProcessing: boolean = false;

  constructor() {
    this.logger = new Logger('AIAgentBrain');
    this.nluProcessor = new NLUProcessor();
    this.taskPlanner = new TaskPlanner();
    this.executionEngine = new ExecutionEngine();
    this.apiIntegration = new APIIntegration();
    this.verificationSystem = new VerificationSystem();
    this.learningEngine = new LearningEngine();
    
    this.state = {
      currentTask: '',
      context: {},
      memory: [],
      performance: {
        successRate: 0,
        averageExecutionTime: 0,
        errorRate: 0
      },
      learning: {
        patterns: [],
        preferences: [],
        adaptations: []
      }
    };

    this.initializeBrain();
  }

  private async initializeBrain(): Promise<void> {
    try {
      this.logger.info('🧠 Initializing AI Agent Brain...');
      
      // Initialize all brain components
      await this.nluProcessor.initialize();
      await this.taskPlanner.initialize();
      await this.executionEngine.initialize();
      await this.apiIntegration.initialize();
      await this.verificationSystem.initialize();
      await this.learningEngine.initialize();
      
      // Load previous learning data if available
      await this.loadLearningData();
      
      this.logger.info('✅ AI Agent Brain initialized successfully');
    } catch (error) {
      this.logger.error('❌ Failed to initialize AI Agent Brain:', error);
      throw error;
    }
  }

  // 🎯 Main processing method - the heart of the brain
  public async process(input: AIAgentInput): Promise<AIAgentOutput> {
    const startTime = Date.now();
    const reasoning: string[] = [];
    const errors: string[] = [];
    const learnings: string[] = [];

    try {
      this.logger.info('🚀 Processing input:', input.text);
      this.isProcessing = true;
      this.state.currentTask = input.text;

      // Step 1: Natural Language Understanding (NLU)
      reasoning.push('📝 Starting Natural Language Understanding...');
      const nluResult = await this.nluProcessor.process(input.text, input.context);
      reasoning.push(`✅ NLU Complete - Intent: ${nluResult.intent}, Confidence: ${nluResult.confidence}`);
      
      if (nluResult.confidence < 0.5) {
        errors.push('Low confidence in understanding user intent');
        return this.createOutput(false, null, reasoning, errors, learnings, startTime, 0.3);
      }

      // Step 2: Task Decomposition & Planning
      reasoning.push('🎯 Starting Task Planning...');
      const taskPlan = await this.taskPlanner.createPlan(nluResult, input.context);
      reasoning.push(`✅ Task Plan Created - ${taskPlan.tasks.length} tasks identified`);
      
      // Step 3: Intelligent Execution
      reasoning.push('⚡ Starting Intelligent Execution...');
      const executionResults = await this.executionEngine.executePlan(taskPlan, input.context);
      reasoning.push(`✅ Execution Complete - ${executionResults.completedTasks}/${executionResults.totalTasks} completed`);
      
      // Step 4: Verification & Testing
      reasoning.push('🔍 Starting Verification...');
      const verificationResults = await this.verificationSystem.verifyResults(executionResults);
      reasoning.push(`✅ Verification Complete - Status: ${verificationResults.status}`);
      
      // Step 5: Learning & Adaptation
      reasoning.push('🧠 Starting Learning Process...');
      const learningResults = await this.learningEngine.learnFromExecution(
        input, nluResult, taskPlan, executionResults, verificationResults
      );
      learnings.push(...learningResults.insights);
      reasoning.push(`✅ Learning Complete - ${learningResults.insights.length} insights gained`);

      // Update brain state
      this.updateBrainState(executionResults, verificationResults, learningResults);
      
      // Calculate overall confidence
      const confidence = this.calculateConfidence(nluResult, executionResults, verificationResults);
      
      // Create final output
      const output = this.createOutput(
        verificationResults.success,
        executionResults.results,
        reasoning,
        errors,
        learnings,
        startTime,
        confidence
      );

      this.logger.info('🎉 Processing completed successfully');
      return output;

    } catch (error) {
      this.logger.error('❌ Processing failed:', error);
      errors.push(`Processing error: ${error.message}`);
      return this.createOutput(false, null, reasoning, errors, learnings, startTime, 0);
    } finally {
      this.isProcessing = false;
    }
  }

  // 🧠 Self-correction and error recovery
  public async selfCorrect(error: any, context: any): Promise<any> {
    this.logger.info('🔄 Initiating self-correction...');
    
    const correctionPlan = await this.executionEngine.generateCorrectionPlan(error, context);
    const correctionResult = await this.executionEngine.executePlan(correctionPlan, context);
    
    await this.learningEngine.learnFromCorrection(error, correctionResult);
    
    this.logger.info('✅ Self-correction completed');
    return correctionResult;
  }

  // 📊 Get brain status and diagnostics
  public getBrainStatus(): any {
    return {
      isProcessing: this.isProcessing,
      currentTask: this.state.currentTask,
      performance: this.state.performance,
      learning: {
        patternsCount: this.state.learning.patterns.length,
        preferencesCount: this.state.learning.preferences.length,
        adaptationsCount: this.state.learning.adaptations.length
      },
      memorySize: this.state.memory.length,
      components: {
        nlu: this.nluProcessor.getStatus(),
        planner: this.taskPlanner.getStatus(),
        execution: this.executionEngine.getStatus(),
        verification: this.verificationSystem.getStatus(),
        learning: this.learningEngine.getStatus()
      }
    };
  }

  // 🎯 Adaptive learning based on user feedback
  public async learnFromFeedback(feedback: any): Promise<void> {
    this.logger.info('📚 Learning from user feedback...');
    
    const adaptations = await this.learningEngine.adaptFromFeedback(feedback);
    this.state.learning.adaptations.push(...adaptations);
    
    await this.saveLearningData();
    
    this.logger.info('✅ Feedback learning completed');
  }

  // 🔍 Predictive analysis and anticipation
  public async anticipateNextActions(context: any): Promise<string[]> {
    this.logger.info('🔮 Analyzing potential next actions...');
    
    const patterns = await this.learningEngine.identifyPatterns(context);
    const predictions = await this.taskPlanner.predictNextActions(patterns, context);
    
    return predictions;
  }

  // 💾 Save and load learning data
  private async saveLearningData(): Promise<void> {
    try {
      const learningData = {
        state: this.state,
        timestamp: new Date().toISOString()
      };
      
      // In a real implementation, this would save to a database
      this.logger.info('💾 Learning data saved');
    } catch (error) {
      this.logger.error('❌ Failed to save learning data:', error);
    }
  }

  private async loadLearningData(): Promise<void> {
    try {
      // In a real implementation, this would load from a database
      this.logger.info('📂 Learning data loaded');
    } catch (error) {
      this.logger.error('❌ Failed to load learning data:', error);
    }
  }

  // 📈 Update brain state with execution results
  private updateBrainState(executionResults: any, verificationResults: any, learningResults: any): void {
    // Update performance metrics
    const successRate = executionResults.completedTasks / executionResults.totalTasks;
    this.state.performance.successRate = (this.state.performance.successRate + successRate) / 2;
    this.state.performance.averageExecutionTime = 
      (this.state.performance.averageExecutionTime + executionResults.executionTime) / 2;
    
    if (!verificationResults.success) {
      this.state.performance.errorRate = (this.state.performance.errorRate + 1) / 2;
    } else {
      this.state.performance.errorRate = this.state.performance.errorRate / 2;
    }

    // Add to memory
    this.state.memory.push({
      timestamp: new Date(),
      input: this.state.currentTask,
      execution: executionResults,
      verification: verificationResults,
      learning: learningResults
    });

    // Keep memory size manageable
    if (this.state.memory.length > 1000) {
      this.state.memory = this.state.memory.slice(-500);
    }
  }

  // 🎯 Calculate overall confidence score
  private calculateConfidence(nluResult: any, executionResults: any, verificationResults: any): number {
    const nluConfidence = nluResult.confidence || 0;
    const executionConfidence = executionResults.completedTasks / executionResults.totalTasks;
    const verificationConfidence = verificationResults.success ? 1 : 0;
    
    return (nluConfidence * 0.3 + executionConfidence * 0.5 + verificationConfidence * 0.2);
  }

  // 📤 Create standardized output
  private createOutput(
    success: boolean,
    result: any,
    reasoning: string[],
    errors: string[],
    learnings: string[],
    startTime: number,
    confidence: number
  ): AIAgentOutput {
    return {
      success,
      result,
      reasoning,
      executionTime: Date.now() - startTime,
      errors,
      learnings,
      confidence
    };
  }

  // 🛑 Shutdown the brain gracefully
  public async shutdown(): Promise<void> {
    this.logger.info('🛑 Shutting down AI Agent Brain...');
    
    await this.saveLearningData();
    await this.learningEngine.shutdown();
    await this.verificationSystem.shutdown();
    await this.executionEngine.shutdown();
    await this.taskPlanner.shutdown();
    await this.nluProcessor.shutdown();
    
    this.logger.info('✅ AI Agent Brain shutdown complete');
  }
}