// 📝 Natural Language Understanding (NLU) Processor - Enhanced with Real AI
// This component handles tokenization, parsing, semantic analysis, and intent recognition using real AI APIs

import { API_CONFIG, getApiHeaders, getApiUrl, getModelId } from '@/lib/apiConfig';

export interface NLUInput {
  text: string;
  context?: any;
}

export interface NLUResult {
  intent: string;
  entities: any[];
  confidence: number;
  sentiment: 'positive' | 'negative' | 'neutral';
  urgency: 'low' | 'medium' | 'high' | 'urgent';
  keywords: string[];
  categories: string[];
  semanticAnalysis: {
    mainAction: string;
    target: string;
    modifiers: string[];
    conditions: string[];
  };
  contextUnderstanding: {
    previousInteractions: any[];
    userPreferences: any[];
    projectContext: any;
  };
  aiEnhanced: {
    realAnalysis: string;
    confidenceScore: number;
    suggestedActions: string[];
  };
}

export class NLUProcessor {
  private initialized: boolean = false;

  constructor() {
    this.initialized = false;
  }

  public async initialize(): Promise<void> {
    this.initialized = true;
    console.log('✅ NLU Processor initialized with real AI capabilities');
  }

  // 🎯 Main NLU processing method with real AI enhancement
  public async process(text: string, context?: any): Promise<NLUResult> {
    console.log('📝 Starting Enhanced NLU Processing for:', text);

    try {
      // Step 1: Basic Processing (Traditional NLU)
      const basicResult = await this.performBasicNLU(text, context);
      
      // Step 2: Real AI Enhancement
      console.log('🤖 Enhancing with real AI analysis...');
      const aiEnhanced = await this.enhanceWithRealAI(text, basicResult, context);
      
      // Step 3: Combine results
      const result: NLUResult = {
        ...basicResult,
        aiEnhanced
      };

      console.log('🎉 Enhanced NLU Processing completed successfully');
      return result;

    } catch (error) {
      console.error('❌ Enhanced NLU Processing failed:', error);
      // Fallback to basic NLU
      return await this.performBasicNLU(text, context);
    }
  }

  // 🤖 Real AI Enhancement
  private async enhanceWithRealAI(text: string, basicResult: any, context?: any): Promise<any> {
    console.log('🤖 Calling real AI for NLU enhancement...');
    
    // Try providers in order of priority
    for (const provider of API_CONFIG.PROVIDER_PRIORITY) {
      try {
        console.log(`🔄 Trying NLU enhancement with: ${provider}`);
        
        let apiUrl = '';
        let headers = getApiHeaders(provider);
        let requestBody: any = {};
        
        // Prepare NLU analysis prompt
        const nluPrompt = `Analyze the following text for natural language understanding. Provide a detailed analysis including:

1. Intent Recognition - What is the main intent?
2. Entity Extraction - What key entities are mentioned?
3. Sentiment Analysis - What is the sentiment?
4. Urgency Detection - How urgent is this request?
5. Keyword Extraction - What are the important keywords?
6. Semantic Analysis - What is the main action, target, and modifiers?
7. Suggested Actions - What actions should be taken?

Text to analyze: "${text}"

Context: ${context ? JSON.stringify(context) : 'No context provided'}

Please respond in JSON format with the following structure:
{
  "intent": "string",
  "entities": [{"type": "string", "value": "string", "confidence": number}],
  "sentiment": "positive|negative|neutral",
  "urgency": "low|medium|high|urgent",
  "keywords": ["string"],
  "mainAction": "string",
  "target": "string",
  "modifiers": ["string"],
  "conditions": ["string"],
  "suggestedActions": ["string"],
  "confidence": number,
  "analysis": "string"
}`;

        // Prepare request based on provider
        switch (provider) {
          case 'openrouter':
          case 'openai':
            apiUrl = getApiUrl(provider, 'chat/completions');
            requestBody = {
              model: getModelId('gpt-4o', provider),
              messages: [
                {
                  role: 'system',
                  content: 'You are an expert Natural Language Understanding (NLU) specialist. Analyze text and provide detailed NLU insights in JSON format.'
                },
                {
                  role: 'user',
                  content: nluPrompt
                }
              ],
              temperature: 0.3,
              max_tokens: 1000,
              response_format: { type: 'json_object' }
            };
            break;
            
          case 'gemini':
            apiUrl = getApiUrl(provider, `models/${getModelId('gemini-1.5-pro', provider)}:generateContent?key=${API_CONFIG.GEMINI_API_KEY}`);
            requestBody = {
              contents: [{
                role: 'user',
                parts: [{
                  text: `You are an expert Natural Language Understanding (NLU) specialist. Analyze text and provide detailed NLU insights.\n\n${nluPrompt}`
                }]
              }],
              generationConfig: {
                temperature: 0.3,
                topK: 40,
                topP: 0.95,
                maxOutputTokens: 1000,
              }
            };
            break;
        }
        
        const response = await fetch(apiUrl, {
          method: 'POST',
          headers: headers,
          body: JSON.stringify(requestBody)
        });
        
        if (!response.ok) {
          const errorText = await response.text();
          console.error(`❌ ${provider} NLU enhancement failed:`, errorText);
          continue;
        }
        
        const data = await response.json();
        console.log(`✅ ${provider} NLU enhancement successful`);
        
        // Extract AI analysis based on provider
        let aiAnalysis;
        try {
          switch (provider) {
            case 'openrouter':
            case 'openai':
              const content = data.choices?.[0]?.message?.content || '{}';
              aiAnalysis = JSON.parse(content);
              break;
              
            case 'gemini':
              const geminiContent = data.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
              // Extract JSON from Gemini response (it might be wrapped in markdown)
              const jsonMatch = geminiContent.match(/\{[\s\S]*\}/);
              const jsonString = jsonMatch ? jsonMatch[0] : '{}';
              aiAnalysis = JSON.parse(jsonString);
              break;
          }
        } catch (parseError) {
          console.error('❌ Failed to parse AI response:', parseError);
          continue;
        }
        
        return {
          realAnalysis: aiAnalysis.analysis || 'AI analysis completed',
          confidenceScore: aiAnalysis.confidence || 0.8,
          suggestedActions: aiAnalysis.suggestedActions || []
        };
        
      } catch (error) {
        console.error(`❌ ${provider} NLU enhancement error:`, error);
        continue;
      }
    }
    
    // Fallback if all AI providers fail
    return {
      realAnalysis: 'Basic NLU analysis completed (AI enhancement unavailable)',
      confidenceScore: 0.6,
      suggestedActions: ['Proceed with basic understanding']
    };
  }

  // 📝 Basic NLU Processing (Fallback)
  private async performBasicNLU(text: string, context?: any): Promise<NLUResult> {
    console.log('📝 Performing basic NLU processing...');
    
    // Tokenization
    const tokens = text
      .toLowerCase()
      .replace(/[^\w\s]/g, ' ')
      .split(/\s+/)
      .filter(token => token.length > 0);
    
    // Basic intent recognition
    const intentPatterns = {
      'file_cleanup': ['keep', 'delete', 'cleanup', 'organize', 'files'],
      'code_generation': ['create', 'generate', 'build', 'code', 'develop'],
      'ai_agent_request': ['ai', 'agent', 'brain', 'autonomous', 'intelligent'],
      'system_analysis': ['analyze', 'check', 'examine', 'verify', 'diagnose']
    };
    
    let detectedIntent = 'general';
    let maxMatches = 0;
    
    for (const [intent, patterns] of Object.entries(intentPatterns)) {
      const matches = patterns.filter(pattern => 
        tokens.some(token => token.includes(pattern))
      ).length;
      
      if (matches > maxMatches) {
        maxMatches = matches;
        detectedIntent = intent;
      }
    }
    
    // Basic sentiment analysis
    const positiveWords = ['good', 'great', 'excellent', 'amazing', 'wonderful', 'perfect'];
    const negativeWords = ['bad', 'terrible', 'awful', 'horrible', 'wrong', 'error'];
    
    const positiveCount = positiveWords.filter(word => tokens.includes(word)).length;
    const negativeCount = negativeWords.filter(word => tokens.includes(word)).length;
    
    let sentiment: 'positive' | 'negative' | 'neutral' = 'neutral';
    if (positiveCount > negativeCount) sentiment = 'positive';
    else if (negativeCount > positiveCount) sentiment = 'negative';
    
    // Urgency detection
    const urgencyWords = ['urgent', 'asap', 'immediately', 'quick', 'fast', 'now', 'ra'];
    const urgencyCount = urgencyWords.filter(word => tokens.includes(word)).length;
    const raCount = (text.match(/ra/g) || []).length;
    
    let urgency: 'low' | 'medium' | 'high' | 'urgent' = 'low';
    if (urgencyCount >= 2 || raCount >= 2) urgency = 'urgent';
    else if (urgencyCount >= 1 || raCount >= 1) urgency = 'high';
    else if (sentiment === 'negative') urgency = 'medium';
    
    // Keyword extraction
    const importantWords = tokens.filter(token => token.length > 3);
    const keywords = [...new Set(importantWords)].slice(0, 10);
    
    // Basic semantic analysis
    const actionWords = ['create', 'delete', 'keep', 'build', 'make', 'analyze', 'implement'];
    const mainAction = tokens.find(t => actionWords.includes(t)) || 'unknown';
    
    const targetWords = ['files', 'code', 'system', 'agent', 'brain', 'component', 'application'];
    const target = tokens.find(t => targetWords.includes(t)) || 'general';
    
    const modifiers = tokens.filter(t => 
      !actionWords.includes(t) && 
      !targetWords.includes(t) && 
      t.length > 2
    );
    
    const conditions = [];
    if (tokens.includes('only')) conditions.push('exclusive');
    if (tokens.includes('all')) conditions.push('comprehensive');
    
    return {
      intent: detectedIntent,
      entities: [
        { type: 'detected_intent', value: detectedIntent, confidence: maxMatches / tokens.length }
      ],
      confidence: Math.min(maxMatches / tokens.length, 1.0),
      sentiment,
      urgency,
      keywords,
      categories: [detectedIntent],
      semanticAnalysis: {
        mainAction,
        target,
        modifiers,
        conditions
      },
      contextUnderstanding: {
        previousInteractions: [],
        userPreferences: [],
        projectContext: context || {}
      },
      aiEnhanced: {
        realAnalysis: 'Basic analysis completed',
        confidenceScore: 0.5,
        suggestedActions: ['Proceed with basic processing']
      }
    };
  }

  // 📊 Get NLU processor status
  public getStatus(): any {
    return {
      initialized: this.initialized,
      capabilities: [
        'Basic NLU Processing',
        'Real AI Enhancement',
        'Intent Recognition',
        'Entity Extraction',
        'Sentiment Analysis',
        'Urgency Detection'
      ],
      aiProviders: API_CONFIG.PROVIDER_PRIORITY.length,
      fallbackAvailable: true
    };
  }

  public async shutdown(): Promise<void> {
    console.log('🛑 Shutting down Enhanced NLU Processor...');
    this.initialized = false;
  }
}

// 🔤 Tokenizer for breaking text into tokens
class Tokenizer {
  private initialized: boolean = false;

  async initialize(): Promise<void> {
    this.initialized = true;
  }

  async tokenize(text: string): Promise<string[]> {
    if (!this.initialized) throw new Error('Tokenizer not initialized');
    
    // Basic tokenization - split by spaces and punctuation
    const tokens = text
      .toLowerCase()
      .replace(/[^\w\s]/g, ' ')
      .split(/\s+/)
      .filter(token => token.length > 0);
    
    return tokens;
  }

  getStatus(): any {
    return { initialized: this.initialized };
  }
}

// 📝 Parser for grammatical analysis
class Parser {
  private initialized: boolean = false;

  async initialize(): Promise<void> {
    this.initialized = true;
  }

  async parse(tokens: string[]): Promise<any> {
    if (!this.initialized) throw new Error('Parser not initialized');
    
    // Basic parsing - identify parts of speech patterns
    return {
      tokens,
      structure: this.analyzeStructure(tokens),
      phrases: this.extractPhrases(tokens)
    };
  }

  private analyzeStructure(tokens: string[]): any {
    // Simple structural analysis
    return {
      hasQuestion: tokens.includes('?') || tokens.some(t => ['what', 'how', 'why', 'when', 'where'].includes(t)),
      hasCommand: tokens.some(t => ['create', 'delete', 'keep', 'build', 'make'].includes(t)),
      hasUrgency: tokens.some(t => ['urgent', 'quick', 'asap', 'ra'].includes(t))
    };
  }

  private extractPhrases(tokens: string[]): string[] {
    // Extract meaningful phrases
    const phrases: string[] = [];
    let currentPhrase: string[] = [];
    
    for (const token of tokens) {
      if (token.length > 2) {
        currentPhrase.push(token);
      } else {
        if (currentPhrase.length > 0) {
          phrases.push(currentPhrase.join(' '));
          currentPhrase = [];
        }
      }
    }
    
    if (currentPhrase.length > 0) {
      phrases.push(currentPhrase.join(' '));
    }
    
    return phrases;
  }

  getStatus(): any {
    return { initialized: this.initialized };
  }
}

// 🧠 Semantic Analyzer for meaning extraction
class SemanticAnalyzer {
  private initialized: boolean = false;

  async initialize(): Promise<void> {
    this.initialized = true;
  }

  async analyze(parsed: any, originalText: string): Promise<any> {
    if (!this.initialized) throw new Error('Semantic Analyzer not initialized');
    
    const tokens = parsed.tokens;
    
    // Extract main action
    const actionWords = ['create', 'delete', 'keep', 'build', 'make', 'analyze', 'implement', 'generate'];
    const mainAction = tokens.find(t => actionWords.includes(t)) || 'unknown';
    
    // Extract target
    const targetWords = ['files', 'code', 'system', 'agent', 'brain', 'component', 'application'];
    const target = tokens.find(t => targetWords.includes(t)) || 'general';
    
    // Extract modifiers
    const modifiers = tokens.filter(t => 
      !actionWords.includes(t) && 
      !targetWords.includes(t) && 
      t.length > 2
    );
    
    // Extract conditions
    const conditions = [];
    if (tokens.includes('only')) conditions.push('exclusive');
    if (tokens.includes('all')) conditions.push('inclusive');
    if (tokens.includes('related')) conditions.push('contextual');
    
    return {
      mainAction,
      target,
      modifiers,
      conditions,
      complexity: this.calculateComplexity(tokens),
      clarity: this.calculateClarity(parsed)
    };
  }

  private calculateComplexity(tokens: string[]): number {
    // Simple complexity calculation based on token count and variety
    return Math.min(tokens.length / 10, 1.0);
  }

  private calculateClarity(parsed: any): number {
    // Simple clarity calculation based on structure
    if (parsed.structure.hasCommand) return 0.9;
    if (parsed.structure.hasQuestion) return 0.7;
    return 0.5;
  }

  getStatus(): any {
    return { initialized: this.initialized };
  }
}

// 🎯 Intent Recognizer for understanding user intent
class IntentRecognizer {
  private intents: IntentPattern[] = [];
  private initialized: boolean = false;

  async initialize(intents: IntentPattern[]): Promise<void> {
    this.intents = intents;
    this.initialized = true;
  }

  async recognizeIntent(text: string, tokens: string[], semanticResult: any): Promise<any> {
    if (!this.initialized) throw new Error('Intent Recognizer not initialized');
    
    const scores: { [key: string]: number } = {};
    
    // Score each intent based on pattern matching
    for (const intent of this.intents) {
      scores[intent.name] = this.calculateIntentScore(text, tokens, intent, semanticResult);
    }
    
    // Find the best matching intent
    const bestIntent = Object.entries(scores)
      .sort((a, b) => b[1] - a[1])[0];
    
    return {
      intent: bestIntent[0],
      confidence: bestIntent[1],
      category: this.intents.find(i => i.name === bestIntent[0])?.category || 'unknown'
    };
  }

  private calculateIntentScore(text: string, tokens: string[], intent: IntentPattern, semanticResult: any): number {
    let score = 0;
    
    // Pattern matching
    for (const pattern of intent.patterns) {
      if (text.toLowerCase().includes(pattern.toLowerCase())) {
        score += 0.3;
      }
    }
    
    // Semantic matching
    if (semanticResult.mainAction && intent.name.includes(semanticResult.mainAction)) {
      score += 0.2;
    }
    
    // Base confidence
    score += intent.confidence * 0.3;
    
    return Math.min(score, 1.0);
  }

  getStatus(): any {
    return { initialized: this.initialized, intentsCount: this.intents.length };
  }
}

// 🏷️ Entity Extractor for identifying important elements
class EntityExtractor {
  private entities: EntityPattern[] = [];
  private initialized: boolean = false;

  async initialize(entities: EntityPattern[]): Promise<void> {
    this.entities = entities;
    this.initialized = true;
  }

  async extractEntities(text: string, tokens: string[], intentResult: any): Promise<any[]> {
    if (!this.initialized) throw new Error('Entity Extractor not initialized');
    
    const extractedEntities: any[] = [];
    
    for (const entity of this.entities) {
      const matches = this.findEntityMatches(text, tokens, entity);
      for (const match of matches) {
        extractedEntities.push({
          type: entity.name,
          value: match,
          confidence: this.calculateEntityConfidence(match, entity)
        });
      }
    }
    
    return extractedEntities;
  }

  private findEntityMatches(text: string, tokens: string[], entity: EntityPattern): string[] {
    const matches: string[] = [];
    
    for (const pattern of entity.patterns) {
      if (text.toLowerCase().includes(pattern.toLowerCase())) {
        matches.push(pattern);
      }
    }
    
    return matches;
  }

  private calculateEntityConfidence(match: string, entity: EntityPattern): number {
    // Simple confidence calculation
    return 0.8; // Base confidence for entity matches
  }

  getStatus(): any {
    return { initialized: this.initialized, entitiesCount: this.entities.length };
  }
}

// 😊 Sentiment Analyzer for emotional tone detection
class SentimentAnalyzer {
  private initialized: boolean = false;

  async initialize(): Promise<void> {
    this.initialized = true;
  }

  async analyzeSentiment(text: string, tokens: string[]): Promise<'positive' | 'negative' | 'neutral'> {
    if (!this.initialized) throw new Error('Sentiment Analyzer not initialized');
    
    const positiveWords = ['good', 'great', 'excellent', 'awesome', 'perfect', 'love', 'like'];
    const negativeWords = ['bad', 'terrible', 'awful', 'hate', 'dislike', 'wrong', 'error'];
    const urgencyWords = ['urgent', 'asap', 'quick', 'fast', 'now', 'ra'];
    
    const positiveCount = tokens.filter(t => positiveWords.includes(t)).length;
    const negativeCount = tokens.filter(t => negativeWords.includes(t)).length;
    const urgencyCount = tokens.filter(t => urgencyWords.includes(t)).length;
    
    if (urgencyCount > 0) return 'negative'; // Urgency often indicates negative sentiment
    if (positiveCount > negativeCount) return 'positive';
    if (negativeCount > positiveCount) return 'negative';
    return 'neutral';
  }

  getStatus(): any {
    return { initialized: this.initialized };
  }
}

// 🌐 Context Analyzer for understanding situation
class ContextAnalyzer {
  private contexts: ContextPattern[] = [];
  private initialized: boolean = false;

  async initialize(contexts: ContextPattern[]): Promise<void> {
    this.contexts = contexts;
    this.initialized = true;
  }

  async analyzeContext(text: string, context?: any): Promise<any> {
    if (!this.initialized) throw new Error('Context Analyzer not initialized');
    
    const contextTypes: string[] = [];
    const contextScores: { [key: string]: number } = {};
    
    // Analyze context based on patterns
    for (const contextPattern of this.contexts) {
      let score = 0;
      for (const pattern of contextPattern.patterns) {
        if (text.toLowerCase().includes(pattern.toLowerCase())) {
          score += contextPattern.weight;
        }
      }
      
      if (score > 0) {
        contextTypes.push(contextPattern.type);
        contextScores[contextPattern.type] = score;
      }
    }
    
    return {
      previousInteractions: context?.previousInteractions || [],
      userPreferences: context?.userPreferences || [],
      projectContext: context?.projectContext || {},
      identifiedContexts: contextTypes,
      contextScores
    };
  }

  getStatus(): any {
    return { initialized: this.initialized, contextsCount: this.contexts.length };
  }
}