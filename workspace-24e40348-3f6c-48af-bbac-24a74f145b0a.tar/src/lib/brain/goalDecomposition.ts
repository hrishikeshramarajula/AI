// 🎯 Goal Decomposition System - Breaking Down Complex Requests into Actionable Sub-Goals
// This system takes text analysis results and decomposes them into a structured goal hierarchy

import { TextAnalysisResult } from './textAnalysis';

export interface GoalInput {
  textAnalysis: TextAnalysisResult;
  originalInput: string;
  context?: any;
  constraints?: string[];
  preferences?: {
    approach?: 'conservative' | 'aggressive' | 'balanced';
    priority?: 'speed' | 'quality' | 'cost' | 'comprehensive';
    style?: 'detailed' | 'concise' | 'creative' | 'analytical';
  };
}

export interface SubGoal {
  id: string;
  title: string;
  description: string;
  type: 'analysis' | 'research' | 'creation' | 'execution' | 'validation' | 'optimization';
  priority: 'critical' | 'high' | 'medium' | 'low';
  estimatedDuration: number; // in seconds
  dependencies: string[]; // IDs of dependent goals
  resources: string[];
  successCriteria: string[];
  riskFactors: string[];
  alternatives: string[];
  status: 'pending' | 'ready' | 'in_progress' | 'completed' | 'failed' | 'blocked';
  confidence: number; // 0-1
  complexity: 'simple' | 'moderate' | 'complex';
  category: 'information' | 'action' | 'decision' | 'validation' | 'optimization';
}

export interface GoalHierarchy {
  mainGoal: {
    id: string;
    title: string;
    description: string;
    objective: string;
    scope: 'specific' | 'general' | 'strategic' | 'tactical';
    priority: 'critical' | 'high' | 'medium' | 'low';
    estimatedTotalDuration: number;
    successCriteria: string[];
    constraints: string[];
  };
  subGoals: SubGoal[];
  executionPlan: {
    approach: 'sequential' | 'parallel' | 'adaptive' | 'hybrid';
    phases: Array<{
      name: string;
      goals: string[]; // Sub-goal IDs
      estimatedDuration: number;
      dependencies: string[]; // Phase dependencies
    }>;
    criticalPath: string[]; // Sub-goal IDs
    milestones: Array<{
      name: string;
      goalId: string;
      estimatedTime: number;
    }>;
  };
  riskAssessment: {
    overallRiskLevel: 'low' | 'medium' | 'high' | 'critical';
    risks: Array<{
      id: string;
      description: string;
      probability: number; // 0-1
      impact: 'low' | 'medium' | 'high' | 'critical';
      affectedGoals: string[];
      mitigation: string[];
    }>;
  };
  optimization: {
    parallelization: Array<{
      goals: string[];
      confidence: number;
    }>;
    shortcuts: Array<{
      from: string;
      to: string;
      description: string;
      risk: number;
    }>;
  };
}

export interface GoalDecompositionResult {
  input: GoalInput;
  hierarchy: GoalHierarchy;
  processingMetadata: {
    decompositionTime: number;
    strategy: string;
    confidence: number;
    subGoalsGenerated: number;
    estimatedTotalDuration: number;
  };
}

export class GoalDecompositionEngine {
  private goalTemplates: Map<string, Array<{
    pattern: RegExp;
    template: Partial<GoalHierarchy>;
    confidence: number;
  }>>;
  private complexityMultipliers: Map<string, number>;
  private riskPatterns: Map<string, Array<{
    pattern: RegExp;
    risk: string;
    probability: number;
    impact: string;
  }>>;

  constructor() {
    this.initializeGoalTemplates();
    this.initializeComplexityMultipliers();
    this.initializeRiskPatterns();
  }

  private initializeGoalTemplates(): void {
    this.goalTemplates = new Map([
      ['informational', [
        {
          pattern: /\b(what|when|where|who|why|how|explain|describe|tell me|define|meaning of)\b/i,
          template: {
            mainGoal: {
              objective: 'provide_information',
              scope: 'specific',
              priority: 'medium'
            },
            executionPlan: {
              approach: 'sequential',
              phases: [
                { name: 'Analysis', goals: [], estimatedDuration: 5, dependencies: [] },
                { name: 'Research', goals: [], estimatedDuration: 10, dependencies: ['Analysis'] },
                { name: 'Synthesis', goals: [], estimatedDuration: 8, dependencies: ['Research'] }
              ]
            }
          },
          confidence: 0.8
        }
      ]],
      ['creative', [
        {
          pattern: /\b(create|write|design|imagine|invent|compose|story|poem|art|music)\b/i,
          template: {
            mainGoal: {
              objective: 'create_content',
              scope: 'general',
              priority: 'high'
            },
            executionPlan: {
              approach: 'adaptive',
              phases: [
                { name: 'Ideation', goals: [], estimatedDuration: 15, dependencies: [] },
                { name: 'Creation', goals: [], estimatedDuration: 20, dependencies: ['Ideation'] },
                { name: 'Refinement', goals: [], estimatedDuration: 10, dependencies: ['Creation'] }
              ]
            }
          },
          confidence: 0.85
        }
      ]],
      ['analytical', [
        {
          pattern: /\b(analyze|analysis|compare|contrast|evaluate|assess|review|examine)\b/i,
          template: {
            mainGoal: {
              objective: 'analyze_information',
              scope: 'specific',
              priority: 'high'
            },
            executionPlan: {
              approach: 'sequential',
              phases: [
                { name: 'Data Collection', goals: [], estimatedDuration: 10, dependencies: [] },
                { name: 'Analysis', goals: [], estimatedDuration: 15, dependencies: ['Data Collection'] },
                { name: 'Validation', goals: [], estimatedDuration: 8, dependencies: ['Analysis'] }
              ]
            }
          },
          confidence: 0.9
        }
      ]],
      ['transactional', [
        {
          pattern: /\b(create|make|build|generate|develop|implement|execute|run|start)\b/i,
          template: {
            mainGoal: {
              objective: 'perform_action',
              scope: 'tactical',
              priority: 'high'
            },
            executionPlan: {
              approach: 'hybrid',
              phases: [
                { name: 'Planning', goals: [], estimatedDuration: 8, dependencies: [] },
                { name: 'Preparation', goals: [], estimatedDuration: 12, dependencies: ['Planning'] },
                { name: 'Execution', goals: [], estimatedDuration: 15, dependencies: ['Preparation'] },
                { name: 'Verification', goals: [], estimatedDuration: 5, dependencies: ['Execution'] }
              ]
            }
          },
          confidence: 0.85
        }
      ]],
      ['philosophical', [
        {
          pattern: /\b(meaning|purpose|existence|reality|consciousness|truth|wisdom)\b/i,
          template: {
            mainGoal: {
              objective: 'seek_wisdom',
              scope: 'strategic',
              priority: 'medium'
            },
            executionPlan: {
              approach: 'adaptive',
              phases: [
                { name: 'Exploration', goals: [], estimatedDuration: 20, dependencies: [] },
                { name: 'Reflection', goals: [], estimatedDuration: 15, dependencies: ['Exploration'] },
                { name: 'Synthesis', goals: [], estimatedDuration: 12, dependencies: ['Reflection'] }
              ]
            }
          },
          confidence: 0.9
        }
      ]]
    ]);
  }

  private initializeComplexityMultipliers(): void {
    this.complexityMultipliers = new Map([
      ['simple', 1.0],
      ['moderate', 1.5],
      ['complex', 2.0],
      ['expert', 3.0]
    ]);
  }

  private initializeRiskPatterns(): void {
    this.riskPatterns = new Map([
      ['uncertainty', [
        { pattern: /\b(maybe|perhaps|possibly|uncertain|not sure| unclear)\b/i, risk: 'uncertainty', probability: 0.7, impact: 'medium' },
        { pattern: /\b(don't know|unsure|ambiguous|vague)\b/i, risk: 'uncertainty', probability: 0.8, impact: 'high' }
      ]],
      ['complexity', [
        { pattern: /\b(complex|complicated|difficult|challenging|hard)\b/i, risk: 'complexity', probability: 0.6, impact: 'medium' },
        { pattern: /\b(too many|multiple|several|various)\b/i, risk: 'complexity', probability: 0.5, impact: 'medium' }
      ]],
      ['time', [
        { pattern: /\b(urgent|asap|immediately|quickly|fast)\b/i, risk: 'time_constraint', probability: 0.8, impact: 'high' },
        { pattern: /\b(deadline|time limit|rush|pressed for time)\b/i, risk: 'time_constraint', probability: 0.9, impact: 'critical' }
      ]],
      ['resources', [
        { pattern: /\b(limited|scarce|not enough|insufficient)\b/i, risk: 'resource_constraint', probability: 0.7, impact: 'medium' },
        { pattern: /\b(no|lack of|missing|unavailable)\b/i, risk: 'resource_constraint', probability: 0.8, impact: 'high' }
      ]]
    ]);
  }

  // Main decomposition method
  public async decomposeGoals(input: GoalInput): Promise<GoalDecompositionResult> {
    const startTime = Date.now();
    
    console.log('🎯 Starting goal decomposition...');
    
    // Find the best matching template
    const template = this.findBestTemplate(input.textAnalysis);
    
    // Generate main goal
    const mainGoal = this.generateMainGoal(input, template);
    
    // Generate sub-goals
    const subGoals = await this.generateSubGoals(input, mainGoal, template);
    
    // Create execution plan
    const executionPlan = this.createExecutionPlan(subGoals, template.executionPlan.approach);
    
    // Assess risks
    const riskAssessment = this.assessRisks(input, subGoals);
    
    // Identify optimization opportunities
    const optimization = this.identifyOptimizations(subGoals);
    
    const hierarchy: GoalHierarchy = {
      mainGoal,
      subGoals,
      executionPlan,
      riskAssessment,
      optimization
    };
    
    const decompositionTime = Date.now() - startTime;
    const estimatedTotalDuration = subGoals.reduce((sum, goal) => sum + goal.estimatedDuration, 0);
    
    const result: GoalDecompositionResult = {
      input,
      hierarchy,
      processingMetadata: {
        decompositionTime,
        strategy: template.executionPlan.approach,
        confidence: template.confidence,
        subGoalsGenerated: subGoals.length,
        estimatedTotalDuration
      }
    };
    
    console.log('✅ Goal decomposition completed:', {
      mainGoal: mainGoal.title,
      subGoals: subGoals.length,
      approach: executionPlan.approach,
      estimatedDuration: `${estimatedTotalDuration}s`,
      confidence: template.confidence
    });
    
    return result;
  }

  private findBestTemplate(textAnalysis: TextAnalysisResult) {
    const text = textAnalysis.input.text.toLowerCase();
    let bestTemplate = this.goalTemplates.get('general')?.[0] || {
      pattern: /.*/,
      template: {
        mainGoal: { objective: 'general_task', scope: 'specific', priority: 'medium' },
        executionPlan: { approach: 'sequential', phases: [] }
      },
      confidence: 0.5
    };
    let maxConfidence = 0;

    for (const [category, templates] of this.goalTemplates) {
      for (const template of templates) {
        if (template.pattern.test(text) && template.confidence > maxConfidence) {
          maxConfidence = template.confidence;
          bestTemplate = template;
        }
      }
    }

    return bestTemplate;
  }

  private generateMainGoal(input: GoalInput, template: any) {
    const textAnalysis = input.textAnalysis;
    const mainGoal = {
      id: 'main-goal-1',
      title: this.generateGoalTitle(textAnalysis),
      description: textAnalysis.input.text,
      objective: template.template.mainGoal.objective,
      scope: textAnalysis.context.scope as any,
      priority: this.determinePriority(textAnalysis) as any,
      estimatedTotalDuration: this.estimateTotalDuration(textAnalysis),
      successCriteria: this.generateSuccessCriteria(textAnalysis),
      constraints: input.constraints || []
    };

    return mainGoal;
  }

  private async generateSubGoals(input: GoalInput, mainGoal: any, template: any): Promise<SubGoal[]> {
    const textAnalysis = input.textAnalysis;
    const subGoals: SubGoal[] = [];
    
    // Generate sub-goals based on intent and complexity
    const baseSubGoals = this.getBaseSubGoals(textAnalysis.intent.primaryIntent, textAnalysis.complexity.overallComplexity);
    
    let goalIndex = 1;
    for (const baseGoal of baseSubGoals) {
      const subGoal: SubGoal = {
        id: `sub-goal-${goalIndex++}`,
        title: baseGoal.title,
        description: baseGoal.description,
        type: baseGoal.type,
        priority: this.calculateSubGoalPriority(baseGoal, mainGoal.priority),
        estimatedDuration: this.calculateSubGoalDuration(baseGoal, textAnalysis.complexity.overallComplexity),
        dependencies: baseGoal.dependencies || [],
        resources: this.identifyResources(baseGoal, textAnalysis),
        successCriteria: baseGoal.successCriteria || ['Successfully completed'],
        riskFactors: this.identifyRisks(baseGoal, textAnalysis),
        alternatives: baseGoal.alternatives || [],
        status: 'pending',
        confidence: baseGoal.confidence || 0.8,
        complexity: this.determineSubGoalComplexity(baseGoal, textAnalysis),
        category: this.determineSubGoalCategory(baseGoal.type)
      };
      
      subGoals.push(subGoal);
    }
    
    // Add domain-specific sub-goals
    const domainSpecificGoals = this.getDomainSpecificSubGoals(textAnalysis.entities.domain, textAnalysis);
    for (const domainGoal of domainSpecificGoals) {
      const subGoal: SubGoal = {
        id: `sub-goal-${goalIndex++}`,
        title: domainGoal.title,
        description: domainGoal.description,
        type: domainGoal.type,
        priority: this.calculateSubGoalPriority(domainGoal, mainGoal.priority),
        estimatedDuration: this.calculateSubGoalDuration(domainGoal, textAnalysis.complexity.overallComplexity),
        dependencies: domainGoal.dependencies || [],
        resources: this.identifyResources(domainGoal, textAnalysis),
        successCriteria: domainGoal.successCriteria || ['Successfully completed'],
        riskFactors: this.identifyRisks(domainGoal, textAnalysis),
        alternatives: domainGoal.alternatives || [],
        status: 'pending',
        confidence: domainGoal.confidence || 0.7,
        complexity: this.determineSubGoalComplexity(domainGoal, textAnalysis),
        category: this.determineSubGoalCategory(domainGoal.type)
      };
      
      subGoals.push(subGoal);
    }
    
    return subGoals;
  }

  private getBaseSubGoals(intent: string, complexity: number): Array<any> {
    const baseGoals: any = {
      informational: [
        {
          title: 'Analyze Request',
          description: 'Deep analysis of the user\'s information request',
          type: 'analysis' as const,
          successCriteria: ['Request fully understood', 'Key concepts identified'],
          confidence: 0.9
        },
        {
          title: 'Gather Information',
          description: 'Collect relevant information and data',
          type: 'research' as const,
          dependencies: ['sub-goal-1'],
          successCriteria: ['Relevant information collected', 'Data sources verified'],
          confidence: 0.8
        },
        {
          title: 'Synthesize Response',
          description: 'Create comprehensive response from gathered information',
          type: 'creation' as const,
          dependencies: ['sub-goal-2'],
          successCriteria: ['Response synthesized', 'Information well-organized'],
          confidence: 0.85
        }
      ],
      creative: [
        {
          title: 'Understand Creative Requirements',
          description: 'Analyze creative needs and requirements',
          type: 'analysis' as const,
          successCriteria: ['Creative requirements understood', 'Scope defined'],
          confidence: 0.9
        },
        {
          title: 'Generate Creative Ideas',
          description: 'Brainstorm and develop creative concepts',
          type: 'creation' as const,
          dependencies: ['sub-goal-1'],
          successCriteria: ['Multiple ideas generated', 'Creativity demonstrated'],
          confidence: 0.8
        },
        {
          title: 'Refine and Finalize',
          description: 'Refine creative work and prepare final output',
          type: 'optimization' as const,
          dependencies: ['sub-goal-2'],
          successCriteria: ['Work refined', 'Final output ready'],
          confidence: 0.85
        }
      ],
      analytical: [
        {
          title: 'Define Analysis Framework',
          description: 'Establish framework and methodology for analysis',
          type: 'analysis' as const,
          successCriteria: ['Framework defined', 'Methodology selected'],
          confidence: 0.9
        },
        {
          title: 'Collect and Analyze Data',
          description: 'Gather data and perform detailed analysis',
          type: 'research' as const,
          dependencies: ['sub-goal-1'],
          successCriteria: ['Data collected', 'Analysis performed'],
          confidence: 0.8
        },
        {
          title: 'Validate Findings',
          description: 'Verify analysis results and conclusions',
          type: 'validation' as const,
          dependencies: ['sub-goal-2'],
          successCriteria: ['Findings validated', 'Conclusions verified'],
          confidence: 0.85
        }
      ],
      transactional: [
        {
          title: 'Plan Action',
          description: 'Plan the required action or execution',
          type: 'analysis' as const,
          successCriteria: ['Action planned', 'Requirements identified'],
          confidence: 0.9
        },
        {
          title: 'Prepare Resources',
          description: 'Gather and prepare necessary resources',
          type: 'research' as const,
          dependencies: ['sub-goal-1'],
          successCriteria: ['Resources prepared', 'Environment ready'],
          confidence: 0.8
        },
        {
          title: 'Execute Action',
          description: 'Perform the main action or execution',
          type: 'execution' as const,
          dependencies: ['sub-goal-2'],
          successCriteria: ['Action completed', 'Results achieved'],
          confidence: 0.85
        },
        {
          title: 'Verify Results',
          description: 'Verify that action was successful',
          type: 'validation' as const,
          dependencies: ['sub-goal-3'],
          successCriteria: ['Results verified', 'Success confirmed'],
          confidence: 0.9
        }
      ],
      philosophical: [
        {
          title: 'Explore Philosophical Concepts',
          description: 'Explore and understand philosophical concepts',
          type: 'analysis' as const,
          successCriteria: ['Concepts understood', 'Context established'],
          confidence: 0.9
        },
        {
          title: 'Reflect and Contemplate',
          description: 'Deep reflection on philosophical questions',
          type: 'research' as const,
          dependencies: ['sub-goal-1'],
          successCriteria: ['Reflection completed', 'Insights gained'],
          confidence: 0.8
        },
        {
          title: 'Synthesize Wisdom',
          description: 'Synthesize philosophical insights and wisdom',
          type: 'creation' as const,
          dependencies: ['sub-goal-2'],
          successCriteria: ['Wisdom synthesized', 'Insights integrated'],
          confidence: 0.85
        }
      ]
    };

    return baseGoals[intent] || baseGoals.informational;
  }

  private getDomainSpecificSubGoals(domain: string, textAnalysis: TextAnalysisResult): Array<any> {
    const domainGoals: any = {
      technology: [
        {
          title: 'Research Technical Solutions',
          description: 'Research relevant technical solutions and approaches',
          type: 'research' as const,
          dependencies: ['sub-goal-1'],
          successCriteria: ['Technical solutions researched', 'Approaches evaluated'],
          confidence: 0.8
        }
      ],
      business: [
        {
          title: 'Analyze Business Context',
          description: 'Analyze business context and requirements',
          type: 'analysis' as const,
          dependencies: ['sub-goal-1'],
          successCriteria: ['Business context analyzed', 'Requirements understood'],
          confidence: 0.8
        }
      ],
      science: [
        {
          title: 'Review Scientific Literature',
          description: 'Review relevant scientific literature and research',
          type: 'research' as const,
          dependencies: ['sub-goal-1'],
          successCriteria: ['Literature reviewed', 'Research synthesized'],
          confidence: 0.8
        }
      ]
    };

    return domainGoals[domain] || [];
  }

  private createExecutionPlan(subGoals: SubGoal[], approach: string) {
    const phases = this.organizeGoalsIntoPhases(subGoals, approach);
    const criticalPath = this.identifyCriticalPath(subGoals);
    const milestones = this.createMilestones(subGoals);

    return {
      approach,
      phases,
      criticalPath,
      milestones
    };
  }

  private organizeGoalsIntoPhases(subGoals: SubGoal[], approach: string) {
    const phases = [
      { name: 'Analysis', goals: [] as string[], estimatedDuration: 0, dependencies: [] },
      { name: 'Research', goals: [] as string[], estimatedDuration: 0, dependencies: ['Analysis'] },
      { name: 'Creation', goals: [] as string[], estimatedDuration: 0, dependencies: ['Research'] },
      { name: 'Execution', goals: [] as string[], estimatedDuration: 0, dependencies: ['Creation'] },
      { name: 'Validation', goals: [] as string[], estimatedDuration: 0, dependencies: ['Execution'] }
    ];

    // Organize goals by type
    for (const goal of subGoals) {
      const phaseIndex = this.getPhaseIndex(goal.type);
      if (phaseIndex >= 0 && phaseIndex < phases.length) {
        phases[phaseIndex].goals.push(goal.id);
        phases[phaseIndex].estimatedDuration += goal.estimatedDuration;
      }
    }

    // Remove empty phases
    return phases.filter(phase => phase.goals.length > 0);
  }

  private getPhaseIndex(type: string): number {
    const phaseMap: { [key: string]: number } = {
      'analysis': 0,
      'research': 1,
      'creation': 2,
      'execution': 3,
      'validation': 4,
      'optimization': 2
    };
    return phaseMap[type] || 0;
  }

  private identifyCriticalPath(subGoals: SubGoal[]): string[] {
    // Simplified critical path identification
    const criticalGoals = subGoals
      .filter(goal => goal.priority === 'critical' || goal.priority === 'high')
      .sort((a, b) => b.estimatedDuration - a.estimatedDuration);
    
    return criticalGoals.slice(0, 3).map(goal => goal.id);
  }

  private createMilestones(subGoals: SubGoal[]) {
    const milestones = [];
    const highPriorityGoals = subGoals.filter(goal => goal.priority === 'high' || goal.priority === 'critical');
    
    for (let i = 0; i < Math.min(3, highPriorityGoals.length); i++) {
      const goal = highPriorityGoals[i];
      milestones.push({
        name: `Complete ${goal.title}`,
        goalId: goal.id,
        estimatedTime: goal.estimatedDuration
      });
    }
    
    return milestones;
  }

  private assessRisks(input: GoalInput, subGoals: SubGoal[]) {
    const text = input.textAnalysis.input.text.toLowerCase();
    const risks = [];
    let overallRiskLevel: 'low' | 'medium' | 'high' | 'critical' = 'low';
    let maxRiskScore = 0;

    for (const [category, patterns] of this.riskPatterns) {
      for (const pattern of patterns) {
        if (pattern.pattern.test(text)) {
          const risk = {
            id: `risk-${risks.length + 1}`,
            description: pattern.risk,
            probability: pattern.probability,
            impact: pattern.impact as any,
            affectedGoals: subGoals.map(g => g.id),
            mitigation: this.generateMitigation(pattern.risk)
          };
          risks.push(risk);
          
          const riskScore = pattern.probability * (pattern.impact === 'critical' ? 1 : pattern.impact === 'high' ? 0.8 : pattern.impact === 'medium' ? 0.5 : 0.2);
          if (riskScore > maxRiskScore) {
            maxRiskScore = riskScore;
          }
        }
      }
    }

    // Determine overall risk level
    if (maxRiskScore > 0.8) overallRiskLevel = 'critical';
    else if (maxRiskScore > 0.6) overallRiskLevel = 'high';
    else if (maxRiskScore > 0.4) overallRiskLevel = 'medium';

    return {
      overallRiskLevel,
      risks
    };
  }

  private generateMitigation(risk: string): string[] {
    const mitigations: { [key: string]: string[] } = {
      uncertainty: ['Gather more information', 'Consult experts', 'Use probabilistic approaches'],
      complexity: ['Break down into smaller tasks', 'Use proven methodologies', 'Get expert help'],
      time_constraint: ['Prioritize tasks', 'Use parallel processing', 'Set realistic deadlines'],
      resource_constraint: ['Identify alternative resources', 'Optimize resource usage', 'Seek additional resources']
    };
    
    return mitigations[risk] || ['Monitor closely', 'Have contingency plans'];
  }

  private identifyOptimizations(subGoals: SubGoal[]) {
    const parallelization = [];
    const shortcuts = [];

    // Identify parallelization opportunities
    const independentGoals = subGoals.filter(goal => goal.dependencies.length === 0);
    if (independentGoals.length > 1) {
      parallelization.push({
        goals: independentGoals.slice(0, 2).map(g => g.id),
        confidence: 0.8
      });
    }

    // Identify potential shortcuts
    const analysisGoals = subGoals.filter(goal => goal.type === 'analysis');
    const researchGoals = subGoals.filter(goal => goal.type === 'research');
    
    if (analysisGoals.length > 0 && researchGoals.length > 0) {
      shortcuts.push({
        from: analysisGoals[0].id,
        to: researchGoals[0].id,
        description: 'Combine analysis and research phases',
        risk: 0.3
      });
    }

    return {
      parallelization,
      shortcuts
    };
  }

  // Helper methods
  private generateGoalTitle(textAnalysis: TextAnalysisResult): string {
    const intent = textAnalysis.intent.primaryIntent;
    const entities = textAnalysis.entities.keyPhrases.slice(0, 3);
    
    const titleMap: { [key: string]: string } = {
      seek_information: `Information Request: ${entities.join(', ')}`,
      perform_action: `Action: ${entities.join(', ')}`,
      create_content: `Creative Work: ${entities.join(', ')}`,
      analyze_information: `Analysis: ${entities.join(', ')}`,
      express_emotion: `Emotional Expression: ${entities.join(', ')}`,
      seek_wisdom: `Philosophical Inquiry: ${entities.join(', ')}`
    };
    
    return titleMap[intent] || `Task: ${entities.join(', ')}`;
  }

  private determinePriority(textAnalysis: TextAnalysisResult): string {
    if (textAnalysis.context.urgency === 'critical' || textAnalysis.context.urgency === 'high') {
      return 'high';
    } else if (textAnalysis.context.urgency === 'medium') {
      return 'medium';
    } else {
      return 'low';
    }
  }

  private estimateTotalDuration(textAnalysis: TextAnalysisResult): number {
    const baseDuration = 30; // Base 30 seconds
    const complexityMultiplier = this.complexityMultipliers.get(textAnalysis.complexity.complexity) || 1.5;
    const urgencyMultiplier = textAnalysis.context.urgency === 'critical' ? 0.8 : 1.0;
    
    return Math.round(baseDuration * complexityMultiplier * urgencyMultiplier);
  }

  private generateSuccessCriteria(textAnalysis: TextAnalysisResult): string[] {
    const baseCriteria = [
      'User request fully addressed',
      'Response is comprehensive and accurate',
      'Quality standards met'
    ];
    
    if (textAnalysis.intent.intentCategory === 'transactional') {
      baseCriteria.push('Action completed successfully');
    } else if (textAnalysis.intent.intentCategory === 'creative') {
      baseCriteria.push('Creative requirements met');
    } else if (textAnalysis.intent.intentCategory === 'analytical') {
      baseCriteria.push('Analysis is thorough and well-supported');
    }
    
    return baseCriteria;
  }

  private calculateSubGoalPriority(baseGoal: any, mainGoalPriority: string): SubGoal['priority'] {
    if (mainGoalPriority === 'critical') return 'high';
    if (mainGoalPriority === 'high') return baseGoal.type === 'execution' ? 'high' : 'medium';
    if (mainGoalPriority === 'medium') return 'medium';
    return 'low';
  }

  private calculateSubGoalDuration(baseGoal: any, complexity: number): number {
    const baseDuration = 10; // Base 10 seconds per sub-goal
    const complexityMultiplier = this.complexityMultipliers.get(
      complexity > 0.7 ? 'complex' : complexity > 0.4 ? 'moderate' : 'simple'
    ) || 1.5;
    
    return Math.round(baseDuration * complexityMultiplier);
  }

  private identifyResources(baseGoal: any, textAnalysis: TextAnalysisResult): string[] {
    const baseResources = ['AI processing capabilities', 'Knowledge base'];
    
    if (baseGoal.type === 'research') {
      baseResources.push('Information sources', 'Data access');
    } else if (baseGoal.type === 'creation') {
      baseResources.push('Creative tools', 'Content generation');
    } else if (baseGoal.type === 'analysis') {
      baseResources.push('Analytical tools', 'Processing power');
    }
    
    return baseResources;
  }

  private identifyRisks(baseGoal: any, textAnalysis: TextAnalysisResult): string[] {
    const baseRisks = ['Processing time constraints', 'Quality assurance challenges'];
    
    if (textAnalysis.complexity.overallComplexity > 0.7) {
      baseRisks.push('High complexity may affect results');
    }
    
    if (textAnalysis.context.urgency === 'critical') {
      baseRisks.push('Time pressure may impact quality');
    }
    
    return baseRisks;
  }

  private determineSubGoalComplexity(baseGoal: any, textAnalysis: TextAnalysisResult): SubGoal['complexity'] {
    if (textAnalysis.complexity.overallComplexity > 0.7) return 'complex';
    if (textAnalysis.complexity.overallComplexity > 0.4) return 'moderate';
    return 'simple';
  }

  private determineSubGoalCategory(type: string): SubGoal['category'] {
    const categoryMap: { [key: string]: SubGoal['category'] } = {
      'analysis': 'information',
      'research': 'information',
      'creation': 'action',
      'execution': 'action',
      'validation': 'validation',
      'optimization': 'optimization'
    };
    
    return categoryMap[type] || 'information';
  }
}

// Export singleton instance
export const goalDecompositionEngine = new GoalDecompositionEngine();