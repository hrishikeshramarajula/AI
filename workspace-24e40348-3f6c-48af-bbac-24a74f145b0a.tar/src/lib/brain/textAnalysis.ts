// 🔍 Real Text Analysis Engine - The Foundation of Brain Processing
// This engine performs sophisticated text analysis with intent detection, entity extraction, and more

export interface TextAnalysisInput {
  text: string;
  context?: any;
  timestamp?: Date;
  userId?: string;
}

export interface IntentAnalysis {
  primaryIntent: string;
  confidence: number;
  secondaryIntents: Array<{
    intent: string;
    confidence: number;
  }>;
  intentCategory: 'informational' | 'transactional' | 'creative' | 'analytical' | 'emotional' | 'philosophical';
}

export interface EntityAnalysis {
  entities: Array<{
    text: string;
    type: 'person' | 'organization' | 'location' | 'date' | 'time' | 'money' | 'percentage' | 'technology' | 'concept' | 'action';
    confidence: number;
    start: number;
    end: number;
    context: string;
  }>;
  keyPhrases: string[];
  topics: string[];
  domain: 'technology' | 'business' | 'science' | 'arts' | 'philosophy' | 'personal' | 'education' | 'health' | 'general';
}

export interface ContextAnalysis {
  situation: 'formal' | 'informal' | 'professional' | 'casual' | 'academic' | 'creative';
  urgency: 'low' | 'medium' | 'high' | 'critical';
  complexity: 'simple' | 'moderate' | 'complex' | 'expert';
  scope: 'specific' | 'general' | 'strategic' | 'tactical';
  emotionalContext: 'neutral' | 'positive' | 'negative' | 'mixed';
}

export interface EmotionalAnalysis {
  primaryEmotion: 'joy' | 'sadness' | 'anger' | 'fear' | 'surprise' | 'disgust' | 'anticipation' | 'trust' | 'neutral';
  emotionalIntensity: number; // 0-1
  emotionalTone: 'enthusiastic' | 'calm' | 'frustrated' | 'confused' | 'confident' | 'curious' | 'concerned' | 'neutral';
  sentiment: 'positive' | 'negative' | 'neutral' | 'mixed';
  sentimentScore: number; // -1 to 1
}

export interface ComplexityAssessment {
  lexicalComplexity: number; // 0-1
  syntacticComplexity: number; // 0-1
  semanticComplexity: number; // 0-1
  overallComplexity: number; // 0-1
  complexityFactors: Array<{
    factor: string;
    impact: number;
    description: string;
  }>;
  estimatedProcessingTime: number; // in seconds
}

export interface TextAnalysisResult {
  input: TextAnalysisInput;
  intent: IntentAnalysis;
  entities: EntityAnalysis;
  context: ContextAnalysis;
  emotional: EmotionalAnalysis;
  complexity: ComplexityAssessment;
  processingMetadata: {
    analysisTime: number;
    confidence: number;
    analysisDepth: 'basic' | 'detailed' | 'comprehensive';
    processingStrategies: string[];
  };
}

export class TextAnalysisEngine {
  private intentPatterns: Map<string, Array<{ pattern: RegExp; intent: string; confidence: number }>>;
  private emotionalKeywords: Map<string, Array<{ word: string; emotion: string; intensity: number }>>;
  private complexityIndicators: Map<string, Array<{ indicator: string; weight: number; description: string }>>;

  constructor() {
    this.initializePatterns();
    this.initializeEmotionalKeywords();
    this.initializeComplexityIndicators();
  }

  private initializePatterns(): void {
    // Intent detection patterns
    this.intentPatterns = new Map([
      ['informational', [
        { pattern: /\b(what|when|where|who|why|how|explain|describe|tell me|define|meaning of)\b/i, intent: 'seek_information', confidence: 0.8 },
        { pattern: /\b(help me understand|learn about|I want to know|can you explain)\b/i, intent: 'seek_information', confidence: 0.9 },
        { pattern: /\b(what is|how does|what are|who is|when did|where is)\b/i, intent: 'seek_information', confidence: 0.85 }
      ]],
      ['transactional', [
        { pattern: /\b(create|make|build|generate|develop|implement|execute|run|start)\b/i, intent: 'perform_action', confidence: 0.8 },
        { pattern: /\b(download|upload|send|receive|save|delete|edit|modify)\b/i, intent: 'perform_action', confidence: 0.85 },
        { pattern: /\b(I need|I want|please|can you|would you)\b/i, intent: 'make_request', confidence: 0.7 }
      ]],
      ['creative', [
        { pattern: /\b(create|write|design|imagine|invent|compose|story|poem|art|music)\b/i, intent: 'create_content', confidence: 0.8 },
        { pattern: /\b(creative|innovative|original|unique|new idea|brainstorm)\b/i, intent: 'create_content', confidence: 0.85 },
        { pattern: /\b(if I were|suppose that|imagine if|what if)\b/i, intent: 'creative_exploration', confidence: 0.8 }
      ]],
      ['analytical', [
        { pattern: /\b(analyze|analysis|compare|contrast|evaluate|assess|review|examine)\b/i, intent: 'analyze_information', confidence: 0.85 },
        { pattern: /\b(pros and cons|advantages|disadvantages|benefits|drawbacks)\b/i, intent: 'analyze_information', confidence: 0.9 },
        { pattern: /\b(statistics|data|metrics|measure|quantify|calculate)\b/i, intent: 'analyze_data', confidence: 0.8 }
      ]],
      ['emotional', [
        { pattern: /\b(feel|feeling|emotion|emotional|happy|sad|angry|love|hate)\b/i, intent: 'express_emotion', confidence: 0.85 },
        { pattern: /\b(help me|support|advice|guidance|counseling|therapy)\b/i, intent: 'seek_emotional_support', confidence: 0.8 },
        { pattern: /\b(empathy|understanding|compassion|connection|relationship)\b/i, intent: 'emotional_connection', confidence: 0.8 }
      ]],
      ['philosophical', [
        { pattern: /\b(meaning|purpose|existence|reality|consciousness|truth|wisdom)\b/i, intent: 'seek_wisdom', confidence: 0.9 },
        { pattern: /\b(philosophy|metaphysics|epistemology|ethics|aesthetics)\b/i, intent: 'philosophical_inquiry', confidence: 0.95 },
        { pattern: /\b(nature of|essence of|ultimate|fundamental|cosmic|universal)\b/i, intent: 'seek_wisdom', confidence: 0.85 }
      ]]
    ]);
  }

  private initializeEmotionalKeywords(): void {
    this.emotionalKeywords = new Map([
      ['joy', [
        { word: 'happy', emotion: 'joy', intensity: 0.8 },
        { word: 'excited', emotion: 'joy', intensity: 0.9 },
        { word: 'wonderful', emotion: 'joy', intensity: 0.85 },
        { word: 'amazing', emotion: 'joy', intensity: 0.9 },
        { word: 'great', emotion: 'joy', intensity: 0.7 },
        { word: 'fantastic', emotion: 'joy', intensity: 0.85 },
        { word: 'love', emotion: 'joy', intensity: 0.9 }
      ]],
      ['sadness', [
        { word: 'sad', emotion: 'sadness', intensity: 0.8 },
        { word: 'depressed', emotion: 'sadness', intensity: 0.9 },
        { word: 'disappointed', emotion: 'sadness', intensity: 0.7 },
        { word: 'upset', emotion: 'sadness', intensity: 0.6 },
        { word: 'crying', emotion: 'sadness', intensity: 0.85 }
      ]],
      ['anger', [
        { word: 'angry', emotion: 'anger', intensity: 0.8 },
        { word: 'furious', emotion: 'anger', intensity: 0.95 },
        { word: 'mad', emotion: 'anger', intensity: 0.7 },
        { word: 'irritated', emotion: 'anger', intensity: 0.6 },
        { word: 'frustrated', emotion: 'anger', intensity: 0.75 }
      ]],
      ['fear', [
        { word: 'scared', emotion: 'fear', intensity: 0.8 },
        { word: 'afraid', emotion: 'fear', intensity: 0.75 },
        { word: 'worried', emotion: 'fear', intensity: 0.7 },
        { word: 'anxious', emotion: 'fear', intensity: 0.8 },
        { word: 'terrified', emotion: 'fear', intensity: 0.95 }
      ]],
      ['trust', [
        { word: 'trust', emotion: 'trust', intensity: 0.8 },
        { word: 'confident', emotion: 'trust', intensity: 0.85 },
        { word: 'believe', emotion: 'trust', intensity: 0.75 },
        { word: 'faith', emotion: 'trust', intensity: 0.9 },
        { word: 'reliable', emotion: 'trust', intensity: 0.8 }
      ]]
    ]);
  }

  private initializeComplexityIndicators(): void {
    this.complexityIndicators = new Map([
      ['lexical', [
        { indicator: 'technical_terms', weight: 0.3, description: 'Presence of technical or specialized vocabulary' },
        { indicator: 'long_words', weight: 0.2, description: 'Words with more than 6 characters' },
        { indicator: 'diverse_vocabulary', weight: 0.2, description: 'High variety of unique words' },
        { indicator: 'abstract_concepts', weight: 0.3, description: 'Abstract or conceptual language' }
      ]],
      ['syntactic', [
        { indicator: 'sentence_length', weight: 0.4, description: 'Average words per sentence' },
        { indicator: 'clause_density', weight: 0.3, description: 'Number of clauses per sentence' },
        { indicator: 'punctuation_complexity', weight: 0.2, description: 'Complex punctuation usage' },
        { indicator: 'nested_structures', weight: 0.1, description: 'Nested phrases or clauses' }
      ]],
      ['semantic', [
        { indicator: 'conceptual_depth', weight: 0.4, description: 'Depth of conceptual content' },
        { indicator: 'multiple_interpretations', weight: 0.3, description: 'Potential for multiple meanings' },
        { indicator: 'implicit_meaning', weight: 0.2, description: 'Implied or hidden meanings' },
        { indicator: 'cross_references', weight: 0.1, description: 'References to external concepts' }
      ]]
    ]);
  }

  // Main analysis method
  public async analyzeText(input: TextAnalysisInput): Promise<TextAnalysisResult> {
    const startTime = Date.now();
    
    console.log('🔍 Starting comprehensive text analysis...');
    
    // Perform all analysis types
    const intent = await this.analyzeIntent(input.text);
    const entities = await this.extractEntities(input.text);
    const context = await this.analyzeContext(input.text, input.context);
    const emotional = await this.analyzeEmotionalTone(input.text);
    const complexity = await this.assessComplexity(input.text);
    
    const analysisTime = Date.now() - startTime;
    const overallConfidence = this.calculateOverallConfidence(intent, entities, context, emotional, complexity);
    
    const result: TextAnalysisResult = {
      input,
      intent,
      entities,
      context,
      emotional,
      complexity,
      processingMetadata: {
        analysisTime,
        confidence: overallConfidence,
        analysisDepth: 'comprehensive',
        processingStrategies: [
          'intent_pattern_matching',
          'entity_recognition',
          'contextual_analysis',
          'emotional_sentiment_analysis',
          'complexity_assessment'
        ]
      }
    };
    
    console.log('✅ Text analysis completed:', {
      intent: intent.primaryIntent,
      confidence: overallConfidence,
      complexity: complexity.overallComplexity,
      analysisTime: `${analysisTime}ms`
    });
    
    return result;
  }

  // Intent Analysis
  private async analyzeIntent(text: string): Promise<IntentAnalysis> {
    const lowerText = text.toLowerCase();
    const intentScores: Map<string, number> = new Map();
    
    // Score each intent category
    for (const [category, patterns] of this.intentPatterns) {
      let maxScore = 0;
      let bestMatch = '';
      
      for (const pattern of patterns) {
        if (pattern.pattern.test(lowerText)) {
          const score = pattern.confidence;
          if (score > maxScore) {
            maxScore = score;
            bestMatch = pattern.intent;
          }
        }
      }
      
      if (maxScore > 0) {
        intentScores.set(category, maxScore);
      }
    }
    
    // Find primary intent
    let primaryIntent = 'general';
    let primaryConfidence = 0.5;
    const secondaryIntents: Array<{ intent: string; confidence: number }> = [];
    
    for (const [category, score] of intentScores) {
      if (score > primaryConfidence) {
        if (primaryIntent !== 'general') {
          secondaryIntents.push({ intent: primaryIntent, confidence: primaryConfidence });
        }
        primaryIntent = category;
        primaryConfidence = score;
      } else if (score > 0.3) {
        secondaryIntents.push({ intent: category, confidence: score });
      }
    }
    
    // Sort secondary intents by confidence
    secondaryIntents.sort((a, b) => b.confidence - a.confidence);
    
    // Determine intent category
    let intentCategory: IntentAnalysis['intentCategory'] = 'informational';
    if (primaryIntent === 'creative') intentCategory = 'creative';
    else if (primaryIntent === 'analytical') intentCategory = 'analytical';
    else if (primaryIntent === 'emotional') intentCategory = 'emotional';
    else if (primaryIntent === 'philosophical') intentCategory = 'philosophical';
    else if (primaryIntent === 'transactional') intentCategory = 'transactional';
    
    return {
      primaryIntent,
      confidence: primaryConfidence,
      secondaryIntents: secondaryIntents.slice(0, 3),
      intentCategory
    };
  }

  // Entity Extraction
  private async extractEntities(text: string): Promise<EntityAnalysis> {
    const entities: EntityAnalysis['entities'] = [];
    const keyPhrases: string[] = [];
    const topics: string[] = [];
    
    // Simple entity extraction patterns
    const entityPatterns = [
      { type: 'technology', pattern: /\b(AI|artificial intelligence|machine learning|neural network|blockchain|cloud|software|hardware|internet|web|app|application|database|API|algorithm)\b/gi },
      { type: 'action', pattern: /\b(create|build|develop|design|analyze|implement|execute|test|deploy|launch|run|start|stop|pause|resume)\b/gi },
      { type: 'concept', pattern: /\b(system|process|method|approach|strategy|technique|framework|architecture|pattern|principle|theory|concept)\b/gi },
      { type: 'organization', pattern: /\b(Google|Microsoft|Apple|Amazon|Facebook|Tesla|OpenAI|GitHub|Stack Overflow|NASA|IBM|Oracle)\b/gi },
      { type: 'person', pattern: /\b(Elon Musk|Bill Gates|Steve Jobs|Mark Zuckerberg|Jeff Bezos|Tim Cook|Sundar Pichai|Satya Nadella)\b/gi }
    ];
    
    // Extract entities
    for (const { type, pattern } of entityPatterns) {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        entities.push({
          text: match[0],
          type,
          confidence: 0.8,
          start: match.index,
          end: match.index + match[0].length,
          context: text.substring(Math.max(0, match.index - 20), Math.min(text.length, match.index + match[0].length + 20))
        });
      }
    }
    
    // Extract key phrases (simplified)
    const sentences = text.split(/[.!?]+/);
    for (const sentence of sentences) {
      const words = sentence.trim().split(/\s+/);
      if (words.length >= 3 && words.length <= 8) {
        keyPhrases.push(sentence.trim());
      }
    }
    
    // Determine domain
    const domainScores: Map<string, number> = new Map();
    const domainKeywords = {
      technology: ['AI', 'software', 'code', 'programming', 'algorithm', 'data', 'system'],
      business: ['business', 'market', 'customer', 'revenue', 'profit', 'strategy', 'management'],
      science: ['research', 'study', 'experiment', 'hypothesis', 'theory', 'analysis', 'scientific'],
      arts: ['art', 'design', 'creative', 'music', 'painting', 'literature', 'aesthetic'],
      philosophy: ['philosophy', 'ethics', 'logic', 'metaphysics', 'epistemology', 'wisdom', 'truth'],
      personal: ['I', 'me', 'my', 'personal', 'feel', 'think', 'believe', 'experience']
    };
    
    const lowerText = text.toLowerCase();
    for (const [domain, keywords] of Object.entries(domainKeywords)) {
      const score = keywords.reduce((acc, keyword) => {
        return acc + (lowerText.includes(keyword.toLowerCase()) ? 1 : 0);
      }, 0);
      domainScores.set(domain, score);
    }
    
    // Find domain with highest score
    let domain: EntityAnalysis['domain'] = 'general';
    let maxScore = 0;
    for (const [domainName, score] of domainScores) {
      if (score > maxScore) {
        maxScore = score;
        domain = domainName as EntityAnalysis['domain'];
      }
    }
    
    // Extract topics from key phrases
    topics.push(...keyPhrases.slice(0, 5));
    
    return {
      entities,
      keyPhrases: keyPhrases.slice(0, 10),
      topics,
      domain
    };
  }

  // Context Analysis
  private async analyzeContext(text: string, providedContext?: any): Promise<ContextAnalysis> {
    const lowerText = text.toLowerCase();
    
    // Determine situation
    let situation: ContextAnalysis['situation'] = 'informal';
    if (lowerText.includes('please') || lowerText.includes('thank you') || lowerText.includes('could you')) {
      situation = 'formal';
    } else if (lowerText.includes('hey') || lowerText.includes('hi') || lowerText.includes('yo')) {
      situation = 'casual';
    } else if (lowerText.includes('professional') || lowerText.includes('business') || lowerText.includes('work')) {
      situation = 'professional';
    } else if (lowerText.includes('research') || lowerText.includes('study') || lowerText.includes('academic')) {
      situation = 'academic';
    } else if (lowerText.includes('create') || lowerText.includes('design') || lowerText.includes('imagine')) {
      situation = 'creative';
    }
    
    // Determine urgency
    let urgency: ContextAnalysis['urgency'] = 'medium';
    if (lowerText.includes('urgent') || lowerText.includes('asap') || lowerText.includes('immediately') || lowerText.includes('now')) {
      urgency = 'high';
    } else if (lowerText.includes('critical') || lowerText.includes('emergency') || lowerText.includes('deadline')) {
      urgency = 'critical';
    } else if (lowerText.includes('when you can') || lowerText.includes('no rush') || lowerText.includes('eventually')) {
      urgency = 'low';
    }
    
    // Determine scope
    let scope: ContextAnalysis['scope'] = 'specific';
    if (lowerText.includes('overall') || lowerText.includes('general') || lowerText.includes('big picture')) {
      scope = 'general';
    } else if (lowerText.includes('strategy') || lowerText.includes('long term') || lowerText.includes('vision')) {
      scope = 'strategic';
    } else if (lowerText.includes('how to') || lowerText.includes('steps') || lowerText.includes('implementation')) {
      scope = 'tactical';
    }
    
    // Determine emotional context (simplified)
    let emotionalContext: ContextAnalysis['emotionalContext'] = 'neutral';
    const emotionalWords = {
      positive: ['happy', 'excited', 'great', 'wonderful', 'amazing', 'love', 'excellent'],
      negative: ['sad', 'angry', 'frustrated', 'disappointed', 'worried', 'upset', 'hate']
    };
    
    let positiveCount = 0;
    let negativeCount = 0;
    
    for (const word of emotionalWords.positive) {
      if (lowerText.includes(word)) positiveCount++;
    }
    
    for (const word of emotionalWords.negative) {
      if (lowerText.includes(word)) negativeCount++;
    }
    
    if (positiveCount > negativeCount) {
      emotionalContext = 'positive';
    } else if (negativeCount > positiveCount) {
      emotionalContext = 'negative';
    } else if (positiveCount > 0 || negativeCount > 0) {
      emotionalContext = 'mixed';
    }
    
    return {
      situation,
      urgency,
      scope,
      emotionalContext,
      complexity: 'moderate' // Will be refined by complexity assessment
    };
  }

  // Emotional Analysis
  private async analyzeEmotionalTone(text: string): Promise<EmotionalAnalysis> {
    const lowerText = text.toLowerCase();
    const emotionScores: Map<string, number> = new Map();
    
    // Score emotions based on keywords
    for (const [emotion, keywords] of this.emotionalKeywords) {
      let score = 0;
      let matchCount = 0;
      
      for (const keyword of keywords) {
        if (lowerText.includes(keyword.word)) {
          score += keyword.intensity;
          matchCount++;
        }
      }
      
      if (matchCount > 0) {
        emotionScores.set(emotion, score / matchCount);
      }
    }
    
    // Find primary emotion
    let primaryEmotion: EmotionalAnalysis['primaryEmotion'] = 'neutral';
    let maxScore = 0;
    
    for (const [emotion, score] of emotionScores) {
      if (score > maxScore) {
        maxScore = score;
        primaryEmotion = emotion as EmotionalAnalysis['primaryEmotion'];
      }
    }
    
    // Calculate emotional intensity
    const emotionalIntensity = Math.min(maxScore, 1);
    
    // Determine emotional tone
    let emotionalTone: EmotionalAnalysis['emotionalTone'] = 'neutral';
    if (primaryEmotion === 'joy') emotionalTone = 'enthusiastic';
    else if (primaryEmotion === 'sadness') emotionalTone = 'calm';
    else if (primaryEmotion === 'anger') emotionalTone = 'frustrated';
    else if (primaryEmotion === 'fear') emotionalTone = 'concerned';
    else if (primaryEmotion === 'trust') emotionalTone = 'confident';
    
    // Determine sentiment
    let sentiment: EmotionalAnalysis['sentiment'] = 'neutral';
    let sentimentScore = 0;
    
    const positiveWords = ['good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic', 'love', 'like', 'happy'];
    const negativeWords = ['bad', 'terrible', 'awful', 'horrible', 'hate', 'dislike', 'sad', 'angry', 'frustrated'];
    
    for (const word of positiveWords) {
      if (lowerText.includes(word)) sentimentScore += 0.1;
    }
    
    for (const word of negativeWords) {
      if (lowerText.includes(word)) sentimentScore -= 0.1;
    }
    
    if (sentimentScore > 0.1) sentiment = 'positive';
    else if (sentimentScore < -0.1) sentiment = 'negative';
    else if (sentimentScore !== 0) sentiment = 'mixed';
    
    return {
      primaryEmotion,
      emotionalIntensity,
      emotionalTone,
      sentiment,
      sentimentScore: Math.max(-1, Math.min(1, sentimentScore))
    };
  }

  // Complexity Assessment
  private async assessComplexity(text: string): Promise<ComplexityAssessment> {
    const words = text.split(/\s+/);
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    
    // Lexical complexity
    let lexicalComplexity = 0;
    const longWords = words.filter(word => word.length > 6).length;
    const uniqueWords = new Set(words.map(w => w.toLowerCase())).size;
    
    lexicalComplexity += (longWords / words.length) * 0.4;
    lexicalComplexity += (uniqueWords / words.length) * 0.3;
    lexicalComplexity += text.length > 500 ? 0.3 : 0;
    
    // Syntactic complexity
    let syntacticComplexity = 0;
    const avgSentenceLength = words.length / sentences.length;
    const punctuationCount = (text.match(/[,:;]/g) || []).length;
    
    syntacticComplexity += Math.min(avgSentenceLength / 20, 1) * 0.5;
    syntacticComplexity += Math.min(punctuationCount / sentences.length / 3, 1) * 0.3;
    syntacticComplexity += sentences.length > 5 ? 0.2 : 0;
    
    // Semantic complexity
    let semanticComplexity = 0;
    const abstractWords = ['concept', 'theory', 'principle', 'philosophy', 'metaphysics', 'consciousness', 'existence'];
    const technicalWords = ['algorithm', 'implementation', 'architecture', 'framework', 'paradigm', 'methodology'];
    
    const abstractCount = abstractWords.filter(word => text.toLowerCase().includes(word)).length;
    const technicalCount = technicalWords.filter(word => text.toLowerCase().includes(word)).length;
    
    semanticComplexity += Math.min(abstractCount / 3, 1) * 0.5;
    semanticComplexity += Math.min(technicalCount / 3, 1) * 0.5;
    
    // Overall complexity
    const overallComplexity = (lexicalComplexity + syntacticComplexity + semanticComplexity) / 3;
    
    // Complexity factors
    const complexityFactors = [
      {
        factor: 'text_length',
        impact: Math.min(text.length / 1000, 1),
        description: 'Longer texts tend to be more complex'
      },
      {
        factor: 'vocabulary_diversity',
        impact: uniqueWords / words.length,
        description: 'Higher vocabulary diversity increases complexity'
      },
      {
        factor: 'sentence_structure',
        impact: avgSentenceLength / 15,
        description: 'Longer sentences increase syntactic complexity'
      },
      {
        factor: 'conceptual_depth',
        impact: (abstractCount + technicalCount) / 10,
        description: 'Abstract and technical concepts increase semantic complexity'
      }
    ];
    
    // Estimate processing time
    const estimatedProcessingTime = Math.max(1, overallComplexity * 10);
    
    return {
      lexicalComplexity: Math.min(lexicalComplexity, 1),
      syntacticComplexity: Math.min(syntacticComplexity, 1),
      semanticComplexity: Math.min(semanticComplexity, 1),
      overallComplexity: Math.min(overallComplexity, 1),
      complexityFactors,
      estimatedProcessingTime
    };
  }

  // Calculate overall confidence
  private calculateOverallConfidence(
    intent: IntentAnalysis,
    entities: EntityAnalysis,
    context: ContextAnalysis,
    emotional: EmotionalAnalysis,
    complexity: ComplexityAssessment
  ): number {
    const intentConfidence = intent.confidence;
    const entityConfidence = entities.entities.length > 0 ? 0.8 : 0.5;
    const contextConfidence = 0.7; // Context analysis is generally reliable
    const emotionalConfidence = emotional.emotionalIntensity > 0.3 ? 0.8 : 0.6;
    const complexityConfidence = 0.8; // Complexity assessment is algorithmic
    
    return (intentConfidence + entityConfidence + contextConfidence + emotionalConfidence + complexityConfidence) / 5;
  }
}

// Export singleton instance
export const textAnalysisEngine = new TextAnalysisEngine();