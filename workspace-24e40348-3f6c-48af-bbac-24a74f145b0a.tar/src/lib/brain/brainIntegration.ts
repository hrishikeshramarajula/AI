// 🧠 Real Brain Integration System - Connects All Brain Processing Components
// This is the main integration layer that combines text analysis, goal decomposition, and knowledge retrieval

import { textAnalysisEngine, TextAnalysisInput, TextAnalysisResult } from './textAnalysis';
import { goalDecompositionEngine, GoalInput, GoalDecompositionResult } from './goalDecomposition';
import { knowledgeRetrievalEngine, KnowledgeQuery, RetrievalResult } from './knowledgeRetrieval';

export interface BrainProcessingInput {
  text: string;
  context?: any;
  userId?: string;
  constraints?: string[];
  preferences?: {
    approach?: 'conservative' | 'aggressive' | 'balanced';
    priority?: 'speed' | 'quality' | 'cost' | 'comprehensive';
    style?: 'detailed' | 'concise' | 'creative' | 'analytical';
  };
}

export interface BrainProcessingResult {
  success: boolean;
  processingId: string;
  input: BrainProcessingInput;
  textAnalysis: TextAnalysisResult;
  goalDecomposition: GoalDecompositionResult;
  knowledgeRetrieval: RetrievalResult;
  synthesizedStrategy: {
    approach: string;
    prioritizedGoals: Array<{
      id: string;
      title: string;
      priority: string;
      estimatedDuration: number;
    }>;
    keyKnowledge: string[];
    recommendedStrategies: string[];
    executionPlan: {
      phases: Array<{
        name: string;
        goals: string[];
        estimatedDuration: number;
      }>;
      totalEstimatedDuration: number;
    };
    riskMitigation: string[];
  };
  actionableInsights: {
    immediateActions: string[];
    considerations: string[];
    successFactors: string[];
    potentialChallenges: string[];
  };
  processingMetadata: {
    totalProcessingTime: number;
    textAnalysisTime: number;
    goalDecompositionTime: number;
    knowledgeRetrievalTime: number;
    integrationTime: number;
    confidence: number;
    processingDepth: 'basic' | 'detailed' | 'comprehensive';
    brainCapabilities: string[];
  };
}

export class RealBrainIntegration {
  private processingHistory: Map<string, BrainProcessingResult>;

  constructor() {
    this.processingHistory = new Map();
  }

  // Main processing method - integrates all 3 brain components
  public async processWithRealBrain(input: BrainProcessingInput): Promise<BrainProcessingResult> {
    const startTime = Date.now();
    const processingId = `brain-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    console.log('🧠 Starting REAL BRAIN processing integration...');
    console.log('📝 Input:', input.text.substring(0, 100) + (input.text.length > 100 ? '...' : ''));
    
    try {
      // STEP 1: Text Analysis
      console.log('🔍 Step 1: Performing text analysis...');
      const textAnalysisStart = Date.now();
      
      const textAnalysisInput: TextAnalysisInput = {
        text: input.text,
        context: input.context,
        timestamp: new Date(),
        userId: input.userId
      };
      
      const textAnalysis = await textAnalysisEngine.analyzeText(textAnalysisInput);
      const textAnalysisTime = Date.now() - textAnalysisStart;
      
      console.log('✅ Text analysis completed:', {
        intent: textAnalysis.intent.primaryIntent,
        confidence: textAnalysis.processingMetadata.confidence,
        complexity: textAnalysis.complexity.overallComplexity,
        time: `${textAnalysisTime}ms`
      });

      // STEP 2: Goal Decomposition
      console.log('🎯 Step 2: Decomposing goals...');
      const goalDecompositionStart = Date.now();
      
      const goalInput: GoalInput = {
        textAnalysis,
        originalInput: input.text,
        context: input.context,
        constraints: input.constraints,
        preferences: input.preferences
      };
      
      const goalDecomposition = await goalDecompositionEngine.decomposeGoals(goalInput);
      const goalDecompositionTime = Date.now() - goalDecompositionStart;
      
      console.log('✅ Goal decomposition completed:', {
        subGoals: goalDecomposition.processingMetadata.subGoalsGenerated,
        approach: goalDecomposition.processingMetadata.strategy,
        estimatedDuration: `${goalDecomposition.processingMetadata.estimatedTotalDuration}s`,
        time: `${goalDecompositionTime}ms`
      });

      // STEP 3: Knowledge Retrieval
      console.log('🧠 Step 3: Retrieving knowledge...');
      const knowledgeRetrievalStart = Date.now();
      
      const knowledgeQuery: KnowledgeQuery = {
        goals: goalDecomposition.hierarchy.subGoals.map(goal => ({
          id: goal.id,
          title: goal.title,
          type: goal.type,
          category: goal.category,
          complexity: goal.complexity
        })),
        context: {
          domain: textAnalysis.entities.domain,
          intent: textAnalysis.intent.primaryIntent,
          urgency: textAnalysis.context.urgency,
          emotionalContext: textAnalysis.context.emotionalContext
        },
        constraints: input.constraints || [],
        preferences: input.preferences || {},
        searchScope: textAnalysis.context.scope
      };
      
      const knowledgeRetrieval = await knowledgeRetrievalEngine.retrieveKnowledge(knowledgeQuery);
      const knowledgeRetrievalTime = Date.now() - knowledgeRetrievalStart;
      
      console.log('✅ Knowledge retrieval completed:', {
        knowledgeItems: knowledgeRetrieval.knowledgeItems.length,
        strategies: knowledgeRetrieval.strategies.length,
        confidence: knowledgeRetrieval.processingMetadata.confidence,
        time: `${knowledgeRetrievalTime}ms`
      });

      // STEP 4: Integration and Synthesis
      console.log('🔄 Step 4: Integrating and synthesizing strategy...');
      const integrationStart = Date.now();
      
      const synthesizedStrategy = this.synthesizeStrategy(textAnalysis, goalDecomposition, knowledgeRetrieval);
      const actionableInsights = this.generateActionableInsights(textAnalysis, goalDecomposition, knowledgeRetrieval);
      
      const integrationTime = Date.now() - integrationStart;
      const totalProcessingTime = Date.now() - startTime;

      // Create final result
      const result: BrainProcessingResult = {
        success: true,
        processingId,
        input,
        textAnalysis,
        goalDecomposition,
        knowledgeRetrieval,
        synthesizedStrategy,
        actionableInsights,
        processingMetadata: {
          totalProcessingTime,
          textAnalysisTime,
          goalDecompositionTime,
          knowledgeRetrievalTime,
          integrationTime,
          confidence: this.calculateOverallConfidence(textAnalysis, goalDecomposition, knowledgeRetrieval),
          processingDepth: 'comprehensive',
          brainCapabilities: [
            'text_analysis',
            'intent_recognition',
            'entity_extraction',
            'emotional_analysis',
            'goal_decomposition',
            'knowledge_retrieval',
            'strategy_formulation',
            'risk_assessment',
            'execution_planning'
          ]
        }
      };

      // Store in processing history
      this.processingHistory.set(processingId, result);

      console.log('🎉 REAL BRAIN processing integration completed successfully!');
      console.log('📊 Summary:', {
        processingId,
        totalProcessingTime: `${totalProcessingTime}ms`,
        confidence: result.processingMetadata.confidence,
        subGoals: goalDecomposition.hierarchy.subGoals.length,
        knowledgeItems: knowledgeRetrieval.knowledgeItems.length,
        strategies: knowledgeRetrieval.strategies.length
      });

      return result;

    } catch (error) {
      console.error('❌ REAL BRAIN processing integration failed:', error);
      
      const totalProcessingTime = Date.now() - startTime;
      
      // Return error result
      const errorResult: BrainProcessingResult = {
        success: false,
        processingId,
        input,
        textAnalysis: this.getFallbackTextAnalysis(input),
        goalDecomposition: this.getFallbackGoalDecomposition(input),
        knowledgeRetrieval: this.getFallbackKnowledgeRetrieval(input),
        synthesizedStrategy: this.getFallbackSynthesizedStrategy(),
        actionableInsights: this.getFallbackActionableInsights(),
        processingMetadata: {
          totalProcessingTime,
          textAnalysisTime: 0,
          goalDecompositionTime: 0,
          knowledgeRetrievalTime: 0,
          integrationTime: 0,
          confidence: 0.3,
          processingDepth: 'basic',
          brainCapabilities: ['fallback_processing']
        }
      };

      return errorResult;
    }
  }

  // Strategy synthesis - combines all components into actionable strategy
  private synthesizeStrategy(
    textAnalysis: TextAnalysisResult,
    goalDecomposition: GoalDecompositionResult,
    knowledgeRetrieval: RetrievalResult
  ): BrainProcessingResult['synthesizedStrategy'] {
    
    // Determine approach based on context and knowledge
    let approach = 'balanced';
    if (textAnalysis.context.urgency === 'critical' || textAnalysis.context.urgency === 'high') {
      approach = 'aggressive';
    } else if (textAnalysis.complexity.overallComplexity > 0.7) {
      approach = 'conservative';
    } else if (textAnalysis.intent.intentCategory === 'creative') {
      approach = 'adaptive';
    }

    // Prioritize goals based on urgency, dependencies, and knowledge recommendations
    const prioritizedGoals = goalDecomposition.hierarchy.subGoals
      .map(goal => ({
        id: goal.id,
        title: goal.title,
        priority: goal.priority,
        estimatedDuration: goal.estimatedDuration,
        dependencies: goal.dependencies.length,
        hasKnowledgeSupport: knowledgeRetrieval.knowledgeItems.some(item => 
          item.metadata.applicableGoals.includes(goal.type)
        )
      }))
      .sort((a, b) => {
        // Sort by priority, then by knowledge support, then by dependencies
        const priorityOrder = { 'critical': 4, 'high': 3, 'medium': 2, 'low': 1 };
        const priorityDiff = priorityOrder[b.priority] - priorityOrder[a.priority];
        if (priorityDiff !== 0) return priorityDiff;
        
        const knowledgeDiff = (b.hasKnowledgeSupport ? 1 : 0) - (a.hasKnowledgeSupport ? 1 : 0);
        if (knowledgeDiff !== 0) return knowledgeDiff;
        
        return a.dependencies - b.dependencies;
      })
      .slice(0, 8)
      .map(goal => ({
        id: goal.id,
        title: goal.title,
        priority: goal.priority,
        estimatedDuration: goal.estimatedDuration
      }));

    // Extract key knowledge items
    const keyKnowledge = knowledgeRetrieval.knowledgeItems
      .slice(0, 5)
      .map(item => item.title);

    // Extract recommended strategies
    const recommendedStrategies = knowledgeRetrieval.strategies
      .slice(0, 3)
      .map(strategy => strategy.name);

    // Create execution plan from goal decomposition phases
    const executionPlan = {
      phases: goalDecomposition.hierarchy.executionPlan.phases.map(phase => ({
        name: phase.name,
        goals: phase.goals,
        estimatedDuration: phase.estimatedDuration
      })),
      totalEstimatedDuration: goalDecomposition.processingMetadata.estimatedTotalDuration
    };

    // Generate risk mitigation strategies
    const riskMitigation: string[] = [];
    if (goalDecomposition.hierarchy.riskAssessment.overallRiskLevel !== 'low') {
      riskMitigation.push('Implement continuous monitoring and risk assessment');
    }
    if (textAnalysis.context.urgency === 'critical') {
      riskMitigation.push('Establish contingency plans and fallback options');
    }
    if (textAnalysis.complexity.overallComplexity > 0.7) {
      riskMitigation.push('Break down complex tasks into manageable components');
    }
    riskMitigation.push('Maintain flexibility to adapt to changing requirements');
    riskMitigation.push('Document all decisions and rationale for future reference');

    return {
      approach,
      prioritizedGoals,
      keyKnowledge,
      recommendedStrategies,
      executionPlan,
      riskMitigation
    };
  }

  // Generate actionable insights from all components
  private generateActionableInsights(
    textAnalysis: TextAnalysisResult,
    goalDecomposition: GoalDecompositionResult,
    knowledgeRetrieval: RetrievalResult
  ): BrainProcessingResult['actionableInsights'] {
    
    const immediateActions: string[] = [];
    const considerations: string[] = [];
    const successFactors: string[] = [];
    const potentialChallenges: string[] = [];

    // Immediate actions based on urgency and priority
    if (textAnalysis.context.urgency === 'critical' || textAnalysis.context.urgency === 'high') {
      immediateActions.push('Prioritize high-impact, quick-win activities');
      immediateActions.push('Establish clear communication channels');
    }
    
    const criticalGoals = goalDecomposition.hierarchy.subGoals.filter(goal => goal.priority === 'critical');
    if (criticalGoals.length > 0) {
      immediateActions.push(`Focus on critical goal: ${criticalGoals[0].title}`);
    }

    // Considerations based on context and complexity
    if (textAnalysis.complexity.overallComplexity > 0.7) {
      considerations.push('High complexity requires thorough planning and testing');
      considerations.push('Consider seeking expert guidance for complex components');
    }
    
    if (textAnalysis.context.emotionalContext !== 'neutral') {
      considerations.push(`Account for emotional context: ${textAnalysis.context.emotionalContext}`);
    }

    // Success factors from knowledge and goals
    successFactors.push('Clear understanding of objectives and requirements');
    successFactors.push('Systematic approach to problem decomposition');
    
    if (knowledgeRetrieval.knowledgeItems.length > 0) {
      successFactors.push('Leverage available knowledge and best practices');
    }
    
    if (knowledgeRetrieval.strategies.length > 0) {
      successFactors.push('Apply proven strategies and methodologies');
    }

    // Potential challenges from risks and gaps
    if (goalDecomposition.hierarchy.riskAssessment.overallRiskLevel !== 'low') {
      potentialChallenges.push('Risk factors require active management and mitigation');
    }
    
    if (knowledgeRetrieval.insights.knowledgeGaps.length > 0) {
      potentialChallenges.push('Knowledge gaps may require additional research or expertise');
    }
    
    if (textAnalysis.context.urgency === 'critical') {
      potentialChallenges.push('Time constraints may impact quality and thoroughness');
    }

    return {
      immediateActions,
      considerations,
      successFactors,
      potentialChallenges
    };
  }

  // Calculate overall confidence across all components
  private calculateOverallConfidence(
    textAnalysis: TextAnalysisResult,
    goalDecomposition: GoalDecompositionResult,
    knowledgeRetrieval: RetrievalResult
  ): number {
    const textConfidence = textAnalysis.processingMetadata.confidence;
    const goalConfidence = goalDecomposition.processingMetadata.confidence;
    const knowledgeConfidence = knowledgeRetrieval.processingMetadata.confidence;
    
    // Weighted average with emphasis on text analysis and goal decomposition
    return (textConfidence * 0.4 + goalConfidence * 0.4 + knowledgeConfidence * 0.2);
  }

  // Fallback methods for error cases
  private getFallbackTextAnalysis(input: BrainProcessingInput): TextAnalysisResult {
    return {
      input: {
        text: input.text,
        context: input.context,
        timestamp: new Date(),
        userId: input.userId
      },
      intent: {
        primaryIntent: 'general',
        confidence: 0.5,
        secondaryIntents: [],
        intentCategory: 'informational'
      },
      entities: {
        entities: [],
        keyPhrases: [input.text.substring(0, 50)],
        topics: [],
        domain: 'general'
      },
      context: {
        situation: 'informal',
        urgency: 'medium',
        complexity: 'moderate',
        scope: 'specific',
        emotionalContext: 'neutral'
      },
      emotional: {
        primaryEmotion: 'neutral',
        emotionalIntensity: 0.5,
        emotionalTone: 'neutral',
        sentiment: 'neutral',
        sentimentScore: 0
      },
      complexity: {
        lexicalComplexity: 0.5,
        syntacticComplexity: 0.5,
        semanticComplexity: 0.5,
        overallComplexity: 0.5,
        complexityFactors: [],
        estimatedProcessingTime: 10
      },
      processingMetadata: {
        analysisTime: 0,
        confidence: 0.3,
        analysisDepth: 'basic',
        processingStrategies: ['fallback_processing']
      }
    };
  }

  private getFallbackGoalDecomposition(input: BrainProcessingInput): GoalDecompositionResult {
    return {
      input: {
        textAnalysis: this.getFallbackTextAnalysis(input),
        originalInput: input.text,
        context: input.context,
        constraints: input.constraints,
        preferences: input.preferences
      },
      hierarchy: {
        mainGoal: {
          id: 'fallback-main-goal',
          title: 'Process User Request',
          description: input.text,
          objective: 'general_task',
          scope: 'specific',
          priority: 'medium',
          estimatedTotalDuration: 30,
          successCriteria: ['Request processed'],
          constraints: input.constraints || []
        },
        subGoals: [{
          id: 'fallback-sub-goal',
          title: 'Analyze and Respond',
          description: 'Basic analysis and response generation',
          type: 'analysis',
          priority: 'medium',
          estimatedDuration: 30,
          dependencies: [],
          resources: ['AI processing'],
          successCriteria: ['Response generated'],
          riskFactors: ['Limited processing capabilities'],
          alternatives: [],
          status: 'pending',
          confidence: 0.5,
          complexity: 'moderate',
          category: 'information'
        }],
        executionPlan: {
          approach: 'sequential',
          phases: [{
            name: 'Processing',
            goals: ['fallback-sub-goal'],
            estimatedDuration: 30,
            dependencies: []
          }],
          criticalPath: ['fallback-sub-goal'],
          milestones: []
        },
        riskAssessment: {
          overallRiskLevel: 'medium',
          risks: []
        },
        optimization: {
          parallelization: [],
          shortcuts: []
        }
      },
      processingMetadata: {
        decompositionTime: 0,
        strategy: 'sequential',
        confidence: 0.3,
        subGoalsGenerated: 1,
        estimatedTotalDuration: 30
      }
    };
  }

  private getFallbackKnowledgeRetrieval(input: BrainProcessingInput): RetrievalResult {
    return {
      query: {
        goals: [{
          id: 'fallback-goal',
          title: 'Basic Processing',
          type: 'analysis',
          category: 'information',
          complexity: 'moderate'
        }],
        context: {
          domain: 'general',
          intent: 'general',
          urgency: 'medium',
          emotionalContext: 'neutral'
        },
        constraints: input.constraints || [],
        preferences: input.preferences || {},
        searchScope: 'specific'
      },
      knowledgeItems: [],
      strategies: [],
      recommendations: [],
      insights: {
        knowledgeGaps: ['Limited knowledge base access'],
        opportunityAreas: ['Basic processing available'],
        riskFactors: ['Reduced capabilities in fallback mode'],
        optimizationSuggestions: ['Restore full functionality when possible']
      },
      processingMetadata: {
        retrievalTime: 0,
        knowledgeSources: [],
        strategiesEvaluated: 0,
        confidence: 0.2,
        relevanceScore: 0.2
      }
    };
  }

  private getFallbackSynthesizedStrategy(): BrainProcessingResult['synthesizedStrategy'] {
    return {
      approach: 'basic',
      prioritizedGoals: [{
        id: 'fallback-goal',
        title: 'Basic Processing',
        priority: 'medium',
        estimatedDuration: 30
      }],
      keyKnowledge: ['Basic processing capabilities'],
      recommendedStrategies: ['Simple sequential approach'],
      executionPlan: {
        phases: [{
          name: 'Basic Processing',
          goals: ['fallback-goal'],
          estimatedDuration: 30
        }],
        totalEstimatedDuration: 30
      },
      riskMitigation: ['Use fallback processing', 'Monitor for errors']
    };
  }

  private getFallbackActionableInsights(): BrainProcessingResult['actionableInsights'] {
    return {
      immediateActions: ['Process request with basic capabilities'],
      considerations: ['Limited functionality in fallback mode'],
      successFactors: ['Basic request completion'],
      potentialChallenges: ['Reduced processing quality']
    };
  }

  // Utility methods
  public getProcessingHistory(): BrainProcessingResult[] {
    return Array.from(this.processingHistory.values());
  }

  public getProcessingById(processingId: string): BrainProcessingResult | null {
    return this.processingHistory.get(processingId) || null;
  }

  public clearProcessingHistory(): void {
    this.processingHistory.clear();
    console.log('🧠 Brain processing history cleared');
  }

  public getBrainStatus(): {
    isReady: boolean;
    capabilities: string[];
    processingCount: number;
    lastProcessingTime?: Date;
  } {
    return {
      isReady: true,
      capabilities: [
        'text_analysis',
        'goal_decomposition',
        'knowledge_retrieval',
        'strategy_synthesis',
        'risk_assessment',
        'execution_planning'
      ],
      processingCount: this.processingHistory.size,
      lastProcessingTime: this.processingHistory.size > 0 
        ? Array.from(this.processingHistory.values())[this.processingHistory.size - 1].processingMetadata.totalProcessingTime > 0 
          ? new Date() 
          : undefined
        : undefined
    };
  }
}

// Export singleton instance
export const realBrainIntegration = new RealBrainIntegration();