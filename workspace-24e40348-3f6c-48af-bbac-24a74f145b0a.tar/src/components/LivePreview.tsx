'use client';

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, Eye, EyeOff, Maximize2, Minimize2, Undo, Redo } from 'lucide-react';

interface WebsiteChange {
  type: 'add' | 'modify' | 'delete';
  file: string;
  description: string;
  codeChanges?: string;
  timestamp: Date;
}

interface LivePreviewProps {
  changes: WebsiteChange[];
  isVisible: boolean;
  onToggleVisibility: () => void;
  onRefresh: () => void;
}

export default function LivePreview({ changes, isVisible, onToggleVisibility, onRefresh }: LivePreviewProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [iframeKey, setIframeKey] = useState(Date.now());
  const [selectedChange, setSelectedChange] = useState<WebsiteChange | null>(null);
  const [changeHistory, setChangeHistory] = useState<WebsiteChange[][]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);

  // Initialize history with current changes
  useEffect(() => {
    if (changes.length > 0 && historyIndex === -1) {
      setChangeHistory([changes]);
      setHistoryIndex(0);
    }
  }, [changes, historyIndex]);

  // Add keyboard shortcuts for undo/redo
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isVisible) return;
      
      if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {
        e.preventDefault();
        handleUndo();
      } else if ((e.ctrlKey || e.metaKey) && (e.key === 'z' && e.shiftKey || e.key === 'y')) {
        e.preventDefault();
        handleRedo();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isVisible, historyIndex, changeHistory]);

  const handleUndo = () => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      setHistoryIndex(newIndex);
      // Here you would also revert the actual file changes
      console.log('Undo to history index:', newIndex);
    }
  };

  const handleRedo = () => {
    if (historyIndex < changeHistory.length - 1) {
      const newIndex = historyIndex + 1;
      setHistoryIndex(newIndex);
      // Here you would also reapply the actual file changes
      console.log('Redo to history index:', newIndex);
    }
  };

  const canUndo = historyIndex > 0;
  const canRedo = historyIndex < changeHistory.length - 1;

  // Refresh iframe when changes are applied
  useEffect(() => {
    if (changes.length > 0) {
      setIframeKey(Date.now());
    }
  }, [changes]);

  const handleRefresh = () => {
    setIframeKey(Date.now());
    onRefresh();
  };

  const formatChangeType = (type: string) => {
    switch (type) {
      case 'add':
        return { label: 'Added', color: 'bg-green-500' };
      case 'modify':
        return { label: 'Modified', color: 'bg-blue-500' };
      case 'delete':
        return { label: 'Deleted', color: 'bg-red-500' };
      default:
        return { label: type, color: 'bg-gray-500' };
    }
  };

  if (!isVisible) {
    return (
      <div className="fixed bottom-4 right-4 z-50">
        <Button
          onClick={onToggleVisibility}
          className="shadow-lg"
          size="sm"
        >
          <Eye className="w-4 h-4 mr-2" />
          Show Preview ({changes.length})
        </Button>
      </div>
    );
  }

  return (
    <div className={`fixed ${isFullscreen ? 'inset-0 z-50 bg-white' : 'bottom-4 right-4 w-96 h-96 z-50'} border border-gray-200 rounded-lg shadow-xl bg-white`}>
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b border-gray-200 bg-gray-50 rounded-t-lg">
        <div className="flex items-center gap-2">
          <Eye className="w-4 h-4 text-blue-500" />
          <h3 className="font-semibold text-sm">Live Preview</h3>
          <Badge variant="secondary" className="text-xs">
            {changes.length} changes
          </Badge>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleUndo}
            disabled={!canUndo}
            className="h-6 w-6 p-0"
            title="Undo (Ctrl+Z)"
          >
            <Undo className="w-3 h-3" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleRedo}
            disabled={!canRedo}
            className="h-6 w-6 p-0"
            title="Redo (Ctrl+Y)"
          >
            <Redo className="w-3 h-3" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleRefresh}
            className="h-6 w-6 p-0"
            title="Refresh"
          >
            <RefreshCw className="w-3 h-3" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="h-6 w-6 p-0"
            title={isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
          >
            {isFullscreen ? <Minimize2 className="w-3 h-3" /> : <Maximize2 className="w-3 h-3" />}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggleVisibility}
            className="h-6 w-6 p-0"
            title="Hide Preview"
          >
            <EyeOff className="w-3 h-3" />
          </Button>
        </div>
      </div>

      <div className="flex h-[calc(100%-48px)]">
        {/* Changes Panel */}
        <div className="w-64 border-r border-gray-200 overflow-y-auto">
          <div className="p-3">
            <h4 className="font-medium text-sm mb-2">Recent Changes</h4>
            <div className="space-y-2">
              {changes.map((change, index) => {
                const { label, color } = formatChangeType(change.type);
                return (
                  <div
                    key={index}
                    className={`p-2 rounded cursor-pointer hover:bg-gray-50 transition-colors ${
                      selectedChange === change ? 'bg-blue-50 border border-blue-200' : ''
                    }`}
                    onClick={() => setSelectedChange(change)}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <div className={`w-2 h-2 rounded-full ${color}`} />
                      <span className="text-xs font-medium">{label}</span>
                    </div>
                    <div className="text-xs text-gray-600">{change.description}</div>
                    <div className="text-xs text-gray-400 mt-1">{change.file}</div>
                  </div>
                );
              })}
              {changes.length === 0 && (
                <div className="text-xs text-gray-400 text-center py-4">
                  No changes yet
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Preview Panel */}
        <div className="flex-1 flex flex-col">
          {selectedChange ? (
            <div className="flex-1 overflow-hidden">
              {/* Change Details */}
              <div className="p-3 border-b border-gray-200 bg-gray-50">
                <h4 className="font-medium text-sm mb-1">{selectedChange.description}</h4>
                <div className="text-xs text-gray-500">{selectedChange.file}</div>
              </div>
              
              {/* Code Changes */}
              {selectedChange.codeChanges && (
                <div className="flex-1 overflow-y-auto p-3">
                  <h5 className="text-xs font-medium mb-2">Code Changes:</h5>
                  <pre className="text-xs bg-gray-900 text-gray-100 p-3 rounded overflow-x-auto">
                    <code>{selectedChange.codeChanges}</code>
                  </pre>
                </div>
              )}
            </div>
          ) : (
            /* Website Preview */
            <div className="flex-1 relative">
              <iframe
                key={iframeKey}
                src="http://localhost:3000"
                className="w-full h-full border-0"
                title="Website Preview"
                sandbox="allow-same-origin allow-scripts allow-forms"
              />
              <div className="absolute top-2 left-2">
                <Badge variant="outline" className="text-xs bg-white/90">
                  Live Preview
                </Badge>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}