// 🧠 Enhanced AI Agent Brain Component - Works like Claude's Brain
// This component showcases an AI Agent Brain that understands requests, creates todos, 
// executes step-by-step, checks for errors, and displays results on home screen

'use client';

import React, { useState, useEffect, useRef } from 'react';
import {
  Brain,
  Zap,
  Target,
  Settings,
  BarChart3,
  Shield,
  BookOpen,
  Activity,
  Lightbulb,
  CheckCircle,
  XCircle,
  Clock,
  Users,
  Cpu,
  Network,
  Database,
  FileText,
  MessageSquare,
  TrendingUp,
  AlertTriangle,
  Info,
  X,
  Play,
  Pause,
  RotateCcw,
  CheckSquare,
  Square,
  ListTodo,
  Progress,
  Eye,
  Download,
  RefreshCw
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Progress as ProgressBar } from '@/components/ui/progress';

interface TodoItem {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed' | 'retrying';
  priority: 'low' | 'medium' | 'high' | 'critical';
  estimatedTime: number;
  actualTime?: number;
  result?: any;
  error?: string;
  dependencies?: string[];
  reasoning?: string[];
  confidence: number;
}

interface ExecutionStep {
  step: number;
  name: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  startTime?: Date;
  endTime?: Date;
  result?: any;
  error?: string;
  progress: number;
}

interface EnhancedAIAgentBrainProps {
  isVisible: boolean;
  onToggleVisibility: () => void;
  onShowHomeScreen?: (content: any) => void;
}

export default function EnhancedAIAgentBrain({ isVisible, onToggleVisibility, onShowHomeScreen }: EnhancedAIAgentBrainProps) {
  const [inputText, setInputText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [todos, setTodos] = useState<TodoItem[]>([]);
  const [executionSteps, setExecutionSteps] = useState<ExecutionStep[]>([]);
  const [currentStep, setCurrentStep] = useState(0);
  const [analysis, setAnalysis] = useState<any>(null);
  const [finalResult, setFinalResult] = useState<any>(null);
  const [progress, setProgress] = useState(0);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [endTime, setEndTime] = useState<Date | null>(null);
  const [liveLogs, setLiveLogs] = useState<string[]>([]);
  const logsEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll logs
  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [liveLogs]);

  const addLiveLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setLiveLogs(prev => [...prev, `[${timestamp}] ${message}`]);
  };

  const analyzeRequest = async (text: string) => {
    addLiveLog('🧠 Starting request analysis...');
    
    // Simulate AI analysis
    const analysisResult = {
      intent: 'general_task',
      confidence: 0.95,
      entities: [],
      complexity: 'medium',
      estimatedSteps: 5,
      estimatedTime: 30000, // 30 seconds
      requirements: [],
      risks: [],
      opportunities: []
    };

    // Add some delay to simulate processing
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    addLiveLog(`✅ Analysis complete - Intent: ${analysisResult.intent}, Confidence: ${analysisResult.confidence}`);
    setAnalysis(analysisResult);
    return analysisResult;
  };

  const createTodos = (analysisResult: any, request: string) => {
    addLiveLog('📋 Creating todo list based on analysis...');
    
    const todos: TodoItem[] = [
      {
        id: '1',
        title: 'Understand Request',
        description: `Analyze and understand the user request: "${request}"`,
        status: 'pending',
        priority: 'critical',
        estimatedTime: 2000,
        confidence: 0.98,
        dependencies: []
      },
      {
        id: '2',
        title: 'Break Down Tasks',
        description: 'Decompose the request into manageable sub-tasks',
        status: 'pending',
        priority: 'high',
        estimatedTime: 3000,
        confidence: 0.90,
        dependencies: ['1']
      },
      {
        id: '3',
        title: 'Plan Execution Strategy',
        description: 'Create a step-by-step execution plan',
        status: 'pending',
        priority: 'high',
        estimatedTime: 2000,
        confidence: 0.85,
        dependencies: ['2']
      },
      {
        id: '4',
        title: 'Execute Tasks',
        description: 'Execute each task in the planned sequence',
        status: 'pending',
        priority: 'high',
        estimatedTime: 15000,
        confidence: 0.80,
        dependencies: ['3']
      },
      {
        id: '5',
        title: 'Verify Results',
        description: 'Check if all tasks completed successfully and results are correct',
        status: 'pending',
        priority: 'medium',
        estimatedTime: 3000,
        confidence: 0.85,
        dependencies: ['4']
      },
      {
        id: '6',
        title: 'Error Checking & Correction',
        description: 'Identify any missed items or errors and fix them',
        status: 'pending',
        priority: 'medium',
        estimatedTime: 2000,
        confidence: 0.75,
        dependencies: ['5']
      },
      {
        id: '7',
        title: 'Final Review',
        description: 'Review the complete execution and prepare final output',
        status: 'pending',
        priority: 'low',
        estimatedTime: 1000,
        confidence: 0.90,
        dependencies: ['6']
      }
    ];

    setTodos(todos);
    addLiveLog(`✅ Created ${todos.length} todo items`);
    return todos;
  };

  const createExecutionSteps = (todos: TodoItem[]) => {
    const steps: ExecutionStep[] = [
      { step: 1, name: 'Natural Language Understanding', status: 'pending', progress: 0 },
      { step: 2, name: 'Task Analysis & Planning', status: 'pending', progress: 0 },
      { step: 3, name: 'Todo List Creation', status: 'pending', progress: 0 },
      { step: 4, name: 'Step-by-Step Execution', status: 'pending', progress: 0 },
      { step: 5, name: 'Real-time Verification', status: 'pending', progress: 0 },
      { step: 6, name: 'Error Detection & Correction', status: 'pending', progress: 0 },
      { step: 7, name: 'Final Output Generation', status: 'pending', progress: 0 }
    ];

    setExecutionSteps(steps);
    return steps;
  };

  const executeTodo = async (todo: TodoItem): Promise<TodoItem> => {
    addLiveLog(`⚡ Executing: ${todo.title}`);
    
    // Update todo status to in_progress
    const updatedTodo = { ...todo, status: 'in_progress' as const };
    setTodos(prev => prev.map(t => t.id === todo.id ? updatedTodo : t));
    
    const startTime = Date.now();
    
    try {
      // Simulate execution with realistic delays
      await new Promise(resolve => setTimeout(resolve, todo.estimatedTime));
      
      // Simulate different results based on todo type
      let result: any = {};
      let success = true;
      
      switch (todo.id) {
        case '1':
          result = {
            understanding: 'Request analyzed successfully',
            intent: 'general_task',
            confidence: 0.95
          };
          break;
        case '2':
          result = {
            subtasks: [
              'Data collection',
              'Processing', 
              'Analysis',
              'Output generation'
            ],
            complexity: 'medium'
          };
          break;
        case '3':
          result = {
            strategy: 'sequential_execution',
            timeline: 'optimized',
            resources: 'allocated'
          };
          break;
        case '4':
          result = {
            executedTasks: 4,
            successfulTasks: 4,
            failedTasks: 0,
            outputs: ['Task 1 result', 'Task 2 result', 'Task 3 result', 'Task 4 result']
          };
          break;
        case '5':
          result = {
            verificationStatus: 'passed',
            checksPerformed: 5,
            issuesFound: 0
          };
          break;
        case '6':
          result = {
            errorsDetected: 0,
            correctionsApplied: 0,
            qualityScore: 0.95
          };
          break;
        case '7':
          result = {
            summary: 'All tasks completed successfully',
            overallConfidence: 0.92,
            recommendations: ['Continue monitoring', 'Document results']
          };
          break;
        default:
          result = { message: 'Task completed' };
      }
      
      const actualTime = Date.now() - startTime;
      
      // Simulate occasional failures for demonstration
      if (Math.random() < 0.1) { // 10% chance of failure
        throw new Error('Simulated execution failure');
      }
      
      addLiveLog(`✅ Completed: ${todo.title}`);
      
      return {
        ...updatedTodo,
        status: 'completed' as const,
        actualTime,
        result,
        reasoning: [`Task completed successfully in ${actualTime}ms`]
      };
      
    } catch (error) {
      addLiveLog(`❌ Failed: ${todo.title} - ${error}`);
      
      return {
        ...updatedTodo,
        status: 'failed' as const,
        actualTime: Date.now() - startTime,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  };

  const checkAndFixErrors = async (todos: TodoItem[]): Promise<TodoItem[]> => {
    addLiveLog('🔍 Checking for errors and missed items...');
    
    let updatedTodos = [...todos];
    let correctionsMade = false;
    
    // Check for failed todos
    const failedTodos = todos.filter(todo => todo.status === 'failed');
    for (const failedTodo of failedTodos) {
      addLiveLog(`🔄 Retrying failed todo: ${failedTodo.title}`);
      
      // Retry the failed todo
      const retriedTodo = await executeTodo({
        ...failedTodo,
        status: 'retrying'
      });
      
      updatedTodos = updatedTodos.map(todo => 
        todo.id === failedTodo.id ? retriedTodo : todo
      );
      
      correctionsMade = true;
    }
    
    // Check for missing todos (simulation)
    const completedTodos = todos.filter(todo => todo.status === 'completed');
    if (completedTodos.length < todos.length * 0.8) { // If less than 80% completed
      addLiveLog('⚠️ Detected incomplete execution - adding recovery todos...');
      
      // Add recovery todos
      const recoveryTodo: TodoItem = {
        id: `recovery_${Date.now()}`,
        title: 'Recovery Execution',
        description: 'Execute recovery plan for incomplete tasks',
        status: 'pending',
        priority: 'high',
        estimatedTime: 5000,
        confidence: 0.80
      };
      
      updatedTodos.push(recoveryTodo);
      correctionsMade = true;
    }
    
    if (correctionsMade) {
      addLiveLog('✅ Error correction and recovery completed');
    } else {
      addLiveLog('✅ No errors detected - all tasks completed successfully');
    }
    
    return updatedTodos;
  };

  const executeStepByStep = async () => {
    if (isPaused) return;
    
    for (let i = 0; i < executionSteps.length; i++) {
      if (isPaused) break;
      
      const step = executionSteps[i];
      setCurrentStep(i + 1);
      
      // Update step status
      setExecutionSteps(prev => prev.map(s => 
        s.step === step.step ? { ...s, status: 'running', startTime: new Date() } : s
      ));
      
      addLiveLog(`🚀 Starting step ${step.step}: ${step.name}`);
      
      // Simulate step execution with progress updates
      for (let progress = 0; progress <= 100; progress += 10) {
        if (isPaused) break;
        
        setExecutionSteps(prev => prev.map(s => 
          s.step === step.step ? { ...s, progress } : s
        ));
        
        setProgress(((i + progress / 100) / executionSteps.length) * 100);
        
        await new Promise(resolve => setTimeout(resolve, 200));
      }
      
      // Complete step
      setExecutionSteps(prev => prev.map(s => 
        s.step === step.step ? { ...s, status: 'completed', endTime: new Date() } : s
      ));
      
      addLiveLog(`✅ Completed step ${step.step}: ${step.name}`);
      
      // Execute corresponding todos
      const stepTodos = todos.filter(todo => {
        const stepIndex = parseInt(todo.id) - 1;
        return stepIndex === i;
      });
      
      for (const todo of stepTodos) {
        if (isPaused) break;
        
        const completedTodo = await executeTodo(todo);
        setTodos(prev => prev.map(t => t.id === todo.id ? completedTodo : t));
      }
    }
    
    // Error checking and correction
    const correctedTodos = await checkAndFixErrors(todos);
    setTodos(correctedTodos);
    
    // Generate final result
    const result = {
      success: true,
      summary: 'All tasks completed successfully',
      executionTime: endTime ? endTime.getTime() - startTime!.getTime() : 0,
      todosCompleted: correctedTodos.filter(t => t.status === 'completed').length,
      totalTodos: correctedTodos.length,
      confidence: 0.92,
      output: {
        message: 'Request processed successfully by Enhanced AI Agent Brain',
        results: correctedTodos.filter(t => t.status === 'completed').map(t => t.result),
        timestamp: new Date().toISOString()
      }
    };
    
    setFinalResult(result);
    addLiveLog('🎉 Execution completed successfully!');
    
    // Show result on home screen if callback provided
    if (onShowHomeScreen) {
      onShowHomeScreen(result);
    }
  };

  const startProcessing = async () => {
    if (!inputText.trim() || isProcessing) return;
    
    setIsProcessing(true);
    setIsPaused(false);
    setStartTime(new Date());
    setEndTime(null);
    setProgress(0);
    setLiveLogs([]);
    setFinalResult(null);
    
    addLiveLog('🚀 Starting Enhanced AI Agent Brain processing...');
    
    try {
      // Step 1: Analyze request
      const analysisResult = await analyzeRequest(inputText);
      
      // Step 2: Create todos
      const createdTodos = createTodos(analysisResult, inputText);
      
      // Step 3: Create execution steps
      const steps = createExecutionSteps(createdTodos);
      
      // Step 4: Execute step by step
      await executeStepByStep();
      
    } catch (error) {
      addLiveLog(`❌ Processing failed: ${error}`);
    } finally {
      setIsProcessing(false);
      setEndTime(new Date());
    }
  };

  const pauseProcessing = () => {
    setIsPaused(!isPaused);
    addLiveLog(isPaused ? '▶️ Resuming processing...' : '⏸️ Pausing processing...');
  };

  const resetProcessing = () => {
    setIsProcessing(false);
    setIsPaused(false);
    setTodos([]);
    setExecutionSteps([]);
    setCurrentStep(0);
    setAnalysis(null);
    setFinalResult(null);
    setProgress(0);
    setStartTime(null);
    setEndTime(null);
    setLiveLogs([]);
    setInputText('');
    addLiveLog('🔄 Reset complete');
  };

  const getTodoIcon = (todo: TodoItem) => {
    switch (todo.status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'in_progress':
      case 'retrying':
        return <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-600" />;
      default:
        return <Square className="w-4 h-4 text-gray-400" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'text-red-600';
      case 'high': return 'text-orange-600';
      case 'medium': return 'text-yellow-600';
      case 'low': return 'text-green-600';
      default: return 'text-gray-600';
    }
  };

  return (
    isVisible && (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-7xl h-[90vh] flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b">
            <div className="flex items-center space-x-3">
              <Brain className="w-6 h-6 text-purple-600" />
              <h2 className="text-xl font-bold">🧠 Enhanced AI Agent Brain</h2>
              <Badge variant="outline">Works like Claude's Brain</Badge>
            </div>
            <div className="flex items-center space-x-2">
              {isProcessing && (
                <>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={pauseProcessing}
                    className="flex items-center space-x-1"
                  >
                    {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                    <span>{isPaused ? 'Resume' : 'Pause'}</span>
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={resetProcessing}
                    className="flex items-center space-x-1"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>Reset</span>
                  </Button>
                </>
              )}
              <Button variant="ghost" size="sm" onClick={onToggleVisibility}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
          
          {/* Content */}
          <div className="flex-1 overflow-hidden">
            <div className="h-full flex">
              {/* Left Panel - Input and Controls */}
              <div className="w-1/3 border-r p-4 flex flex-col space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Enter your request:</label>
                  <Textarea
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="I want you to create a todo list, execute step by step, check for errors, and show the results..."
                    className="min-h-24"
                    disabled={isProcessing}
                  />
                </div>
                
                <Button
                  onClick={startProcessing}
                  disabled={!inputText.trim() || isProcessing}
                  className="flex items-center space-x-2"
                >
                  {isProcessing ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      <span>Processing...</span>
                    </>
                  ) : (
                    <>
                      <Brain className="w-4 h-4" />
                      <span>Start AI Brain Processing</span>
                    </>
                  )}
                </Button>
                
                {/* Progress Overview */}
                {progress > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm">Progress Overview</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <ProgressBar value={progress} className="w-full" />
                      <div className="flex justify-between text-xs text-gray-600">
                        <span>{Math.round(progress)}% Complete</span>
                        <span>Step {currentStep} of {executionSteps.length}</span>
                      </div>
                      {startTime && (
                        <div className="text-xs text-gray-600">
                          Started: {startTime.toLocaleTimeString()}
                          {endTime && ` • Ended: ${endTime.toLocaleTimeString()}`}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
                
                {/* Analysis Results */}
                {analysis && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm">Request Analysis</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span>Intent:</span>
                        <Badge variant="outline">{analysis.intent}</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Confidence:</span>
                        <span>{(analysis.confidence * 100).toFixed(1)}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Complexity:</span>
                        <Badge variant="outline">{analysis.complexity}</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Est. Steps:</span>
                        <span>{analysis.estimatedSteps}</span>
                      </div>
                    </CardContent>
                  </Card>
                )}
                
                {/* Final Result */}
                {finalResult && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm flex items-center justify-between">
                        <span>Final Result</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onShowHomeScreen?.(finalResult)}
                          className="flex items-center space-x-1"
                        >
                          <Eye className="w-3 h-3" />
                          <span>Show on Home</span>
                        </Button>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span>Status:</span>
                        <Badge variant={finalResult.success ? "default" : "destructive"}>
                          {finalResult.success ? "Success" : "Failed"}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Completed:</span>
                        <span>{finalResult.todosCompleted}/{finalResult.totalTodos}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Confidence:</span>
                        <span>{(finalResult.confidence * 100).toFixed(1)}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Time:</span>
                        <span>{(finalResult.executionTime / 1000).toFixed(1)}s</span>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
              
              {/* Right Panel - Todo List and Live Logs */}
              <div className="flex-1 flex flex-col">
                <Tabs defaultValue="todos" className="h-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="todos">📋 Todo List</TabsTrigger>
                    <TabsTrigger value="steps">🚀 Execution Steps</TabsTrigger>
                    <TabsTrigger value="logs">📝 Live Logs</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="todos" className="flex-1 p-4">
                    <ScrollArea className="h-full">
                      <div className="space-y-3">
                        {todos.length === 0 ? (
                          <div className="text-center text-gray-500 py-8">
                            <ListTodo className="w-12 h-12 mx-auto mb-4 opacity-50" />
                            <p>No todos yet. Start processing to see the todo list.</p>
                          </div>
                        ) : (
                          todos.map((todo) => (
                            <Card key={todo.id} className="transition-all duration-300">
                              <CardContent className="p-4">
                                <div className="flex items-start space-x-3">
                                  <div className="mt-1">
                                    {getTodoIcon(todo)}
                                  </div>
                                  <div className="flex-1 space-y-2">
                                    <div className="flex items-center justify-between">
                                      <h4 className="font-medium">{todo.title}</h4>
                                      <div className="flex items-center space-x-2">
                                        <Badge 
                                          variant="outline" 
                                          className={getPriorityColor(todo.priority)}
                                        >
                                          {todo.priority}
                                        </Badge>
                                        <Badge variant={todo.status === 'completed' ? 'default' : 'secondary'}>
                                          {todo.status.replace('_', ' ')}
                                        </Badge>
                                      </div>
                                    </div>
                                    <p className="text-sm text-gray-600">{todo.description}</p>
                                    <div className="flex items-center justify-between text-xs text-gray-500">
                                      <span>Est: {todo.estimatedTime}ms</span>
                                      {todo.actualTime && (
                                        <span>Actual: {todo.actualTime}ms</span>
                                      )}
                                      <span>Confidence: {(todo.confidence * 100).toFixed(0)}%</span>
                                    </div>
                                    {todo.error && (
                                      <div className="text-xs text-red-600 bg-red-50 p-2 rounded">
                                        Error: {todo.error}
                                      </div>
                                    )}
                                    {todo.result && (
                                      <details className="text-xs">
                                        <summary className="cursor-pointer text-blue-600">View Result</summary>
                                        <pre className="mt-1 p-2 bg-gray-50 rounded text-xs overflow-x-auto">
                                          {JSON.stringify(todo.result, null, 2)}
                                        </pre>
                                      </details>
                                    )}
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          ))
                        )}
                      </div>
                    </ScrollArea>
                  </TabsContent>
                  
                  <TabsContent value="steps" className="flex-1 p-4">
                    <ScrollArea className="h-full">
                      <div className="space-y-3">
                        {executionSteps.length === 0 ? (
                          <div className="text-center text-gray-500 py-8">
                            <Activity className="w-12 h-12 mx-auto mb-4 opacity-50" />
                            <p>No execution steps yet. Start processing to see the steps.</p>
                          </div>
                        ) : (
                          executionSteps.map((step) => (
                            <Card key={step.step}>
                              <CardContent className="p-4">
                                <div className="flex items-center justify-between mb-2">
                                  <div className="flex items-center space-x-3">
                                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                                      step.status === 'completed' ? 'bg-green-100 text-green-700' :
                                      step.status === 'running' ? 'bg-blue-100 text-blue-700' :
                                      step.status === 'failed' ? 'bg-red-100 text-red-700' :
                                      'bg-gray-100 text-gray-700'
                                    }`}>
                                      {step.step}
                                    </div>
                                    <div>
                                      <h4 className="font-medium">{step.name}</h4>
                                      <div className="flex items-center space-x-2 text-xs text-gray-500">
                                        <Badge variant={step.status === 'completed' ? 'default' : 'secondary'}>
                                          {step.status.replace('_', ' ')}
                                        </Badge>
                                        {step.startTime && (
                                          <span>Started: {step.startTime.toLocaleTimeString()}</span>
                                        )}
                                        {step.endTime && (
                                          <span>Ended: {step.endTime.toLocaleTimeString()}</span>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                  {getTodoIcon({ 
                                    id: step.step.toString(), 
                                    title: step.name, 
                                    description: '', 
                                    status: step.status,
                                    priority: 'medium',
                                    estimatedTime: 0,
                                    confidence: 0 
                                  } as TodoItem)}
                                </div>
                                {step.progress > 0 && (
                                  <ProgressBar value={step.progress} className="w-full mt-2" />
                                )}
                                {step.error && (
                                  <div className="text-xs text-red-600 bg-red-50 p-2 rounded mt-2">
                                    Error: {step.error}
                                  </div>
                                )}
                              </CardContent>
                            </Card>
                          ))
                        )}
                      </div>
                    </ScrollArea>
                  </TabsContent>
                  
                  <TabsContent value="logs" className="flex-1 p-4">
                    <ScrollArea className="h-full">
                      <div className="space-y-1">
                        {liveLogs.length === 0 ? (
                          <div className="text-center text-gray-500 py-8">
                            <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                            <p>No logs yet. Start processing to see live updates.</p>
                          </div>
                        ) : (
                          liveLogs.map((log, index) => (
                            <div
                              key={index}
                              className="text-sm font-mono p-2 rounded hover:bg-gray-50 transition-colors"
                            >
                              {log}
                            </div>
                          ))
                        )}
                        <div ref={logsEndRef} />
                      </div>
                    </ScrollArea>
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  );
}