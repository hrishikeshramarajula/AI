import { NextRequest, NextResponse } from 'next/server';
import { FullstackGenerator } from '@/lib/fullstackGenerator';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { prompt } = body;

    if (!prompt) {
      return NextResponse.json(
        { error: 'Prompt is required' },
        { status: 400 }
      );
    }

    console.log('🚀 Generating fullstack project for:', prompt);

    // Generate the complete fullstack project
    const fullstackProject = await FullstackGenerator.generateFullstackProject(prompt);

    // Return the project structure and files
    return NextResponse.json({
      success: true,
      project: fullstackProject,
      summary: {
        name: fullstackProject.structure.name,
        description: fullstackProject.structure.description,
        files: fullstackProject.files.length,
        features: fullstackProject.structure.features,
        framework: fullstackProject.structure.framework,
        database: fullstackProject.structure.database
      },
      message: `Successfully generated ${fullstackProject.structure.name} with ${fullstackProject.files.length} files`
    });

  } catch (error) {
    console.error('Fullstack generation error:', error);
    
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to generate fullstack project',
        message: 'I encountered an error while generating your fullstack project. Please try again with a simpler description.',
        suggestions: [
          'Try describing your project in simpler terms',
          'Focus on the main features you need',
          'Specify the type of application (e.g., todo app, blog, e-commerce)',
          'Mention any specific technologies if preferred'
        ]
      },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    message: 'Simple Fullstack Generator API',
    capabilities: [
      'Generate complete Next.js applications',
      'Create database schemas with Prisma',
      'Build REST API endpoints',
      'Design responsive frontend components',
      'Generate configuration files',
      'Create project documentation',
      'Show live preview with demo'
    ],
    examples: [
      'Create a todo list application',
      'Build a blog CMS with authentication',
      'Make an e-commerce platform',
      'Develop a real-time chat application'
    ]
  });
}