'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Loader2, Brain, Search, CheckCircle, AlertCircle } from 'lucide-react';
import MarkdownRenderer from './MarkdownRenderer';

interface StreamingDeepResearchMessageProps {
  query: string;
  config?: any;
  onComplete?: (content: string, metadata: any) => void;
  onError?: (error: string) => void;
}

interface StreamingChunk {
  type: 'start' | 'chunk' | 'complete' | 'error';
  line?: string;
  lineNumber?: number;
  isLast?: boolean;
  message?: string;
  confidence?: number;
  intent?: string;
  processingTime?: number;
  metadata?: any;
  error?: string;
}

export default function StreamingDeepResearchMessage({ 
  query, 
  config,
  onComplete, 
  onError 
}: StreamingDeepResearchMessageProps) {
  const [chunks, setChunks] = useState<string[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [isError, setIsError] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [metadata, setMetadata] = useState<any>(null);
  const [startTime, setStartTime] = useState<Date>(new Date());
  const [sourcesCount, setSourcesCount] = useState(0);
  const [elapsedTime, setElapsedTime] = useState<string>('0s');
  
  // Use a ref to track all chunks for immediate access
  const allChunksRef = useRef<string[]>([]);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    startStreamingResearch();
    return () => {
      // Cleanup is handled by the stream completion
    };
  }, [query, config]);

  useEffect(() => {
    // Auto-scroll to bottom as content comes in
    if (contentRef.current) {
      contentRef.current.scrollTop = contentRef.current.scrollHeight;
    }
  }, [chunks]);

  const startStreamingResearch = async () => {
    try {
      setStartTime(new Date());
      setChunks([]);
      allChunksRef.current = []; // Reset the ref
      setIsStreaming(true);
      setIsError(false);
      setError(null);
      setMetadata(null);

      // Try non-streaming API first for better reliability
      console.log('🔬 Starting deep research with non-streaming API...');
      
      // Add a simple initializing message
      const initializingMessage = [`🔍 Initializing deep research for: ${query}...`];
      allChunksRef.current = initializingMessage;
      setChunks(initializingMessage);
      
      try {
        const fallbackResponse = await fetch('/api/deep-research', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: query,
            config: config || {
              researchDepth: 'comprehensive',
              includeWebSearch: true,
              maxSources: 10
            }
          }),
        });

        if (fallbackResponse.ok) {
          const fallbackData = await fallbackResponse.json();
          
          if (fallbackData.success && fallbackData.response) {
            console.log('✅ Non-streaming research completed successfully');
            
            // Clear initializing message and add actual research content
            const content = fallbackData.response;
            
            // Split content into manageable chunks but preserve structure
            const lines = content.split('\n');
            const researchChunks = [];
            let currentChunk = '';
            
            for (const line of lines) {
              if (line.trim()) {
                currentChunk += line + '\n';
              } else if (currentChunk.trim()) {
                researchChunks.push(currentChunk.trim());
                currentChunk = '';
              }
            }
            
            // Add any remaining content
            if (currentChunk.trim()) {
              researchChunks.push(currentChunk.trim());
            }
            
            // If we got no structured chunks, use the whole content as one chunk
            if (researchChunks.length === 0 && content.trim()) {
              researchChunks.push(content.trim());
            }
            
            console.log(`📝 Research processed into ${researchChunks.length} chunks`);
            
            // Update both ref and state with actual content
            allChunksRef.current = researchChunks;
            setChunks(researchChunks);
            
            // Mark as complete
            setIsStreaming(false);
            setIsComplete(true);
            setMetadata({
              confidence: 0.9,
              intent: 'deep_research_non_streaming',
              processingTime: Date.now() - startTime.getTime(),
              ...fallbackData._metadata
            });
            
            if (onComplete) {
              const finalResponse = allChunksRef.current.join('\n\n');
              onComplete(finalResponse, {
                confidence: 0.9,
                intent: 'deep_research_non_streaming',
                processingTime: Date.now() - startTime.getTime(),
                metadata: fallbackData._metadata || {}
              });
            }
            return; // Success, exit the function
          }
        }
      } catch (nonStreamingError) {
        console.log('🔄 Non-streaming API failed, trying streaming API:', nonStreamingError);
      }

      // If non-streaming fails, try streaming API as fallback
      console.log('🔄 Trying streaming API as fallback...');
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => {
          controller.abort();
          console.warn('⚠️ Deep research request timed out after 4 minutes');
        }, 240000); // Increased to 4 minutes to match backend timeout
        
        const response = await fetch('/api/deep-research-streaming', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: query,
            config: config || {
              researchDepth: 'comprehensive',
              includeWebSearch: true,
              maxSources: 10
            }
          }),
          signal: controller.signal
        });
        
        clearTimeout(timeoutId);

        if (!response.ok) {
          throw new Error(`Research request failed (${response.status}): ${response.statusText}`);
        }

        const reader = response.body?.getReader();
        const decoder = new TextDecoder();

        if (!reader) {
          throw new Error('No reader available for streaming');
        }

        while (true) {
          const { done, value } = await reader.read();
          
          if (done) break;

          const chunk = decoder.decode(value, { stream: true });
          const lines = chunk.split('\n');

          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const data: StreamingChunk = JSON.parse(line.slice(6));
                
                switch (data.type) {
                  case 'start':
                    console.log('🚀 Deep research started for query:', query);
                    // Clear initializing message when streaming starts
                    if (allChunksRef.current.length > 0 && allChunksRef.current[0].includes('Initializing deep research')) {
                      allChunksRef.current = [];
                      setChunks([]);
                    }
                    break;
                    
                  case 'keepalive':
                    // Ignore keepalive messages
                    break;
                    
                  case 'chunk':
                    if (data.line && data.line.trim()) {
                      // Update both state and ref
                      const newChunks = [...allChunksRef.current, data.line];
                      allChunksRef.current = newChunks;
                      setChunks(newChunks);
                      
                      // Extract sources count from the content if available
                      if (data.line.includes('Total Sources Analyzed:')) {
                        const match = data.line.match(/Total Sources Analyzed:\s*(\d+)/);
                        if (match) {
                          setSourcesCount(parseInt(match[1]));
                        }
                      }
                    }
                    break;
                    
                  case 'complete':
                    console.log('🎉 Deep research completed for query:', query);
                    setIsStreaming(false);
                    setIsComplete(true);
                    setMetadata({
                      confidence: data.confidence,
                      intent: data.intent,
                      processingTime: data.processingTime,
                      ...data.metadata
                    });
                    
                    if (onComplete) {
                      // Use the ref to get all chunks immediately
                      const finalResponse = allChunksRef.current.join('\n');
                      
                      onComplete(finalResponse, {
                        confidence: data.confidence || 0.9,
                        intent: data.intent || 'deep_research',
                        processingTime: data.processingTime || 0,
                        metadata: data.metadata || {}
                      });
                    }
                    return; // Success, exit the function
                    
                  case 'error':
                    throw new Error(data.error || 'Deep research error occurred');
                }
              } catch (e) {
                console.error('❌ Error parsing deep research streaming chunk:', e, 'Line:', line);
                // Don't throw here, just continue processing
              }
            }
          }
        }
      } catch (streamingError) {
        console.log('🔄 Streaming failed or aborted, checking if we have enough content...');
        
        // Check if we have any content from the streaming attempt
        if (allChunksRef.current.length > 0 && !allChunksRef.current[0].includes('Initializing deep research')) {
          console.log('✅ Using partial content from streaming attempt');
          setIsStreaming(false);
          setIsComplete(true);
          
          if (onComplete) {
            const finalResponse = allChunksRef.current.join('\n');
            onComplete(finalResponse, {
              confidence: 0.7,
              intent: 'deep_research_partial',
              processingTime: Date.now() - startTime.getTime(),
              metadata: { partial: true }
            });
          }
          return; // Use partial content instead of fallback
        }
        
        console.log('🔄 No content from streaming, both APIs failed:', streamingError);
        throw streamingError; // Both APIs failed, go to final error handler
      }
    } catch (err) {
      console.error('❌ Deep research error (both streaming and fallback failed):', err);
      const errorMessage = err instanceof Error ? err.message : 'Research failed';
      setError(errorMessage);
      setIsStreaming(false);
      setIsError(true);
      
      // Provide a helpful fallback response that will persist
      const isTimeout = errorMessage.includes('timeout') || errorMessage.includes('aborted');
      const fallbackResponse = `🔧 Deep Research - Service Response

${isTimeout 
  ? 'I apologize, but the deep research service is taking longer than expected to respond. This is normal for comprehensive research queries.'
  : `I apologize, but I encountered an error while trying to connect to the deep research service: ${errorMessage}.`
}

Current Status:
- Deep Research Service: ${isTimeout ? '⏳ Processing complex research query' : '⚠️ Temporarily experiencing technical difficulties'}
- System: ✅ All other components working normally
- Recovery: 🔄 Auto-recovery in progress

${isTimeout 
  ? 'This usually happens when:\n• The research query requires comprehensive analysis\n• The AI model is gathering detailed information\n• High demand on research services\n\nImmediate Solutions:\n1. Wait a few moments and try again\n2. Try a simpler research query\n3. Use a different AI model for faster results'
  : 'This could be due to:\n• Temporary network connectivity issues\n• Deep research service being temporarily unavailable\n• High demand on research services\n\nImmediate Solutions:\n1. Wait 30 seconds and try your query again\n2. Try a different research configuration\n3. Use regular chat mode for simpler queries'
}

The system is designed to handle these situations gracefully and will recover automatically.

If the problem persists, you can try using a different research configuration or AI model.`;

      // Update both state and ref
      allChunksRef.current = [fallbackResponse];
      setChunks([fallbackResponse]);
      
      // Ensure onComplete is called even in error case to make the message permanent
      if (onComplete) {
        onComplete(fallbackResponse, {
          confidence: 0,
          intent: 'error',
          processingTime: 0,
          metadata: { error: errorMessage }
        });
      }
    }
  };

  const getElapsedTime = () => {
    const now = new Date();
    const diff = now.getTime() - startTime.getTime();
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    
    if (minutes > 0) {
      return `${minutes}m ${remainingSeconds}s`;
    }
    return `${seconds}s`;
  };

  // Update the timer every second
  React.useEffect(() => {
    if (isStreaming) {
      const interval = setInterval(() => {
        const now = new Date();
        const diff = now.getTime() - startTime.getTime();
        const seconds = Math.floor(diff / 1000);
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        
        if (minutes > 0) {
          setElapsedTime(`${minutes}m ${remainingSeconds}s`);
        } else {
          setElapsedTime(`${seconds}s`);
        }
      }, 1000);
      
      return () => clearInterval(interval);
    }
  }, [isStreaming, startTime]);

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5" />
            Deep Research
            {isComplete && <CheckCircle className="w-4 h-4 text-green-500" />}
            {isError && <AlertCircle className="w-4 h-4 text-red-500" />}
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant="outline">
              {sourcesCount > 0 ? `${sourcesCount} sources` : 'Researching...'}
            </Badge>
            <Badge variant="outline">
              {elapsedTime}
            </Badge>
            {isStreaming && (
              <Loader2 className="w-4 h-4 animate-spin" />
            )}
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <ScrollArea className="h-96 w-full border rounded-md p-4">
          <div 
            ref={contentRef}
            className="prose prose-sm max-w-none"
          >
            {chunks.map((chunk, index) => (
              <div 
                key={index} 
                className="text-sm text-gray-800 leading-relaxed mb-2"
                style={{ 
                  opacity: 1,
                  transition: 'opacity 0.3s ease-in-out'
                }}
              >
                <MarkdownRenderer content={chunk} />
              </div>
            ))}
            
            {isStreaming && chunks.length === 0 && (
              <div className="flex items-center gap-2 text-gray-500 mt-4">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>🔍 Initializing deep research...</span>
              </div>
            )}
            
            {isStreaming && chunks.length > 0 && (
              <div className="flex items-center gap-2 text-blue-600 mt-4">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>🧠 Research in progress... {elapsedTime}</span>
              </div>
            )}
          </div>
        </ScrollArea>
        
        {isComplete && metadata && (
          <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-md">
            <div className="flex items-center gap-2 text-green-800">
              <CheckCircle className="w-4 h-4" />
              <span className="font-medium">Research completed successfully!</span>
            </div>
            <div className="text-sm text-green-700 mt-1 grid grid-cols-2 gap-2">
              <div>Processing time: {elapsedTime}</div>
              <div>Sources analyzed: {metadata.totalSources || sourcesCount}</div>
              <div>Research stages: {metadata.researchStages || 3}</div>
              <div>Confidence: {Math.round((metadata.confidence || 0.9) * 100)}%</div>
            </div>
          </div>
        )}
        
        {isError && (
          <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-md">
            <div className="flex items-center gap-2 text-red-800">
              <AlertCircle className="w-4 h-4" />
              <span className="font-medium">Research encountered an error</span>
            </div>
            {error && (
              <p className="text-sm text-red-700 mt-1">
                {error}
              </p>
            )}
            <div className="flex gap-2 mt-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={startStreamingResearch}
              >
                Retry Research
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => onError?.(error || 'Unknown error')}
              >
                Report Error
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}