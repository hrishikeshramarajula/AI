'use client';

import React from 'react';
import HTMLRenderer from './HTMLRenderer';

interface MarkdownRendererProps {
  content: string | undefined | null;
  className?: string;
}

export default function MarkdownRenderer({ content, className = '' }: MarkdownRendererProps) {
  // Clean up unwanted # symbols while preserving proper Markdown headers
  const cleanContent = (markdown: string | undefined | null) => {
    // Add this line to prevent the error - ensure we always have a string
    let cleaned = markdown || '';
    
    // First, preserve proper headers by temporarily replacing them
    const headerMap = new Map();
    let headerIndex = 0;
    
    // Preserve proper headers (# Header at beginning of line)
    cleaned = cleaned.replace(/^# (.+)$/gm, (match, content) => {
      const placeholder = `__HEADER_${headerIndex}__`;
      headerMap.set(placeholder, `# ${content}`);
      headerIndex++;
      return placeholder;
    });
    
    // Preserve proper subheaders (## Subheader at beginning of line)
    cleaned = cleaned.replace(/^## (.+)$/gm, (match, content) => {
      const placeholder = `__SUBHEADER_${headerIndex}__`;
      headerMap.set(placeholder, `## ${content}`);
      headerIndex++;
      return placeholder;
    });
    
    // Preserve proper subsubheaders (### Subsubheader at beginning of line)
    cleaned = cleaned.replace(/^### (.+)$/gm, (match, content) => {
      const placeholder = `__SUBSUBHEADER_${headerIndex}__`;
      headerMap.set(placeholder, `### ${content}`);
      headerIndex++;
      return placeholder;
    });
    
    // Now remove unwanted # symbols (completion markers, standalone symbols, etc.)
    
    // Remove # symbols at end of lines (completion markers)
    cleaned = cleaned.replace(/#\s*$/gm, '');
    
    // Remove ## symbols at end of lines (section completion markers)
    cleaned = cleaned.replace(/##\s*$/gm, '');
    
    // Remove # symbols that appear alone between text (not at beginning of line)
    cleaned = cleaned.replace(/([^#\n])\s*#\s*([^#\n])/g, '$1 $2');
    
    // Remove ## symbols that appear alone between text (not at beginning of line)
    cleaned = cleaned.replace(/([^#\n])\s*##\s*([^#\n])/g, '$1 $2');
    
    // Remove standalone # symbols on their own lines
    cleaned = cleaned.replace(/^\s*#\s*$/gm, '');
    
    // Remove standalone ## symbols on their own lines
    cleaned = cleaned.replace(/^\s*##\s*$/gm, '');
    
    // Remove # symbols that appear before proper punctuation
    cleaned = cleaned.replace(/#\s*([.,;:!])/g, '$1');
    
    // Remove # symbols that appear after proper punctuation
    cleaned = cleaned.replace(/([.,;:!])\s*#/g, '$1');
    
    // Remove # symbols attached to words (like word# or #word)
    cleaned = cleaned.replace(/(\w)#/g, '$1');
    cleaned = cleaned.replace(/#(\w)/g, '$1');
    
    // Remove ## symbols attached to words (like word## or ##word)
    cleaned = cleaned.replace(/(\w)##/g, '$1');
    cleaned = cleaned.replace(/##(\w)/g, '$1');
    
    // Remove any remaining stray # symbols
    cleaned = cleaned.replace(/\s*#\s*/g, ' ');
    cleaned = cleaned.replace(/\s*##\s*/g, ' ');
    
    // Clean up multiple spaces
    cleaned = cleaned.replace(/\s+/g, ' ');
    
    // Clean up excessive line breaks
    cleaned = cleaned.replace(/\n\s*\n\s*\n/g, '\n\n');
    cleaned = cleaned.replace(/\n\s*\n\s*\n\s*\n/g, '\n\n');
    
    // Clean up spaces at beginning or end of lines
    cleaned = cleaned.replace(/^\s+/gm, '');
    cleaned = cleaned.replace(/\s+$/gm, '');
    
    // Restore preserved headers
    headerMap.forEach((original, placeholder) => {
      cleaned = cleaned.replace(placeholder, original);
    });
    
    return cleaned.trim();
  };

  // Convert Markdown to HTML
  const markdownToHTML = (markdown: string | undefined | null) => {
    // First clean the content
    let html = cleanContent(markdown);
    
    // Headers (# Header, ## Subheader, etc.)
    html = html.replace(/^### (.*$)/gim, '<h3 class="text-lg font-semibold my-3 text-gray-900 dark:text-gray-100">$1</h3>');
    html = html.replace(/^## (.*$)/gim, '<h2 class="text-xl font-bold my-4 text-gray-900 dark:text-gray-100">$1</h2>');
    html = html.replace(/^# (.*$)/gim, '<h1 class="text-2xl font-bold my-4 text-gray-900 dark:text-gray-100">$1</h1>');
    
    // Bold text (**bold**)
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-gray-900 dark:text-gray-100">$1</strong>');
    
    // Italic text (*italic*)
    html = html.replace(/\*(.*?)\*/g, '<em class="italic text-gray-700 dark:text-gray-300">$1</em>');
    
    // Bullet points (* item)
    html = html.replace(/^\* (.*$)/gim, '<li class="ml-4 my-1">• $1</li>');
    
    // Wrap bullet points in ul
    html = html.replace(/(<li class="ml-4 my-1">.*<\/li>)/s, '<ul class="my-4 space-y-1">$1</ul>');
    
    // Numbered lists (1. item)
    html = html.replace(/^\d+\. (.*$)/gim, '<li class="ml-4 my-1">$1</li>');
    
    // Wrap numbered lists in ol
    html = html.replace(/(<li class="ml-4 my-1">.*<\/li>)/s, '<ol class="my-4 space-y-1 list-decimal list-inside">$1</ol>');
    
    // Inline code (`code`)
    html = html.replace(/`([^`]+)`/g, '<code class="bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded text-sm font-mono text-gray-800 dark:text-gray-200">$1</code>');
    
    // Links [text](url)
    html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 underline">$1</a>');
    
    // Blockquotes (> quote)
    html = html.replace(/^> (.*$)/gim, '<blockquote class="border-l-4 border-gray-300 dark:border-gray-600 pl-4 my-4 italic text-gray-600 dark:text-gray-400">$1</blockquote>');
    
    // Line breaks
    html = html.replace(/\n\n/g, '</p><p class="my-3 text-gray-700 dark:text-gray-300 leading-relaxed">');
    html = html.replace(/\n/g, '<br />');
    
    // Wrap in paragraphs
    html = '<p class="my-3 text-gray-700 dark:text-gray-300 leading-relaxed">' + html + '</p>';
    
    // Fix multiple paragraph tags
    html = html.replace(/<p class="my-3 text-gray-700 dark:text-gray-300 leading-relaxed"><\/p>/g, '');
    html = html.replace(/<p class="my-3 text-gray-700 dark:text-gray-300 leading-relaxed"><p class="my-3 text-gray-700 dark:text-gray-300 leading-relaxed">/g, '<p class="my-3 text-gray-700 dark:text-gray-300 leading-relaxed">');
    
    return html;
  };

  const htmlContent = markdownToHTML(content);

  return (
    <HTMLRenderer 
      content={htmlContent} 
      className={className}
    />
  );
}