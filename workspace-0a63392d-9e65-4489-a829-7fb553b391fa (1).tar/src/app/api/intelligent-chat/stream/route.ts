import { NextRequest } from 'next/server';
import { IntelligentChatBot, ChatBotConfig } from '@/lib/intelligentChat/intelligentChatBot';

// Global chatbot instance
let globalChatBot: IntelligentChatBot | null = null;

function getChatBot(config?: ChatBotConfig): IntelligentChatBot {
  if (!globalChatBot) {
    globalChatBot = new IntelligentChatBot(config);
  }
  return globalChatBot;
}

// Function to filter unwanted symbols from text
function filterUnwantedSymbols(text: string): string {
  return text
    // Remove markdown heading symbols (#, ##, ###) but keep the content
    .replace(/^#{1,6}\s*/gm, '')
    // Remove standalone * symbols but keep bold formatting (**text**)
    .replace(/(?<!\*)\*(?!\*)/g, '')
    // Remove multiple consecutive * symbols
    .replace(/\*{2,}/g, '')
    // Remove trailing * symbols
    .replace(/\*+$/gm, '')
    // Remove leading * symbols
    .replace(/^\*+/gm, '')
    // Clean up extra whitespace that might be left
    .replace(/\s{3,}/g, '  ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

export async function POST(request: NextRequest) {
  const encoder = new TextEncoder();
  const stream = new TransformStream();
  const writer = stream.writable.getWriter();
  let streamClosed = false;
  
  // Add timeout mechanism
  const STREAM_TIMEOUT = 60000; // 60 seconds timeout
  let timeoutId: NodeJS.Timeout;
  
  // Track start time for processing
  const startTime = Date.now();

  const closeStream = async () => {
    if (!streamClosed) {
      try {
        // Clear timeout if stream is closing
        if (timeoutId) {
          clearTimeout(timeoutId);
        }
        await writer.close();
        streamClosed = true;
        console.log('✅ Stream closed successfully');
      } catch (error) {
        console.warn('⚠️ Stream already closed or error closing:', error);
      }
    }
  };

  const writeToStream = async (data: string) => {
    if (!streamClosed) {
      try {
        await writer.write(encoder.encode(data));
      } catch (error) {
        console.warn('⚠️ Error writing to stream:', error);
        streamClosed = true;
      }
    }
  };

  // Set up timeout
  timeoutId = setTimeout(() => {
    console.warn('⚠️ Stream timeout reached, closing connection...');
    closeStream();
  }, STREAM_TIMEOUT);

  try {
    const body = await request.json();
    const { message, config, clearHistory = false } = body;

    if (!message) {
      await writeToStream(`data: ${JSON.stringify({ error: 'Message is required' })}\n\n`);
      await closeStream();
      return new Response(stream.readable, {
        headers: {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive',
        },
      });
    }

    // Get chatbot instance
    const chatBot = getChatBot(config);

    // Clear history if requested
    if (clearHistory) {
      chatBot.clearConversation();
    }

    // Start streaming response
    (async () => {
      try {
        // Send initial status
        await writeToStream(`data: ${JSON.stringify({ type: 'start', message: 'Processing...' })}\n\n`);

        // Process the message to get the complete response
        const response = await chatBot.processMessage(message);
        
        // Split the response into lines for streaming
        const lines = response.response.split('\n');
        
        // Send each line individually with filtering
        for (let i = 0; i < lines.length; i++) {
          const originalLine = lines[i];
          const filteredLine = filterUnwantedSymbols(originalLine);
          
          if (filteredLine.trim()) { // Only send non-empty lines
            const chunkData = {
              type: 'chunk',
              line: filteredLine,
              lineNumber: i + 1,
              isLast: i === lines.length - 1
            };
            
            await writeToStream(`data: ${JSON.stringify(chunkData)}\n\n`);
            
            // Add a small delay to simulate streaming effect
            await new Promise(resolve => setTimeout(resolve, 50 + Math.random() * 100));
          }
        }

        // Send completion signal with metadata
        const completionData = {
          type: 'complete',
          confidence: response.confidence,
          intent: response.intent,
          processingTime: response.processingTime,
          metadata: {
            wordCount: response.metadata.postProcessing.metadata.wordCount,
            readingTime: response.metadata.postProcessing.metadata.readingTime,
            suggestions: response.suggestions,
            followUpQuestions: response.followUpQuestions
          }
        };

        await writeToStream(`data: ${JSON.stringify(completionData)}\n\n`);
        
        // Add a small delay to ensure the completion data is sent
        await new Promise(resolve => setTimeout(resolve, 100));
        
        // Ensure the stream is properly closed after completion
        console.log('✅ Streaming completed successfully, closing stream...');
        await closeStream();
        return; // Exit the function to ensure no further processing
        
      } catch (error) {
        console.error('❌ Streaming error:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        
        // Check if this is a 502 error and provide a helpful fallback
        if (errorMessage.includes('502')) {
          const fallbackData = {
            type: 'chunk',
            line: '# **⚠️ 502 Gateway Error - Fallback Response**',
            lineNumber: 1
          };
          await writeToStream(`data: ${JSON.stringify(fallbackData)}\n\n`);
          
          const fallbackLines = [
            '',
            'I understand you\'re asking about: "' + message + '"',
            '',
            '**Current Status:**',
            '- AI Service: ⚠️ Temporary gateway connectivity issue (502 error)',
            '- System: ✅ All other components working normally',
            '- Recovery: 🔄 Auto-recovery in progress',
            '',
            '## **What\'s Happening:**',
            '- The AI service gateway is temporarily experiencing connectivity issues',
            '- This is a common, temporary problem that usually resolves within 1-3 minutes',
            '- Your request is safe and will be processed when service resumes',
            '',
            '## **Immediate Solutions:**',
            '1. **Wait 30 seconds** and try your query again',
            '2. **Try a different AI model** from the dropdown menu',
            '3. **Use deep research mode** which has alternative routing',
            '',
            'The system is designed to handle these situations gracefully and will recover automatically.'
          ];
          
          for (let i = 0; i < fallbackLines.length; i++) {
            const lineData = {
              type: 'chunk',
              line: fallbackLines[i],
              lineNumber: i + 2
            };
            await writeToStream(`data: ${JSON.stringify(lineData)}\n\n`);
          }
        } else {
          // General error fallback
          const fallbackData = {
            type: 'chunk',
            line: '# **🔧 AI Service - Fallback Response**',
            lineNumber: 1
          };
          await writeToStream(`data: ${JSON.stringify(fallbackData)}\n\n`);
          
          const fallbackLines = [
            '',
            'I understand you\'re asking about: "' + message + '"',
            '',
            '**Current Status:**',
            '- AI Service: ⚠️ Temporarily experiencing technical difficulties',
            '- System: ✅ All other components working normally',
            '- Recovery: 🔄 Auto-recovery in progress',
            '',
            '## **What\'s Happening:**',
            '- The AI service is temporarily unavailable due to technical issues',
            '- This could be due to high demand, maintenance, or connectivity problems',
            '- The system is designed to handle these situations gracefully',
            '',
            '## **Immediate Solutions:**',
            '1. **Wait 30 seconds** and try your query again',
            '2. **Try a different AI model** from the dropdown menu',
            '3. **Use deep research mode** which has alternative routing',
            '',
            'The system is designed to be resilient and will automatically recover from temporary issues.'
          ];
          
          for (let i = 0; i < fallbackLines.length; i++) {
            const lineData = {
              type: 'chunk',
              line: fallbackLines[i],
              lineNumber: i + 2
            };
            await writeToStream(`data: ${JSON.stringify(lineData)}\n\n`);
          }
        }
        
        const errorData = {
          type: 'complete',
          confidence: 0.8,
          intent: 'fallback_response',
          processingTime: Date.now() - startTime,
          metadata: {
            wordCount: 150,
            readingTime: 1,
            suggestions: ['Try again in 30 seconds', 'Try a different model'],
            followUpQuestions: ['Can I help you with something else?']
          }
        };
        await writeToStream(`data: ${JSON.stringify(errorData)}\n\n`);
        
        // Add a small delay to ensure the error data is sent
        await new Promise(resolve => setTimeout(resolve, 100));
      } finally {
        console.log('🔄 Streaming process ended, ensuring stream is closed...');
        await closeStream();
      }
    })();

    return new Response(stream.readable, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });

  } catch (error) {
    console.error('❌ Outer streaming error:', error);
    const errorData = {
      type: 'error',
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
    
    try {
      await writeToStream(`data: ${JSON.stringify(errorData)}\n\n`);
    } catch (streamError) {
      console.error('❌ Error writing to stream in outer catch:', streamError);
    }
    
    try {
      await closeStream();
    } catch (closeError) {
      console.error('❌ Error closing stream in outer catch:', closeError);
    }
    
    return new Response(stream.readable, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });
  }
}