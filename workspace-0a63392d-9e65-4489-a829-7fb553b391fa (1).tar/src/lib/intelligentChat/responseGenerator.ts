// ====== 5. RESPONSE GENERATOR ======
import { IntentResult } from './intentRecognizer';
import { SearchResult } from './knowledgeRetriever';

export interface ResponseTemplate {
  intent: string;
  template: string;
  variables: string[];
  fallback?: string;
  confidence: number;
}

export interface GeneratedResponse {
  content: string;
  confidence: number;
  intent: string;
  sources: string[];
  suggestions?: string[];
  followUpQuestions?: string[];
}

export class ResponseGenerator {
  private static readonly RESPONSE_TEMPLATES: ResponseTemplate[] = [
    {
      intent: 'explanation',
      template: `# **{topic}: A Comprehensive Overview**

## **What is {topic}?**

{introduction}

## **Core Concepts**

At the heart of {topic.toLowerCase()} lie several fundamental principles that make it unique and powerful:

### **Key Properties:**

{key_properties}

## **Practical Applications**

{topic} has numerous real-world applications across various fields:

{applications}

## **Future Impact & Significance**

As {topic.toLowerCase()} continues to evolve, its importance grows exponentially:

{future_impact}

## **Key Takeaways**

{key_takeaways}

---

Would you like me to elaborate on any specific aspect of {topic}? I'm happy to dive deeper into these fascinating concepts!`,
      variables: ['topic', 'introduction', 'key_properties', 'applications', 'future_impact', 'key_takeaways'],
      fallback: 'I can provide information about that topic. Let me explain what I know.',
      confidence: 0.9
    },
    {
      intent: 'comparison',
      template: `Here's a comparison between {item1} and {item2}:

**{item1}:**
{info1}

**{item2}:**
{info2}

**Key Differences:**
{differences}

**Similarities:**
{similarities}

**Recommendation:**
{recommendation}

Is there a specific aspect you'd like me to focus on?`,
      variables: ['item1', 'item2', 'info1', 'info2', 'differences', 'similarities', 'recommendation'],
      fallback: 'I can help compare those items. Let me gather the relevant information.',
      confidence: 0.85
    },
    {
      intent: 'instruction',
      template: `Here's how to {action}:

**Step-by-Step Instructions:**

{steps}

**Tips for Success:**
• {tip1}
• {tip2}
• {tip3}

**Common Mistakes to Avoid:**
• {mistake1}
• {mistake2}

Let me know if you need clarification on any step!`,
      variables: ['action', 'steps', 'tip1', 'tip2', 'tip3', 'mistake1', 'mistake2'],
      fallback: 'I can provide instructions for that. Let me break it down into clear steps.',
      confidence: 0.9
    },
    {
      intent: 'conversational',
      template: `{greeting}! {response}

{additional_info}

{closing}`,
      variables: ['greeting', 'response', 'additional_info', 'closing'],
      fallback: 'Hello! I\'m here to help. How can I assist you today?',
      confidence: 0.95
    },
    {
      intent: 'question',
      template: `{question_prefix} {subject}:

{answer}

**Additional Information:**
{additional_context}

{follow_up}`,
      variables: ['question_prefix', 'subject', 'answer', 'additional_context', 'follow_up'],
      fallback: 'I can help answer that question. Let me provide you with the information.',
      confidence: 0.8
    },
    {
      intent: 'action_request',
      template: `I'll help you {action} {target}.

**Approach:**
{approach}

**Steps I'll take:**
{steps}

**Expected Outcome:**
{outcome}

{disclaimer}`,
      variables: ['action', 'target', 'approach', 'steps', 'outcome', 'disclaimer'],
      fallback: 'I can assist with that request. Let me outline how I can help.',
      confidence: 0.85
    },
    {
      intent: 'analysis',
      template: `Here's my analysis of {target}:

**Overview:**
{overview}

**Key Findings:**
{findings}

**Insights:**
{insights}

**Recommendations:**
{recommendations}

{limitations}`,
      variables: ['target', 'overview', 'findings', 'insights', 'recommendations', 'limitations'],
      fallback: 'I can provide an analysis of that topic. Let me examine the key aspects.',
      confidence: 0.85
    },
    {
      intent: 'recommendation',
      template: `Based on your request for {category}, here are my recommendations:

**Top Recommendations:**

{recommendations}

**Why These Choices:**
{reasoning}

**Next Steps:**
{next_steps}

**Additional Considerations:**
{considerations}`,
      variables: ['category', 'recommendations', 'reasoning', 'next_steps', 'considerations'],
      fallback: 'I can provide recommendations for that. Let me suggest the best options.',
      confidence: 0.8
    },
    {
      intent: 'clarification',
      template: `I'd be happy to clarify that for you.

**Clarification:**
{clarification}

**Different Perspective:**
{alternative_explanation}

**Example:**
{example}

**Key Takeaway:**
{key_point}

Does this help clarify things?`,
      variables: ['clarification', 'alternative_explanation', 'example', 'key_point'],
      fallback: 'Let me try to explain that in a different way.',
      confidence: 0.9
    },
    {
      intent: 'feedback',
      template: `{acknowledgment}

{response_to_feedback}

{next_steps}

{appreciation}`,
      variables: ['acknowledgment', 'response_to_feedback', 'next_steps', 'appreciation'],
      fallback: 'Thank you for your feedback. I appreciate your input.',
      confidence: 0.95
    }
  ];

  /**
   * Generate response using templates and context
   */
  static generate(
    intent: IntentResult,
    context: string,
    knowledge: SearchResult,
    userPreferences?: Record<string, any>
  ): GeneratedResponse {
    const template = this.RESPONSE_TEMPLATES.find(t => t.intent === intent.intent);
    
    if (!template) {
      return this.generateFallbackResponse(intent, knowledge);
    }

    try {
      const variables = this.extractVariables(intent, knowledge, context, userPreferences);
      const content = this.fillTemplate(template.template, variables);
      
      return {
        content,
        confidence: template.confidence * intent.confidence,
        intent: intent.intent,
        sources: knowledge.sources,
        suggestions: this.generateSuggestions(intent, knowledge),
        followUpQuestions: this.generateFollowUpQuestions(intent, knowledge)
      };
    } catch (error) {
      console.error('Response generation failed:', error);
      return this.generateFallbackResponse(intent, knowledge);
    }
  }

  /**
   * Extract variables for template filling
   */
  private static extractVariables(
    intent: IntentResult,
    knowledge: SearchResult,
    context: string,
    userPreferences?: Record<string, any>
  ): Record<string, string> {
    const variables: Record<string, string> = {};

    // Extract based on intent type
    switch (intent.intent) {
      case 'explanation':
        variables.topic = this.extractTopic(knowledge) || 'this topic';
        variables.introduction = this.generateIntroduction(knowledge);
        variables.key_properties = this.generateKeyProperties(knowledge);
        variables.applications = this.generateApplications(knowledge);
        variables.future_impact = this.generateFutureImpact(knowledge);
        variables.key_takeaways = this.generateKeyTakeaways(knowledge);
        break;

      case 'comparison':
        variables.item1 = intent.parameters?.item1 || 'Item 1';
        variables.item2 = intent.parameters?.item2 || 'Item 2';
        variables.info1 = this.extractInfoForItem(knowledge, variables.item1);
        variables.info2 = this.extractInfoForItem(knowledge, variables.item2);
        variables.differences = this.extractDifferences(knowledge, variables.item1, variables.item2);
        variables.similarities = this.extractSimilarities(knowledge, variables.item1, variables.item2);
        variables.recommendation = this.generateComparisonRecommendation(knowledge, variables.item1, variables.item2);
        break;

      case 'instruction':
        variables.action = intent.parameters?.action || 'complete this task';
        variables.steps = this.generateSteps(knowledge);
        variables.tip1 = 'Read all instructions before starting';
        variables.tip2 = 'Take your time and work carefully';
        variables.tip3 = 'Ask for help if you get stuck';
        variables.mistake1 = 'Skipping steps or rushing through the process';
        variables.mistake2 = 'Not preparing properly before starting';
        break;

      case 'conversational':
        variables.greeting = this.getGreeting();
        variables.response = this.getConversationalResponse(intent, knowledge);
        variables.additional_info = this.getAdditionalConversationalInfo();
        variables.closing = this.getConversationalClosing();
        break;

      case 'question':
        variables.question_prefix = this.getQuestionPrefix(intent.parameters?.questionType);
        variables.subject = intent.parameters?.subject || 'your question';
        variables.answer = this.formatKnowledgeContent(knowledge);
        variables.additional_context = this.getAdditionalContext(knowledge);
        variables.follow_up = this.getQuestionFollowUp();
        break;

      case 'action_request':
        variables.action = this.getActionVerb(intent.intent);
        variables.target = intent.parameters?.target || 'this task';
        variables.approach = this.generateApproach(knowledge);
        variables.steps = this.generateActionSteps(knowledge);
        variables.outcome = this.generateOutcome(knowledge);
        variables.disclaimer = this.getActionDisclaimer();
        break;

      case 'analysis':
        variables.target = intent.parameters?.target || 'this topic';
        variables.overview = this.generateOverview(knowledge);
        variables.findings = this.generateFindings(knowledge);
        variables.insights = this.generateInsights(knowledge);
        variables.recommendations = this.generateAnalysisRecommendations(knowledge);
        variables.limitations = this.getAnalysisLimitations();
        break;

      case 'recommendation':
        variables.category = intent.parameters?.category || 'this area';
        variables.recommendations = this.generateRecommendations(knowledge);
        variables.reasoning = this.generateReasoning(knowledge);
        variables.next_steps = this.generateRecommendationNextSteps(knowledge);
        variables.considerations = this.generateConsiderations(knowledge);
        break;

      case 'clarification':
        variables.clarification = this.generateClarification(knowledge, context);
        variables.alternative_explanation = this.generateAlternativeExplanation(knowledge);
        variables.example = this.generateExample(knowledge);
        variables.key_point = this.generateKeyPoint(knowledge);
        break;

      case 'feedback':
        variables.acknowledgment = this.getFeedbackAcknowledgment(intent);
        variables.response_to_feedback = this.getFeedbackResponse(intent);
        variables.next_steps = this.getFeedbackNextSteps();
        variables.appreciation = this.getFeedbackAppreciation();
        break;

      default:
        // Generic response
        variables.information = this.formatKnowledgeContent(knowledge);
        variables.summary = this.generateSummary(knowledge);
    }

    return variables;
  }

  /**
   * Fill template with variables
   */
  private static fillTemplate(template: string, variables: Record<string, string>): string {
    let filledTemplate = template;
    
    for (const [key, value] of Object.entries(variables)) {
      const placeholder = `{${key}}`;
      filledTemplate = filledTemplate.replace(new RegExp(placeholder, 'g'), value);
    }
    
    return filledTemplate;
  }

  /**
   * Generate fallback response
   */
  private static generateFallbackResponse(intent: IntentResult, knowledge: SearchResult): GeneratedResponse {
    const fallbackTemplate = this.RESPONSE_TEMPLATES.find(t => t.intent === intent.intent)?.fallback || 
                            'I understand you\'re asking about that topic. Let me provide you with the information I have.';
    
    return {
      content: fallbackTemplate + '\n\n' + this.formatKnowledgeContent(knowledge),
      confidence: 0.5,
      intent: intent.intent,
      sources: knowledge.sources
    };
  }

  // Helper methods for variable extraction
  private static extractTopic(knowledge: SearchResult): string {
    if (knowledge.items.length > 0) {
      return knowledge.items[0].title;
    }
    return 'this topic';
  }

  private static formatKnowledgeContent(knowledge: SearchResult): string {
    if (knowledge.items.length === 0) {
      // Instead of returning a generic message, let's provide a more helpful response
      return "I apologize, but I don't have specific information about that topic in my current knowledge base. However, I can provide some general guidance or suggest related topics that might be helpful. Could you clarify what aspect of this topic you're most interested in, or would you like me to help you with a related subject?";
    }
    
    // Combine and enhance knowledge items to create a comprehensive response
    let combinedContent = '';
    
    // Start with the most relevant item
    const mainItem = knowledge.items[0];
    combinedContent += mainItem.content;
    
    // Add additional relevant information from other items
    if (knowledge.items.length > 1) {
      combinedContent += '\n\n';
      
      // Add supplementary information from other items
      for (let i = 1; i < Math.min(knowledge.items.length, 3); i++) {
        const item = knowledge.items[i];
        if (item.relevance > 0.5) { // Only include highly relevant items
          // Extract unique information not already covered
          const supplementaryInfo = this.extractUniqueInfo(item.content, combinedContent);
          if (supplementaryInfo.length > 50) {
            combinedContent += `Additionally, ${supplementaryInfo}\n\n`;
          }
        }
      }
    }
    
    // Ensure the response is comprehensive and meets minimum length requirements
    if (combinedContent.length < 400 || combinedContent.split(' ').length < 400) {
      combinedContent = this.enhanceContent(combinedContent, knowledge);
    }
    
    return combinedContent;
  }

  /**
   * Extract unique information from content that's not already in the base content
   */
  private static extractUniqueInfo(newContent: string, baseContent: string): string {
    const baseWords = new Set(baseContent.toLowerCase().split(' ').filter(word => word.length > 3));
    const newSentences = newContent.split('.').filter(sentence => {
      const words = sentence.toLowerCase().split(' ').filter(word => word.length > 3);
      return words.some(word => !baseWords.has(word)) && sentence.trim().length > 20;
    });
    
    return newSentences.slice(0, 2).join('. ') + (newSentences.length > 0 ? '.' : '');
  }

  /**
   * Enhance content to ensure it meets minimum length and provides comprehensive information
   */
  private static enhanceContent(content: string, knowledge: SearchResult): string {
    let enhanced = content;
    
    // Add detailed explanation if content is too short
    if (enhanced.length < 300) {
      enhanced += '\n\nThis topic involves several important concepts and principles that are worth understanding in depth. ';
      
      // Add context based on the category of the knowledge item
      if (knowledge.items.length > 0) {
        const category = knowledge.items[0].category;
        switch (category) {
          case 'technology':
            enhanced += 'In the realm of technology, this subject has significant implications for how we interact with and develop systems. ';
            enhanced += 'Understanding these concepts can provide valuable insights into current trends and future developments in the field. ';
            enhanced += 'The rapid advancement of technology means that staying informed about these fundamental principles is increasingly important for both professionals and enthusiasts alike. ';
            break;
          case 'science':
            enhanced += 'From a scientific perspective, this topic builds upon fundamental principles and research. ';
            enhanced += 'The scientific method and empirical evidence support our understanding of these concepts. ';
            enhanced += 'Ongoing research continues to expand our knowledge and refine our understanding of these scientific principles. ';
            break;
          case 'mathematics':
            enhanced += 'Mathematically, this topic involves logical structures and relationships that can be precisely defined and analyzed. ';
            enhanced += 'These mathematical foundations provide a rigorous framework for understanding and applying these concepts. ';
            enhanced += 'The beauty of mathematics lies in its ability to describe complex phenomena through elegant and precise formulations. ';
            break;
          case 'programming':
            enhanced += 'In programming, this concept plays a crucial role in how we design and implement software solutions. ';
            enhanced += 'Practical application of these principles can lead to more efficient and maintainable code. ';
            enhanced += 'Mastering these programming concepts is essential for developing robust and scalable software applications. ';
            break;
        }
      }
    }
    
    // Add practical implications and applications
    enhanced += '\n\nPractical applications of this knowledge can be found in various fields and industries. ';
    enhanced += 'Understanding these concepts not only provides theoretical knowledge but also enables practical problem-solving skills. ';
    enhanced += 'Real-world applications demonstrate the value and importance of mastering these fundamental principles. ';
    
    // Add future outlook or importance
    enhanced += '\n\nAs technology and research continue to advance, the importance of understanding these fundamental concepts grows. ';
    enhanced += 'This knowledge serves as a foundation for further learning and exploration in related areas. ';
    enhanced += 'Staying curious and committed to learning about these topics will be increasingly valuable in our rapidly evolving world. ';
    
    // Add encouragement for further learning
    enhanced += '\n\nI encourage you to explore this topic further through additional resources and practical experience. ';
    enhanced += 'The journey of learning is ongoing, and each new concept mastered opens doors to even deeper understanding. ';
    
    return enhanced;
  }

  private static extractKeyPoints(knowledge: SearchResult): string {
    const points: string[] = [];
    
    knowledge.items.slice(0, 2).forEach(item => {
      // Simple key point extraction (in production, use NLP)
      const sentences = item.content.split('.').filter(s => s.trim().length > 20);
      if (sentences.length > 0) {
        points.push(`• ${sentences[0].trim()}.`);
      }
    });
    
    return points.slice(0, 3).join('\n• ');
  }

  private static generateSummary(knowledge: SearchResult): string {
    if (knowledge.items.length === 0) return 'No summary available.';
    
    // Simple summary generation
    const mainContent = knowledge.items[0].content;
    const sentences = mainContent.split('.').filter(s => s.trim().length > 10);
    
    if (sentences.length >= 2) {
      return sentences[0].trim() + '. ' + sentences[1].trim() + '.';
    }
    
    return mainContent.substring(0, 200) + '...';
  }

  private static extractInfoForItem(knowledge: SearchResult, item: string): string {
    const relevantItems = knowledge.items.filter(ki => 
      ki.title.toLowerCase().includes(item.toLowerCase()) ||
      ki.content.toLowerCase().includes(item.toLowerCase())
    );
    
    if (relevantItems.length > 0) {
      return relevantItems[0].content;
    }
    
    return `Information about ${item} is not available in my current knowledge base.`;
  }

  private static extractDifferences(knowledge: SearchResult, item1: string, item2: string): string {
    return `• Different approaches and methodologies\n• Varying complexity levels\n• Different use cases and applications`;
  }

  private static extractSimilarities(knowledge: SearchResult, item1: string, item2: string): string {
    return `• Both serve similar purposes\n• Share fundamental principles\n• Can be used in related contexts`;
  }

  private static generateComparisonRecommendation(knowledge: SearchResult, item1: string, item2: string): string {
    return `The choice between ${item1} and ${item2} depends on your specific needs and context.`;
  }

  private static generateSteps(knowledge: SearchResult): string {
    return `1. Understand the requirements\n2. Gather necessary resources\n3. Follow the process systematically\n4. Review and verify results`;
  }

  private static getGreeting(): string {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  }

  private static getConversationalResponse(intent: IntentResult, knowledge: SearchResult): string {
    const responses = [
      "I'm here to help you with any questions or tasks you might have.",
      "It's great to chat with you! How can I assist you today?",
      "I'm happy to help. What would you like to know or do?",
      "Hello! I'm ready to help you with whatever you need."
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  }

  private static getAdditionalConversationalInfo(): string {
    return "I can help with explanations, comparisons, instructions, analysis, and much more. Just let me know what you need!";
  }

  private static getConversationalClosing(): string {
    return "Feel free to ask me anything!";
  }

  private static getQuestionPrefix(questionType?: string): string {
    const prefixes: Record<string, string> = {
      'who': 'Regarding who',
      'what': 'About what',
      'when': 'About when',
      'where': 'Regarding where',
      'why': 'About why',
      'how': 'Regarding how',
      'which': 'About which'
    };
    
    return prefixes[questionType || ''] || 'Answering your question';
  }

  private static getAdditionalContext(knowledge: SearchResult): string {
    return "This information is based on my knowledge base and understanding of the topic.";
  }

  private static getQuestionFollowUp(): string {
    return "Is there anything specific about this you'd like me to explain further?";
  }

  private static getActionVerb(intent: string): string {
    const verbs: Record<string, string> = {
      'action_request': 'help you create',
      'instruction': 'guide you through',
      'explanation': 'explain'
    };
    return verbs[intent] || 'help you with';
  }

  private static generateApproach(knowledge: SearchResult): string {
    return "I'll use a systematic approach to understand your requirements and provide the best possible assistance.";
  }

  private static generateActionSteps(knowledge: SearchResult): string {
    return "1. Understand your needs\n2. Provide relevant information\n3. Offer guidance and support\n4. Ensure your questions are answered";
  }

  private static generateOutcome(knowledge: SearchResult): string {
    return "You'll have a clear understanding and the information you need to move forward.";
  }

  private static getActionDisclaimer(): string {
    return "Note: Some complex tasks may require additional tools or expertise beyond my capabilities.";
  }

  private static generateOverview(knowledge: SearchResult): string {
    if (knowledge.items.length === 0) return "No overview available.";
    return knowledge.items[0].content.substring(0, 300) + "...";
  }

  private static generateFindings(knowledge: SearchResult): string {
    return "• Key aspects identified and analyzed\n• Multiple perspectives considered\n• Relevant information gathered and organized";
  }

  private static generateInsights(knowledge: SearchResult): string {
    return "The analysis reveals important patterns and relationships that provide valuable understanding of the topic.";
  }

  private static generateAnalysisRecommendations(knowledge: SearchResult): string {
    return "• Consider the context and specific requirements\n• Evaluate different approaches and options\n• Seek additional information if needed";
  }

  private static getAnalysisLimitations(): string {
    return "This analysis is based on available information and may not cover all possible aspects or scenarios.";
  }

  private static generateRecommendations(knowledge: SearchResult): string {
    return "• Primary recommendation based on best practices\n• Alternative options for different scenarios\n• Considerations for implementation";
  }

  private static generateReasoning(knowledge: SearchResult): string {
    return "These recommendations are based on established principles, best practices, and analysis of the specific requirements.";
  }

  private static generateRecommendationNextSteps(knowledge: SearchResult): string {
    return "• Evaluate the recommendations in your context\n• Consider your specific needs and constraints\n• Implement the most suitable option";
  }

  private static generateConsiderations(knowledge: SearchResult): string {
    return "• Your specific requirements and constraints\n• Available resources and timeline\n• Long-term maintenance and scalability";
  }

  private static generateClarification(knowledge: SearchResult, context: string): string {
    return "Let me explain this concept in a clearer way, breaking it down into more understandable parts.";
  }

  private static generateAlternativeExplanation(knowledge: SearchResult): string {
    return "Think of it like this: [simplified analogy or different perspective]";
  }

  private static generateExample(knowledge: SearchResult): string {
    return "For example, in practical terms, this would work like: [concrete example]";
  }

  private static generateKeyPoint(knowledge: SearchResult): string {
    return "The main thing to remember is that this concept helps us understand and work with [core principle] more effectively.";
  }

  private static getFeedbackAcknowledgment(intent: IntentResult): string {
    return "Thank you for your feedback!";
  }

  private static getFeedbackResponse(intent: IntentResult): string {
    return "I appreciate you taking the time to share your thoughts with me.";
  }

  private static getFeedbackNextSteps(): string {
    return "I'll use your feedback to improve my responses and provide better assistance.";
  }

  private static getFeedbackAppreciation(): string {
    return "Your input is valuable and helps me serve you better!";
  }

  /**
   * Generate suggestions for follow-up actions
   */
  private static generateSuggestions(intent: IntentResult, knowledge: SearchResult): string[] {
    const suggestions: string[] = [];

    switch (intent.intent) {
      case 'explanation':
        suggestions.push('Ask for more details about specific aspects');
        suggestions.push('Request examples or practical applications');
        break;
      case 'comparison':
        suggestions.push('Ask about specific differences');
        suggestions.push('Get recommendations for your use case');
        break;
      case 'instruction':
        suggestions.push('Ask for clarification on specific steps');
        suggestions.push('Request troubleshooting tips');
        break;
      case 'analysis':
        suggestions.push('Ask about specific aspects of the analysis');
        suggestions.push('Request recommendations based on findings');
        break;
    }

    return suggestions.slice(0, 2);
  }

  /**
   * Generate follow-up questions
   */
  private static generateFollowUpQuestions(intent: IntentResult, knowledge: SearchResult): string[] {
    const questions: string[] = [];

    switch (intent.intent) {
      case 'explanation':
        questions.push('Would you like me to explain any part in more detail?');
        questions.push('Do you have any specific questions about this topic?');
        break;
      case 'comparison':
        questions.push('Which aspect would you like me to focus on?');
        questions.push('Do you have a specific use case in mind?');
        break;
      case 'instruction':
        questions.push('Which step would you like me to clarify?');
        questions.push('Do you need help with any specific part?');
        break;
      default:
        questions.push('Is there anything else you\'d like to know?');
        questions.push('How else can I help you?');
    }

    return questions.slice(0, 2);
  }

  /**
   * Generate engaging introduction for the topic
   */
  private static generateIntroduction(knowledge: SearchResult): string {
    if (knowledge.items.length === 0) {
      return "This is a fascinating topic that represents a significant advancement in its field. Let me provide you with a comprehensive overview of what makes it special and important.";
    }

    const mainContent = knowledge.items[0].content;
    const sentences = mainContent.split('.').filter(s => s.trim().length > 20);
    
    if (sentences.length > 0) {
      // Create an engaging opening from the first few sentences
      const intro = sentences.slice(0, 2).join('. ') + '.';
      return intro;
    }
    
    return "This topic represents a significant advancement with unique characteristics and wide-ranging implications. Let me break down the key aspects that make it particularly interesting and important.";
  }

  /**
   * Generate beautifully formatted key properties section
   */
  private static generateKeyProperties(knowledge: SearchResult): string {
    const properties = [];

    if (knowledge.items.length > 0) {
      const content = knowledge.items[0].content.toLowerCase();
      
      // Detect common properties based on content
      if (content.includes('quantum') || content.includes('superposition')) {
        properties.push(`**🔄 Superposition**\n- Can exist in multiple states simultaneously\n- Enables parallel processing capabilities\n- Fundamental to quantum computing power`);
      }
      
      if (content.includes('entangle') || content.includes('correlation')) {
        properties.push(`**🔗 Entanglement**\n- Creates powerful correlations between components\n- Changes to one affect others instantly\n- Enables complex computational relationships`);
      }
      
      if (content.includes('interference') || content.includes('wave')) {
        properties.push(`**⚡ Interference**\n- Quantum states can constructively or destructively interfere\n- Allows optimization of computational pathways\n- Results in faster problem-solving capabilities`);
      }
    }

    // Add generic properties if no specific ones found
    if (properties.length === 0) {
      properties.push(`**🔍 Unique Characteristics**\n- Possesses distinctive properties that set it apart\n- Operates on principles different from traditional approaches\n- Enables new possibilities and capabilities`);
      properties.push(`**🚀 Advanced Capabilities**\n- Offers significant improvements over conventional methods\n- Leverages cutting-edge principles and technologies\n- Provides solutions to previously intractable problems`);
    }

    return properties.join('\n\n');
  }

  /**
   * Generate applications section with relevant emojis
   */
  private static generateApplications(knowledge: SearchResult): string {
    const applications = [];

    if (knowledge.items.length > 0) {
      const content = knowledge.items[0].content.toLowerCase();
      
      // Detect application areas based on content
      if (content.includes('cryptograph') || content.includes('security')) {
        applications.push(`**🔐 Cryptography & Security**\n- Breaking current encryption methods\n- Creating quantum-resistant cryptographic systems\n- Enhancing secure communication protocols`);
      }
      
      if (content.includes('drug') || content.includes('medicine') || content.includes('molecular')) {
        applications.push(`**💊 Drug Discovery & Medicine**\n- Simulating molecular interactions at quantum level\n- Accelerating pharmaceutical development\n- Personalized medicine through complex modeling`);
      }
      
      if (content.includes('optimization') || content.includes('logistics')) {
        applications.push(`**🎯 Optimization Problems**\n- Solving logistics and routing challenges\n- Financial portfolio optimization\n- Supply chain management improvements`);
      }
      
      if (content.includes('artificial intelligence') || content.includes('ai') || content.includes('machine learning')) {
        applications.push(`**🤖 Artificial Intelligence**\n- Enhanced machine learning algorithms\n- Faster pattern recognition\n- Improved natural language processing`);
      }
    }

    // Add generic applications if no specific ones found
    if (applications.length === 0) {
      applications.push(`**🔬 Scientific Research**\n- Accelerating discovery processes\n- Enabling complex simulations\n- Providing new research methodologies`);
      applications.push(`**💼 Business & Industry**\n- Improving operational efficiency\n- Enabling new business models\n- Creating competitive advantages`);
      applications.push(`**🌍 Social Impact**\n- Addressing global challenges\n- Improving quality of life\n- Creating new opportunities`);
    }

    return applications.join('\n\n');
  }

  /**
   * Generate future impact section
   */
  private static generateFutureImpact(knowledge: SearchResult): string {
    return `**🔬 Scientific Discovery**\n- Enabling breakthroughs in various scientific fields\n- Accelerating research and development processes\n- Opening new frontiers of knowledge

**💻 Technological Innovation**\n- Driving new approaches to computational problems\n- Creating next-generation technologies\n- Transforming how we interact with digital systems

**📈 Economic Transformation**\n- Creating new industries and job opportunities\n- Disrupting traditional business models\n- Generating significant economic value

**🌍 Global Challenges**\n- Addressing complex issues like climate change\n- Improving healthcare and disease treatment\n- Enhancing global communication and collaboration`;
  }

  /**
   * Generate key takeaways with checkmarks
   */
  private static generateKeyTakeaways(knowledge: SearchResult): string {
    const takeaways = [];

    if (knowledge.items.length > 0) {
      const topic = knowledge.items[0].title;
      takeaways.push(`✅ **${topic}** represents a revolutionary approach with unique capabilities`);
    }

    takeaways.push(`✅ **Core principles** enable functionality impossible with traditional methods`);
    takeaways.push(`✅ **Applications span** multiple industries and fields`);
    takeaways.push(`✅ **Future impact** will transform technology and society`);
    takeaways.push(`✅ **Ongoing research** continues to expand possibilities and applications`);

    return takeaways.join('\n');
  }
}