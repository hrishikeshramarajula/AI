// ====== 4. KNOWLEDGE RETRIEVER ======
export interface KnowledgeItem {
  id: string;
  title: string;
  content: string;
  category: string;
  tags: string[];
  relevance: number;
  source: 'builtin' | 'ai' | 'web' | 'user';
  timestamp: Date;
  confidence: number;
}

export interface SearchResult {
  items: KnowledgeItem[];
  query: string;
  totalFound: number;
  searchTime: number;
  sources: string[];
}

export class KnowledgeRetriever {
  private static readonly KNOWLEDGE_BASE: Record<string, KnowledgeItem[]> = {
    technology: [
      {
        id: 'quantum_computing',
        title: 'Quantum Computing',
        content: 'Quantum computing is a revolutionary approach to computation that uses quantum bits (qubits) instead of classical bits. Unlike classical bits that can be either 0 or 1, qubits can exist in superposition, allowing them to be both 0 and 1 simultaneously. This enables quantum computers to perform certain calculations exponentially faster than classical computers. Key concepts include quantum entanglement, superposition, and quantum interference. Applications include cryptography, drug discovery, optimization problems, and artificial intelligence. Quantum computing represents a paradigm shift in computational capability, leveraging the principles of quantum mechanics to process information in ways that are impossible for classical computers. The field combines physics, computer science, and mathematics to create machines that can solve problems considered intractable by today\'s standards.',
        category: 'technology',
        tags: ['quantum', 'computing', 'qubits', 'superposition', 'entanglement'],
        relevance: 0.9,
        source: 'builtin',
        timestamp: new Date(),
        confidence: 0.95
      },
      {
        id: 'qubits_explained',
        title: 'Qubits - Quantum Bits',
        content: 'Qubits, or quantum bits, are the fundamental units of quantum information, analogous to classical bits in traditional computing. However, unlike classical bits that can only exist in one of two states (0 or 1), qubits can exist in a superposition of both states simultaneously. This property is derived from quantum mechanics and is what gives quantum computers their potential for massive parallel processing. A qubit can be implemented using various physical systems such as trapped ions, superconducting circuits, photons, or quantum dots. The state of a qubit is described by a quantum state vector, and when measured, it collapses to either 0 or 1 with probabilities determined by its quantum state. Multiple qubits can be entangled, meaning their states become correlated in ways that cannot be described by classical physics, enabling quantum computers to perform complex calculations much faster than classical computers for certain problems.',
        category: 'technology',
        tags: ['qubits', 'quantum bits', 'superposition', 'quantum computing', 'entanglement'],
        relevance: 0.95,
        source: 'builtin',
        timestamp: new Date(),
        confidence: 0.95
      },
      {
        id: 'artificial_intelligence',
        title: 'Artificial Intelligence',
        content: 'Artificial Intelligence (AI) refers to the simulation of human intelligence in machines that are programmed to think like humans and mimic their actions. The term may also be applied to any machine that exhibits traits associated with a human mind such as learning and problem-solving. AI can be categorized into Narrow AI (designed for specific tasks), General AI (human-level intelligence), and Superintelligent AI (beyond human capabilities). Key areas include machine learning, natural language processing, computer vision, robotics, and expert systems.',
        category: 'technology',
        tags: ['ai', 'artificial intelligence', 'machine learning', 'nlp', 'computer vision'],
        relevance: 0.9,
        source: 'builtin',
        timestamp: new Date(),
        confidence: 0.95
      },
      {
        id: 'machine_learning',
        title: 'Machine Learning',
        content: 'Machine Learning is a subset of artificial intelligence that enables systems to learn and improve from experience without being explicitly programmed. It focuses on the development of computer programs that can access data and use it to learn for themselves. The process of learning begins with observations or data, such as examples, direct experience, or instruction, in order to look for patterns in data and make better decisions in the future based on the examples that we provide. Main types include supervised learning, unsupervised learning, and reinforcement learning.',
        category: 'technology',
        tags: ['machine learning', 'ai', 'supervised learning', 'unsupervised learning', 'reinforcement learning'],
        relevance: 0.9,
        source: 'builtin',
        timestamp: new Date(),
        confidence: 0.95
      },
      {
        id: 'ibm_qiskit',
        title: 'IBM Qiskit',
        content: 'IBM Qiskit is an open-source quantum computing software development framework developed by IBM. It provides tools for creating, simulating, and running quantum circuits on real quantum computers and simulators. Qiskit is designed to be accessible to researchers, developers, and students interested in quantum computing. The framework includes several modules: Qiskit Terra for composing quantum programs, Qiskit Aer for high-performance simulators, Qiskit Ignis for quantum error correction, and Qiskit Aqua for building quantum algorithms and applications. Qiskit supports multiple quantum backends including IBM Quantum real quantum processors, local simulators, and cloud-based quantum computing services. It has become one of the most popular quantum computing frameworks due to its comprehensive documentation, active community, and integration with IBM Quantum Experience.',
        category: 'technology',
        tags: ['ibm', 'qiskit', 'quantum computing', 'quantum circuits', 'quantum programming'],
        relevance: 0.95,
        source: 'builtin',
        timestamp: new Date(),
        confidence: 0.95
      }
    ],
    science: [
      {
        id: 'physics_basics',
        title: 'Physics Fundamentals',
        content: 'Physics is the natural science that studies matter, its motion and behavior through space and time, and the related entities of energy and force. Physics is one of the most fundamental scientific disciplines, and its main goal is to understand how the universe behaves. Key areas include classical mechanics, thermodynamics, electromagnetism, quantum mechanics, and relativity. Physics forms the basis for many other scientific fields and has led to countless technological advancements.',
        category: 'science',
        tags: ['physics', 'mechanics', 'thermodynamics', 'quantum', 'relativity'],
        relevance: 0.8,
        source: 'builtin',
        timestamp: new Date(),
        confidence: 0.9
      },
      {
        id: 'chemistry_basics',
        title: 'Chemistry Fundamentals',
        content: 'Chemistry is the scientific discipline involved with elements and compounds composed of atoms, molecules and ions: their composition, structure, properties, behavior and the changes they undergo during a reaction with other substances. Chemistry addresses topics such as how atoms and molecules interact via chemical bonds to form chemical compounds, the properties of chemical compounds, and the reactions that compounds undergo. Major branches include organic chemistry, inorganic chemistry, physical chemistry, analytical chemistry, and biochemistry.',
        category: 'science',
        tags: ['chemistry', 'atoms', 'molecules', 'compounds', 'reactions'],
        relevance: 0.8,
        source: 'builtin',
        timestamp: new Date(),
        confidence: 0.9
      }
    ],
    mathematics: [
      {
        id: 'calculus_basics',
        title: 'Calculus Fundamentals',
        content: 'Calculus is the mathematical study of continuous change, in the same way that geometry is the study of shape and algebra is the study of generalizations of arithmetic operations. It has two major branches: differential calculus and integral calculus. Differential calculus concerns instantaneous rates of change and slopes of curves, while integral calculus concerns accumulation of quantities and the areas under and between curves. Calculus is fundamental to many scientific disciplines including physics, engineering, economics, and statistics.',
        category: 'mathematics',
        tags: ['calculus', 'derivatives', 'integrals', 'limits', 'functions'],
        relevance: 0.8,
        source: 'builtin',
        timestamp: new Date(),
        confidence: 0.9
      },
      {
        id: 'linear_algebra',
        title: 'Linear Algebra',
        content: 'Linear algebra is the branch of mathematics concerning linear equations such as linear maps and their representations in vector spaces and through matrices. Linear algebra is central to almost all areas of mathematics. It deals with vectors, matrices, linear transformations, systems of linear equations, eigenvalues and eigenvectors, and vector spaces. Applications include computer graphics, machine learning, quantum mechanics, optimization, and many areas of engineering.',
        category: 'mathematics',
        tags: ['linear algebra', 'vectors', 'matrices', 'transformations', 'eigenvalues'],
        relevance: 0.8,
        source: 'builtin',
        timestamp: new Date(),
        confidence: 0.9
      }
    ],
    programming: [
      {
        id: 'programming_basics',
        title: 'Programming Fundamentals',
        content: 'Programming is the process of creating a set of instructions that tell a computer how to perform a task. Programming can be done using a variety of computer programming languages, such as JavaScript, Python, Java, C++, etc. Key concepts include variables, data types, control structures (if/else, loops), functions, arrays, objects, and algorithms. Good programming practices include writing clean, readable code, following naming conventions, adding comments, and using version control systems like Git.',
        category: 'programming',
        tags: ['programming', 'coding', 'algorithms', 'variables', 'functions'],
        relevance: 0.9,
        source: 'builtin',
        timestamp: new Date(),
        confidence: 0.95
      },
      {
        id: 'web_development',
        title: 'Web Development',
        content: 'Web development is the work involved in developing a website for the Internet (World Wide Web) or an intranet (a private network). Web development can range from developing a simple single static page of plain text to complex web applications, electronic businesses, and social network services. It typically includes web design, web content development, client-side/server-side scripting, and network security configuration. Main technologies include HTML, CSS, JavaScript, and various backend frameworks.',
        category: 'programming',
        tags: ['web development', 'html', 'css', 'javascript', 'frontend', 'backend'],
        relevance: 0.9,
        source: 'builtin',
        timestamp: new Date(),
        confidence: 0.95
      }
    ]
  };

  private static cache: Map<string, SearchResult> = new Map();
  private static readonly cacheExpiry: number = 300000; // 5 minutes

  // Static initialization to ensure cache is properly set up
  private static readonly initialized = (() => {
    if (!KnowledgeRetriever.cache) {
      KnowledgeRetriever.cache = new Map();
    }
    return true;
  })();

  /**
   * Retrieve relevant information from knowledge base
   */
  static async retrieve(query: string, context?: string): Promise<SearchResult> {
    const startTime = Date.now();
    const normalizedQuery = query.toLowerCase().trim();
    
    // Ensure cache is initialized
    if (!this.cache) {
      this.cache = new Map();
    }
    
    // Check cache first
    const cacheKey = `${normalizedQuery}_${context || ''}`;
    const cachedResult = this.cache.get(cacheKey);
    if (cachedResult && (Date.now() - cachedResult.searchTime) < this.cacheExpiry) {
      return cachedResult;
    }

    const results: KnowledgeItem[] = [];
    const sources: Set<string> = new Set();

    // Search through all categories
    for (const [category, items] of Object.entries(this.KNOWLEDGE_BASE)) {
      for (const item of items) {
        const relevance = this.calculateRelevance(normalizedQuery, item, context);
        
        if (relevance > 0.3) { // Threshold for relevance
          results.push({
            ...item,
            relevance
          });
          sources.add(item.source);
        }
      }
    }

    // Sort by relevance
    results.sort((a, b) => b.relevance - a.relevance);

    const searchResult: SearchResult = {
      items: results,
      query: normalizedQuery,
      totalFound: results.length,
      searchTime: Date.now() - startTime,
      sources: Array.from(sources)
    };

    // Cache the result
    this.cache.set(cacheKey, searchResult);

    return searchResult;
  }

  /**
   * Calculate relevance score for a knowledge item
   */
  private static calculateRelevance(query: string, item: KnowledgeItem, context?: string): number {
    let score = 0;
    const queryWords = query.split(' ').filter(word => word.length > 2);
    const itemText = (item.title + ' ' + item.content).toLowerCase();

    // Handle common misspellings and variations
    const normalizedQueryWords = queryWords.map(word => {
      if (word === 'qbits') return 'qubits';
      if (word === 'quantam') return 'quantum';
      if (word === 'artifical') return 'artificial';
      return word;
    });

    // Title matching (higher weight)
    const titleWords = item.title.toLowerCase().split(' ');
    const titleMatches = normalizedQueryWords.filter(word => titleWords.includes(word)).length;
    score += titleMatches * 0.5; // Increased weight for title matches

    // Content matching with partial word matching
    const contentMatches = normalizedQueryWords.filter(word => {
      // Check for exact matches
      if (itemText.includes(word)) return true;
      // Check for partial matches (e.g., 'quant' matches 'quantum')
      return itemText.split(' ').some(itemWord => 
        itemWord.includes(word) || word.includes(itemWord)
      );
    }).length;
    score += contentMatches * 0.3;

    // Tag matching
    const tagMatches = item.tags.filter(tag => 
      normalizedQueryWords.some(word => 
        tag.toLowerCase().includes(word) || word.includes(tag.toLowerCase())
      )
    ).length;
    score += tagMatches * 0.2;

    // Context relevance
    if (context) {
      const contextWords = context.toLowerCase().split(' ').filter(word => word.length > 2);
      const contextMatches = contextWords.filter(word => itemText.includes(word)).length;
      score += contextMatches * 0.1;
    }

    // Boost score for highly relevant technical terms
    const technicalTerms = ['quantum', 'qubit', 'qubits', 'computing', 'ai', 'artificial intelligence', 'machine learning'];
    const technicalTermMatches = normalizedQueryWords.filter(word => 
      technicalTerms.some(term => term.includes(word) || word.includes(term))
    ).length;
    score += technicalTermMatches * 0.15;

    // Normalize score
    const maxPossibleScore = queryWords.length * 0.5 + queryWords.length * 0.3 + item.tags.length * 0.2 + (context ? queryWords.length * 0.1 : 0) + technicalTermMatches * 0.15;
    return maxPossibleScore > 0 ? Math.min(score / maxPossibleScore, 1.0) : 0;
  }

  /**
   * Add custom knowledge items
   */
  static addKnowledgeItem(item: Omit<KnowledgeItem, 'id' | 'timestamp'>): string {
    const id = `custom_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const knowledgeItem: KnowledgeItem = {
      ...item,
      id,
      timestamp: new Date()
    };

    // Add to appropriate category or create new one
    if (!this.KNOWLEDGE_BASE[item.category]) {
      this.KNOWLEDGE_BASE[item.category] = [];
    }
    this.KNOWLEDGE_BASE[item.category].push(knowledgeItem);

    // Clear cache to force refresh
    this.cache.clear();

    return id;
  }

  /**
   * Get knowledge by category
   */
  static getKnowledgeByCategory(category: string): KnowledgeItem[] {
    return this.KNOWLEDGE_BASE[category] || [];
  }

  /**
   * Get all available categories
   */
  static getCategories(): string[] {
    return Object.keys(this.KNOWLEDGE_BASE);
  }

  /**
   * Search for similar knowledge items
   */
  static findSimilarItems(itemId: string, limit: number = 5): KnowledgeItem[] {
    const targetItem = this.findItemById(itemId);
    if (!targetItem) return [];

    const similarItems: Array<{ item: KnowledgeItem; score: number }> = [];

    for (const [category, items] of Object.entries(this.KNOWLEDGE_BASE)) {
      for (const item of items) {
        if (item.id === itemId) continue;

        const similarity = this.calculateSimilarity(targetItem, item);
        if (similarity > 0.3) {
          similarItems.push({ item, score: similarity });
        }
      }
    }

    return similarItems
      .sort((a, b) => b.score - a.score)
      .slice(0, limit)
      .map(({ item }) => item);
  }

  /**
   * Find knowledge item by ID
   */
  private static findItemById(itemId: string): KnowledgeItem | null {
    for (const items of Object.values(this.KNOWLEDGE_BASE)) {
      const item = items.find(item => item.id === itemId);
      if (item) return item;
    }
    return null;
  }

  /**
   * Calculate similarity between two knowledge items
   */
  private static calculateSimilarity(item1: KnowledgeItem, item2: KnowledgeItem): number {
    let score = 0;

    // Tag similarity
    const commonTags = item1.tags.filter(tag => item2.tags.includes(tag));
    const tagSimilarity = commonTags.length / Math.max(item1.tags.length, item2.tags.length);
    score += tagSimilarity * 0.4;

    // Category similarity
    if (item1.category === item2.category) {
      score += 0.3;
    }

    // Content similarity (simplified word overlap)
    const words1 = new Set(item1.content.toLowerCase().split(' ').filter(word => word.length > 3));
    const words2 = new Set(item2.content.toLowerCase().split(' ').filter(word => word.length > 3));
    const intersection = new Set([...words1].filter(word => words2.has(word)));
    const union = new Set([...words1, ...words2]);
    const contentSimilarity = intersection.size / union.size;
    score += contentSimilarity * 0.3;

    return Math.min(score, 1.0);
  }

  /**
   * Clear the cache
   */
  static clearCache(): void {
    this.cache.clear();
  }

  /**
   * Get cache statistics
   */
  static getCacheStats(): { size: number; hitRate: number } {
    return {
      size: this.cache.size,
      hitRate: 0 // Would need to track hits/misses for accurate rate
    };
  }
}