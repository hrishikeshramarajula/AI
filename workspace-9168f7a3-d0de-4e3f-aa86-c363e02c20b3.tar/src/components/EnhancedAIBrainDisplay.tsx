// 🧠 Enhanced AI Brain Display - Live working display like Claude's thought process
// This component shows the AI brain's analytical thinking, todo management, and execution progress

'use client';

import React, { useState, useEffect, useRef } from 'react';
import {
  Brain,
  Zap,
  Target,
  Settings,
  BarChart3,
  Shield,
  BookOpen,
  Activity,
  Lightbulb,
  CheckCircle,
  XCircle,
  Clock,
  Users,
  Cpu,
  Network,
  Database,
  FileText,
  MessageSquare,
  TrendingUp,
  AlertTriangle,
  Info,
  X,
  Play,
  Pause,
  RotateCcw,
  Loader2,
  ChevronRight,
  ChevronDown,
  Plus,
  Minus,
  Edit3,
  Trash2,
  Eye,
  EyeOff
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';

interface Todo {
  id: string;
  content: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  priority: 'high' | 'medium' | 'low';
  estimatedTime: number;
  dependencies: string[];
  result?: any;
  error?: string;
  reasoning: string[];
  startTime?: Date;
  endTime?: Date;
  category?: 'analysis' | 'development' | 'testing' | 'validation' | 'correction' | 'general';
}

interface AnalysisResult {
  understanding: {
    mainGoal: string;
    requirements: string[];
    constraints: string[];
    expectedOutput: string;
    complexity: 'simple' | 'moderate' | 'complex';
  };
  todoPlan: Todo[];
  executionStrategy: {
    approach: 'sequential' | 'parallel' | 'adaptive';
    errorHandling: 'strict' | 'flexible' | 'resilient';
    validationPoints: string[];
  };
  confidence: number;
}

interface ExecutionLog {
  timestamp: Date;
  step: string;
  status: 'started' | 'completed' | 'failed' | 'corrected';
  details: any;
}

interface EnhancedAIBrainDisplayProps {
  isVisible: boolean;
  onClose: () => void;
  onProcess?: (input: string) => Promise<any>;
}

export default function EnhancedAIBrainDisplay({ isVisible, onClose, onProcess }: EnhancedAIBrainDisplayProps) {
  const [inputText, setInputText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [executionLog, setExecutionLog] = useState<ExecutionLog[]>([]);
  const [todos, setTodos] = useState<Todo[]>([]);
  const [progress, setProgress] = useState({ total: 0, completed: 0, percentage: 0 });
  const [reasoning, setReasoning] = useState<string[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [corrections, setCorrections] = useState<string[]>([]);
  const [learnings, setLearnings] = useState<string[]>([]);
  const [finalOutput, setFinalOutput] = useState('');
  const [isLiveMode, setIsLiveMode] = useState(true);
  const [showDetails, setShowDetails] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const executionLogRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom of execution log
  useEffect(() => {
    if (executionLogRef.current) {
      executionLogRef.current.scrollTop = executionLogRef.current.scrollHeight;
    }
  }, [executionLog]);

  // Simulate live processing updates
  const simulateProcessing = async (input: string) => {
    setIsProcessing(true);
    setExecutionLog([]);
    setTodos([]);
    setReasoning([]);
    setErrors([]);
    setCorrections([]);
    setLearnings([]);
    setFinalOutput('');

    try {
      // Step 1: Deep Analysis
      addExecutionLog('Deep Analysis', 'started', { input });
      await delay(1000);
      setReasoning(prev => [...prev, '🔍 Starting deep analysis and understanding...']);
      await delay(800);
      
      // Simulate analysis result
      const mockAnalysis: AnalysisResult = {
        understanding: {
          mainGoal: `Process: ${input}`,
          requirements: [
            'Understand user requirements',
            'Create comprehensive solution',
            'Validate results',
            'Provide clear output'
          ],
          constraints: [
            'Must be accurate and reliable',
            'Should handle edge cases',
            'Need to be efficient'
          ],
          expectedOutput: 'Comprehensive response with actionable insights',
          complexity: 'moderate'
        },
        todoPlan: [
          {
            id: 'todo-1',
            content: 'Analyze user input and understand requirements',
            status: 'pending',
            priority: 'high',
            estimatedTime: 5,
            dependencies: [],
            reasoning: ['Initial analysis task'],
            category: 'analysis'
          },
          {
            id: 'todo-2',
            content: 'Develop comprehensive solution approach',
            status: 'pending',
            priority: 'high',
            estimatedTime: 8,
            dependencies: ['todo-1'],
            reasoning: ['Solution development task'],
            category: 'development'
          },
          {
            id: 'todo-3',
            content: 'Validate and test the solution',
            status: 'pending',
            priority: 'medium',
            estimatedTime: 6,
            dependencies: ['todo-2'],
            reasoning: ['Validation task'],
            category: 'testing'
          },
          {
            id: 'todo-4',
            content: 'Generate final output and insights',
            status: 'pending',
            priority: 'medium',
            estimatedTime: 4,
            dependencies: ['todo-3'],
            reasoning: ['Output generation task'],
            category: 'general'
          }
        ],
        executionStrategy: {
          approach: 'sequential',
          errorHandling: 'resilient',
          validationPoints: ['After each task', 'Before final output']
        },
        confidence: 0.85
      };

      setAnalysisResult(mockAnalysis);
      setTodos(mockAnalysis.todoPlan);
      setProgress({ total: mockAnalysis.todoPlan.length, completed: 0, percentage: 0 });
      setReasoning(prev => [...prev, `✅ Deep analysis complete - Goal: ${mockAnalysis.understanding.mainGoal}`]);
      setReasoning(prev => [...prev, `📋 Generated ${mockAnalysis.todoPlan.length} todo tasks`]);
      addExecutionLog('Deep Analysis', 'completed', { analysis: mockAnalysis });
      await delay(500);

      // Step 2: Execute todos systematically
      addExecutionLog('Systematic Execution', 'started', { strategy: mockAnalysis.executionStrategy.approach });
      setReasoning(prev => [...prev, '⚡ Starting systematic execution...']);
      
      for (let i = 0; i < mockAnalysis.todoPlan.length; i++) {
        const todo = mockAnalysis.todoPlan[i];
        
        // Update todo status to in_progress
        updateTodoStatus(todo.id, 'in_progress');
        addExecutionLog('Task Execution', 'started', { taskId: todo.id, task: todo.content });
        await delay(todo.estimatedTime * 200);
        
        // Simulate task execution
        const taskResult = await executeTask(todo);
        
        // Update todo status to completed
        updateTodoStatus(todo.id, 'completed', taskResult);
        addExecutionLog('Task Execution', 'completed', { taskId: todo.id, result: taskResult });
        
        // Update progress
        const completed = i + 1;
        const percentage = Math.round((completed / mockAnalysis.todoPlan.length) * 100);
        setProgress({ total: mockAnalysis.todoPlan.length, completed, percentage });
        
        setReasoning(prev => [...prev, `✅ Task completed: ${todo.content}`]);
        
        // Simulate occasional errors and corrections
        if (Math.random() < 0.2 && i < mockAnalysis.todoPlan.length - 1) {
          const error = `Simulated error in task ${todo.id}`;
          setErrors(prev => [...prev, error]);
          addExecutionLog('Error Detected', 'failed', { taskId: todo.id, error });
          
          await delay(500);
          const correction = `Applied correction for task ${todo.id}`;
          setCorrections(prev => [...prev, correction]);
          addExecutionLog('Self-Correction', 'corrected', { taskId: todo.id, correction });
          setReasoning(prev => [...prev, `🔧 Applied correction for task ${todo.id}`]);
        }
        
        await delay(300);
      }
      
      setReasoning(prev => [...prev, `✅ Systematic execution complete - ${mockAnalysis.todoPlan.length}/${mockAnalysis.todoPlan.length} tasks completed`]);
      addExecutionLog('Systematic Execution', 'completed', { completedTasks: mockAnalysis.todoPlan.length });
      await delay(500);

      // Step 3: Final verification and output
      addExecutionLog('Final Verification', 'started', {});
      setReasoning(prev => [...prev, '🔍 Starting final verification...']);
      await delay(800);
      
      const mockFinalOutput = `✅ Task completed successfully!\n\n🎯 Goal: ${mockAnalysis.understanding.mainGoal}\n📋 Completed ${mockAnalysis.todoPlan.length} tasks\n🔧 Applied ${corrections.length} corrections\n⏱️ Execution time: ${(mockAnalysis.todoPlan.reduce((sum, todo) => sum + todo.estimatedTime, 0) * 0.2).toFixed(1)}s\n\n📊 Summary:\n- All requirements analyzed and addressed\n- Systematic execution with error handling\n- Self-correction applied when needed\n- Final output generated successfully`;
      
      setFinalOutput(mockFinalOutput);
      setReasoning(prev => [...prev, '✅ Final verification complete']);
      addExecutionLog('Final Verification', 'completed', { output: mockFinalOutput });
      await delay(500);

      // Step 4: Learning
      addExecutionLog('Learning & Improvement', 'started', {});
      setReasoning(prev => [...prev, '🧠 Starting learning process...']);
      await delay(600);
      
      const mockLearnings = [
        'Successfully completed all tasks systematically',
        'Error handling and self-correction working effectively',
        'Execution strategy performed well for this complexity level',
        'User requirements were properly understood and addressed'
      ];
      
      setLearnings(mockLearnings);
      setReasoning(prev => [...prev, `✅ Learning complete - ${mockLearnings.length} insights gained`]);
      addExecutionLog('Learning & Improvement', 'completed', { insights: mockLearnings });

    } catch (error) {
      setErrors(prev => [...prev, `Processing error: ${error}`]);
      addExecutionLog('Error', 'failed', { error });
    } finally {
      setIsProcessing(false);
    }
  };

  const addExecutionLog = (step: string, status: ExecutionLog['status'], details: any) => {
    const newLog: ExecutionLog = {
      timestamp: new Date(),
      step,
      status,
      details
    };
    setExecutionLog(prev => [...prev, newLog]);
  };

  const updateTodoStatus = (todoId: string, status: Todo['status'], result?: any) => {
    setTodos(prev => prev.map(todo => {
      if (todo.id === todoId) {
        const updatedTodo = { 
          ...todo, 
          status,
          reasoning: [...todo.reasoning, `Status updated to ${status}`]
        };
        
        if (status === 'in_progress') {
          updatedTodo.startTime = new Date();
        } else if (status === 'completed') {
          updatedTodo.endTime = new Date();
          updatedTodo.result = result;
        } else if (status === 'failed') {
          updatedTodo.endTime = new Date();
          updatedTodo.error = result;
        }
        
        return updatedTodo;
      }
      return todo;
    }));
  };

  const executeTask = async (todo: Todo): Promise<any> => {
    // Simulate task execution
    await delay(todo.estimatedTime * 100);
    
    return {
      type: 'execution_result',
      taskId: todo.id,
      success: true,
      output: `Task "${todo.content}" completed successfully`,
      timestamp: new Date()
    };
  };

  const delay = (ms: number): Promise<void> => {
    return new Promise(resolve => setTimeout(resolve, ms));
  };

  const handleProcess = async () => {
    if (!inputText.trim() || isProcessing) return;
    
    if (onProcess) {
      try {
        const result = await onProcess(inputText);
        // Handle real processing result
      } catch (error) {
        console.error('Processing failed:', error);
      }
    } else {
      // Simulate processing
      await simulateProcessing(inputText);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600';
      case 'in_progress': return 'text-blue-600';
      case 'failed': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4" />;
      case 'in_progress': return <Loader2 className="w-4 h-4 animate-spin" />;
      case 'failed': return <XCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const TodoItem = ({ todo }: { todo: Todo }) => (
    <Card className="mb-3">
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              {getStatusIcon(todo.status)}
              <span className={`font-medium ${getStatusColor(todo.status)}`}>
                {todo.content}
              </span>
              <Badge className={getPriorityColor(todo.priority)}>
                {todo.priority}
              </Badge>
              {todo.category && (
                <Badge variant="outline">
                  {todo.category}
                </Badge>
              )}
            </div>
            
            <div className="text-sm text-gray-600 space-y-1">
              <div>Estimated time: {todo.estimatedTime}s</div>
              {todo.dependencies.length > 0 && (
                <div>Dependencies: {todo.dependencies.join(', ')}</div>
              )}
              {todo.startTime && (
                <div>Started: {todo.startTime.toLocaleTimeString()}</div>
              )}
              {todo.endTime && (
                <div>Ended: {todo.endTime.toLocaleTimeString()}</div>
              )}
            </div>
            
            {todo.reasoning.length > 0 && (
              <div className="mt-2 space-y-1">
                {todo.reasoning.map((reason, index) => (
                  <div key={index} className="text-xs text-gray-500 bg-gray-50 px-2 py-1 rounded">
                    {reason}
                  </div>
                ))}
              </div>
            )}
            
            {todo.result && (
              <div className="mt-2 p-2 bg-green-50 rounded text-sm text-green-800">
                Result: {JSON.stringify(todo.result)}
              </div>
            )}
            
            {todo.error && (
              <div className="mt-2 p-2 bg-red-50 rounded text-sm text-red-800">
                Error: {todo.error}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const ExecutionLogItem = ({ log }: { log: ExecutionLog }) => {
    const getStatusColor = (status: string) => {
      switch (status) {
        case 'completed': return 'text-green-600 bg-green-50';
        case 'failed': return 'text-red-600 bg-red-50';
        case 'corrected': return 'text-blue-600 bg-blue-50';
        default: return 'text-blue-600 bg-blue-50';
      }
    };

    const getStatusIcon = (status: string) => {
      switch (status) {
        case 'completed': return <CheckCircle className="w-4 h-4" />;
        case 'failed': return <XCircle className="w-4 h-4" />;
        case 'corrected': return <RotateCcw className="w-4 h-4" />;
        default: return <Play className="w-4 h-4" />;
      }
    };

    return (
      <div className={`flex items-start space-x-3 p-3 rounded-lg ${getStatusColor(log.status)}`}>
        {getStatusIcon(log.status)}
        <div className="flex-1">
          <div className="flex items-center justify-between">
            <span className="font-medium">{log.step}</span>
            <span className="text-xs opacity-75">
              {log.timestamp.toLocaleTimeString()}
            </span>
          </div>
          <div className="text-sm mt-1">
            Status: <span className="font-medium">{log.status}</span>
          </div>
          {Object.keys(log.details).length > 0 && (
            <details className="mt-2">
              <summary className="text-xs cursor-pointer hover:underline">
                View details
              </summary>
              <pre className="text-xs mt-1 p-2 bg-white bg-opacity-50 rounded overflow-x-auto">
                {JSON.stringify(log.details, null, 2)}
              </pre>
            </details>
          )}
        </div>
      </div>
    );
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-6xl h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center space-x-3">
            <Brain className="w-6 h-6 text-purple-600" />
            <h2 className="text-xl font-bold">🧠 Enhanced AI Brain - Live Working Display</h2>
            <Badge variant={isLiveMode ? "default" : "secondary"}>
              {isLiveMode ? "Live Mode" : "Paused"}
            </Badge>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsLiveMode(!isLiveMode)}
            >
              {isLiveMode ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              {isLiveMode ? 'Pause' : 'Resume'}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowDetails(!showDetails)}
            >
              {showDetails ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              {showDetails ? 'Hide' : 'Show'} Details
            </Button>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Progress Bar */}
        {progress.total > 0 && (
          <div className="px-4 py-2 border-b">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Progress</span>
              <span className="text-sm text-gray-600">
                {progress.completed}/{progress.total} ({progress.percentage}%)
              </span>
            </div>
            <Progress value={progress.percentage} className="w-full" />
          </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-hidden">
          <ScrollArea className="h-full">
            <div className="p-6 space-y-6">
              {/* Input Section */}
              <Card>
                <CardHeader>
                  <CardTitle>🎯 Enter Your Request</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="Enter your request for the Enhanced AI Brain to process..."
                    className="min-h-24"
                    disabled={isProcessing}
                  />
                  <div className="flex items-center space-x-4">
                    <Button 
                      onClick={handleProcess} 
                      disabled={isProcessing || !inputText.trim()}
                      className="flex items-center space-x-2"
                    >
                      {isProcessing ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Processing...</span>
                        </>
                      ) : (
                        <>
                          <Brain className="w-4 h-4" />
                          <span>Process with Enhanced AI Brain</span>
                        </>
                      )}
                    </Button>
                    
                    {isProcessing && (
                      <Button variant="outline" onClick={() => setIsProcessing(false)}>
                        <Pause className="w-4 h-4 mr-2" />
                        Stop
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Main Content */}
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-6">
                  <TabsTrigger value="overview">📊 Overview</TabsTrigger>
                  <TabsTrigger value="todos">📝 Todos</TabsTrigger>
                  <TabsTrigger value="execution">⚡ Execution</TabsTrigger>
                  <TabsTrigger value="analysis">🔍 Analysis</TabsTrigger>
                  <TabsTrigger value="learning">🧠 Learning</TabsTrigger>
                  <TabsTrigger value="output">📤 Output</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="space-y-6">
                  {analysisResult && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center space-x-2">
                            <Target className="w-5 h-5" />
                            <span>Understanding</span>
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div>
                            <h4 className="font-semibold mb-2">Main Goal</h4>
                            <p className="text-sm text-gray-600">{analysisResult.understanding.mainGoal}</p>
                          </div>
                          <div>
                            <h4 className="font-semibold mb-2">Requirements</h4>
                            <ul className="text-sm text-gray-600 space-y-1">
                              {analysisResult.understanding.requirements.map((req, index) => (
                                <li key={index} className="flex items-start">
                                  <ChevronRight className="w-3 h-3 mt-1 mr-2 flex-shrink-0" />
                                  {req}
                                </li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <h4 className="font-semibold mb-2">Complexity</h4>
                            <Badge variant={
                              analysisResult.understanding.complexity === 'simple' ? 'default' :
                              analysisResult.understanding.complexity === 'moderate' ? 'secondary' : 'destructive'
                            }>
                              {analysisResult.understanding.complexity}
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center space-x-2">
                            <Zap className="w-5 h-5" />
                            <span>Execution Strategy</span>
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div>
                            <h4 className="font-semibold mb-2">Approach</h4>
                            <Badge variant="outline">{analysisResult.executionStrategy.approach}</Badge>
                          </div>
                          <div>
                            <h4 className="font-semibold mb-2">Error Handling</h4>
                            <Badge variant="outline">{analysisResult.executionStrategy.errorHandling}</Badge>
                          </div>
                          <div>
                            <h4 className="font-semibold mb-2">Validation Points</h4>
                            <ul className="text-sm text-gray-600 space-y-1">
                              {analysisResult.executionStrategy.validationPoints.map((point, index) => (
                                <li key={index} className="flex items-start">
                                  <ChevronRight className="w-3 h-3 mt-1 mr-2 flex-shrink-0" />
                                  {point}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  )}

                  {/* Real-time Stats */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <Card>
                      <CardContent className="p-4 text-center">
                        <div className="text-2xl font-bold text-blue-600">{todos.length}</div>
                        <div className="text-sm text-gray-600">Total Tasks</div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4 text-center">
                        <div className="text-2xl font-bold text-green-600">{progress.completed}</div>
                        <div className="text-sm text-gray-600">Completed</div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4 text-center">
                        <div className="text-2xl font-bold text-yellow-600">{errors.length}</div>
                        <div className="text-sm text-gray-600">Errors</div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4 text-center">
                        <div className="text-2xl font-bold text-purple-600">{corrections.length}</div>
                        <div className="text-sm text-gray-600">Corrections</div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="todos" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>📝 Todo Management</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {todos.length > 0 ? (
                        <div className="space-y-3">
                          {todos.map((todo) => (
                            <TodoItem key={todo.id} todo={todo} />
                          ))}
                        </div>
                      ) : (
                        <div className="text-center text-gray-500 py-8">
                          No todos available. Start processing to see todos.
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="execution" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>⚡ Execution Log</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {executionLog.length > 0 ? (
                        <div ref={executionLogRef} className="space-y-3 max-h-96 overflow-y-auto">
                          {executionLog.map((log, index) => (
                            <ExecutionLogItem key={index} log={log} />
                          ))}
                        </div>
                      ) : (
                        <div className="text-center text-gray-500 py-8">
                          No execution logs available. Start processing to see execution details.
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {reasoning.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle>🧠 Reasoning Process</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {reasoning.map((reason, index) => (
                            <div key={index} className="flex items-start space-x-2">
                              <ChevronRight className="w-4 h-4 mt-0.5 text-blue-600 flex-shrink-0" />
                              <span className="text-sm">{reason}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </TabsContent>

                <TabsContent value="analysis" className="space-y-6">
                  {analysisResult && (
                    <Card>
                      <CardHeader>
                        <CardTitle>🔍 Deep Analysis Results</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        <div>
                          <h4 className="font-semibold mb-2">Expected Output</h4>
                          <p className="text-sm text-gray-600">{analysisResult.understanding.expectedOutput}</p>
                        </div>
                        
                        <div>
                          <h4 className="font-semibold mb-2">Constraints</h4>
                          <ul className="text-sm text-gray-600 space-y-1">
                            {analysisResult.understanding.constraints.map((constraint, index) => (
                              <li key={index} className="flex items-start">
                                <ChevronRight className="w-3 h-3 mt-1 mr-2 flex-shrink-0" />
                                {constraint}
                              </li>
                            ))}
                          </ul>
                        </div>
                        
                        <div>
                          <h4 className="font-semibold mb-2">Confidence Score</h4>
                          <div className="flex items-center space-x-2">
                            <Progress value={analysisResult.confidence * 100} className="flex-1" />
                            <span className="text-sm font-medium">{(analysisResult.confidence * 100).toFixed(1)}%</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </TabsContent>

                <TabsContent value="learning" className="space-y-6">
                  {errors.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center space-x-2">
                          <AlertTriangle className="w-5 h-5 text-red-600" />
                          <span>Errors Encountered</span>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {errors.map((error, index) => (
                            <div key={index} className="flex items-start space-x-2">
                              <XCircle className="w-4 h-4 mt-0.5 text-red-600 flex-shrink-0" />
                              <span className="text-sm text-red-700">{error}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {corrections.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center space-x-2">
                          <RotateCcw className="w-5 h-5 text-blue-600" />
                          <span>Corrections Applied</span>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {corrections.map((correction, index) => (
                            <div key={index} className="flex items-start space-x-2">
                              <CheckCircle className="w-4 h-4 mt-0.5 text-blue-600 flex-shrink-0" />
                              <span className="text-sm text-blue-700">{correction}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {learnings.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center space-x-2">
                          <Lightbulb className="w-5 h-5 text-yellow-600" />
                          <span>Learnings & Insights</span>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {learnings.map((learning, index) => (
                            <div key={index} className="flex items-start space-x-2">
                              <Lightbulb className="w-4 h-4 mt-0.5 text-yellow-600 flex-shrink-0" />
                              <span className="text-sm text-yellow-700">{learning}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </TabsContent>

                <TabsContent value="output" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>📤 Final Output</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {finalOutput ? (
                        <div className="space-y-4">
                          <div className="p-4 bg-green-50 rounded-lg">
                            <pre className="whitespace-pre-wrap text-sm text-green-800">
                              {finalOutput}
                            </pre>
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <CheckCircle className="w-5 h-5 text-green-600" />
                              <span className="font-medium text-green-800">Processing Completed Successfully</span>
                            </div>
                            <Badge variant="outline">
                              {progress.percentage}% Complete
                            </Badge>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center text-gray-500 py-8">
                          No output available yet. Start processing to see results.
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </ScrollArea>
        </div>
      </div>
    </div>
  );
}