import { NextRequest } from 'next/server';
import { performWebSearch } from '@/lib/search';
import { AIMessage, AIResponse } from '@/types/ai';
import { safeZAIChatCompletion } from '@/lib/zaiHelper';
import { 
  createSuccessResponse, 
  createErrorResponse, 
  withErrorHandling,
  validateRequiredFields 
} from '@/lib/apiUtils';

async function callZAI(messages: AIMessage[], model: string, searchType: string) {
  try {
    console.log('🤖 Calling ZAI with safeZAIChatCompletion...');
    console.log('📋 Model:', model);
    console.log('🎯 Search Type:', searchType);
    
    // Extract the actual API model name from the display name
    let apiModel = model;
    
    // Map display names to API model names
    if (model.includes('GPT-4O')) {
      apiModel = 'gpt-4o';
    } else if (model.includes('GPT-4 Turbo')) {
      apiModel = 'gpt-4-turbo';
    } else if (model.includes('GPT-4')) {
      apiModel = 'gpt-4';
    } else if (model.includes('Claude 3.5 Sonnet')) {
      apiModel = 'claude-3-5-sonnet-20241022';
    } else if (model.includes('Claude 3 Opus')) {
      apiModel = 'claude-3-opus-20240229';
    } else if (model.includes('Claude 3 Sonnet')) {
      apiModel = 'claude-3-sonnet-20240229';
    } else if (model.includes('Claude 3 Haiku')) {
      apiModel = 'claude-3-haiku-20240307';
    } else if (model.includes('Gemini 1.5 Pro')) {
      apiModel = 'gemini-1.5-pro';
    } else if (model.includes('Gemini Pro')) {
      apiModel = 'gemini-pro';
    } else if (model.includes('GLM-4.5')) {
      apiModel = 'glm-4.5';
    } else if (model.includes('Mixtral')) {
      apiModel = 'mixtral-8x7b';
    } else if (model.includes('Llama 3')) {
      apiModel = 'llama-3-70b';
    } else if (model.includes('Qwen')) {
      apiModel = 'qwen-72b';
    } else {
      apiModel = 'gpt-3.5-turbo'; // fallback
    }
    
    console.log('🔄 Using API model:', apiModel);
    
    const completion = await safeZAIChatCompletion(messages, {
      temperature: 0.7,
      max_tokens: 2000,
      model: apiModel
    });
    
    console.log('✅ ZAI chat completion successful');
    
    // Extract response content
    if (completion && completion.choices && Array.isArray(completion.choices)) {
      const content = completion.choices[0]?.message?.content || 'No response generated';
      console.log('📝 Response length:', content.length, 'characters');
      return content;
    }
    
    throw new Error('Invalid response format from ZAI SDK');
    
  } catch (error) {
    console.error('ZAI SDK Error:', error);
    
    // Instead of throwing, return a helpful fallback response
    const lastMessage = messages[messages.length - 1];
    const userContent = lastMessage?.content || 'Unknown query';
    
    return `💡 **AI Assistant - Initializing**

I understand you're asking about: "${userContent}"

**Current Status:** 🔄 AI services are starting up (this normally takes 30-60 seconds)

**What I can help you with right now:**
• Basic information and explanations
• General guidance and suggestions
• Simple code examples and concepts
• Web search functionality (if available)

**What's happening:**
The AI services are initializing in the background. This is a normal part of the startup process.

**Immediate options:**
• **Try again in 30 seconds** - Services should be ready soon
• **Use simpler requests** - Basic queries work best during initialization
• **Try different modes** - Some modes may be available sooner than others

**Technical details:** ${error instanceof Error ? error.message : 'Services initializing'}

**Estimated wait time:** 30-60 seconds for full AI capabilities

Thank you for your patience! The system is designed to recover automatically. 🚀`;
  }
}

export async function POST(request: NextRequest) {
  return withErrorHandling(async () => {
    try {
      const body = await request.json();
      
      // Validate required fields
      const validation = validateRequiredFields(body, ['message']);
      if (!validation.valid) {
        return createErrorResponse(validation.error!, 400);
      }

      const { message, model, searchType = 'chat' } = body;
      
      console.log(`Processing request: ${message} with model: ${model} and type: ${searchType}`);

      let response = '';
      let searchResults: any[] = [];
      let imageData: string | undefined;
      let imagePrompt: string | undefined;
      let usedProvider = '';

      // Handle different search types
      switch (searchType) {
        case 'search':
          // Perform web search first
          try {
            searchResults = await performWebSearch(message);
            console.log(`Web search completed with ${searchResults.length} results`);
          } catch (searchError) {
            console.warn('Web search failed, continuing without search results:', searchError);
            searchResults = [];
          }
          
          const searchContext = searchResults.map(result => 
            `Source: ${result.name}\nContent: ${result.snippet}`
          ).join('\n\n');

          const searchMessages: AIMessage[] = [
            {
              role: 'system',
              content: `You are an AI assistant that provides accurate, comprehensive answers based on search results and your knowledge. Use the search results to enhance your response.\n\nSearch Results:\n${searchContext}`
            },
            {
              role: 'user',
              content: message
            }
          ];

          try {
            response = await callZAI(searchMessages, model, searchType);
            usedProvider = 'ZAI SDK';
          } catch (providerError) {
            console.error('ZAI SDK failed for search:', providerError);
            response = `🔍 **Web Search Mode**

I apologize, but I'm experiencing technical difficulties with search services. However, I can still help you with: "${message}"

**Search Results Found:** ${searchResults.length} sources

**What I can provide:**
• Summary of available search results
• General knowledge on the topic
• Guidance on where to find more information
• Basic explanations and concepts

**Available Search Results:**
${searchResults.slice(0, 3).map((result, index) => `${index + 1}. ${result.name} - ${result.snippet.substring(0, 100)}...`).join('\n')}

**Technical Status:** The ZAI SDK is initializing. Please try again in a moment for enhanced search capabilities.`;
            usedProvider = 'partial';
          }
          break;

        case 'image':
          imagePrompt = message;
          
          try {
            // Actually call the image generation API
            console.log('🎨 Calling image generation API for:', message);
            
            const imageResponse = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000'}/api/generate-image`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                prompt: message,
                provider: 'auto',
                model: 'auto',
                size: '1024x1024',
                optimize: true,
                saveToFile: false
              }),
            });
            
            if (!imageResponse.ok) {
              const errorText = await imageResponse.text();
              console.error('Image generation API failed:', errorText);
              throw new Error(`Image generation failed: ${errorText}`);
            }
            
            const imageResult = await imageResponse.json();
            console.log('✅ Image generated successfully:', imageResult);
            
            imageData = imageResult.imageData;
            response = `🎨 **Image Generated Successfully!**

I've created an image based on your prompt: "${message}"

**Generation Details:**
- **Provider:** ${imageResult.provider}
- **Model:** ${imageResult.model}
- **Size:** ${imageResult.metadata?.size || '1024x1024'}
- **Optimized:** ${imageResult.metadata?.optimized ? 'Yes' : 'No'}

The image is displayed above. If you'd like to generate a different image or make adjustments, just let me know!`;
            usedProvider = imageResult.provider;
            
          } catch (imageError) {
            console.error('Image generation error:', imageError);
            response = `❌ **Image Generation Failed**

I apologize, but I encountered an issue while generating the image for: "${message}"

**Error Details:** ${imageError instanceof Error ? imageError.message : 'Unknown error'}

**Possible Solutions:**
• Try again in a few moments
• Check if the AI services are properly configured
• Try a different image model from the dropdown
• Simplify your image prompt

**Available Image Models:**
• 🎨 FLUX Dev (Hugging Face) - Highest quality
• ⚡ FLUX Schnell (Hugging Face) - Fast generation
• 🎭 SD 3 Medium (Hugging Face) - Balanced quality
• 🎨 DALL-E 3 (OpenAI) - Premium quality

Please try again or select a different image generation model.`;
            usedProvider = 'error';
          }
          break;

        case 'code':
          const codeMessages: AIMessage[] = [
            {
              role: 'system',
              content: 'You are an expert software developer and coding assistant. Provide clear, well-commented, production-ready code solutions with explanations and best practices.'
            },
            {
              role: 'user',
              content: message
            }
          ];

          try {
            response = await callZAI(codeMessages, model, searchType);
            usedProvider = 'ZAI SDK';
          } catch (providerError) {
            console.error('ZAI SDK failed for code:', providerError);
            response = `💻 **Code Generation**

I apologize, but I'm experiencing technical difficulties with code generation. However, I can still help you with: "${message}"

**What I can provide:**
• Basic code structure and syntax
• Programming concepts and explanations
• Debugging tips and best practices
• Algorithm explanations

**For better results, try:**
• Being more specific about the programming language
• Including specific requirements or constraints
• Breaking down complex requests into smaller parts
• Providing context about your project structure

**Technical Status:** The ZAI SDK is initializing. Please try again in a moment for full code generation capabilities.`;
            usedProvider = 'partial';
          }
          break;

        case 'analysis':
          const analysisMessages: AIMessage[] = [
            {
              role: 'system',
              content: 'You are an expert data analyst and researcher. Provide thorough, evidence-based analysis with clear insights, trends, and actionable recommendations.'
            },
            {
              role: 'user',
              content: message
            }
          ];

          try {
            response = await callZAI(analysisMessages, model, searchType);
            usedProvider = 'ZAI SDK';
          } catch (providerError) {
            console.error('ZAI SDK failed for analysis:', providerError);
            response = `📊 **Analysis Mode**

I apologize, but I'm experiencing technical difficulties with analysis services. However, I can still provide insights on: "${message}"

**What I can offer:**
• General analytical frameworks and approaches
• Basic data interpretation concepts
• Research methodology suggestions
• Statistical analysis fundamentals

**For better analysis results, consider:**
• Providing more specific data or context
• Specifying the type of analysis you need
• Including relevant metrics or parameters
• Being clear about your analysis goals

**Technical Status:** The ZAI SDK is initializing. Please try again in a moment for full analysis capabilities.`;
            usedProvider = 'partial';
          }
          break;

        default: // 'chat'
          const chatMessages: AIMessage[] = [
            {
              role: 'system',
              content: 'You are a helpful, knowledgeable, and friendly AI assistant. Provide accurate, detailed, and useful responses while maintaining a conversational tone.'
            },
            {
              role: 'user',
              content: message
            }
          ];

          try {
            response = await callZAI(chatMessages, model, searchType);
            usedProvider = 'ZAI SDK';
          } catch (providerError) {
            console.error('ZAI SDK failed for chat:', providerError);
            response = `💬 **Chat Mode**

I apologize, but I'm experiencing technical difficulties with chat services. However, I'm still here to help you with: "${message}"

**What I can provide:**
• General information and knowledge
• Basic explanations and concepts
• Guidance on various topics
• Conversational support

**This could be due to:**
• Temporary AI service connectivity issues
• High demand on AI services
• Service initialization in progress

**Technical Status:** The ZAI SDK is initializing. Please try again in a moment for full chat capabilities.`;
            usedProvider = 'partial';
          }
          break;
      }

      const aiResponse: AIResponse = {
        success: true,
        response: response + (usedProvider !== 'fallback' ? `\n\n*Powered by ${usedProvider}*` : ''),
        searchResults: searchResults.length > 0 ? searchResults : undefined,
        imageData,
        imagePrompt,
        model: `${model} (${usedProvider})`
      };

      return createSuccessResponse(aiResponse.response, aiResponse);
      
    } catch (error: any) {
      console.error('AI API error:', error);
      
      // Always return JSON, never HTML
      return createErrorResponse(
        `AI service failed: ${error.message || 'Unknown error occurred'}`,
        500
      );
    }
  });
}