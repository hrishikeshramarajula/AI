// 📝 Logger Utility for AI Agent Components
// Provides structured logging with different levels and outputs

export enum LogLevel {
  DEBUG = 0,
  INFO = 1,
  WARN = 2,
  ERROR = 3,
  CRITICAL = 4
}

export interface LogEntry {
  timestamp: Date;
  level: LogLevel;
  component: string;
  message: string;
  data?: any;
  error?: any;
  traceId?: string;
}

export interface LoggerConfig {
  level: LogLevel;
  enableConsole: boolean;
  enableFile: boolean;
  enableStructured: boolean;
  filePath?: string;
  maxFileSize: number;
  maxFiles: number;
}

export class Logger {
  private config: LoggerConfig;
  private logs: LogEntry[] = [];
  private traceId: string;

  constructor(component: string, config?: Partial<LoggerConfig>) {
    this.traceId = this.generateTraceId();
    
    this.config = {
      level: LogLevel.INFO,
      enableConsole: true,
      enableFile: false,
      enableStructured: true,
      maxFileSize: 10 * 1024 * 1024, // 10MB
      maxFiles: 5,
      ...config
    };
    
    this.info(`${component} logger initialized`);
  }

  public debug(message: string, data?: any): void {
    this.log(LogLevel.DEBUG, message, data);
  }

  public info(message: string, data?: any): void {
    this.log(LogLevel.INFO, message, data);
  }

  public warn(message: string, data?: any): void {
    this.log(LogLevel.WARN, message, data);
  }

  public error(message: string, error?: any, data?: any): void {
    this.log(LogLevel.ERROR, message, data, error);
  }

  public critical(message: string, error?: any, data?: any): void {
    this.log(LogLevel.CRITICAL, message, data, error);
  }

  private log(level: LogLevel, message: string, data?: any, error?: any): void {
    if (level < this.config.level) return;

    const entry: LogEntry = {
      timestamp: new Date(),
      level,
      component: this.getComponentName(),
      message,
      data,
      error,
      traceId: this.traceId
    };

    this.logs.push(entry);

    if (this.config.enableConsole) {
      this.logToConsole(entry);
    }

    if (this.config.enableFile) {
      this.logToFile(entry);
    }
  }

  private logToConsole(entry: LogEntry): void {
    const timestamp = entry.timestamp.toISOString();
    const level = LogLevel[entry.level];
    const component = entry.component;
    const message = entry.message;
    
    let logMessage = `[${timestamp}] [${level}] [${component}] ${message}`;
    
    if (entry.data) {
      logMessage += ` ${JSON.stringify(entry.data)}`;
    }
    
    if (entry.error) {
      logMessage += ` Error: ${entry.error.message || entry.error}`;
    }

    switch (entry.level) {
      case LogLevel.DEBUG:
        console.debug(logMessage);
        break;
      case LogLevel.INFO:
        console.log(logMessage);
        break;
      case LogLevel.WARN:
        console.warn(logMessage);
        break;
      case LogLevel.ERROR:
        console.error(logMessage);
        break;
      case LogLevel.CRITICAL:
        console.error(`🚨 ${logMessage}`);
        break;
    }
  }

  private logToFile(entry: LogEntry): void {
    // File logging would be implemented here
    // For now, we'll just acknowledge it
    if (this.config.enableStructured) {
      console.log('📄 File logging enabled (not implemented in this demo)');
    }
  }

  private getComponentName(): string {
    const stack = new Error().stack || '';
    const lines = stack.split('\n');
    const componentLine = lines.find(line => line.includes('src/lib/aiAgent'));
    
    if (componentLine) {
      const match = componentLine.match(/\/([^\/]+)\.ts/);
      if (match) {
        return match[1];
      }
    }
    
    return 'Unknown';
  }

  private generateTraceId(): string {
    return Math.random().toString(36).substr(2, 9);
  }

  public getLogs(level?: LogLevel): LogEntry[] {
    if (level !== undefined) {
      return this.logs.filter(log => log.level >= level);
    }
    return this.logs;
  }

  public clearLogs(): void {
    this.logs = [];
  }

  public setLevel(level: LogLevel): void {
    this.config.level = level;
  }
}