// 📝 Todo Manager - Manages todos like Claude's systematic approach
// This provides TodoWrite/TodoRead functionality for the Enhanced AI Agent Brain

export interface Todo {
  id: string;
  content: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  priority: 'high' | 'medium' | 'low';
  estimatedTime: number;
  dependencies: string[];
  result?: any;
  error?: string;
  reasoning: string[];
  startTime?: Date;
  endTime?: Date;
  category?: 'analysis' | 'development' | 'testing' | 'validation' | 'correction' | 'general';
}

export interface TodoList {
  id: string;
  name: string;
  description: string;
  todos: Todo[];
  createdAt: Date;
  updatedAt: Date;
  status: 'active' | 'completed' | 'archived';
}

export interface TodoManagerConfig {
  maxActiveTodos?: number;
  autoPrioritize?: boolean;
  dependencyCheck?: boolean;
  progressTracking?: boolean;
}

export class TodoManager {
  private todoLists: Map<string, TodoList> = new Map();
  private activeListId: string | null = null;
  private config: TodoManagerConfig;
  private eventListeners: Map<string, Array<(args: any[]) => void>> = new Map();

  constructor(config: TodoManagerConfig = {}) {
    this.config = {
      maxActiveTodos: 50,
      autoPrioritize: true,
      dependencyCheck: true,
      progressTracking: true,
      ...config
    };
    
    this.initializeEventListeners();
  }

  private initializeEventListeners(): void {
    this.eventListeners.set('todoCreated', []);
    this.eventListeners.set('todoUpdated', []);
    this.eventListeners.set('todoCompleted', []);
    this.eventListeners.set('todoFailed', []);
    this.eventListeners.set('listCreated', []);
    this.eventListeners.set('listUpdated', []);
  }

  // 📝 TodoWrite - Create a new todo list
  public async TodoWrite(todos: Todo[], listName?: string, description?: string): Promise<string> {
    const listId = this.generateId();
    const now = new Date();
    
    const todoList: TodoList = {
      id: listId,
      name: listName || `Todo List ${this.todoLists.size + 1}`,
      description: description || `Auto-generated todo list with ${todos.length} tasks`,
      todos: [...todos],
      createdAt: now,
      updatedAt: now,
      status: 'active'
    };

    // Validate and process todos
    todoList.todos = this.processTodos(todoList.todos);
    
    // Store the list
    this.todoLists.set(listId, todoList);
    this.activeListId = listId;
    
    // Emit event
    this.emit('listCreated', todoList);
    
    console.log(`📝 TodoWrite: Created todo list "${listName}" with ${todos.length} tasks`);
    return listId;
  }

  // 📖 TodoRead - Read todos from a list
  public async TodoRead(listId?: string): Promise<TodoList | null> {
    const targetListId = listId || this.activeListId;
    
    if (!targetListId) {
      console.warn('📖 TodoRead: No active todo list found');
      return null;
    }
    
    const todoList = this.todoLists.get(targetListId);
    if (!todoList) {
      console.warn(`📖 TodoRead: Todo list with id "${targetListId}" not found`);
      return null;
    }
    
    console.log(`📖 TodoRead: Retrieved todo list "${todoList.name}" with ${todoList.todos.length} tasks`);
    return todoList;
  }

  // ➕ Add a single todo to the active list
  public async addTodo(todo: Todo, listId?: string): Promise<void> {
    const targetListId = listId || this.activeListId;
    
    if (!targetListId) {
      throw new Error('No active todo list found');
    }
    
    const todoList = this.todoLists.get(targetListId);
    if (!todoList) {
      throw new Error(`Todo list with id "${targetListId}" not found`);
    }
    
    // Process the todo
    const processedTodo = this.processTodo(todo);
    todoList.todos.push(processedTodo);
    todoList.updatedAt = new Date();
    
    // Auto-prioritize if enabled
    if (this.config.autoPrioritize) {
      this.prioritizeTodos(todoList);
    }
    
    // Emit event
    this.emit('todoCreated', processedTodo);
    
    console.log(`➕ Added todo: "${todo.content}" to list "${todoList.name}"`);
  }

  // ✅ Mark a todo as completed
  public async completeTodo(todoId: string, result?: any, listId?: string): Promise<void> {
    const targetListId = listId || this.activeListId;
    
    if (!targetListId) {
      throw new Error('No active todo list found');
    }
    
    const todoList = this.todoLists.get(targetListId);
    if (!todoList) {
      throw new Error(`Todo list with id "${targetListId}" not found`);
    }
    
    const todo = todoList.todos.find(t => t.id === todoId);
    if (!todo) {
      throw new Error(`Todo with id "${todoId}" not found`);
    }
    
    // Update todo
    todo.status = 'completed';
    todo.endTime = new Date();
    todo.result = result;
    todo.reasoning.push(`✅ Todo completed successfully`);
    
    todoList.updatedAt = new Date();
    
    // Check if all todos are completed
    if (this.areAllTodosCompleted(todoList)) {
      todoList.status = 'completed';
    }
    
    // Emit event
    this.emit('todoCompleted', todo);
    
    console.log(`✅ Completed todo: "${todo.content}" in list "${todoList.name}"`);
  }

  // ❌ Mark a todo as failed
  public async failTodo(todoId: string, error: string, listId?: string): Promise<void> {
    const targetListId = listId || this.activeListId;
    
    if (!targetListId) {
      throw new Error('No active todo list found');
    }
    
    const todoList = this.todoLists.get(targetListId);
    if (!todoList) {
      throw new Error(`Todo list with id "${targetListId}" not found`);
    }
    
    const todo = todoList.todos.find(t => t.id === todoId);
    if (!todo) {
      throw new Error(`Todo with id "${todoId}" not found`);
    }
    
    // Update todo
    todo.status = 'failed';
    todo.endTime = new Date();
    todo.error = error;
    todo.reasoning.push(`❌ Todo failed: ${error}`);
    
    todoList.updatedAt = new Date();
    
    // Emit event
    this.emit('todoFailed', todo);
    
    console.log(`❌ Failed todo: "${todo.content}" in list "${todoList.name}" - ${error}`);
  }

  // 🔄 Update todo status
  public async updateTodoStatus(todoId: string, status: Todo['status'], listId?: string): Promise<void> {
    const targetListId = listId || this.activeListId;
    
    if (!targetListId) {
      throw new Error('No active todo list found');
    }
    
    const todoList = this.todoLists.get(targetListId);
    if (!todoList) {
      throw new Error(`Todo list with id "${targetListId}" not found`);
    }
    
    const todo = todoList.todos.find(t => t.id === todoId);
    if (!todo) {
      throw new Error(`Todo with id "${todoId}" not found`);
    }
    
    const oldStatus = todo.status;
    todo.status = status;
    
    if (status === 'in_progress') {
      todo.startTime = new Date();
      todo.reasoning.push(`🚀 Todo started execution`);
    }
    
    todoList.updatedAt = new Date();
    
    // Emit event
    this.emit('todoUpdated', todo, oldStatus);
    
    console.log(`🔄 Updated todo "${todo.content}" status from ${oldStatus} to ${status}`);
  }

  // 📊 Get todo progress
  public async getProgress(listId?: string): Promise<{
    total: number;
    completed: number;
    inProgress: number;
    failed: number;
    pending: number;
    percentage: number;
  }> {
    const targetListId = listId || this.activeListId;
    
    if (!targetListId) {
      return {
        total: 0,
        completed: 0,
        inProgress: 0,
        failed: 0,
        pending: 0,
        percentage: 0
      };
    }
    
    const todoList = this.todoLists.get(targetListId);
    if (!todoList) {
      throw new Error(`Todo list with id "${targetListId}" not found`);
    }
    
    const total = todoList.todos.length;
    const completed = todoList.todos.filter(t => t.status === 'completed').length;
    const inProgress = todoList.todos.filter(t => t.status === 'in_progress').length;
    const failed = todoList.todos.filter(t => t.status === 'failed').length;
    const pending = todoList.todos.filter(t => t.status === 'pending').length;
    const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
    
    return {
      total,
      completed,
      inProgress,
      failed,
      pending,
      percentage
    };
  }

  // 🎯 Get next available todo (respecting dependencies)
  public async getNextTodo(listId?: string): Promise<Todo | null> {
    const targetListId = listId || this.activeListId;
    
    if (!targetListId) {
      return null;
    }
    
    const todoList = this.todoLists.get(targetListId);
    if (!todoList) {
      throw new Error(`Todo list with id "${targetListId}" not found`);
    }
    
    // Get pending todos
    const pendingTodos = todoList.todos.filter(t => t.status === 'pending');
    
    // Check dependencies if enabled
    if (this.config.dependencyCheck) {
      for (const todo of pendingTodos) {
        if (this.areDependenciesMet(todo, todoList.todos)) {
          return todo;
        }
      }
    } else {
      // Return first pending todo
      return pendingTodos[0] || null;
    }
    
    return null;
  }

  // 📋 Get all active todos
  public async getActiveTodos(listId?: string): Promise<Todo[]> {
    const targetListId = listId || this.activeListId;
    
    if (!targetListId) {
      return [];
    }
    
    const todoList = this.todoLists.get(targetListId);
    if (!todoList) {
      throw new Error(`Todo list with id "${targetListId}" not found`);
    }
    
    return todoList.todos.filter(t => t.status !== 'completed');
  }

  // 🗑️ Delete todo list
  public async deleteList(listId: string): Promise<void> {
    const deleted = this.todoLists.delete(listId);
    
    if (deleted) {
      if (this.activeListId === listId) {
        this.activeListId = null;
      }
      console.log(`🗑️ Deleted todo list with id "${listId}"`);
    } else {
      console.warn(`🗑️ Todo list with id "${listId}" not found`);
    }
  }

  // 📊 Get all todo lists
  public async getAllLists(): Promise<TodoList[]> {
    return Array.from(this.todoLists.values());
  }

  // 🎯 Set active todo list
  public async setActiveList(listId: string): Promise<void> {
    if (!this.todoLists.has(listId)) {
      throw new Error(`Todo list with id "${listId}" not found`);
    }
    
    this.activeListId = listId;
    console.log(`🎯 Set active todo list to "${this.todoLists.get(listId)?.name}"`);
  }

  // 📊 Get manager status
  public getStatus(): any {
    const activeList = this.activeListId ? this.todoLists.get(this.activeListId) : null;
    
    return {
      config: this.config,
      activeListId: this.activeListId,
      activeListName: activeList?.name,
      totalLists: this.todoLists.size,
      activeListProgress: activeList ? this.getProgressSync(activeList) : null
    };
  }

  // Event handling
  public on(event: string, callback: (args: any[]) => void): void {
    if (!this.eventListeners.has(event)) {
      this.eventListeners.set(event, []);
    }
    this.eventListeners.get(event)!.push(callback);
  }

  private emit(event: string, ...args: any[]): void {
    const callbacks = this.eventListeners.get(event);
    if (callbacks) {
      callbacks.forEach(callback => callback(...args));
    }
  }

  // Private helper methods
  private processTodos(todos: Todo[]): Todo[] {
    return todos.map(todo => this.processTodo(todo));
  }

  private processTodo(todo: Todo): Todo {
    const processedTodo = { ...todo };
    
    // Ensure required fields
    if (!processedTodo.id) {
      processedTodo.id = this.generateId();
    }
    
    if (!processedTodo.status) {
      processedTodo.status = 'pending';
    }
    
    if (!processedTodo.priority) {
      processedTodo.priority = 'medium';
    }
    
    if (!processedTodo.estimatedTime) {
      processedTodo.estimatedTime = 5;
    }
    
    if (!processedTodo.dependencies) {
      processedTodo.dependencies = [];
    }
    
    if (!processedTodo.reasoning) {
      processedTodo.reasoning = [];
    }
    
    return processedTodo;
  }

  private prioritizeTodos(todoList: TodoList): void {
    const priorityOrder = { 'high': 3, 'medium': 2, 'low': 1 };
    
    todoList.todos.sort((a, b) => {
      // First by priority
      if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
        return priorityOrder[b.priority] - priorityOrder[a.priority];
      }
      
      // Then by dependency count (fewer dependencies first)
      if (a.dependencies.length !== b.dependencies.length) {
        return a.dependencies.length - b.dependencies.length;
      }
      
      // Finally by estimated time (shorter tasks first)
      return a.estimatedTime - b.estimatedTime;
    });
  }

  private areDependenciesMet(todo: Todo, allTodos: Todo[]): boolean {
    for (const depId of todo.dependencies) {
      const dependency = allTodos.find(t => t.id === depId);
      if (!dependency || dependency.status !== 'completed') {
        return false;
      }
    }
    return true;
  }

  private areAllTodosCompleted(todoList: TodoList): boolean {
    return todoList.todos.length > 0 && 
           todoList.todos.every(t => t.status === 'completed');
  }

  private getProgressSync(todoList: TodoList): any {
    const total = todoList.todos.length;
    const completed = todoList.todos.filter(t => t.status === 'completed').length;
    const inProgress = todoList.todos.filter(t => t.status === 'in_progress').length;
    const failed = todoList.todos.filter(t => t.status === 'failed').length;
    const pending = todoList.todos.filter(t => t.status === 'pending').length;
    const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
    
    return {
      total,
      completed,
      inProgress,
      failed,
      pending,
      percentage
    };
  }

  private generateId(): string {
    return `todo_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

// Global todo manager instance
export const todoManager = new TodoManager();