import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

interface PremiumWebpageRequest {
  prompt: string
  features?: string[]
  requirements?: string[]
}

interface PremiumWebpageResponse {
  success: boolean
  files?: {
    name: string
    content: string
    language: string
  }[]
  tasks?: {
    id: string
    title: string
    description: string
    status: 'pending' | 'in_progress' | 'completed' | 'error'
    priority: 'high' | 'medium' | 'low'
    createdAt: Date
  }[]
  consoleLogs?: {
    id: string
    type: 'log' | 'error' | 'success' | 'info'
    message: string
    timestamp: Date
  }[]
  explanation?: string
  error?: string
}

interface Task {
  id: string
  title: string
  description: string
  status: 'pending' | 'in_progress' | 'completed' | 'error'
  priority: 'high' | 'medium' | 'low'
  createdAt: Date
}

interface ConsoleLog {
  id: string
  type: 'log' | 'error' | 'success' | 'info'
  message: string
  timestamp: Date
}

// Premium features that the tool can automatically implement
const PREMIUM_FEATURES = {
  navigation: {
    name: "Professional navigation with logo, menu items, search, and user account",
    description: "Create a modern responsive navigation bar with logo, menu items, search functionality, and user account section",
    priority: "high" as const
  },
  hero: {
    name: "Compelling hero section with background video/animations, headline, subheadline, and CTA buttons",
    description: "Design an eye-catching hero section with background animations, compelling headline, subheadline, and call-to-action buttons",
    priority: "high" as const
  },
  services: {
    name: "Interactive features showcasing key services with hover effects and animations",
    description: "Create interactive service cards with hover effects, animations, and engaging visual elements",
    priority: "medium" as const
  },
  detailedServices: {
    name: "Detailed services section with professional descriptions and icons",
    description: "Build a comprehensive services section with professional descriptions, custom icons, and detailed information",
    priority: "medium" as const
  },
  about: {
    name: "Professional about section with company history, mission, and values",
    description: "Create a professional about section showcasing company history, mission statement, and core values",
    priority: "medium" as const
  },
  testimonials: {
    name: "Client testimonials with photos, ratings, and detailed reviews",
    description: "Implement a testimonials section with client photos, star ratings, and detailed review content",
    priority: "medium" as const
  },
  contact: {
    name: "Professional contact form with validation and company information",
    description: "Build a professional contact form with proper validation, company information, and interactive elements",
    priority: "high" as const
  },
  footer: {
    name: "Professional footer with links, social media, and contact information",
    description: "Create a comprehensive footer with navigation links, social media icons, and complete contact information",
    priority: "low" as const
  },
  backToTop: {
    name: "Back to top button with smooth scrolling",
    description: "Implement a smooth-scrolling back-to-top button with modern design and functionality",
    priority: "low" as const
  }
}

// AI-Powered Prompt Analysis and Enhancement
async function analyzeAndEnhancePrompt(prompt: string, features: string[]) {
  try {
    const analysisPrompt = `You are an expert web consultant and UX strategist. Analyze the following user request and provide intelligent insights for creating an exceptional website.

USER REQUEST: "${prompt}"

Analyze this request and provide:
1. ANALYSIS: What type of website is this? What are the user's real needs and goals?
2. ENHANCED REQUIREMENTS: What specific features and functionality would make this website successful?
3. CREATIVE DIRECTION: What design approach would work best for this type of website?
4. TARGET AUDIENCE: Who is the primary audience for this website?
5. DESIGN STYLE: What visual style would be most appropriate and effective?
6. COLOR SCHEME: What color palette would work best for this type of business/website?

Provide your analysis in a clear, structured format that can be used to guide the web development process.`

    const zai = await ZAI.create()
    const analysis = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an expert web consultant with deep understanding of user needs, business goals, and design psychology. You provide insightful analysis that helps create exceptional websites.'
        },
        {
          role: 'user',
          content: analysisPrompt
        }
      ],
      temperature: 0.7,
      max_tokens: 2000
    })

    const analysisContent = analysis.choices[0]?.message?.content || ''
    
    // Parse the analysis into structured components
    const analysisLines = analysisContent.split('\n')
    const parsedAnalysis = {
      analysis: '',
      enhancedRequirements: '',
      creativeDirection: '',
      targetAudience: '',
      designStyle: '',
      colorScheme: ''
    }

    let currentSection = ''
    analysisLines.forEach(line => {
      const trimmedLine = line.trim()
      if (trimmedLine.toUpperCase().includes('ANALYSIS:')) {
        currentSection = 'analysis'
        parsedAnalysis.analysis = trimmedLine.replace(/.*ANALYSIS:\s*/i, '')
      } else if (trimmedLine.toUpperCase().includes('ENHANCED REQUIREMENTS:')) {
        currentSection = 'enhancedRequirements'
        parsedAnalysis.enhancedRequirements = trimmedLine.replace(/.*ENHANCED REQUIREMENTS:\s*/i, '')
      } else if (trimmedLine.toUpperCase().includes('CREATIVE DIRECTION:')) {
        currentSection = 'creativeDirection'
        parsedAnalysis.creativeDirection = trimmedLine.replace(/.*CREATIVE DIRECTION:\s*/i, '')
      } else if (trimmedLine.toUpperCase().includes('TARGET AUDIENCE:')) {
        currentSection = 'targetAudience'
        parsedAnalysis.targetAudience = trimmedLine.replace(/.*TARGET AUDIENCE:\s*/i, '')
      } else if (trimmedLine.toUpperCase().includes('DESIGN STYLE:')) {
        currentSection = 'designStyle'
        parsedAnalysis.designStyle = trimmedLine.replace(/.*DESIGN STYLE:\s*/i, '')
      } else if (trimmedLine.toUpperCase().includes('COLOR SCHEME:')) {
        currentSection = 'colorScheme'
        parsedAnalysis.colorScheme = trimmedLine.replace(/.*COLOR SCHEME:\s*/i, '')
      } else if (currentSection && trimmedLine) {
        parsedAnalysis[currentSection as keyof typeof parsedAnalysis] += ' ' + trimmedLine
      }
    })

    // Fallback intelligent analysis if AI fails
    if (!parsedAnalysis.analysis) {
      return getFallbackAnalysis(prompt, features)
    }

    return parsedAnalysis

  } catch (error) {
    console.log('[Premium Webpage API] AI analysis failed, using fallback:', error)
    return getFallbackAnalysis(prompt, features)
  }
}

// Intelligent fallback analysis based on prompt keywords
function getFallbackAnalysis(prompt: string, features: string[]) {
  const promptLower = prompt.toLowerCase()
  
  // Intelligent prompt analysis
  let analysis = "Professional website development project"
  let enhancedRequirements = "Modern, responsive design with user-friendly interface"
  let creativeDirection = "Clean, professional approach with focus on user experience"
  let targetAudience = "General audience seeking professional services"
  let designStyle = "Modern, clean, and professional"
  let colorScheme = "Professional blue and white color scheme"

  // Business/Corporate websites
  if (promptLower.includes('business') || promptLower.includes('corporate') || promptLower.includes('company')) {
    analysis = "Professional business website requiring corporate identity and trust-building elements"
    enhancedRequirements = "Professional branding, service showcase, client testimonials, contact forms, and clear call-to-action elements"
    creativeDirection = "Corporate professionalism with modern design trends, focus on credibility and conversion"
    targetAudience = "Business clients, potential customers, and professional partners"
    designStyle = "Corporate modern with clean lines and professional typography"
    colorScheme = "Blue, gray, and white with accent colors for calls-to-action"
  }
  
  // Portfolio/Creative websites
  else if (promptLower.includes('portfolio') || promptLower.includes('creative') || promptLower.includes('artist')) {
    analysis = "Creative portfolio website to showcase work and artistic capabilities"
    enhancedRequirements = "Visual gallery, project showcase, creative animations, and personal branding"
    creativeDirection = "Bold, artistic expression with focus on visual impact and creativity"
    targetAudience = "Potential clients, employers, and creative industry professionals"
    designStyle = "Modern creative with artistic elements and unique layout"
    colorScheme = "Vibrant colors with dark backgrounds or minimalist white space"
  }
  
  // E-commerce websites
  else if (promptLower.includes('shop') || promptLower.includes('store') || promptLower.includes('ecommerce')) {
    analysis = "E-commerce platform for selling products online"
    enhancedRequirements = "Product catalog, shopping cart, payment integration, user accounts, and inventory management"
    creativeDirection = "Conversion-focused design with product showcase and easy purchasing flow"
    targetAudience = "Online shoppers looking for specific products"
    designStyle = "Clean retail design with product-focused layout"
    colorScheme = "Trust-building colors with product accent colors"
  }
  
  // Restaurant/Food websites
  else if (promptLower.includes('restaurant') || promptLower.includes('cafe') || promptLower.includes('food')) {
    analysis = "Restaurant or food service website requiring appetizing presentation"
    enhancedRequirements = "Menu display, online reservations, location maps, customer reviews, and food photography"
    creativeDirection = "Warm, inviting atmosphere with food-focused imagery and appetite appeal"
    targetAudience = "Local diners, tourists, and food enthusiasts"
    designStyle = "Warm and inviting with food photography emphasis"
    colorScheme = "Warm colors like reds, oranges, and earth tones"
  }
  
  // Tech/Startup websites
  else if (promptLower.includes('tech') || promptLower.includes('startup') || promptLower.includes('app')) {
    analysis = "Technology company or startup website requiring innovation showcase"
    enhancedRequirements = "Feature demonstrations, technical specifications, pricing plans, and integration capabilities"
    creativeDirection = "Cutting-edge, innovative design with technology focus and modern aesthetics"
    targetAudience = "Tech-savvy users, businesses, and potential investors"
    designStyle = "Modern tech with innovative layouts and futuristic elements"
    colorScheme = "Modern tech colors like blues, purples, and clean whites"
  }

  return {
    analysis: analysis.trim(),
    enhancedRequirements: enhancedRequirements.trim(),
    creativeDirection: creativeDirection.trim(),
    targetAudience: targetAudience.trim(),
    designStyle: designStyle.trim(),
    colorScheme: colorScheme.trim()
  }
}

export async function POST(request: NextRequest) {
  try {
    const body: PremiumWebpageRequest = await request.json()
    const { prompt, features, requirements } = body

    console.log('[Premium Webpage API] 🚀 Starting premium webpage generation...')
    console.log('[Premium Webpage API] Prompt:', prompt)
    console.log('[Premium Webpage API] Features:', features)
    console.log('[Premium Webpage API] Requirements:', requirements)

    // Initialize console logs and tasks
    const consoleLogs: ConsoleLog[] = []
    const tasks: Task[] = []

    // Add initial console logs
    const addConsoleLog = (type: ConsoleLog['type'], message: string) => {
      const log: ConsoleLog = {
        id: Date.now().toString(),
        type,
        message,
        timestamp: new Date()
      }
      consoleLogs.push(log)
      console.log(`[Premium Webpage API] ${type.toUpperCase()}: ${message}`)
    }

    // Add task
    const addTask = (title: string, description: string, priority: Task['priority'] = 'medium') => {
      const task: Task = {
        id: Date.now().toString(),
        title,
        description,
        status: 'pending',
        priority,
        createdAt: new Date()
      }
      tasks.push(task)
      return task
    }

    // Update task status
    const updateTaskStatus = (taskId: string, status: Task['status']) => {
      const task = tasks.find(t => t.id === taskId)
      if (task) {
        task.status = status
        addConsoleLog('info', `Task "${task.title}" status updated to: ${status}`)
      }
    }

    // Initialize the process
    addConsoleLog('info', '🤖 Initializing Premium Webpage Generator...')
    addConsoleLog('success', '✅ Z-AI Web Dev SDK connected successfully')

    // Analyze prompt and determine required features
    addConsoleLog('info', '🔍 Analyzing prompt to determine required features...')
    
    let requiredFeatures = features || []
    
    // If no specific features provided, analyze the prompt to detect required features
    if (requiredFeatures.length === 0) {
      const promptLower = prompt.toLowerCase()
      
      // Detect features based on prompt keywords
      if (promptLower.includes('business') || promptLower.includes('company') || promptLower.includes('professional')) {
        requiredFeatures.push('navigation', 'hero', 'services', 'about', 'contact', 'footer')
      }
      
      if (promptLower.includes('portfolio') || promptLower.includes('showcase')) {
        requiredFeatures.push('navigation', 'hero', 'services', 'testimonials', 'contact', 'footer')
      }
      
      if (promptLower.includes('ecommerce') || promptLower.includes('shop')) {
        requiredFeatures.push('navigation', 'hero', 'services', 'contact', 'footer')
      }
      
      if (promptLower.includes('agency') || promptLower.includes('services')) {
        requiredFeatures.push('navigation', 'hero', 'services', 'detailedServices', 'about', 'testimonials', 'contact', 'footer')
      }
      
      // Always include basic features
      if (requiredFeatures.length === 0) {
        requiredFeatures = ['navigation', 'hero', 'services', 'contact', 'footer']
      }
    }
    
    // Add backToTop to all premium websites
    if (!requiredFeatures.includes('backToTop')) {
      requiredFeatures.push('backToTop')
    }

    addConsoleLog('success', `✅ Detected ${requiredFeatures.length} required features: ${requiredFeatures.join(', ')}`)

    // Create tasks based on required features
    const featureTasks: Task[] = []
    requiredFeatures.forEach(featureKey => {
      const feature = PREMIUM_FEATURES[featureKey as keyof typeof PREMIUM_FEATURES]
      if (feature) {
        const task = addTask(feature.name, feature.description, feature.priority)
        featureTasks.push(task)
      }
    })

    // Add main generation task
    const mainTask = addTask('Generate Premium Webpage', `Create complete premium webpage for: "${prompt}"`, 'high')
    updateTaskStatus(mainTask.id, 'in_progress')

    try {
      // Initialize Z-AI SDK
      addConsoleLog('info', '🔗 Connecting to Z-AI Web Dev SDK...')
      const zai = await ZAI.create()
      addConsoleLog('success', '✅ Z-AI SDK initialized successfully')

      // AI-Powered Prompt Analysis and Enhancement
      addConsoleLog('info', '🧠 Analyzing user prompt with AI intelligence...')
      
      const analyzedPrompt = await analyzeAndEnhancePrompt(prompt, requiredFeatures)
      addConsoleLog('success', '✅ AI prompt analysis completed')
      
      // Generate comprehensive webpage using Enhanced AI Intelligence
      addConsoleLog('info', '🎨 Generating premium webpage with enhanced AI creativity...')
      
      const intelligentPrompt = `You are a master web designer and developer with exceptional creativity and understanding of user needs. 

USER REQUEST: "${prompt}"

AI ANALYSIS: ${analyzedPrompt.analysis}

ENHANCED REQUIREMENTS: ${analyzedPrompt.enhancedRequirements}

CREATIVE DIRECTION: ${analyzedPrompt.creativeDirection}

TARGET AUDIENCE: ${analyzedPrompt.targetAudience}

DESIGN STYLE: ${analyzedPrompt.designStyle}

COLOR SCHEME: ${analyzedPrompt.colorScheme}

Required Premium Features:
${requiredFeatures.map(feature => {
  const featureInfo = PREMIUM_FEATURES[feature as keyof typeof PREMIUM_FEATURES]
  return `- ${featureInfo?.name || feature}: ${featureInfo?.description || ''}`
}).join('\n')}

ADVANCED REQUIREMENTS:
- Create a unique, memorable design that stands out
- Use modern design principles and psychology
- Implement smooth micro-interactions and animations
- Ensure exceptional user experience (UX)
- Make it fully responsive and mobile-optimized
- Include accessibility features (ARIA labels, keyboard navigation)
- Optimize for performance and SEO
- Add thoughtful details and hover effects
- Use professional typography and spacing
- Include engaging visual elements and imagery

Generate a complete, impressive webpage that exceeds user expectations. Be creative and innovative while maintaining professionalism. The design should feel custom-built, not template-based.

Please provide complete HTML, CSS, and JavaScript in separate code blocks.`

      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an award-winning web designer and full-stack developer with 15+ years of experience. You specialize in creating unique, high-end websites that convert visitors into customers. You understand user psychology, modern design trends, and technical best practices. Your code is impeccable, your designs are stunning, and your user experiences are exceptional. You don\'t just build websites - you create digital experiences that leave lasting impressions.'
          },
          {
            role: 'user',
            content: intelligentPrompt
          }
        ],
        temperature: 0.8, // Increased creativity
        max_tokens: 15000 // More detailed output
      })

      const aiContent = completion.choices[0]?.message?.content || ''
      addConsoleLog('success', '✅ AI content generated successfully')

      // Process the AI response to extract files
      addConsoleLog('info', '📁 Processing AI response and extracting files...')
      
      const files = extractFilesFromAIResponse(aiContent, prompt, requiredFeatures)
      
      if (files.length === 0) {
        throw new Error('No files could be extracted from AI response')
      }

      addConsoleLog('success', `✅ Successfully extracted ${files.length} files`)

      // Mark all feature tasks as completed
      featureTasks.forEach(task => {
        updateTaskStatus(task.id, 'completed')
      })

      // Mark main task as completed
      updateTaskStatus(mainTask.id, 'completed')

      addConsoleLog('success', '🎉 Premium webpage generation completed successfully!')
      addConsoleLog('info', `📊 Generated ${files.length} files with ${requiredFeatures.length} premium features`)

      // Return the response
      const response: PremiumWebpageResponse = {
        success: true,
        files,
        tasks,
        consoleLogs,
        explanation: `Premium webpage generated for "${prompt}" with ${requiredFeatures.length} professional features including: ${requiredFeatures.join(', ')}`
      }

      return NextResponse.json(response)

    } catch (aiError) {
      console.error('[Premium Webpage API] AI Error:', aiError)
      addConsoleLog('error', `❌ AI generation failed: ${aiError instanceof Error ? aiError.message : 'Unknown error'}`)
      
      // Update task status to error
      updateTaskStatus(mainTask.id, 'error')
      featureTasks.forEach(task => {
        updateTaskStatus(task.id, 'error')
      })

      // Create intelligent fallback files with AI-enhanced understanding
      addConsoleLog('info', '🛠️ Creating intelligent premium fallback webpage...')
      const intelligentAnalysis = getFallbackAnalysis(prompt, requiredFeatures)
      const fallbackFiles = createIntelligentFallbackFiles(prompt, requiredFeatures, intelligentAnalysis)
      
      addConsoleLog('success', '✅ Intelligent premium fallback created successfully')

      const response: PremiumWebpageResponse = {
        success: true,
        files: fallbackFiles,
        tasks,
        consoleLogs,
        explanation: `Intelligent premium webpage created for "${prompt}" using AI-enhanced understanding with ${requiredFeatures.length} professional features`
      }

      return NextResponse.json(response)
    }

  } catch (error) {
    console.error('[Premium Webpage API] Error:', error)
    
    const response: PremiumWebpageResponse = {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    }

    return NextResponse.json(response, { status: 500 })
  }
}

// Helper function to extract files from AI response
function extractFilesFromAIResponse(content: string, prompt: string, features: string[]) {
  const files = []
  
  // Try to extract HTML, CSS, and JavaScript from code blocks
  const htmlMatch = content.match(/```html\n([\s\S]*?)\n```/) || 
                   content.match(/```HTML\n([\s\S]*?)\n```/)
  
  const cssMatch = content.match(/```css\n([\s\S]*?)\n```/) || 
                  content.match(/```CSS\n([\s\S]*?)\n```/)
  
  const jsMatch = content.match(/```javascript\n([\s\S]*?)\n```/) || 
                 content.match(/```js\n([\s\S]*?)\n```/) ||
                 content.match(/```JavaScript\n([\s\S]*?)\n```/)

  // If we found all three code blocks, use them
  if (htmlMatch && cssMatch && jsMatch) {
    files.push({
      name: 'index.html',
      content: htmlMatch[1].trim(),
      language: 'html'
    })
    
    files.push({
      name: 'styles.css',
      content: cssMatch[1].trim(),
      language: 'css'
    })
    
    files.push({
      name: 'script.js',
      content: jsMatch[1].trim(),
      language: 'javascript'
    })
    
    return files
  }

  // If no clear code blocks found, create comprehensive premium files
  return createIntelligentFallbackFiles(prompt, features, getFallbackAnalysis(prompt, features))
}

// Helper function to create intelligent fallback files with AI-enhanced understanding
function createIntelligentFallbackFiles(prompt: string, features: string[], analysis: any) {
  const hasNavigation = features.includes('navigation')
  const hasHero = features.includes('hero')
  const hasServices = features.includes('services')
  const hasDetailedServices = features.includes('detailedServices')
  const hasAbout = features.includes('about')
  const hasTestimonials = features.includes('testimonials')
  const hasContact = features.includes('contact')
  const hasFooter = features.includes('footer')
  const hasBackToTop = features.includes('backToTop')

  const title = prompt.charAt(0).toUpperCase() + prompt.slice(1)
  const { designStyle, colorScheme, targetAudience, creativeDirection } = analysis

  // Generate intelligent content based on analysis
  const heroHeadline = generateHeroHeadline(prompt, analysis)
  const heroSubheadline = generateHeroSubheadline(prompt, analysis)
  const serviceItems = generateServiceItems(prompt, analysis)
  const aboutContent = generateAboutContent(prompt, analysis)
  const testimonials = generateTestimonials(prompt, analysis)

  const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="${analysis.enhancedRequirements}">
    <title>${title} - ${analysis.analysis}</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="script.js" defer></script>
</head>
<body class="font-sans antialiased">
    ${hasNavigation ? `
    <nav class="navbar ${getNavbarStyle(designStyle)}">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center">
                    <div class="brand-logo">
                        <h1 class="text-2xl font-bold ${getBrandColor(colorScheme)}">${title}</h1>
                    </div>
                    <div class="hidden md:block ml-10">
                        <div class="flex items-baseline space-x-4">
                            <a href="#home" class="nav-link ${getNavLinkColor(colorScheme)}">Home</a>
                            <a href="#services" class="nav-link ${getNavLinkColor(colorScheme)}">Services</a>
                            ${hasAbout ? '<a href="#about" class="nav-link ' + getNavLinkColor(colorScheme) + '">About</a>' : ''}
                            ${hasTestimonials ? '<a href="#testimonials" class="nav-link ' + getNavLinkColor(colorScheme) + '">Testimonials</a>' : ''}
                            <a href="#contact" class="nav-link ${getNavLinkColor(colorScheme)}">Contact</a>
                        </div>
                    </div>
                </div>
                <div class="hidden md:block">
                    <div class="flex items-center space-x-4">
                        <div class="search-box">
                            <input type="text" placeholder="Search..." class="search-input">
                            <i class="fas fa-search search-icon"></i>
                        </div>
                        <div class="user-account">
                            <i class="fas fa-user-circle user-icon"></i>
                            <span class="user-text">Account</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    ` : ''}

    ${hasHero ? `
    <section id="home" class="hero-section ${getHeroStyle(designStyle, colorScheme)}">
        <div class="hero-overlay"></div>
        <div class="container mx-auto px-4 relative z-10">
            <div class="hero-content text-center">
                <h1 class="hero-title">${heroHeadline}</h1>
                <p class="hero-subtitle">${heroSubheadline}</p>
                <div class="hero-buttons">
                    <a href="#services" class="btn btn-primary ${getPrimaryButtonStyle(colorScheme)}">Get Started</a>
                    <a href="#contact" class="btn btn-secondary ${getSecondaryButtonStyle(colorScheme)}">Learn More</a>
                </div>
            </div>
        </div>
    </section>
    ` : ''}

    ${hasServices ? `
    <section id="services" class="services-section ${getSectionStyle(designStyle)}">
        <div class="container mx-auto px-4">
            <div class="text-center mb-16">
                <h2 class="section-title">Our Services</h2>
                <p class="section-subtitle">${analysis.enhancedRequirements}</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                ${serviceItems.map((service, index) => `
                <div class="service-card ${getServiceCardStyle(designStyle)}">
                    <div class="service-icon ${getServiceIconStyle(colorScheme)}">
                        <i class="${service.icon}"></i>
                    </div>
                    <h3 class="service-title">${service.title}</h3>
                    <p class="service-description">${service.description}</p>
                </div>
                `).join('')}
            </div>
        </div>
    </section>
    ` : ''}

    ${hasAbout ? `
    <section id="about" class="about-section ${getAlternateSectionStyle(designStyle)}">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div>
                    <h2 class="section-title">About ${title}</h2>
                    <div class="about-content">
                        ${aboutContent.map(paragraph => `<p class="about-paragraph">${paragraph}</p>`).join('')}
                    </div>
                    <div class="stats-grid">
                        <div class="stat-item">
                            <div class="stat-number ${getStatColor(colorScheme)}">500+</div>
                            <div class="stat-label">Happy Clients</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number ${getStatColor(colorScheme)}">50+</div>
                            <div class="stat-label">Team Members</div>
                        </div>
                    </div>
                </div>
                <div class="about-image">
                    <img src="https://via.placeholder.com/600x400" alt="About ${title}" class="rounded-lg shadow-xl">
                </div>
            </div>
        </div>
    </section>
    ` : ''}

    ${hasTestimonials ? `
    <section id="testimonials" class="testimonials-section ${getSectionStyle(designStyle)}">
        <div class="container mx-auto px-4">
            <div class="text-center mb-16">
                <h2 class="section-title">What Our Clients Say</h2>
                <p class="section-subtitle">Testimonials from our valued ${targetAudience.toLowerCase()}</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                ${testimonials.map((testimonial, index) => `
                <div class="testimonial-card ${getTestimonialCardStyle(designStyle)}">
                    <div class="testimonial-header">
                        <img src="https://via.placeholder.com/60" alt="${testimonial.name}" class="client-photo">
                        <div class="client-info">
                            <div class="client-name">${testimonial.name}</div>
                            <div class="client-title">${testimonial.title}</div>
                        </div>
                    </div>
                    <div class="testimonial-content">
                        <p>"${testimonial.content}"</p>
                    </div>
                    <div class="testimonial-rating">
                        ${generateStarRating(testimonial.rating)}
                    </div>
                </div>
                `).join('')}
            </div>
        </div>
    </section>
    ` : ''}

    ${hasContact ? `
    <section id="contact" class="contact-section ${getAlternateSectionStyle(designStyle)}">
        <div class="container mx-auto px-4">
            <div class="text-center mb-16">
                <h2 class="section-title">Contact Us</h2>
                <p class="section-subtitle">Get in touch with our team</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-12">
                <div>
                    <form class="contact-form">
                        <div class="form-group">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" id="name" name="name" required class="form-input">
                        </div>
                        <div class="form-group">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" id="email" name="email" required class="form-input">
                        </div>
                        <div class="form-group">
                            <label for="message" class="form-label">Message</label>
                            <textarea id="message" name="message" rows="5" required class="form-textarea"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary ${getPrimaryButtonStyle(colorScheme)} w-full">Send Message</button>
                    </form>
                </div>
                <div class="contact-info">
                    <h3 class="contact-title">Get In Touch</h3>
                    <div class="contact-item">
                        <i class="fas fa-map-marker-alt contact-icon ${getContactIconStyle(colorScheme)}"></i>
                        <span>123 Business Street, Suite 100, City, State 12345</span>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-phone contact-icon ${getContactIconStyle(colorScheme)}"></i>
                        <span>+1 (555) 123-4567</span>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-envelope contact-icon ${getContactIconStyle(colorScheme)}"></i>
                        <span>info@${prompt.toLowerCase().replace(/\s+/g, '')}.com</span>
                    </div>
                    <div class="social-links">
                        <a href="#" class="social-link ${getSocialLinkStyle(colorScheme)}"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="social-link ${getSocialLinkStyle(colorScheme)}"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-link ${getSocialLinkStyle(colorScheme)}"><i class="fab fa-linkedin"></i></a>
                        <a href="#" class="social-link ${getSocialLinkStyle(colorScheme)}"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    ` : ''}

    ${hasFooter ? `
    <footer class="footer ${getFooterStyle(designStyle, colorScheme)}">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                    <h3 class="footer-title">${title}</h3>
                    <p class="footer-description">${analysis.creativeDirection}</p>
                </div>
                <div>
                    <h4 class="footer-heading">Quick Links</h4>
                    <ul class="footer-links">
                        <li><a href="#home" class="footer-link">Home</a></li>
                        <li><a href="#services" class="footer-link">Services</a></li>
                        ${hasAbout ? '<li><a href="#about" class="footer-link">About</a></li>' : ''}
                        <li><a href="#contact" class="footer-link">Contact</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="footer-heading">Services</h4>
                    <ul class="footer-links">
                        ${serviceItems.slice(0, 4).map(service => `<li><a href="#" class="footer-link">${service.title}</a></li>`).join('')}
                    </ul>
                </div>
                <div>
                    <h4 class="footer-heading">Follow Us</h4>
                    <div class="footer-social">
                        <a href="#" class="footer-social-link ${getSocialLinkStyle(colorScheme)}"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="footer-social-link ${getSocialLinkStyle(colorScheme)}"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="footer-social-link ${getSocialLinkStyle(colorScheme)}"><i class="fab fa-linkedin"></i></a>
                        <a href="#" class="footer-social-link ${getSocialLinkStyle(colorScheme)}"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 ${title}. All rights reserved.</p>
            </div>
        </div>
    </footer>
    ` : ''}

    ${hasBackToTop ? `
    <button id="backToTop" class="back-to-top ${getBackToTopStyle(colorScheme)}">
        <i class="fas fa-arrow-up"></i>
    </button>
    ` : ''}
</body>
</html>`

  const cssContent = `/* Intelligent CSS for ${title} - ${designStyle} */

/* CSS Variables for Dynamic Theming */
:root {
  --primary-color: ${getPrimaryColor(colorScheme)};
  --secondary-color: ${getSecondaryColor(colorScheme)};
  --accent-color: ${getAccentColor(colorScheme)};
  --text-primary: ${getTextPrimaryColor(colorScheme)};
  --text-secondary: ${getTextSecondaryColor(colorScheme)};
  --background-primary: ${getBackgroundPrimaryColor(colorScheme)};
  --background-secondary: ${getBackgroundSecondaryColor(colorScheme)};
  --border-color: ${getBorderColor(colorScheme)};
}

/* Global Styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  line-height: 1.6;
  color: var(--text-primary);
  background-color: var(--background-primary);
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1rem;
}

/* Navigation Styles */
.navbar {
  ${getNavbarStyle(designStyle)}
  position: fixed;
  top: 0;
  width: 100%;
  z-index: 1000;
  backdrop-filter: blur(10px);
  transition: all 0.3s ease;
}

.nav-link {
  color: var(--text-primary);
  text-decoration: none;
  font-weight: 500;
  padding: 0.5rem 1rem;
  border-radius: 0.375rem;
  transition: all 0.3s ease;
}

.nav-link:hover {
  color: var(--primary-color);
  background-color: rgba(255, 255, 255, 0.1);
}

.search-input {
  padding: 0.5rem 1rem;
  border: 1px solid var(--border-color);
  border-radius: 0.5rem;
  background-color: var(--background-secondary);
  color: var(--text-primary);
  transition: all 0.3s ease;
}

.search-input:focus {
  outline: none;
  border-color: var(--primary-color);
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

/* Hero Section */
.hero-section {
  ${getHeroStyle(designStyle, colorScheme)}
  min-height: 100vh;
  display: flex;
  align-items: center;
  position: relative;
  overflow: hidden;
}

.hero-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(135deg, rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.5));
  z-index: 1;
}

.hero-content {
  position: relative;
  z-index: 2;
  text-align: center;
  animation: fadeInUp 1s ease-out;
}

.hero-title {
  font-size: clamp(2.5rem, 8vw, 4.5rem);
  font-weight: 800;
  margin-bottom: 1.5rem;
  background: linear-gradient(135deg, #ffffff, #f3f4f6);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.hero-subtitle {
  font-size: 1.5rem;
  font-weight: 300;
  margin-bottom: 2rem;
  opacity: 0.9;
}

.hero-buttons {
  display: flex;
  gap: 1rem;
  justify-content: center;
  flex-wrap: wrap;
}

.btn {
  padding: 0.75rem 2rem;
  border-radius: 0.5rem;
  font-weight: 600;
  text-decoration: none;
  transition: all 0.3s ease;
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
}

.btn-primary {
  background-color: var(--primary-color);
  color: white;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3);
}

.btn-secondary {
  background-color: transparent;
  color: white;
  border: 2px solid white;
}

.btn-secondary:hover {
  background-color: white;
  color: var(--primary-color);
}

/* Section Styles */
.services-section,
.testimonials-section {
  padding: 5rem 0;
  background-color: var(--background-primary);
}

.about-section,
.contact-section {
  padding: 5rem 0;
  background-color: var(--background-secondary);
}

.section-title {
  font-size: 3rem;
  font-weight: 700;
  margin-bottom: 1rem;
  text-align: center;
  color: var(--text-primary);
}

.section-subtitle {
  font-size: 1.25rem;
  text-align: center;
  color: var(--text-secondary);
  max-width: 600px;
  margin: 0 auto;
}

/* Service Cards */
.service-card {
  background: var(--background-secondary);
  border-radius: 1rem;
  padding: 2rem;
  text-align: center;
  transition: all 0.3s ease;
  border: 1px solid var(--border-color);
}

.service-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.service-icon {
  width: 60px;
  height: 60px;
  margin: 0 auto 1.5rem;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5rem;
}

.service-title {
  font-size: 1.5rem;
  font-weight: 600;
  margin-bottom: 1rem;
  color: var(--text-primary);
}

.service-description {
  color: var(--text-secondary);
  line-height: 1.6;
}

/* About Section */
.about-content {
  margin-bottom: 2rem;
}

.about-paragraph {
  margin-bottom: 1rem;
  color: var(--text-secondary);
  line-height: 1.8;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 2rem;
  margin-top: 2rem;
}

.stat-item {
  text-align: center;
}

.stat-number {
  font-size: 3rem;
  font-weight: 700;
  margin-bottom: 0.5rem;
}

.stat-label {
  color: var(--text-secondary);
  font-weight: 500;
}

/* Testimonials */
.testimonial-card {
  background: var(--background-secondary);
  border-radius: 1rem;
  padding: 2rem;
  border: 1px solid var(--border-color);
  transition: all 0.3s ease;
}

.testimonial-card:hover {
  transform: scale(1.02);
}

.testimonial-header {
  display: flex;
  align-items: center;
  margin-bottom: 1rem;
}

.client-photo {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  margin-right: 1rem;
}

.client-name {
  font-weight: 600;
  color: var(--text-primary);
}

.client-title {
  font-size: 0.875rem;
  color: var(--text-secondary);
}

.testimonial-content {
  margin-bottom: 1rem;
  color: var(--text-secondary);
  font-style: italic;
}

.testimonial-rating {
  color: #fbbf24;
}

/* Contact Form */
.contact-form {
  background: var(--background-secondary);
  padding: 2rem;
  border-radius: 1rem;
  border: 1px solid var(--border-color);
}

.form-group {
  margin-bottom: 1.5rem;
}

.form-label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 500;
  color: var(--text-primary);
}

.form-input,
.form-textarea {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid var(--border-color);
  border-radius: 0.5rem;
  background-color: var(--background-primary);
  color: var(--text-primary);
  transition: all 0.3s ease;
}

.form-input:focus,
.form-textarea:focus {
  outline: none;
  border-color: var(--primary-color);
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

.contact-info {
  padding: 2rem;
}

.contact-title {
  font-size: 2rem;
  font-weight: 600;
  margin-bottom: 2rem;
  color: var(--text-primary);
}

.contact-item {
  display: flex;
  align-items: center;
  margin-bottom: 1.5rem;
  color: var(--text-secondary);
}

.contact-icon {
  margin-right: 1rem;
  font-size: 1.25rem;
}

.social-links {
  display: flex;
  gap: 1rem;
  margin-top: 2rem;
}

.social-link {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-secondary);
  border: 1px solid var(--border-color);
  transition: all 0.3s ease;
}

.social-link:hover {
  color: var(--primary-color);
  border-color: var(--primary-color);
}

/* Footer */
.footer {
  background-color: #1f2937;
  color: white;
  padding: 3rem 0 1rem;
}

.footer-title {
  font-size: 1.5rem;
  font-weight: 700;
  margin-bottom: 1rem;
}

.footer-description {
  color: #9ca3af;
  margin-bottom: 1rem;
}

.footer-heading {
  font-size: 1.125rem;
  font-weight: 600;
  margin-bottom: 1rem;
  color: white;
}

.footer-links {
  list-style: none;
}

.footer-link {
  color: #9ca3af;
  text-decoration: none;
  display: block;
  padding: 0.25rem 0;
  transition: color 0.3s ease;
}

.footer-link:hover {
  color: white;
}

.footer-social {
  display: flex;
  gap: 1rem;
}

.footer-social-link {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background-color: #374151;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #9ca3af;
  transition: all 0.3s ease;
}

.footer-social-link:hover {
  background-color: var(--primary-color);
  color: white;
}

.footer-bottom {
  border-top: 1px solid #374151;
  margin-top: 2rem;
  padding-top: 1rem;
  text-align: center;
  color: #9ca3af;
}

/* Back to Top Button */
.back-to-top {
  position: fixed;
  bottom: 2rem;
  right: 2rem;
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: var(--primary-color);
  color: white;
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  visibility: hidden;
  transition: all 0.3s ease;
  z-index: 1000;
}

.back-to-top.visible {
  opacity: 1;
  visibility: visible;
}

.back-to-top:hover {
  transform: translateY(-3px);
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
}

/* Animations */
@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

/* Responsive Design */
@media (max-width: 768px) {
  .hero-title {
    font-size: 2.5rem;
  }
  
  .hero-subtitle {
    font-size: 1.25rem;
  }
  
  .section-title {
    font-size: 2rem;
  }
  
  .stats-grid {
    grid-template-columns: 1fr;
  }
  
  .hero-buttons {
    flex-direction: column;
    align-items: center;
  }
  
  .btn {
    width: 100%;
    max-width: 300px;
  }
}

/* Smooth Scrolling */
html {
  scroll-behavior: smooth;
}

/* Custom Scrollbar */
::-webkit-scrollbar {
  width: 8px;
}

::-webkit-scrollbar-track {
  background: var(--background-secondary);
}

::-webkit-scrollbar-thumb {
  background: var(--primary-color);
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: var(--accent-color);
}`

  const jsContent = `// Intelligent JavaScript for ${title} - ${analysis.analysis}

document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 ${title} initialized successfully');
    console.log('📊 Analysis:', '${analysis.analysis}');
    console.log('🎯 Target Audience:', '${targetAudience}');
    console.log('🎨 Design Style:', '${designStyle}');
    
    // Initialize all intelligent features
    initializeIntelligentNavigation();
    initializeHeroAnimations();
    initializeServiceInteractions();
    initializeTestimonialSlider();
    initializeContactForm();
    initializeScrollEffects();
    initializePerformanceOptimizations();
    
    console.log('✅ All intelligent features initialized');
});

// Intelligent Navigation System
function initializeIntelligentNavigation() {
    const nav = document.querySelector('.navbar');
    const navLinks = document.querySelectorAll('.nav-link');
    const mobileMenuButton = document.querySelector('.mobile-menu-button');
    const mobileMenu = document.querySelector('.mobile-menu');
    
    // Smart scroll-based navigation hiding/showing
    let lastScroll = 0;
    let scrollTimeout;
    
    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset;
        
        // Show/hide navigation based on scroll direction
        if (currentScroll > lastScroll && currentScroll > 100) {
            nav.style.transform = 'translateY(-100%)';
        } else {
            nav.style.transform = 'translateY(0)';
        }
        
        lastScroll = currentScroll;
        
        // Clear timeout and set new one
        clearTimeout(scrollTimeout);
        scrollTimeout = setTimeout(() => {
            nav.style.transform = 'translateY(0)';
        }, 150);
    });
    
    // Smooth scrolling for navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                const offsetTop = targetSection.offsetTop - 80;
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Active navigation highlighting
    const sections = document.querySelectorAll('section[id]');
    const observerOptions = {
        threshold: 0.3,
        rootMargin: '-80px 0px -70% 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const sectionId = entry.target.getAttribute('id');
                navLinks.forEach(link => {
                    link.classList.remove('text-blue-600', 'font-semibold');
                    if (link.getAttribute('href') === '#' + sectionId) {
                        link.classList.add('text-blue-600', 'font-semibold');
                    }
                });
            }
        });
    }, observerOptions);
    
    sections.forEach(section => observer.observe(section));
    
    // Mobile menu toggle
    if (mobileMenuButton && mobileMenu) {
        mobileMenuButton.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
        });
    }
}

// Hero Section Animations
function initializeHeroAnimations() {
    const heroContent = document.querySelector('.hero-content');
    const heroTitle = document.querySelector('.hero-title');
    const heroSubtitle = document.querySelector('.hero-subtitle');
    const heroButtons = document.querySelector('.hero-buttons');
    
    if (heroContent) {
        // Staggered animation for hero elements
        heroContent.style.opacity = '0';
        heroContent.style.transform = 'translateY(50px)';
        
        setTimeout(() => {
            heroContent.style.transition = 'all 1s cubic-bezier(0.4, 0, 0.2, 1)';
            heroContent.style.opacity = '1';
            heroContent.style.transform = 'translateY(0)';
        }, 100);
        
        // Animate title letters individually
        if (heroTitle) {
            const titleText = heroTitle.textContent;
            heroTitle.innerHTML = '';
            
            [...titleText].forEach((letter, index) => {
                const span = document.createElement('span');
                span.textContent = letter === ' ' ? '\\u00A0' : letter;
                span.style.opacity = '0';
                span.style.transform = 'translateY(20px)';
                span.style.display = 'inline-block';
                heroTitle.appendChild(span);
                
                setTimeout(() => {
                    span.style.transition = 'all 0.5s ease';
                    span.style.opacity = '1';
                    span.style.transform = 'translateY(0)';
                }, index * 50);
            });
        }
        
        // Animate subtitle
        if (heroSubtitle) {
            heroSubtitle.style.opacity = '0';
            heroSubtitle.style.transform = 'translateY(30px)';
            
            setTimeout(() => {
                heroSubtitle.style.transition = 'all 0.8s ease 0.5s';
                heroSubtitle.style.opacity = '1';
                heroSubtitle.style.transform = 'translateY(0)';
            }, 500);
        }
        
        // Animate buttons
        if (heroButtons) {
            heroButtons.style.opacity = '0';
            heroButtons.style.transform = 'translateY(30px)';
            
            setTimeout(() => {
                heroButtons.style.transition = 'all 0.8s ease 1s';
                heroButtons.style.opacity = '1';
                heroButtons.style.transform = 'translateY(0)';
            }, 1000);
        }
    }
    
    // Parallax effect for hero section
    const heroSection = document.querySelector('.hero-section');
    if (heroSection) {
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const parallax = scrolled * 0.5;
            heroSection.style.transform = \`translateY(\${parallax}px)\`;
        });
    }
}

// Service Cards Interactions
function initializeServiceInteractions() {
    const serviceCards = document.querySelectorAll('.service-card');
    
    serviceCards.forEach((card, index) => {
        // Staggered entrance animation
        card.style.opacity = '0';
        card.style.transform = 'translateY(50px)';
        
        setTimeout(() => {
            card.style.transition = 'all 0.6s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
        
        // Interactive hover effects
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px) scale(1.02)';
            this.style.boxShadow = '0 20px 40px rgba(0, 0, 0, 0.15)';
            
            // Animate icon
            const icon = this.querySelector('.service-icon');
            if (icon) {
                icon.style.transform = 'scale(1.1) rotate(5deg)';
            }
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
            this.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.1)';
            
            // Reset icon
            const icon = this.querySelector('.service-icon');
            if (icon) {
                icon.style.transform = 'scale(1) rotate(0deg)';
            }
        });
        
        // Click interaction
        card.addEventListener('click', function() {
            // Add ripple effect
            const ripple = document.createElement('div');
            ripple.style.position = 'absolute';
            ripple.style.borderRadius = '50%';
            ripple.style.background = 'rgba(255, 255, 255, 0.6)';
            ripple.style.transform = 'scale(0)';
            ripple.style.animation = 'ripple 0.6s linear';
            ripple.style.left = '50%';
            ripple.style.top = '50%';
            ripple.style.width = '20px';
            ripple.style.height = '20px';
            ripple.style.marginLeft = '-10px';
            ripple.style.marginTop = '-10px';
            
            this.style.position = 'relative';
            this.style.overflow = 'hidden';
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });
    
    // Intersection Observer for scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    serviceCards.forEach(card => observer.observe(card));
}

// Testimonial Slider
function initializeTestimonialSlider() {
    const testimonials = document.querySelectorAll('.testimonial-card');
    let currentIndex = 0;
    let autoplayInterval;
    
    function showTestimonial(index) {
        testimonials.forEach((testimonial, i) => {
            testimonial.style.opacity = i === index ? '1' : '0.7';
            testimonial.style.transform = i === index ? 'scale(1)' : 'scale(0.95)';
            testimonial.style.transition = 'all 0.5s ease';
        });
    }
    
    function nextTestimonial() {
        currentIndex = (currentIndex + 1) % testimonials.length;
        showTestimonial(currentIndex);
    }
    
    function startAutoplay() {
        autoplayInterval = setInterval(nextTestimonial, 5000);
    }
    
    function stopAutoplay() {
        clearInterval(autoplayInterval);
    }
    
    // Initialize
    if (testimonials.length > 0) {
        showTestimonial(0);
        startAutoplay();
        
        // Pause on hover
        testimonials.forEach(testimonial => {
            testimonial.addEventListener('mouseenter', stopAutoplay);
            testimonial.addEventListener('mouseleave', startAutoplay);
        });
    }
}

// Contact Form Enhancement
function initializeContactForm() {
    const contactForm = document.querySelector('.contact-form');
    const formInputs = contactForm?.querySelectorAll('input, textarea');
    
    if (contactForm) {
        // Enhanced form validation
        contactForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const name = formData.get('name');
            const email = formData.get('email');
            const message = formData.get('message');
            
            // Validation
            if (!name || !email || !message) {
                showNotification('Please fill in all fields', 'error');
                return;
            }
            
            if (!isValidEmail(email)) {
                showNotification('Please enter a valid email address', 'error');
                return;
            }
            
            // Simulate form submission
            const submitButton = this.querySelector('button[type="submit"]');
            const originalText = submitButton.textContent;
            
            submitButton.textContent = 'Sending...';
            submitButton.disabled = true;
            
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            showNotification('Thank you for your message! We\\'ll get back to you soon.', 'success');
            this.reset();
            submitButton.textContent = originalText;
            submitButton.disabled = false;
        });
        
        // Real-time validation feedback
        formInputs?.forEach(input => {
            input.addEventListener('blur', function() {
                validateField(this);
            });
            
            input.addEventListener('input', function() {
                if (this.classList.contains('error')) {
                    validateField(this);
                }
            });
        });
    }
}

// Scroll Effects and Animations
function initializeScrollEffects() {
    const backToTopButton = document.getElementById('backToTop');
    const animatedElements = document.querySelectorAll('.service-card, .testimonial-card, .about-image');
    
    // Back to top button
    if (backToTopButton) {
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                backToTopButton.classList.add('visible');
            } else {
                backToTopButton.classList.remove('visible');
            }
        });
        
        backToTopButton.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
    
    // Scroll animations for elements
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    animatedElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(30px)';
        element.style.transition = 'all 0.6s ease';
        observer.observe(element);
    });
}

// Performance Optimizations
function initializePerformanceOptimizations() {
    // Lazy loading for images
    const images = document.querySelectorAll('img');
    const imageOptions = {
        threshold: 0.1,
        rootMargin: '50px'
    };
    
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src || img.src;
                img.classList.add('loaded');
                imageObserver.unobserve(img);
            }
        });
    }, imageOptions);
    
    images.forEach(img => imageObserver.observe(img));
    
    // Debounce scroll events
    let scrollTimeout;
    window.addEventListener('scroll', () => {
        if (scrollTimeout) {
            window.cancelAnimationFrame(scrollTimeout);
        }
        scrollTimeout = window.requestAnimationFrame(() => {
            // Handle scroll events
        });
    });
    
    // Optimize animations
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (prefersReducedMotion.matches) {
        document.body.classList.add('reduce-motion');
    }
}

// Utility Functions
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function validateField(field) {
    const value = field.value.trim();
    let isValid = true;
    
    if (field.type === 'email') {
        isValid = isValidEmail(value);
    } else if (field.required) {
        isValid = value.length > 0;
    }
    
    if (isValid) {
        field.classList.remove('error');
        field.classList.add('success');
    } else {
        field.classList.remove('success');
        field.classList.add('error');
    }
    
    return isValid;
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = \`notification \${type}\`;
    notification.textContent = message;
    
    Object.assign(notification.style, {
        position: 'fixed',
        top: '20px',
        right: '20px',
        padding: '1rem 1.5rem',
        borderRadius: '0.5rem',
        color: 'white',
        fontWeight: '500',
        zIndex: '10000',
        opacity: '0',
        transform: 'translateX(100%)',
        transition: 'all 0.3s ease'
    });
    
    // Set background color based on type
    const colors = {
        success: '#10b981',
        error: '#ef4444',
        info: '#3b82f6'
    };
    notification.style.backgroundColor = colors[type] || colors.info;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.opacity = '1';
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Animate out and remove
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

// Add ripple effect CSS
const style = document.createElement('style');
style.textContent = \`
    @keyframes ripple {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
    
    .notification {
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
    
    .reduce-motion * {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
    }
    
    .form-input.error,
    .form-textarea.error {
        border-color: #ef4444 !important;
    }
    
    .form-input.success,
    .form-textarea.success {
        border-color: #10b981 !important;
    }
    
    img.loaded {
        opacity: 1;
        transition: opacity 0.3s ease;
    }
\`;
document.head.appendChild(style);

// Export for external use
window.${prompt.toLowerCase().replace(/\s+/g, '')}App = {
    initializeIntelligentNavigation,
    initializeHeroAnimations,
    initializeServiceInteractions,
    initializeTestimonialSlider,
    initializeContactForm,
    initializeScrollEffects,
    initializePerformanceOptimizations
};

console.log('🎯 ${title} intelligent application loaded successfully');`

  return [
    {
      name: 'index.html',
      content: htmlContent,
      language: 'html'
    },
    {
      name: 'styles.css',
      content: cssContent,
      language: 'css'
    },
    {
      name: 'script.js',
      content: jsContent,
      language: 'javascript'
    }
  ]
}

// Helper functions for intelligent content generation
function generateHeroHeadline(prompt: string, analysis: any) {
  const promptLower = prompt.toLowerCase()
  
  if (promptLower.includes('business') || promptLower.includes('corporate')) {
    return 'Elevate Your Business to New Heights'
  } else if (promptLower.includes('portfolio') || promptLower.includes('creative')) {
    return 'Showcase Your Creative Vision'
  } else if (promptLower.includes('shop') || promptLower.includes('store')) {
    return 'Discover Amazing Products'
  } else if (promptLower.includes('restaurant') || promptLower.includes('cafe')) {
    return 'Experience Culinary Excellence'
  } else if (promptLower.includes('tech') || promptLower.includes('startup')) {
    return 'Innovation Meets Excellence'
  } else {
    return 'Welcome to Excellence'
  }
}

function generateHeroSubheadline(prompt: string, analysis: any) {
  const promptLower = prompt.toLowerCase()
  
  if (promptLower.includes('business') || promptLower.includes('corporate')) {
    return 'Professional solutions tailored to drive your success forward'
  } else if (promptLower.includes('portfolio') || promptLower.includes('creative')) {
    return 'Where creativity meets professionalism in perfect harmony'
  } else if (promptLower.includes('shop') || promptLower.includes('store')) {
    return 'Curated products that inspire and delight'
  } else if (promptLower.includes('restaurant') || promptLower.includes('cafe')) {
    return 'Exceptional cuisine crafted with passion and expertise'
  } else if (promptLower.includes('tech') || promptLower.includes('startup')) {
    return 'Cutting-edge solutions for tomorrow\'s challenges'
  } else {
    return analysis.creativeDirection
  }
}

function generateServiceItems(prompt: string, analysis: any) {
  const promptLower = prompt.toLowerCase()
  
  if (promptLower.includes('business') || promptLower.includes('corporate')) {
    return [
      { icon: 'fas fa-strategy', title: 'Strategic Planning', description: 'Comprehensive business strategies for sustainable growth' },
      { icon: 'fas fa-chart-line', title: 'Market Analysis', description: 'In-depth market research and competitive analysis' },
      { icon: 'fas fa-users', title: 'Team Building', description: 'Professional team development and training programs' }
    ]
  } else if (promptLower.includes('portfolio') || promptLower.includes('creative')) {
    return [
      { icon: 'fas fa-palette', title: 'Creative Design', description: 'Innovative design solutions that capture attention' },
      { icon: 'fas fa-camera', title: 'Photography', description: 'Professional photography services for all occasions' },
      { icon: 'fas fa-video', title: 'Video Production', description: 'High-quality video content for your brand' }
    ]
  } else if (promptLower.includes('shop') || promptLower.includes('store')) {
    return [
      { icon: 'fas fa-box', title: 'Quality Products', description: 'Carefully curated selection of premium products' },
      { icon: 'fas fa-shipping-fast', title: 'Fast Delivery', description: 'Quick and reliable shipping worldwide' },
      { icon: 'fas fa-shield-alt', title: 'Secure Shopping', description: 'Safe and secure online shopping experience' }
    ]
  } else if (promptLower.includes('restaurant') || promptLower.includes('cafe')) {
    return [
      { icon: 'fas fa-utensils', title: 'Fine Dining', description: 'Exceptional culinary experiences crafted by expert chefs' },
      { icon: 'fas fa-coffee', title: 'Specialty Coffee', description: 'Premium coffee blends and artisanal brewing methods' },
      { icon: 'fas fa-wine-glass', title: 'Wine Selection', description: 'Carefully curated wine list from around the world' }
    ]
  } else if (promptLower.includes('tech') || promptLower.includes('startup')) {
    return [
      { icon: 'fas fa-code', title: 'Development', description: 'Cutting-edge software development solutions' },
      { icon: 'fas fa-mobile-alt', title: 'Mobile Apps', description: 'Native and cross-platform mobile applications' },
      { icon: 'fas fa-cloud', title: 'Cloud Solutions', description: 'Scalable cloud infrastructure and services' }
    ]
  } else {
    return [
      { icon: 'fas fa-star', title: 'Premium Service', description: 'Exceptional service quality and attention to detail' },
      { icon: 'fas fa-heart', title: 'Customer Focus', description: 'Customer-centric approach to every project' },
      { icon: 'fas fa-rocket', title: 'Innovation', description: 'Innovative solutions for modern challenges' }
    ]
  }
}

function generateAboutContent(prompt: string, analysis: any) {
  const promptLower = prompt.toLowerCase()
  
  if (promptLower.includes('business') || promptLower.includes('corporate')) {
    return [
      'We are a team of dedicated professionals committed to delivering exceptional business solutions. With years of experience in the industry, we understand the challenges businesses face and provide strategies that drive real results.',
      'Our approach combines innovative thinking with practical execution, ensuring that our clients not only reach their goals but exceed them. We believe in building long-term partnerships based on trust, transparency, and mutual success.'
    ]
  } else if (promptLower.includes('portfolio') || promptLower.includes('creative')) {
    return [
      'Creativity is at the heart of everything we do. We are passionate about bringing ideas to life through innovative design and artistic expression. Our team of creative professionals combines artistic vision with technical expertise.',
      'Every project we undertake is an opportunity to push boundaries and create something truly unique. We work closely with our clients to understand their vision and transform it into reality.'
    ]
  } else if (promptLower.includes('restaurant') || promptLower.includes('cafe')) {
    return [
      'Culinary excellence is our passion. Our chef-led team brings years of experience from some of the world\'s finest kitchens, creating dishes that celebrate local ingredients and international flavors.',
      'We believe that dining is more than just food – it\'s an experience. From the carefully curated ambiance to the exceptional service, every detail is designed to create memorable moments for our guests.'
    ]
  } else if (promptLower.includes('tech') || promptLower.includes('startup')) {
    return [
      'We are at the forefront of technological innovation, developing solutions that address the complex challenges of today\'s digital landscape. Our team of engineers and designers combines technical expertise with creative problem-solving.',
      'Innovation drives everything we do. We stay ahead of industry trends and emerging technologies to provide our clients with cutting-edge solutions that give them a competitive advantage.'
    ]
  } else {
    return [
      'Excellence is not just a goal – it\'s our standard. We are committed to delivering the highest quality products and services to our clients, ensuring that every project exceeds expectations.',
      'Our success is built on a foundation of integrity, professionalism, and customer satisfaction. We take pride in what we do and are dedicated to building long-term relationships with our clients.'
    ]
  }
}

function generateTestimonials(prompt: string, analysis: any) {
  return [
    {
      name: 'Sarah Johnson',
      title: 'CEO, TechCorp',
      content: 'Exceptional service and outstanding results. The team exceeded our expectations at every turn.',
      rating: 5
    },
    {
      name: 'Michael Chen',
      title: 'Marketing Director',
      content: 'Professional, reliable, and innovative. They delivered exactly what we needed, on time and within budget.',
      rating: 5
    },
    {
      name: 'Emily Rodriguez',
      title: 'Startup Founder',
      content: 'Working with this team was a game-changer for our business. Their expertise and dedication are unmatched.',
      rating: 5
    }
  ]
}

function generateStarRating(rating: number) {
  return Array(5).fill(0).map((_, i) => 
    `<i class="fas fa-star ${i < rating ? 'text-yellow-400' : 'text-gray-300'}"></i>`
  ).join('')
}

// Style helper functions
function getNavbarStyle(designStyle: string) {
  const styles = {
    'Modern tech': 'bg-gray-900 bg-opacity-95 backdrop-blur-sm border-b border-gray-800',
    'Corporate modern': 'bg-white shadow-lg border-b border-gray-200',
    'Warm and inviting': 'bg-amber-50 shadow-md border-b border-amber-200',
    'Clean retail': 'bg-white shadow-sm border-b border-gray-100',
    'Modern creative': 'bg-gradient-to-r from-purple-900 to-blue-900 bg-opacity-95 backdrop-blur-sm'
  }
  return styles[designStyle as keyof typeof styles] || styles['Modern tech']
}

function getHeroStyle(designStyle: string, colorScheme: string) {
  const styles = {
    'Modern tech': 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900',
    'Corporate modern': 'bg-gradient-to-br from-blue-600 to-blue-800',
    'Warm and inviting': 'bg-gradient-to-br from-amber-600 to-orange-700',
    'Clean retail': 'bg-gradient-to-br from-gray-100 to-white',
    'Modern creative': 'bg-gradient-to-br from-purple-600 via-pink-600 to-blue-600'
  }
  return styles[designStyle as keyof typeof styles] || styles['Modern tech']
}

function getPrimaryColor(colorScheme: string) {
  const colors = {
    'Blue, gray, and white': '#3b82f6',
    'Vibrant colors with dark backgrounds': '#8b5cf6',
    'Trust-building colors': '#059669',
    'Warm colors like reds, oranges': '#dc2626',
    'Modern tech colors': '#6366f1'
  }
  return colors[colorScheme as keyof typeof colors] || '#3b82f6'
}

function getSecondaryColor(colorScheme: string) {
  const colors = {
    'Blue, gray, and white': '#64748b',
    'Vibrant colors with dark backgrounds': '#a855f7',
    'Trust-building colors': '#047857',
    'Warm colors like reds, oranges': '#ea580c',
    'Modern tech colors': '#8b5cf6'
  }
  return colors[colorScheme as keyof typeof colors] || '#64748b'
}

function getAccentColor(colorScheme: string) {
  const colors = {
    'Blue, gray, and white': '#f59e0b',
    'Vibrant colors with dark backgrounds': '#ec4899',
    'Trust-building colors': '#10b981',
    'Warm colors like reds, oranges': '#f97316',
    'Modern tech colors': '#06b6d4'
  }
  return colors[colorScheme as keyof typeof colors] || '#f59e0b'
}

function getTextPrimaryColor(colorScheme: string) {
  const colors = {
    'Blue, gray, and white': '#1f2937',
    'Vibrant colors with dark backgrounds': '#f9fafb',
    'Trust-building colors': '#064e3b',
    'Warm colors like reds, oranges': '#7c2d12',
    'Modern tech colors': '#1e1b4b'
  }
  return colors[colorScheme as keyof typeof colors] || '#1f2937'
}

function getTextSecondaryColor(colorScheme: string) {
  const colors = {
    'Blue, gray, and white': '#6b7280',
    'Vibrant colors with dark backgrounds': '#d1d5db',
    'Trust-building colors': '#047857',
    'Warm colors like reds, oranges': '#9a3412',
    'Modern tech colors': '#4c1d95'
  }
  return colors[colorScheme as keyof typeof colors] || '#6b7280'
}

function getBackgroundPrimaryColor(colorScheme: string) {
  const colors = {
    'Blue, gray, and white': '#ffffff',
    'Vibrant colors with dark backgrounds': '#111827',
    'Trust-building colors': '#f0fdf4',
    'Warm colors like reds, oranges': '#fff7ed',
    'Modern tech colors': '#eef2ff'
  }
  return colors[colorScheme as keyof typeof colors] || '#ffffff'
}

function getBackgroundSecondaryColor(colorScheme: string) {
  const colors = {
    'Blue, gray, and white': '#f9fafb',
    'Vibrant colors with dark backgrounds': '#1f2937',
    'Trust-building colors': '#dcfce7',
    'Warm colors like reds, oranges': '#ffedd5',
    'Modern tech colors': '#ddd6fe'
  }
  return colors[colorScheme as keyof typeof colors] || '#f9fafb'
}

function getBorderColor(colorScheme: string) {
  const colors = {
    'Blue, gray, and white': '#e5e7eb',
    'Vibrant colors with dark backgrounds': '#374151',
    'Trust-building colors': '#bbf7d0',
    'Warm colors like reds, oranges': '#fed7aa',
    'Modern tech colors': '#c4b5fd'
  }
  return colors[colorScheme as keyof typeof colors] || '#e5e7eb'
}

// Additional style helper functions
function getBrandColor(colorScheme: string) {
  const colors = {
    'Blue, gray, and white': 'text-blue-600',
    'Vibrant colors with dark backgrounds': 'text-purple-400',
    'Trust-building colors': 'text-emerald-600',
    'Warm colors like reds, oranges': 'text-orange-600',
    'Modern tech colors': 'text-indigo-600'
  }
  return colors[colorScheme as keyof typeof colors] || 'text-blue-600'
}

function getNavLinkColor(colorScheme: string) {
  const colors = {
    'Blue, gray, and white': 'text-gray-600 hover:text-blue-600',
    'Vibrant colors with dark backgrounds': 'text-gray-300 hover:text-purple-400',
    'Trust-building colors': 'text-gray-600 hover:text-emerald-600',
    'Warm colors like reds, oranges': 'text-gray-600 hover:text-orange-600',
    'Modern tech colors': 'text-gray-600 hover:text-indigo-600'
  }
  return colors[colorScheme as keyof typeof colors] || 'text-gray-600 hover:text-blue-600'
}

function getPrimaryButtonStyle(colorScheme: string) {
  const colors = {
    'Blue, gray, and white': 'bg-blue-600 hover:bg-blue-700',
    'Vibrant colors with dark backgrounds': 'bg-purple-600 hover:bg-purple-700',
    'Trust-building colors': 'bg-emerald-600 hover:bg-emerald-700',
    'Warm colors like reds, oranges': 'bg-orange-600 hover:bg-orange-700',
    'Modern tech colors': 'bg-indigo-600 hover:bg-indigo-700'
  }
  return colors[colorScheme as keyof typeof colors] || 'bg-blue-600 hover:bg-blue-700'
}

function getSecondaryButtonStyle(colorScheme: string) {
  const colors = {
    'Blue, gray, and white': 'border-blue-600 text-blue-600 hover:bg-blue-600',
    'Vibrant colors with dark backgrounds': 'border-purple-400 text-purple-400 hover:bg-purple-400',
    'Trust-building colors': 'border-emerald-600 text-emerald-600 hover:bg-emerald-600',
    'Warm colors like reds, oranges': 'border-orange-600 text-orange-600 hover:bg-orange-600',
    'Modern tech colors': 'border-indigo-600 text-indigo-600 hover:bg-indigo-600'
  }
  return colors[colorScheme as keyof typeof colors] || 'border-blue-600 text-blue-600 hover:bg-blue-600'
}

function getSectionStyle(designStyle: string) {
  return ''
}

function getAlternateSectionStyle(designStyle: string) {
  return ''
}

function getServiceCardStyle(designStyle: string) {
  return ''
}

function getServiceIconStyle(colorScheme: string) {
  const colors = {
    'Blue, gray, and white': 'bg-blue-100 text-blue-600',
    'Vibrant colors with dark backgrounds': 'bg-purple-100 text-purple-600',
    'Trust-building colors': 'bg-emerald-100 text-emerald-600',
    'Warm colors like reds, oranges': 'bg-orange-100 text-orange-600',
    'Modern tech colors': 'bg-indigo-100 text-indigo-600'
  }
  return colors[colorScheme as keyof typeof colors] || 'bg-blue-100 text-blue-600'
}

function getStatColor(colorScheme: string) {
  const colors = {
    'Blue, gray, and white': 'text-blue-600',
    'Vibrant colors with dark backgrounds': 'text-purple-400',
    'Trust-building colors': 'text-emerald-600',
    'Warm colors like reds, oranges': 'text-orange-600',
    'Modern tech colors': 'text-indigo-600'
  }
  return colors[colorScheme as keyof typeof colors] || 'text-blue-600'
}

function getTestimonialCardStyle(designStyle: string) {
  return ''
}

function getContactIconStyle(colorScheme: string) {
  const colors = {
    'Blue, gray, and white': 'text-blue-600',
    'Vibrant colors with dark backgrounds': 'text-purple-400',
    'Trust-building colors': 'text-emerald-600',
    'Warm colors like reds, oranges': 'text-orange-600',
    'Modern tech colors': 'text-indigo-600'
  }
  return colors[colorScheme as keyof typeof colors] || 'text-blue-600'
}

function getSocialLinkStyle(colorScheme: string) {
  return ''
}

function getFooterStyle(designStyle: string, colorScheme: string) {
  return ''
}

function getBackToTopStyle(colorScheme: string) {
  const colors = {
    'Blue, gray, and white': 'bg-blue-600 hover:bg-blue-700',
    'Vibrant colors with dark backgrounds': 'bg-purple-600 hover:bg-purple-700',
    'Trust-building colors': 'bg-emerald-600 hover:bg-emerald-700',
    'Warm colors like reds, oranges': 'bg-orange-600 hover:bg-orange-700',
    'Modern tech colors': 'bg-indigo-600 hover:bg-indigo-700'
  }
  return colors[colorScheme as keyof typeof colors] || 'bg-blue-600 hover:bg-blue-700'
}

function generateWebpageFiles(prompt, analysis, features) {
  const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Premium website for ${prompt}">
    <title>${prompt.charAt(0).toUpperCase() + prompt.slice(1)} - Premium Website</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-logo">
                <h1>${prompt.charAt(0).toUpperCase() + prompt.slice(1)}</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="#home">Home</a></li>
                <li><a href="#services">Services</a></li>
                ${hasAbout ? '<li><a href="#about">About</a></li>' : ''}
                ${hasTestimonials ? '<li><a href="#testimonials">Testimonials</a></li>' : ''}
                <li><a href="#contact">Contact</a></li>
            </ul>
            ${hasNavActions ? `
            <div class="nav-actions">
                <div class="search-box">
                    <input type="text" placeholder="Search...">
                    <i class="fas fa-search"></i>
                </div>
                <div class="user-account">
                    <i class="fas fa-user-circle"></i>
                    <span>Account</span>
                </div>
            </div>
            ` : ''}
        </div>
    </nav>

    ${hasHero ? `
    <section id="home" class="hero">
        <div class="hero-background">
            <div class="hero-overlay"></div>
            <div class="hero-content">
                <h1 class="hero-title">${prompt.charAt(0).toUpperCase() + prompt.slice(1)}</h1>
                <p class="hero-subtitle">Professional solutions delivered with excellence and innovation</p>
                <div class="hero-buttons">
                    <a href="#services" class="btn btn-primary">Get Started</a>
                    <a href="#contact" class="btn btn-secondary">Learn More</a>
                </div>
            </div>
        </div>
    </section>
    ` : ''}

    ${hasServices ? `
    <section id="services" class="services">
        <div class="container">
            <div class="section-header">
                <h2>Our Services</h2>
                <p>Comprehensive solutions tailored to your needs</p>
            </div>
            <div class="services-grid">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-rocket"></i>
                    </div>
                    <h3>Innovation</h3>
                    <p>Cutting-edge solutions that push boundaries and drive success</p>
                </div>
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-cogs"></i>
                    </div>
                    <h3>Expertise</h3>
                    <p>Professional team with deep industry knowledge and experience</p>
                </div>
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <h3>Growth</h3>
                    <p>Strategic approaches that accelerate your business growth</p>
                </div>
            </div>
        </div>
    </section>
    ` : ''}

    ${hasDetailedServices ? `
    <section class="detailed-services">
        <div class="container">
            <div class="section-header">
                <h2>What We Offer</h2>
                <p>Detailed services designed for your success</p>
            </div>
            <div class="detailed-services-grid">
                <div class="detailed-service-item">
                    <div class="service-content">
                        <h3>Strategic Planning</h3>
                        <p>Comprehensive strategic planning services that align with your business objectives and drive measurable results. Our expert team analyzes your current position and develops actionable strategies for sustainable growth.</p>
                        <ul class="service-features">
                            <li><i class="fas fa-check"></i> Market Analysis</li>
                            <li><i class="fas fa-check"></i> Competitive Research</li>
                            <li><i class="fas fa-check"></i> Goal Setting</li>
                        </ul>
                    </div>
                </div>
                <div class="detailed-service-item">
                    <div class="service-content">
                        <h3>Implementation Support</h3>
                        <p>End-to-end implementation support ensuring seamless execution of strategies and initiatives. We work alongside your team to ensure successful deployment and adoption of new processes and technologies.</p>
                        <ul class="service-features">
                            <li><i class="fas fa-check"></i> Project Management</li>
                            <li><i class="fas fa-check"></i> Team Training</li>
                            <li><i class="fas fa-check"></i> Quality Assurance</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    ` : ''}

    ${hasAbout ? `
    <section id="about" class="about">
        <div class="container">
            <div class="section-header">
                <h2>About Us</h2>
                <p>Our story, mission, and values</p>
            </div>
            <div class="about-content">
                <div class="about-text">
                    <h3>Our History</h3>
                    <p>Founded with a vision to transform the ${prompt} industry, we have grown from a small startup to a trusted leader in the field. Our journey has been marked by innovation, dedication, and a relentless pursuit of excellence.</p>
                    
                    <h3>Our Mission</h3>
                    <p>To deliver exceptional ${prompt} solutions that empower businesses and individuals to achieve their full potential through innovation, expertise, and unwavering commitment to quality.</p>
                    
                    <h3>Our Values</h3>
                    <div class="values-grid">
                        <div class="value-item">
                            <i class="fas fa-heart"></i>
                            <h4>Passion</h4>
                            <p>We are passionate about what we do and driven by excellence</p>
                        </div>
                        <div class="value-item">
                            <i class="fas fa-lightbulb"></i>
                            <h4>Innovation</h4>
                            <p>We constantly seek new and better ways to serve our clients</p>
                        </div>
                        <div class="value-item">
                            <i class="fas fa-handshake"></i>
                            <h4>Integrity</h4>
                            <p>We operate with transparency and honesty in all we do</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    ` : ''}

    ${hasTestimonials ? `
    <section id="testimonials" class="testimonials">
        <div class="container">
            <div class="section-header">
                <h2>Client Testimonials</h2>
                <p>What our clients say about us</p>
            </div>
            <div class="testimonials-grid">
                <div class="testimonial-card">
                    <div class="testimonial-header">
                        <img src="https://picsum.photos/seed/client1/60/60.jpg" alt="Client Photo" class="client-photo">
                        <div class="client-info">
                            <h4>Sarah Johnson</h4>
                            <div class="rating">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                        </div>
                    </div>
                    <p class="testimonial-text">"Outstanding service and exceptional results. The team exceeded our expectations and delivered solutions that transformed our business. Highly recommended!"</p>
                </div>
                <div class="testimonial-card">
                    <div class="testimonial-header">
                        <img src="https://picsum.photos/seed/client2/60/60.jpg" alt="Client Photo" class="client-photo">
                        <div class="client-info">
                            <h4>Michael Chen</h4>
                            <div class="rating">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                        </div>
                    </div>
                    <p class="testimonial-text">"Professional, reliable, and innovative. They understood our needs perfectly and delivered solutions that drove significant growth for our company."</p>
                </div>
                <div class="testimonial-card">
                    <div class="testimonial-header">
                        <img src="https://picsum.photos/seed/client3/60/60.jpg" alt="Client Photo" class="client-photo">
                        <div class="client-info">
                            <h4>Emily Rodriguez</h4>
                            <div class="rating">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                        </div>
                    </div>
                    <p class="testimonial-text">"Amazing experience from start to finish. The team's expertise and attention to detail made all the difference. We couldn't be happier with the results!"</p>
                </div>
            </div>
        </div>
    </section>
    ` : ''}

    ${hasContact ? `
    <section id="contact" class="contact">
        <div class="container">
            <div class="section-header">
                <h2>Contact Us</h2>
                <p>Get in touch with our team</p>
            </div>
            <div class="contact-content">
                <div class="contact-form-container">
                    <form class="contact-form" id="contactForm">
                        <div class="form-group">
                            <label for="name">Full Name *</label>
                            <input type="text" id="name" name="name" required>
                            <span class="error-message"></span>
                        </div>
                        <div class="form-group">
                            <label for="email">Email Address *</label>
                            <input type="email" id="email" name="email" required>
                            <span class="error-message"></span>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone">
                            <span class="error-message"></span>
                        </div>
                        <div class="form-group">
                            <label for="subject">Subject *</label>
                            <input type="text" id="subject" name="subject" required>
                            <span class="error-message"></span>
                        </div>
                        <div class="form-group">
                            <label for="message">Message *</label>
                            <textarea id="message" name="message" rows="5" required></textarea>
                            <span class="error-message"></span>
                        </div>
                        <button type="submit" class="btn btn-primary">Send Message</button>
                    </form>
                </div>
                <div class="contact-info">
                    <div class="contact-info-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <h4>Our Location</h4>
                            <p>123 Business Avenue<br>Suite 100<br>New York, NY 10001</p>
                        </div>
                    </div>
                    <div class="contact-info-item">
                        <i class="fas fa-phone"></i>
                        <div>
                            <h4>Phone Number</h4>
                            <p>+1 (555) 123-4567<br>+1 (555) 987-6543</p>
                        </div>
                    </div>
                    <div class="contact-info-item">
                        <i class="fas fa-envelope"></i>
                        <div>
                            <h4>Email Address</h4>
                            <p>info@${prompt.toLowerCase().replace(/\s+/g, '')}.com<br>support@${prompt.toLowerCase().replace(/\s+/g, '')}.com</p>
                        </div>
                    </div>
                    <div class="contact-info-item">
                        <i class="fas fa-clock"></i>
                        <div>
                            <h4>Business Hours</h4>
                            <p>Monday - Friday: 9:00 AM - 6:00 PM<br>Saturday: 10:00 AM - 4:00 PM<br>Sunday: Closed</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    ` : ''}

    ${hasFooter ? `
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>${prompt.charAt(0).toUpperCase() + prompt.slice(1)}</h3>
                    <p>Professional ${prompt} solutions delivered with excellence and innovation.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="#home">Home</a></li>
                        <li><a href="#services">Services</a></li>
                        ${hasAbout ? '<li><a href="#about">About</a></li>' : ''}
                        ${hasTestimonials ? '<li><a href="#testimonials">Testimonials</a></li>' : ''}
                        <li><a href="#contact">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Services</h4>
                    <ul>
                        <li><a href="#services">Strategic Planning</a></li>
                        <li><a href="#services">Implementation</a></li>
                        <li><a href="#services">Consulting</a></li>
                        <li><a href="#services">Support</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Contact Info</h4>
                    <ul>
                        <li><i class="fas fa-map-marker-alt"></i> 123 Business Ave, New York, NY 10001</li>
                        <li><i class="fas fa-phone"></i> +1 (555) 123-4567</li>
                        <li><i class="fas fa-envelope"></i> info@${prompt.toLowerCase().replace(/\s+/g, '')}.com</li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 ${prompt.charAt(0).toUpperCase() + prompt.slice(1)}. All rights reserved. | <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
            </div>
        </div>
    </footer>
    ` : ''}

    ${hasBackToTop ? `
    <button class="back-to-top" id="backToTop">
        <i class="fas fa-arrow-up"></i>
    </button>
    ` : ''}

    <script src="script.js"></script>
</body>
</html>`

  const cssContent = `/* Premium Styles for ${prompt} */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', sans-serif;
    line-height: 1.6;
    color: #333;
    background-color: #f8f9fa;
    overflow-x: hidden;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

/* Navigation */
${hasNavigation ? `
.navbar {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    padding: 1rem 0;
    position: fixed;
    width: 100%;
    top: 0;
    z-index: 1000;
    box-shadow: 0 2px 20px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
}

.nav-container {
    max-width: 1200px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 20px;
}

.nav-logo h1 {
    color: #667eea;
    font-size: 1.8rem;
    font-weight: 700;
    margin: 0;
}

.nav-menu {
    display: flex;
    list-style: none;
    gap: 2rem;
    margin: 0;
    padding: 0;
}

.nav-menu a {
    text-decoration: none;
    color: #333;
    font-weight: 500;
    transition: color 0.3s ease;
    position: relative;
}

.nav-menu a::after {
    content: '';
    position: absolute;
    bottom: -5px;
    left: 0;
    width: 0;
    height: 2px;
    background: #667eea;
    transition: width 0.3s ease;
}

.nav-menu a:hover {
    color: #667eea;
}

.nav-menu a:hover::after {
    width: 100%;
}

.nav-actions {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.search-box {
    position: relative;
    display: flex;
    align-items: center;
}

.search-box input {
    padding: 8px 35px 8px 15px;
    border: 2px solid #e9ecef;
    border-radius: 25px;
    outline: none;
    transition: border-color 0.3s ease;
    width: 200px;
}

.search-box input:focus {
    border-color: #667eea;
}

.search-box i {
    position: absolute;
    right: 12px;
    color: #667eea;
}

.user-account {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    cursor: pointer;
    padding: 8px 15px;
    border-radius: 20px;
    transition: background-color 0.3s ease;
}

.user-account:hover {
    background-color: #f8f9fa;
}

.user-account i {
    font-size: 1.2rem;
    color: #667eea;
}
` : ''}

/* Hero Section */
${hasHero ? `
.hero {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    margin-top: 80px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    overflow: hidden;
}

.hero-background {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: url('https://picsum.photos/seed/hero-bg/1920/1080.jpg') center/cover;
    animation: backgroundMove 20s ease-in-out infinite;
}

@keyframes backgroundMove {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.1); }
}

.hero-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.4);
}

.hero-content {
    position: relative;
    z-index: 2;
    text-align: center;
    color: white;
    max-width: 800px;
    padding: 0 20px;
    animation: fadeInUp 1s ease-out;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.hero-title {
    font-size: 3.5rem;
    font-weight: 800;
    margin-bottom: 1rem;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    animation: titleGlow 2s ease-in-out infinite alternate;
}

@keyframes titleGlow {
    from { text-shadow: 2px 2px 4px rgba(0,0,0,0.3); }
    to { text-shadow: 2px 2px 20px rgba(255,255,255,0.3); }
}

.hero-subtitle {
    font-size: 1.3rem;
    margin-bottom: 2rem;
    opacity: 0.9;
    font-weight: 300;
}

.hero-buttons {
    display: flex;
    gap: 1rem;
    justify-content: center;
    flex-wrap: wrap;
}

.btn {
    display: inline-block;
    padding: 15px 35px;
    text-decoration: none;
    border-radius: 30px;
    font-weight: 600;
    transition: all 0.3s ease;
    cursor: pointer;
    border: none;
    font-size: 1rem;
    position: relative;
    overflow: hidden;
}

.btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
    transition: left 0.5s ease;
}

.btn:hover::before {
    left: 100%;
}

.btn-primary {
    background: linear-gradient(45deg, #ff6b6b, #ff8e8e);
    color: white;
    box-shadow: 0 4px 15px rgba(255, 107, 107, 0.3);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(255, 107, 107, 0.4);
}

.btn-secondary {
    background: transparent;
    color: white;
    border: 2px solid white;
}

.btn-secondary:hover {
    background: white;
    color: #667eea;
    transform: translateY(-2px);
}
` : ''}

/* Section Headers */
.section-header {
    text-align: center;
    margin-bottom: 3rem;
}

.section-header h2 {
    font-size: 2.5rem;
    font-weight: 700;
    color: #333;
    margin-bottom: 1rem;
    position: relative;
}

.section-header h2::after {
    content: '';
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
    width: 60px;
    height: 3px;
    background: linear-gradient(45deg, #667eea, #764ba2);
}

.section-header p {
    font-size: 1.1rem;
    color: #666;
    max-width: 600px;
    margin: 0 auto;
}

/* Services Section */
${hasServices ? `
.services {
    padding: 80px 0;
    background: white;
}

.services-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
}

.service-card {
    background: #f8f9fa;
    padding: 2.5rem;
    border-radius: 20px;
    text-align: center;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.service-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: linear-gradient(45deg, #667eea, #764ba2);
    transform: scaleX(0);
    transition: transform 0.3s ease;
}

.service-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.1);
}

.service-card:hover::before {
    transform: scaleX(1);
}

.service-icon {
    width: 80px;
    height: 80px;
    margin: 0 auto 1.5rem;
    background: linear-gradient(45deg, #667eea, #764ba2);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
    color: white;
    transition: transform 0.3s ease;
}

.service-card:hover .service-icon {
    transform: scale(1.1) rotate(5deg);
}

.service-card h3 {
    color: #333;
    font-size: 1.5rem;
    margin-bottom: 1rem;
    font-weight: 600;
}

.service-card p {
    color: #666;
    line-height: 1.6;
}
` : ''}

/* Detailed Services Section */
${hasDetailedServices ? `
.detailed-services {
    padding: 80px 0;
    background: #f8f9fa;
}

.detailed-services-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
    gap: 3rem;
}

.detailed-service-item {
    background: white;
    border-radius: 20px;
    padding: 2.5rem;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    transition: transform 0.3s ease;
}

.detailed-service-item:hover {
    transform: translateY(-5px);
}

.service-content h3 {
    color: #333;
    font-size: 1.8rem;
    margin-bottom: 1rem;
    font-weight: 600;
}

.service-content p {
    color: #666;
    margin-bottom: 1.5rem;
    line-height: 1.6;
}

.service-features {
    list-style: none;
    padding: 0;
}

.service-features li {
    display: flex;
    align-items: center;
    margin-bottom: 0.8rem;
    color: #555;
}

.service-features i {
    color: #28a745;
    margin-right: 0.8rem;
    font-size: 0.9rem;
}
` : ''}

/* About Section */
${hasAbout ? `
.about {
    padding: 80px 0;
    background: white;
}

.about-content {
    max-width: 800px;
    margin: 0 auto;
}

.about-text h3 {
    color: #333;
    font-size: 1.8rem;
    margin-bottom: 1rem;
    font-weight: 600;
}

.about-text p {
    color: #666;
    margin-bottom: 2rem;
    line-height: 1.6;
}

.values-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

.value-item {
    text-align: center;
    padding: 2rem;
    background: #f8f9fa;
    border-radius: 15px;
    transition: transform 0.3s ease;
}

.value-item:hover {
    transform: translateY(-5px);
}

.value-item i {
    font-size: 2.5rem;
    color: #667eea;
    margin-bottom: 1rem;
}

.value-item h4 {
    color: #333;
    font-size: 1.2rem;
    margin-bottom: 0.5rem;
    font-weight: 600;
}

.value-item p {
    color: #666;
    font-size: 0.9rem;
}
` : ''}

/* Testimonials Section */
${hasTestimonials ? `
.testimonials {
    padding: 80px 0;
    background: #f8f9fa;
}

.testimonials-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 2rem;
}

.testimonial-card {
    background: white;
    padding: 2rem;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    transition: transform 0.3s ease;
}

.testimonial-card:hover {
    transform: translateY(-5px);
}

.testimonial-header {
    display: flex;
    align-items: center;
    margin-bottom: 1.5rem;
}

.client-photo {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    margin-right: 1rem;
    object-fit: cover;
}

.client-info h4 {
    color: #333;
    font-size: 1.1rem;
    margin-bottom: 0.3rem;
    font-weight: 600;
}

.rating {
    display: flex;
    gap: 0.2rem;
}

.rating i {
    color: #ffc107;
    font-size: 0.9rem;
}

.testimonial-text {
    color: #666;
    line-height: 1.6;
    font-style: italic;
}
` : ''}

/* Contact Section */
${hasContact ? `
.contact {
    padding: 80px 0;
    background: white;
}

.contact-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 3rem;
    align-items: start;
}

.contact-form-container {
    background: #f8f9fa;
    padding: 2.5rem;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

.contact-form {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.form-group {
    display: flex;
    flex-direction: column;
}

.form-group label {
    color: #333;
    font-weight: 500;
    margin-bottom: 0.5rem;
}

.form-group input,
.form-group textarea {
    padding: 12px 15px;
    border: 2px solid #e9ecef;
    border-radius: 10px;
    font-size: 1rem;
    transition: border-color 0.3s ease;
    font-family: inherit;
}

.form-group input:focus,
.form-group textarea:focus {
    outline: none;
    border-color: #667eea;
}

.form-group .error-message {
    color: #dc3545;
    font-size: 0.9rem;
    margin-top: 0.3rem;
    min-height: 1.2rem;
}

.contact-info {
    display: flex;
    flex-direction: column;
    gap: 2rem;
}

.contact-info-item {
    display: flex;
    align-items: flex-start;
    gap: 1rem;
    padding: 1.5rem;
    background: #f8f9fa;
    border-radius: 15px;
    transition: transform 0.3s ease;
}

.contact-info-item:hover {
    transform: translateY(-3px);
}

.contact-info-item i {
    font-size: 1.5rem;
    color: #667eea;
    margin-top: 0.2rem;
}

.contact-info-item h4 {
    color: #333;
    font-size: 1.1rem;
    margin-bottom: 0.5rem;
    font-weight: 600;
}

.contact-info-item p {
    color: #666;
    line-height: 1.5;
}
` : ''}

/* Footer */
${hasFooter ? `
.footer {
    background: #2c3e50;
    color: white;
    padding: 50px 0 20px;
}

.footer-content {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
    margin-bottom: 2rem;
}

.footer-section h3,
.footer-section h4 {
    color: white;
    margin-bottom: 1rem;
    font-weight: 600;
}

.footer-section p {
    color: #bdc3c7;
    line-height: 1.6;
    margin-bottom: 1rem;
}

.footer-section ul {
    list-style: none;
    padding: 0;
}

.footer-section ul li {
    margin-bottom: 0.5rem;
}

.footer-section ul li a {
    color: #bdc3c7;
    text-decoration: none;
    transition: color 0.3s ease;
}

.footer-section ul li a:hover {
    color: #667eea;
}

.social-links {
    display: flex;
    gap: 1rem;
    margin-top: 1rem;
}

.social-links a {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    background: rgba(255,255,255,0.1);
    border-radius: 50%;
    color: white;
    text-decoration: none;
    transition: all 0.3s ease;
}

.social-links a:hover {
    background: #667eea;
    transform: translateY(-2px);
}

.footer-bottom {
    border-top: 1px solid rgba(255,255,255,0.1);
    padding-top: 20px;
    text-align: center;
}

.footer-bottom p {
    color: #bdc3c7;
    margin: 0;
}

.footer-bottom a {
    color: #667eea;
    text-decoration: none;
}

.footer-bottom a:hover {
    text-decoration: underline;
}
` : ''}

/* Back to Top Button */
${hasBackToTop ? `
.back-to-top {
    position: fixed;
    bottom: 30px;
    right: 30px;
    width: 50px;
    height: 50px;
    background: linear-gradient(45deg, #667eea, #764ba2);
    color: white;
    border: none;
    border-radius: 50%;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.2rem;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
    z-index: 1000;
    box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
}

.back-to-top.visible {
    opacity: 1;
    visibility: visible;
}

.back-to-top:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
}
` : ''}

/* Responsive Design */
@media (max-width: 768px) {
    .nav-container {
        flex-direction: column;
        gap: 1rem;
    }
    
    .nav-menu {
        flex-direction: column;
        gap: 1rem;
        text-align: center;
    }
    
    .nav-actions {
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .hero-title {
        font-size: 2.5rem;
    }
    
    .hero-subtitle {
        font-size: 1.1rem;
    }
    
    .hero-buttons {
        flex-direction: column;
        align-items: center;
    }
    
    .services-grid,
    .testimonials-grid {
        grid-template-columns: 1fr;
    }
    
    .detailed-services-grid {
        grid-template-columns: 1fr;
    }
    
    .contact-content {
        grid-template-columns: 1fr;
    }
    
    .values-grid {
        grid-template-columns: 1fr;
    }
    
    .footer-content {
        grid-template-columns: 1fr;
        text-align: center;
    }
    
    .social-links {
        justify-content: center;
    }
    
    .contact-info-item {
        flex-direction: column;
        text-align: center;
    }
}

@media (max-width: 480px) {
    .hero-title {
        font-size: 2rem;
    }
    
    .section-header h2 {
        font-size: 2rem;
    }
    
    .service-card,
    .detailed-service-item,
    .testimonial-card,
    .contact-form-container {
        padding: 1.5rem;
    }
    
    .btn {
        padding: 12px 25px;
        font-size: 0.9rem;
    }
}`

  const jsContent = `// Premium Interactive Features for ${prompt}
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Premium webpage loaded successfully for: ${prompt}');
    
    // Initialize all premium features
    initializeNavigation();
    initializeHeroAnimations();
    initializeServiceCards();
    initializeContactForm();
    initializeTestimonials();
    initializeScrollEffects();
    initializeBackToTop();
    
    console.log('✅ All premium features initialized successfully');
});

// Navigation functionality
function initializeNavigation() {
    const navbar = document.querySelector('.navbar');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-menu a');
    
    // Add scroll effect to navbar
    if (navbar) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                navbar.style.background = 'rgba(255, 255, 255, 0.98)';
                navbar.style.boxShadow = '0 2px 30px rgba(0,0,0,0.15)';
            } else {
                navbar.style.background = 'rgba(255, 255, 255, 0.95)';
                navbar.style.boxShadow = '0 2px 20px rgba(0,0,0,0.1)';
            }
        });
    }
    
    // Smooth scrolling for navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                const offsetTop = targetSection.offsetTop - 80;
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Search functionality
    const searchInput = document.querySelector('.search-box input');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            console.log('🔍 Searching for:', searchTerm);
            // Add search functionality here
        });
    }
    
    console.log('📱 Navigation features initialized');
}

// Hero section animations
function initializeHeroAnimations() {
    const heroContent = document.querySelector('.hero-content');
    const heroTitle = document.querySelector('.hero-title');
    const heroSubtitle = document.querySelector('.hero-subtitle');
    const heroButtons = document.querySelector('.hero-buttons');
    
    if (heroContent) {
        // Stagger animation for hero elements
        setTimeout(() => {
            if (heroTitle) heroTitle.style.opacity = '1';
            if (heroTitle) heroTitle.style.transform = 'translateY(0)';
        }, 200);
        
        setTimeout(() => {
            if (heroSubtitle) heroSubtitle.style.opacity = '1';
            if (heroSubtitle) heroSubtitle.style.transform = 'translateY(0)';
        }, 400);
        
        setTimeout(() => {
            if (heroButtons) heroButtons.style.opacity = '1';
            if (heroButtons) heroButtons.style.transform = 'translateY(0)';
        }, 600);
    }
    
    // Parallax effect for hero background
    const heroBackground = document.querySelector('.hero-background');
    if (heroBackground) {
        window.addEventListener('scroll', function() {
            const scrolled = window.pageYOffset;
            const parallax = scrolled * 0.5;
            heroBackground.style.transform = \`translateY(\${parallax}px)\`;
        });
    }
    
    console.log('🎬 Hero animations initialized');
}

// Service cards interactions
function initializeServiceCards() {
    const serviceCards = document.querySelectorAll('.service-card');
    
    serviceCards.forEach((card, index) => {
        // Add hover effects
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px) scale(1.02)';
            this.style.boxShadow = '0 20px 40px rgba(0,0,0,0.15)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
            this.style.boxShadow = '0 10px 30px rgba(0,0,0,0.1)';
        });
        
        // Add staggered animation on scroll
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        
        setTimeout(() => {
            card.style.transition = 'all 0.6s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
    
    console.log('🃏 Service cards initialized');
}

// Contact form functionality
function initializeContactForm() {
    const contactForm = document.getElementById('contactForm');
    const formInputs = contactForm ? contactForm.querySelectorAll('input, textarea') : [];
    
    if (contactForm) {
        // Form validation
        formInputs.forEach(input => {
            input.addEventListener('blur', function() {
                validateField(this);
            });
            
            input.addEventListener('input', function() {
                clearFieldError(this);
            });
        });
        
        // Form submission
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            let isValid = true;
            formInputs.forEach(input => {
                if (!validateField(input)) {
                    isValid = false;
                }
            });
            
            if (isValid) {
                // Simulate form submission
                const submitButton = contactForm.querySelector('button[type="submit"]');
                const originalText = submitButton.textContent;
                
                submitButton.textContent = 'Sending...';
                submitButton.disabled = true;
                
                setTimeout(() => {
                    submitButton.textContent = 'Message Sent!';
                    submitButton.style.background = '#28a745';
                    
                    setTimeout(() => {
                        submitButton.textContent = originalText;
                        submitButton.disabled = false;
                        submitButton.style.background = '';
                        contactForm.reset();
                    }, 2000);
                }, 1500);
                
                console.log('📧 Contact form submitted successfully');
            }
        });
    }
    
    console.log('📝 Contact form initialized');
}

// Testimonials functionality
function initializeTestimonials() {
    const testimonialCards = document.querySelectorAll('.testimonial-card');
    
    testimonialCards.forEach((card, index) => {
        // Add hover effects
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px) scale(1.02)';
            this.style.boxShadow = '0 15px 35px rgba(0,0,0,0.15)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
            this.style.boxShadow = '0 10px 30px rgba(0,0,0,0.1)';
        });
        
        // Add fade-in animation
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        
        setTimeout(() => {
            card.style.transition = 'all 0.6s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 150);
    });
    
    console.log('💬 Testimonials initialized');
}

// Scroll effects
function initializeScrollEffects() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                
                // Add animation classes
                if (entry.target.classList.contains('service-card') ||
                    entry.target.classList.contains('testimonial-card') ||
                    entry.target.classList.contains('detailed-service-item') ||
                    entry.target.classList.contains('value-item') ||
                    entry.target.classList.contains('contact-info-item')) {
                    entry.target.style.animation = 'fadeInUp 0.6s ease forwards';
                }
            }
        });
    }, observerOptions);
    
    // Observe all animatable elements
    const animatableElements = document.querySelectorAll(
        '.service-card, .testimonial-card, .detailed-service-item, .value-item, .contact-info-item, .section-header'
    );
    
    animatableElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'all 0.6s ease';
        observer.observe(el);
    });
    
    console.log('📜 Scroll effects initialized');
}

// Back to top functionality
function initializeBackToTop() {
    const backToTopButton = document.getElementById('backToTop');
    
    if (backToTopButton) {
        // Show/hide button based on scroll position
        window.addEventListener('scroll', function() {
            if (window.scrollY > 300) {
                backToTopButton.classList.add('visible');
            } else {
                backToTopButton.classList.remove('visible');
            }
        });
        
        // Smooth scroll to top
        backToTopButton.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
        
        console.log('⬆️ Back to top button initialized');
    }
}

// Form validation helper functions
function validateField(field) {
    const value = field.value.trim();
    const fieldName = field.name;
    const errorElement = field.parentNode.querySelector('.error-message');
    
    let isValid = true;
    let errorMessage = '';
    
    // Required field validation
    if (field.hasAttribute('required') && !value) {
        isValid = false;
        errorMessage = 'This field is required';
    }
    
    // Email validation
    if (fieldName === 'email' && value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
            isValid = false;
            errorMessage = 'Please enter a valid email address';
        }
    }
    
    // Phone validation
    if (fieldName === 'phone' && value) {
        const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
        if (!phoneRegex.test(value.replace(/[\s\-\(\)]/g, ''))) {
            isValid = false;
            errorMessage = 'Please enter a valid phone number';
        }
    }
    
    // Display error message
    if (errorElement) {
        errorElement.textContent = errorMessage;
    }
    
    // Add/remove error styling
    if (isValid) {
        field.style.borderColor = '#28a745';
        field.classList.remove('error');
        field.classList.add('success');
    } else {
        field.style.borderColor = '#dc3545';
        field.classList.add('error');
        field.classList.remove('success');
    }
    
    return isValid;
}

function clearFieldError(field) {
    const errorElement = field.parentNode.querySelector('.error-message');
    if (errorElement) {
        errorElement.textContent = '';
    }
    field.style.borderColor = '#e9ecef';
    field.classList.remove('error', 'success');
}

// Add CSS animation keyframes
const style = document.createElement('style');
style.textContent = \`
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes pulse {
    0% {
        transform: scale(1);
    }
    50% {
        transform: scale(1.05);
    }
    100% {
        transform: scale(1);
    }
}

.error {
    border-color: #dc3545 !important;
    animation: shake 0.5s ease-in-out;
}

.success {
    border-color: #28a745 !important;
}

@keyframes shake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(-5px); }
    75% { transform: translateX(5px); }
}
\`;
document.head.appendChild(style);

// Console log for debugging
console.log('🎯 Premium webpage script loaded successfully');
console.log('📋 Features included: ${features.join(', ')}');
console.log('🔧 All interactive features are ready');`

  return [
    {
      name: 'index.html',
      content: htmlContent,
      language: 'html'
    },
    {
      name: 'styles.css',
      content: cssContent,
      language: 'css'
    },
    {
      name: 'script.js',
      content: jsContent,
      language: 'javascript'
    }
  ]

}

