import { NextRequest, NextResponse } from 'next/server'

interface PromptRequest {
  prompt: string
  type: 'complete-webpage' | 'component' | 'feature'
  context?: string
}

interface PromptResponse {
  success: boolean
  files?: {
    name: string
    content: string
    language: string
  }[]
  explanation?: string
  error?: string
}

// OpenRouter API configuration
const OPENROUTER_API_KEY = "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"
const OPENROUTER_MODEL = "mistralai/mistral-7b-instruct"
const OPENROUTER_API_URL = "https://openrouter.ai/api/v1/chat/completions"

// Helper function to call OpenRouter API
async function callOpenRouterAPI(prompt: string) {
  const response = await fetch(OPENROUTER_API_URL, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': 'http://localhost:3000',
      'X-Title': 'AI-IDE Webpage Generator'
    },
    body: JSON.stringify({
      model: OPENROUTER_MODEL,
      messages: [
        {
          role: 'system',
          content: 'You are an expert web developer who creates complete, modern, and functional webpages. Generate clean, well-structured code with proper functionality and beautiful design.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 4000
    })
  })

  if (!response.ok) {
    const errorText = await response.text()
    throw new Error(`OpenRouter API error: ${response.status} - ${errorText}`)
  }

  return await response.json()
}

// Helper function to extract HTML, CSS, and JavaScript from AI response
function extractFilesFromResponse(content: string, prompt: string) {
  const files = []
  
  // Try to find HTML code block
  const htmlMatch = content.match(/```html\n([\s\S]*?)\n```/) || 
                   content.match(/```HTML\n([\s\S]*?)\n```/)
  
  // Try to find CSS code block
  const cssMatch = content.match(/```css\n([\s\S]*?)\n```/) || 
                  content.match(/```CSS\n([\s\S]*?)\n```/)
  
  // Try to find JavaScript code block
  const jsMatch = content.match(/```javascript\n([\s\S]*?)\n```/) || 
                 content.match(/```js\n([\s\S]*?)\n```/) ||
                 content.match(/```JavaScript\n([\s\S]*?)\n```/)
  
  if (htmlMatch && htmlMatch[1]) {
    files.push({
      name: 'index.html',
      content: htmlMatch[1].trim(),
      language: 'html'
    })
  } else {
    // If no HTML found, create from the entire content
    files.push({
      name: 'index.html',
      content: content.trim(),
      language: 'html'
    })
  }
  
  if (cssMatch && cssMatch[1]) {
    files.push({
      name: 'styles.css',
      content: cssMatch[1].trim(),
      language: 'css'
    })
  }
  
  if (jsMatch && jsMatch[1]) {
    files.push({
      name: 'script.js',
      content: jsMatch[1].trim(),
      language: 'javascript'
    })
  }
  
  return files
}

// Simple, reliable webpage generator
class WebpageGenerator {
  async generateWebpage(prompt: string) {
    console.log(`[AI-Prompt API] Starting webpage generation for: "${prompt}"`)
    
    try {
      console.log('[AI-Prompt API] 🚀 Using OpenRouter API...')
      
      // Advanced prompt analysis and enhancement
      const enhancedPrompt = this.createEnhancedPrompt(prompt)
      
      console.log('[AI-Prompt API] 🤖 Sending enhanced request to OpenRouter API...')
      
      // Implement retry logic for better reliability
      let lastError = null
      const maxRetries = 3
      
      for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
          // Create a timeout promise for the OpenRouter API
          const timeoutPromise = new Promise((_, reject) => {
            setTimeout(() => reject(new Error('OpenRouter API timeout')), 60000) // Increased to 60 second timeout
          })
          
          // Create the OpenRouter API promise
          const apiPromise = callOpenRouterAPI(enhancedPrompt)
          
          // Race between OpenRouter API and timeout
          const completion = await Promise.race([apiPromise, timeoutPromise])

          const content = completion.choices[0]?.message?.content || ''
          
          if (!content) {
            throw new Error('Empty response from OpenRouter API')
          }
          
          console.log('[AI-Prompt API] 📝 OpenRouter API response received, parsing files...')
          const files = extractFilesFromResponse(content, prompt)
          
          if (files.length === 0) {
            throw new Error('No files were generated from OpenRouter API')
          }
          
          return {
            files: files,
            explanation: `Generated a premium, professional webpage specifically for: "${prompt}" using advanced AI analysis`
          }
          
        } catch (error) {
          lastError = error
          console.error(`[AI-Prompt API] ❌ OpenRouter API attempt ${attempt} failed:`, error.message)
          
          if (attempt < maxRetries) {
            const delay = attempt * 2000 // Exponential backoff: 2s, 4s, 6s
            console.log(`[AI-Prompt API] 🔄 Retrying in ${delay}ms...`)
            await new Promise(resolve => setTimeout(resolve, delay))
          }
        }
      }
      
      // All retries failed, throw the last error
      throw lastError || new Error('All OpenRouter API attempts failed')
      
    } catch (error) {
      console.error('[AI-Prompt API] ❌ OpenRouter API error:', error)
      throw error
    }
  }

  // Advanced prompt analysis and enhancement
  createEnhancedPrompt(prompt: string): string {
    // Analyze the prompt to understand what type of website is needed
    const lowerPrompt = prompt.toLowerCase()
    
    let websiteType = 'business'
    let specificFeatures = []
    let designStyle = 'modern'
    let colorScheme = 'professional'
    let contentFocus = []
    
    // Advanced prompt analysis
    if (lowerPrompt.includes('cafe') || lowerPrompt.includes('coffee') || lowerPrompt.includes('restaurant')) {
      websiteType = 'cafe-restaurant'
      specificFeatures = ['menu-display', 'online-ordering', 'reservation-system', 'location-map', 'hours-display']
      designStyle = 'warm-cozy'
      colorScheme = 'coffee-warm'
      contentFocus = ['menu-items', 'specialty-drinks', 'atmosphere-description', 'chef-profile', 'customer-reviews']
    }
    
    if (lowerPrompt.includes('portfolio') || lowerPrompt.includes('artist') || lowerPrompt.includes('designer')) {
      websiteType = 'portfolio'
      specificFeatures = ['project-gallery', 'skill-showcase', 'contact-form', 'about-section', 'resume-download']
      designStyle = 'creative-minimal'
      colorScheme = 'artistic'
      contentFocus = ['project-descriptions', 'skill-sets', 'experience-timeline', 'testimonials']
    }
    
    if (lowerPrompt.includes('ecommerce') || lowerPrompt.includes('shop') || lowerPrompt.includes('store')) {
      websiteType = 'ecommerce'
      specificFeatures = ['product-catalog', 'shopping-cart', 'checkout-process', 'user-accounts', 'payment-integration']
      designStyle = 'clean-commercial'
      colorScheme = 'trustworthy'
      contentFocus = ['product-listings', 'pricing', 'inventory-management', 'customer-reviews']
    }
    
    if (lowerPrompt.includes('blog') || lowerPrompt.includes('news') || lowerPrompt.includes('magazine')) {
      websiteType = 'blog-magazine'
      specificFeatures = ['article-listings', 'category-filters', 'search-functionality', 'comment-system', 'newsletter-signup']
      designStyle = 'content-focused'
      colorScheme = 'readable'
      contentFocus = ['article-content', 'author-bios', 'publication-dates', 'social-sharing']
    }
    
    // Create highly detailed, professional prompt
    return `Create a PREMIUM, PROFESSIONAL ${websiteType.toUpperCase()} WEBSITE for: "${prompt}"

=== REQUIREMENTS ===
✨ This must be a HIGH-END, PROFESSIONAL website that would impress clients and customers
🎨 Design Style: ${designStyle} with modern UI/UX principles
🎨 Color Scheme: ${colorScheme} with thoughtful color psychology
📱 Fully responsive design that works perfectly on all devices
⚡ Smooth animations and micro-interactions throughout
🚀 Fast loading with optimized performance
🔍 SEO-optimized with proper meta tags and structured data

=== SPECIFIC FEATURES TO INCLUDE ===
${specificFeatures.map(feature => `• ${feature.replace('-', ' ').toUpperCase()}: Advanced implementation with best practices`).join('\n')}

=== CONTENT FOCUS ===
${contentFocus.map(focus => `• ${focus.replace('-', ' ').toUpperCase()}: Detailed, engaging content`).join('\n')}

=== TECHNICAL REQUIREMENTS ===
• HTML5 semantic structure with proper accessibility
• CSS3 with modern features (Grid, Flexbox, Custom Properties)
• Vanilla JavaScript with ES6+ features
• No external dependencies - everything self-contained
• Cross-browser compatible
• Mobile-first responsive design
• Smooth scrolling and navigation
• Form validation and submission handling
• Interactive elements that actually work (not placeholders)

=== DESIGN STANDARDS ===
• Professional typography with proper hierarchy
• Consistent spacing and layout system
• Beautiful hover effects and transitions
• Modern card-based layouts where appropriate
• Professional color palette with good contrast
• High-quality imagery placeholders using picsum.photos
• Icon integration using Font Awesome or similar

=== HTML STRUCTURE REQUIRED ===
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="[Compelling, SEO-optimized description]">
    <meta name="keywords" content="[Relevant keywords for SEO]">
    <title>[Professional, catchy title]</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=[Appropriate Google Fonts]&display=swap" rel="stylesheet">
</head>
<body>
    [Professional navigation with smooth scrolling]
    [Hero section with compelling headline and call-to-action]
    [Main content sections relevant to ${websiteType}]
    [Interactive features and elements]
    [Professional footer with contact info]
    <script src="script.js"></script>
</body>
</html>

=== CSS REQUIREMENTS ===
• CSS Custom Properties for theming
• Modern CSS Grid and Flexbox layouts
• Smooth transitions and hover effects
• Professional typography with font imports
• Responsive design with mobile-first approach
• Beautiful color schemes and gradients
• Box shadows and modern styling
• Animation keyframes for smooth effects

=== JAVASCRIPT REQUIREMENTS ===
• ES6+ modern JavaScript
• DOM manipulation for interactivity
• Form validation and handling
• Smooth scrolling navigation
• Dynamic content updates
• Local storage for user preferences
• Event listeners for all interactive elements
• Error handling and user feedback

=== QUALITY STANDARDS ===
• This must look like a $5,000+ professional website
• No generic templates or placeholder content
• Real, functional features that work perfectly
• Professional copywriting and content
• Modern design trends and best practices
• Impressive to potential clients or customers

RETURN YOUR RESPONSE IN THIS EXACT FORMAT:
\`\`\`html
[Complete, professional HTML code here]
\`\`\`

\`\`\`css
[Complete, professional CSS code here]
\`\`\`

\`\`\`javascript
[Complete, professional JavaScript code here]
\`\`\`

REMEMBER: This is a premium website that should impress and convert visitors. Make it exceptional!`
  }
  
  createFallbackWebpage(prompt: string) {
    console.log('[AI-Prompt API] 🛠️ Creating premium professional fallback webpage...')
    
    // Advanced prompt analysis for fallback
    const lowerPrompt = prompt.toLowerCase()
    let websiteConfig = this.getWebsiteConfig(lowerPrompt)
    
    return {
      files: [
        {
          name: 'index.html',
          content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="${websiteConfig.description}">
    <meta name="keywords" content="${websiteConfig.keywords}">
    <title>${websiteConfig.title}</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=${websiteConfig.fontFamily}&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-logo">
                <h1>${websiteConfig.brandName}</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#services">Services</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" class="hero">
        <div class="hero-content">
            <h1 class="hero-title">${websiteConfig.heroTitle}</h1>
            <p class="hero-subtitle">${websiteConfig.heroSubtitle}</p>
            <div class="hero-buttons">
                <a href="#services" class="btn btn-primary">${websiteConfig.primaryCTA}</a>
                <a href="#contact" class="btn btn-secondary">${websiteConfig.secondaryCTA}</a>
            </div>
        </div>
        <div class="hero-image">
            <img src="https://picsum.photos/seed/${websiteConfig.imageSeed}/600/400.jpg" alt="${websiteConfig.brandName}">
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about">
        <div class="container">
            <div class="about-content">
                <div class="about-text">
                    <h2>About ${websiteConfig.brandName}</h2>
                    <p>${websiteConfig.aboutContent}</p>
                    <div class="about-features">
                        ${websiteConfig.features.map(feature => `
                        <div class="feature">
                            <div class="feature-icon">✨</div>
                            <h3>${feature.title}</h3>
                            <p>${feature.description}</p>
                        </div>`).join('')}
                    </div>
                </div>
                <div class="about-image">
                    <img src="https://picsum.photos/seed/${websiteConfig.imageSeed}2/500/600.jpg" alt="About ${websiteConfig.brandName}">
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="services">
        <div class="container">
            <h2>Our ${websiteConfig.servicesTitle}</h2>
            <div class="services-grid">
                ${websiteConfig.services.map(service => `
                <div class="service-card">
                    <div class="service-icon">${service.icon}</div>
                    <h3>${service.title}</h3>
                    <p>${service.description}</p>
                    <div class="service-price">${service.price}</div>
                    <button class="btn btn-service">Learn More</button>
                </div>`).join('')}
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="contact">
        <div class="container">
            <div class="contact-content">
                <div class="contact-info">
                    <h2>Contact ${websiteConfig.brandName}</h2>
                    <p>${websiteConfig.contactDescription}</p>
                    <div class="contact-details">
                        <div class="contact-item">
                            <strong>Address:</strong>
                            <p>${websiteConfig.address}</p>
                        </div>
                        <div class="contact-item">
                            <strong>Phone:</strong>
                            <p>${websiteConfig.phone}</p>
                        </div>
                        <div class="contact-item">
                            <strong>Email:</strong>
                            <p>${websiteConfig.email}</p>
                        </div>
                        <div class="contact-item">
                            <strong>Hours:</strong>
                            <p>${websiteConfig.hours}</p>
                        </div>
                    </div>
                </div>
                <div class="contact-form">
                    <h3>Send us a message</h3>
                    <form id="contactForm">
                        <div class="form-group">
                            <input type="text" id="name" name="name" placeholder="Your Name" required>
                        </div>
                        <div class="form-group">
                            <input type="email" id="email" name="email" placeholder="Your Email" required>
                        </div>
                        <div class="form-group">
                            <textarea id="message" name="message" placeholder="Your Message" rows="5" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>${websiteConfig.brandName}</h3>
                    <p>${websiteConfig.footerDescription}</p>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="#home">Home</a></li>
                        <li><a href="#about">About</a></li>
                        <li><a href="#services">Services</a></li>
                        <li><a href="#contact">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Follow Us</h4>
                    <div class="social-links">
                        <a href="#" class="social-link">📘</a>
                        <a href="#" class="social-link">🐦</a>
                        <a href="#" class="social-link">📷</a>
                        <a href="#" class="social-link">💼</a>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 ${websiteConfig.brandName}. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="script.js"></script>
</body>
</html>`,
          language: 'html'
        },
        {
          name: 'styles.css',
          content: `/* Premium Professional Styles for ${websiteConfig.brandName} */
:root {
  --primary-color: ${websiteConfig.primaryColor};
  --secondary-color: ${websiteConfig.secondaryColor};
  --accent-color: ${websiteConfig.accentColor};
  --text-color: ${websiteConfig.textColor};
  --text-light: ${websiteConfig.textLight};
  --bg-color: ${websiteConfig.bgColor};
  --bg-light: ${websiteConfig.bgLight};
  --white: #ffffff;
  --shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  --shadow-hover: 0 15px 40px rgba(0, 0, 0, 0.15);
  --border-radius: 12px;
  --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: '${websiteConfig.fontFamily.replace('+', ' ')}', sans-serif;
  line-height: 1.6;
  color: var(--text-color);
  background-color: var(--bg-color);
  overflow-x: hidden;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

/* Navigation */
.navbar {
  position: fixed;
  top: 0;
  width: 100%;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
  z-index: 1000;
  transition: var(--transition);
}

.nav-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 1rem 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.nav-logo h1 {
  color: var(--primary-color);
  font-size: 1.8rem;
  font-weight: 700;
}

.nav-menu {
  display: flex;
  list-style: none;
  gap: 2rem;
}

.nav-menu a {
  text-decoration: none;
  color: var(--text-color);
  font-weight: 500;
  transition: var(--transition);
  position: relative;
}

.nav-menu a::after {
  content: '';
  position: absolute;
  bottom: -5px;
  left: 0;
  width: 0;
  height: 2px;
  background: var(--primary-color);
  transition: var(--transition);
}

.nav-menu a:hover::after {
  width: 100%;
}

.nav-menu a:hover {
  color: var(--primary-color);
}

.hamburger {
  display: none;
  flex-direction: column;
  cursor: pointer;
}

.hamburger span {
  width: 25px;
  height: 3px;
  background: var(--text-color);
  margin: 3px 0;
  transition: var(--transition);
}

/* Hero Section */
.hero {
  min-height: 100vh;
  display: flex;
  align-items: center;
  padding: 100px 20px 50px;
  background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
  color: var(--white);
  position: relative;
  overflow: hidden;
}

.hero::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="50" cy="50" r="1" fill="white" opacity="0.1"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
  opacity: 0.3;
}

.hero-content {
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4rem;
  align-items: center;
  position: relative;
  z-index: 1;
}

.hero-title {
  font-size: 3.5rem;
  font-weight: 800;
  margin-bottom: 1.5rem;
  line-height: 1.2;
  animation: fadeInUp 1s ease-out;
}

.hero-subtitle {
  font-size: 1.3rem;
  margin-bottom: 2rem;
  opacity: 0.9;
  animation: fadeInUp 1s ease-out 0.2s both;
}

.hero-buttons {
  display: flex;
  gap: 1rem;
  animation: fadeInUp 1s ease-out 0.4s both;
}

.btn {
  display: inline-block;
  padding: 15px 30px;
  text-decoration: none;
  border-radius: 50px;
  font-weight: 600;
  transition: var(--transition);
  cursor: pointer;
  border: none;
  font-size: 1rem;
}

.btn-primary {
  background: var(--white);
  color: var(--primary-color);
  box-shadow: var(--shadow);
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-hover);
}

.btn-secondary {
  background: transparent;
  color: var(--white);
  border: 2px solid var(--white);
}

.btn-secondary:hover {
  background: var(--white);
  color: var(--primary-color);
}

.hero-image {
  text-align: center;
  animation: fadeInRight 1s ease-out 0.6s both;
}

.hero-image img {
  max-width: 100%;
  height: auto;
  border-radius: var(--border-radius);
  box-shadow: var(--shadow-hover);
}

/* About Section */
.about {
  padding: 100px 20px;
  background: var(--bg-light);
}

.about-content {
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4rem;
  align-items: center;
}

.about-text h2 {
  font-size: 2.5rem;
  margin-bottom: 2rem;
  color: var(--primary-color);
}

.about-text p {
  font-size: 1.1rem;
  margin-bottom: 2rem;
  line-height: 1.8;
}

.about-features {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
}

.feature {
  background: var(--white);
  padding: 2rem;
  border-radius: var(--border-radius);
  box-shadow: var(--shadow);
  transition: var(--transition);
}

.feature:hover {
  transform: translateY(-5px);
  box-shadow: var(--shadow-hover);
}

.feature-icon {
  font-size: 2rem;
  margin-bottom: 1rem;
}

.feature h3 {
  font-size: 1.3rem;
  margin-bottom: 1rem;
  color: var(--primary-color);
}

.about-image img {
  max-width: 100%;
  height: auto;
  border-radius: var(--border-radius);
  box-shadow: var(--shadow-hover);
}

/* Services Section */
.services {
  padding: 100px 20px;
  background: var(--white);
}

.services h2 {
  text-align: center;
  font-size: 2.5rem;
  margin-bottom: 3rem;
  color: var(--primary-color);
}

.services-grid {
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
}

.service-card {
  background: var(--bg-light);
  padding: 2.5rem;
  border-radius: var(--border-radius);
  text-align: center;
  box-shadow: var(--shadow);
  transition: var(--transition);
  position: relative;
  overflow: hidden;
}

.service-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 4px;
  background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
}

.service-card:hover {
  transform: translateY(-10px);
  box-shadow: var(--shadow-hover);
}

.service-icon {
  font-size: 3rem;
  margin-bottom: 1.5rem;
}

.service-card h3 {
  font-size: 1.5rem;
  margin-bottom: 1rem;
  color: var(--primary-color);
}

.service-card p {
  margin-bottom: 1.5rem;
  line-height: 1.6;
}

.service-price {
  font-size: 1.3rem;
  font-weight: 700;
  color: var(--accent-color);
  margin-bottom: 1.5rem;
}

.btn-service {
  background: var(--primary-color);
  color: var(--white);
  width: 100%;
}

.btn-service:hover {
  background: var(--secondary-color);
}

/* Contact Section */
.contact {
  padding: 100px 20px;
  background: linear-gradient(135deg, var(--bg-light), var(--white));
}

.contact-content {
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4rem;
}

.contact-info h2 {
  font-size: 2.5rem;
  margin-bottom: 2rem;
  color: var(--primary-color);
}

.contact-info p {
  font-size: 1.1rem;
  margin-bottom: 2rem;
  line-height: 1.8;
}

.contact-details {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.contact-item {
  background: var(--white);
  padding: 1.5rem;
  border-radius: var(--border-radius);
  box-shadow: var(--shadow);
}

.contact-item strong {
  color: var(--primary-color);
  display: block;
  margin-bottom: 0.5rem;
}

.contact-form {
  background: var(--white);
  padding: 2.5rem;
  border-radius: var(--border-radius);
  box-shadow: var(--shadow-hover);
}

.contact-form h3 {
  font-size: 1.8rem;
  margin-bottom: 2rem;
  color: var(--primary-color);
  text-align: center;
}

.form-group {
  margin-bottom: 1.5rem;
}

.form-group input,
.form-group textarea {
  width: 100%;
  padding: 15px;
  border: 2px solid #e0e0e0;
  border-radius: var(--border-radius);
  font-size: 1rem;
  transition: var(--transition);
  font-family: inherit;
}

.form-group input:focus,
.form-group textarea:focus {
  outline: none;
  border-color: var(--primary-color);
  box-shadow: 0 0 0 3px rgba(0, 0, 0, 0.1);
}

/* Footer */
.footer {
  background: var(--primary-color);
  color: var(--white);
  padding: 50px 20px 20px;
}

.footer-content {
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
  margin-bottom: 2rem;
}

.footer-section h3,
.footer-section h4 {
  margin-bottom: 1rem;
  color: var(--white);
}

.footer-section p {
  opacity: 0.9;
  line-height: 1.6;
}

.footer-section ul {
  list-style: none;
}

.footer-section ul li {
  margin-bottom: 0.5rem;
}

.footer-section ul li a {
  color: var(--white);
  text-decoration: none;
  opacity: 0.9;
  transition: var(--transition);
}

.footer-section ul li a:hover {
  opacity: 1;
}

.social-links {
  display: flex;
  gap: 1rem;
}

.social-link {
  display: inline-block;
  width: 40px;
  height: 40px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 50%;
  text-align: center;
  line-height: 40px;
  transition: var(--transition);
}

.social-link:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: translateY(-2px);
}

.footer-bottom {
  text-align: center;
  padding-top: 2rem;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  opacity: 0.8;
}

/* Animations */
@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes fadeInRight {
  from {
    opacity: 0;
    transform: translateX(30px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

/* Responsive Design */
@media (max-width: 768px) {
  .hamburger {
    display: flex;
  }
  
  .nav-menu {
    position: fixed;
    top: 70px;
    left: -100%;
    width: 100%;
    height: calc(100vh - 70px);
    background: var(--white);
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
    padding-top: 2rem;
    transition: var(--transition);
  }
  
  .nav-menu.active {
    left: 0;
  }
  
  .nav-menu li {
    margin: 1rem 0;
  }
  
  .hero-content {
    grid-template-columns: 1fr;
    text-align: center;
  }
  
  .hero-title {
    font-size: 2.5rem;
  }
  
  .hero-image {
    order: -1;
  }
  
  .about-content,
  .contact-content {
    grid-template-columns: 1fr;
  }
  
  .about-image {
    order: -1;
  }
  
  .services-grid {
    grid-template-columns: 1fr;
  }
  
  .hero-buttons {
    flex-direction: column;
    align-items: center;
  }
  
  .btn {
    width: 200px;
  }
}

@media (max-width: 480px) {
  .hero-title {
    font-size: 2rem;
  }
  
  .hero-subtitle {
    font-size: 1.1rem;
  }
  
  .about-text h2,
  .services h2,
  .contact-info h2 {
    font-size: 2rem;
  }
  
  .container {
    padding: 0 15px;
  }
  
  .service-card,
  .feature,
  .contact-form {
    padding: 1.5rem;
  }
}`,
          language: 'css'
        },
        {
          name: 'script.js',
          content: `// Premium Interactive Features for ${websiteConfig.brandName}
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 ${websiteConfig.brandName} website initialized successfully');
    
    // Mobile Navigation Toggle
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            hamburger.classList.toggle('active');
        });
        
        // Close mobile menu when clicking on a link
        document.querySelectorAll('.nav-menu a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('active');
                hamburger.classList.remove('active');
            });
        });
    }
    
    // Smooth Scrolling for Navigation Links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const headerOffset = 80;
                const elementPosition = target.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Navbar Scroll Effect
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                navbar.style.background = 'rgba(255, 255, 255, 0.98)';
                navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
            } else {
                navbar.style.background = 'rgba(255, 255, 255, 0.95)';
                navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
            }
        });
    }
    
    // Animated Counter for Statistics (if any)
    function animateCounter(element, target, duration = 2000) {
        let start = 0;
        const increment = target / (duration / 16);
        
        function updateCounter() {
            start += increment;
            if (start < target) {
                element.textContent = Math.floor(start);
                requestAnimationFrame(updateCounter);
            } else {
                element.textContent = target;
            }
            }
            updateCounter();
        }
        
        // Intersection Observer for Animations
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                    
                    // Animate elements with counter class
                    if (entry.target.classList.contains('counter')) {
                        const target = parseInt(entry.target.getAttribute('data-target'));
                        animateCounter(entry.target, target);
                    }
                }
            });
        }, observerOptions);
        
        // Observe all animated elements
        document.querySelectorAll('.animate-on-scroll').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(30px)';
            el.style.transition = 'all 0.6s ease-out';
            observer.observe(el);
        });
        
        // Contact Form Handling
        const contactForm = document.getElementById('contactForm');
        if (contactForm) {
            contactForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const formData = new FormData(this);
                const name = formData.get('name');
                const email = formData.get('email');
                const message = formData.get('message');
                
                // Basic validation
                if (name && email && message) {
                    // Show success message
                    showNotification('Thank you for your message! We\'ll get back to you soon.', 'success');
                    this.reset();
                } else {
                    showNotification('Please fill in all fields.', 'error');
                }
            });
        }
        
        // Service Card Click Handlers
        document.querySelectorAll('.btn-service').forEach(button => {
            button.addEventListener('click', function() {
                const serviceCard = this.closest('.service-card');
                const serviceName = serviceCard.querySelector('h3').textContent;
                showNotification(\`Learn more about \${serviceName} - Contact us for details!\`, 'info');
            });
        });
        
        // Notification System
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = \`notification \${type}\`;
            notification.innerHTML = \`
                <div class="notification-content">
                    <span class="notification-message">\${message}</span>
                    <button class="notification-close">&times;</button>
                </div>
            \`;
            
            // Add notification styles if not already added
            if (!document.querySelector('#notification-styles')) {
                const styles = document.createElement('style');
                styles.id = 'notification-styles';
                styles.textContent = \`
                    .notification {
                        position: fixed;
                        top: 20px;
                        right: 20px;
                        background: var(--white);
                        padding: 1rem 1.5rem;
                        border-radius: var(--border-radius);
                        box-shadow: var(--shadow-hover);
                        z-index: 10000;
                        transform: translateX(400px);
                        transition: transform 0.3s ease;
                        max-width: 300px;
                        border-left: 4px solid var(--primary-color);
                    }
                    
                    .notification.show {
                        transform: translateX(0);
                    }
                    
                    .notification.success {
                        border-left-color: #28a745;
                    }
                    
                    .notification.error {
                        border-left-color: #dc3545;
                    }
                    
                    .notification.info {
                        border-left-color: #17a2b8;
                    }
                    
                    .notification-content {
                        display: flex;
                        align-items: center;
                        justify-content: space-between;
                    }
                    
                    .notification-close {
                        background: none;
                        border: none;
                        font-size: 1.2rem;
                        cursor: pointer;
                        color: var(--text-light);
                    }
                \`;
                document.head.appendChild(styles);
            }
            
            document.body.appendChild(notification);
            
            // Show notification
            setTimeout(() => {
                notification.classList.add('show');
            }, 100);
            
            // Auto remove after 5 seconds
            setTimeout(() => {
                notification.classList.remove('show');
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 300);
            }, 5000);
            
            // Close button functionality
            const closeBtn = notification.querySelector('.notification-close');
            closeBtn.addEventListener('click', () => {
                notification.classList.remove('show');
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 300);
            });
        }
        
        // Parallax Effect for Hero Section
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const hero = document.querySelector('.hero');
            if (hero) {
                hero.style.transform = \`translateY(\${scrolled * 0.5}px)\`;
            }
        });
        
        // Lazy Loading for Images
        const images = document.querySelectorAll('img');
        const imageOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px 50px 0px'
        };
        
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.style.opacity = '0';
                    img.style.transition = 'opacity 0.5s ease-in-out';
                    
                    img.onload = () => {
                        img.style.opacity = '1';
                    };
                    
                    observer.unobserve(img);
                }
            });
        }, imageOptions);
        
        images.forEach(img => {
            imageObserver.observe(img);
        });
        
        // Add hover effects to cards
        document.querySelectorAll('.service-card, .feature').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-10px) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
            });
        });
        
        // Initialize tooltips if any
        document.querySelectorAll('[data-tooltip]').forEach(element => {
            element.addEventListener('mouseenter', function() {
                const tooltipText = this.getAttribute('data-tooltip');
                const tooltip = document.createElement('div');
                tooltip.className = 'tooltip';
                tooltip.textContent = tooltipText;
                document.body.appendChild(tooltip);
                
                const rect = this.getBoundingClientRect();
                tooltip.style.position = 'absolute';
                tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + 'px';
                tooltip.style.left = rect.left + (rect.width - tooltip.offsetWidth) / 2 + 'px';
                tooltip.style.background = 'rgba(0, 0, 0, 0.8)';
                tooltip.style.color = 'white';
                tooltip.style.padding = '5px 10px';
                tooltip.style.borderRadius = '4px';
                tooltip.style.fontSize = '12px';
                tooltip.style.whiteSpace = 'nowrap';
                tooltip.style.zIndex = '1000';
            });
            
            element.addEventListener('mouseleave', function() {
                const tooltip = document.querySelector('.tooltip');
                if (tooltip) {
                    tooltip.remove();
                }
            });
        });
        
        console.log('✅ All interactive features initialized for ${websiteConfig.brandName}');
        console.log('🎨 Premium animations and effects active');
        console.log('📱 Fully responsive design ready');
        console.log('🚀 Performance optimized');
    });
    
    // Error handling for missing elements
    window.addEventListener('error', function(e) {
        console.warn('Minor UI warning:', e.message);
    });
});`,
          language: 'javascript'
        }
      ],
      explanation: `Created a premium, professional ${websiteConfig.websiteType} website for: "${prompt}" with modern design, interactive features, and responsive layout. This is a high-quality, production-ready website that would impress clients and customers.`
    }
  }

  // Advanced website configuration based on prompt analysis
  getWebsiteConfig(lowerPrompt: string) {
    // Comprehensive prompt analysis for multiple website types
    if (lowerPrompt.includes('cafe') || lowerPrompt.includes('coffee') || lowerPrompt.includes('restaurant')) {
      return {
        websiteType: 'cafe-restaurant',
        brandName: 'Brew & Beans Cafe',
        title: 'Brew & Beans Cafe - Premium Coffee Experience',
        description: 'Experience the finest artisanal coffee and freshly baked pastries in a cozy, welcoming atmosphere.',
        keywords: 'coffee, cafe, artisanal, pastries, wifi, workspace, meetings',
        heroTitle: 'Welcome to Brew & Beans Cafe',
        heroSubtitle: 'Where every cup tells a story and every moment becomes a memory',
        primaryCTA: 'View Our Menu',
        secondaryCTA: 'Visit Us Today',
        imageSeed: 'coffeeshop-interior',
        aboutContent: 'At Brew & Beans Cafe, we\'re passionate about creating exceptional coffee experiences. From carefully selected beans to expertly crafted beverages, we ensure every visit is memorable. Our cozy atmosphere is perfect for work, meetings, or simply enjoying a quiet moment with your favorite brew.',
        features: [
          { title: 'Artisanal Coffee', description: 'Hand-crafted beverages made from premium, ethically sourced beans' },
          { title: 'Fresh Pastries', description: 'Daily baked goods made with locally sourced ingredients' },
          { title: 'Cozy Atmosphere', description: 'Comfortable seating perfect for work, study, or relaxation' },
          { title: 'Free WiFi', description: 'High-speed internet and power outlets for all guests' }
        ],
        servicesTitle: 'Signature Offerings',
        services: [
          { title: 'Specialty Coffee', description: 'Expertly crafted espresso drinks, pour-over coffee, and cold brew creations', price: 'From $3.50', icon: '☕' },
          { title: 'Artisan Pastries', description: 'Fresh croissants, muffins, cakes, and savory baked goods', price: 'From $2.50', icon: '🥐' },
          { title: 'Light Meals', description: 'Gourmet sandwiches, salads, and quiches made fresh daily', price: 'From $8.00', icon: '🥪' },
          { title: 'Catering', description: 'Custom catering for events, meetings, and special occasions', price: 'Custom Quote', icon: '🍽️' }
        ],
        contactDescription: 'We\'d love to hear from you! Whether you have questions about our menu, want to make a reservation, or are interested in our catering services, feel free to reach out.',
        address: '123 Coffee Street, Downtown District, City, State 12345',
        phone: '(555) 123-4567',
        email: 'hello@brewandbeanscafe.com',
        hours: 'Monday-Friday: 6:30 AM - 8:00 PM<br>Saturday-Sunday: 7:00 AM - 9:00 PM',
        footerDescription: 'Brew & Beans Cafe - Crafting exceptional coffee experiences since 2024.',
        primaryColor: '#6F4E37',
        secondaryColor: '#8B4513',
        accentColor: '#D2691E',
        textColor: '#333333',
        textLight: '#666666',
        bgColor: '#FFFFFF',
        bgLight: '#F5F5F5',
        fontFamily: 'Playfair+Display:wght@400;700&family=Inter:wght@300;400;500;600&display=swap'
      }
    }

    if (lowerPrompt.includes('portfolio') || lowerPrompt.includes('artist') || lowerPrompt.includes('designer')) {
      return {
        websiteType: 'portfolio',
        brandName: 'Creative Studio',
        title: 'Creative Studio - Portfolio & Design Works',
        description: 'Showcasing innovative design solutions and creative projects across multiple disciplines.',
        keywords: 'portfolio, design, creative, art, projects, freelance',
        heroTitle: 'Creative Excellence in Every Project',
        heroSubtitle: 'Transforming ideas into stunning visual experiences',
        primaryCTA: 'View My Work',
        secondaryCTA: 'Get In Touch',
        imageSeed: 'creative-portfolio',
        aboutContent: 'I am a passionate creative professional dedicated to delivering exceptional design solutions. With a keen eye for detail and a commitment to innovation, I help brands and individuals bring their vision to life through thoughtful, impactful design.',
        features: [
          { title: 'Creative Vision', description: 'Unique perspective and innovative approach to every project' },
          { title: 'Technical Expertise', description: 'Proficient in latest design tools and technologies' },
          { title: 'Client Collaboration', description: 'Partnership approach to ensure client satisfaction' },
          { title: 'Timely Delivery', description: 'Consistent on-time project completion' }
        ],
        servicesTitle: 'Services',
        services: [
          { title: 'UI/UX Design', description: 'User-centered design for digital products and applications', price: 'From $1,500', icon: '🎨' },
          { title: 'Brand Identity', description: 'Complete brand development and visual identity systems', price: 'From $2,000', icon: '🏷️' },
          { title: 'Web Design', description: 'Custom website design with modern responsive layouts', price: 'From $3,000', icon: '💻' },
          { title: 'Graphic Design', description: 'Print and digital graphics for marketing and communication', price: 'From $500', icon: '🖼️' }
        ],
        contactDescription: 'Ready to bring your creative vision to life? Let\'s collaborate on your next project.',
        address: '456 Creative Avenue, Arts District, City, State 12345',
        phone: '(555) 234-5678',
        email: 'hello@creativestudio.com',
        hours: 'Monday-Friday: 9:00 AM - 6:00 PM<br>Weekend: By Appointment',
        footerDescription: 'Creative Studio - Where imagination meets innovation.',
        primaryColor: '#2C3E50',
        secondaryColor: '#34495E',
        accentColor: '#E74C3C',
        textColor: '#2C3E50',
        textLight: '#7F8C8D',
        bgColor: '#FFFFFF',
        bgLight: '#F8F9FA',
        fontFamily: 'Poppins:wght@300;400;600;700&family=Montserrat:wght@300;400;600&display=swap'
      }
    }

    if (lowerPrompt.includes('ecommerce') || lowerPrompt.includes('shop') || lowerPrompt.includes('store')) {
      return {
        websiteType: 'ecommerce',
        brandName: 'Modern Shop',
        title: 'Modern Shop - Premium Online Shopping Experience',
        description: 'Discover curated collections of high-quality products with exceptional customer service.',
        keywords: 'ecommerce, shop, online, store, products, shopping',
        heroTitle: 'Shop Premium Products',
        heroSubtitle: 'Curated selection of quality items delivered to your doorstep',
        primaryCTA: 'Shop Now',
        secondaryCTA: 'New Arrivals',
        imageSeed: 'modern-ecommerce',
        aboutContent: 'Modern Shop is your destination for carefully curated products that combine quality, style, and value. We source the finest items from around the world to bring you an exceptional shopping experience.',
        features: [
          { title: 'Quality Guaranteed', description: 'Every product is carefully selected and tested for quality' },
          { title: 'Fast Shipping', description: 'Quick and reliable delivery to your doorstep' },
          { title: 'Secure Shopping', description: 'Advanced security for all your transactions' },
          { title: '24/7 Support', description: 'Round-the-clock customer service and assistance' }
        ],
        servicesTitle: 'Featured Categories',
        services: [
          { title: 'Electronics', description: 'Latest gadgets and tech accessories', price: 'From $49', icon: '📱' },
          { title: 'Fashion', description: 'Trendy clothing and accessories', price: 'From $29', icon: '👕' },
          { title: 'Home & Living', description: 'Beautiful items for your living space', price: 'From $19', icon: '🏠' },
          { title: 'Sports & Outdoors', description: 'Gear for your active lifestyle', price: 'From $39', icon: '⚽' }
        ],
        contactDescription: 'Have questions about our products or need help with your order? We\'re here to help!',
        address: '789 Commerce Street, Shopping District, City, State 12345',
        phone: '(555) 345-6789',
        email: 'support@modernshop.com',
        hours: 'Monday-Sunday: 24/7 Online<br>Customer Service: 9 AM - 9 PM',
        footerDescription: 'Modern Shop - Your trusted online shopping destination.',
        primaryColor: '#27AE60',
        secondaryColor: '#2ECC71',
        accentColor: '#3498DB',
        textColor: '#2C3E50',
        textLight: '#7F8C8D',
        bgColor: '#FFFFFF',
        bgLight: '#F8F9FA',
        fontFamily: 'Roboto:wght@300;400;500;700&family=Open+Sans:wght@300;400;600&display=swap'
      }
    }

    if (lowerPrompt.includes('blog') || lowerPrompt.includes('news') || lowerPrompt.includes('magazine')) {
      return {
        websiteType: 'blog-magazine',
        brandName: 'Insight Magazine',
        title: 'Insight Magazine - Stories That Matter',
        description: 'Delivering thought-provoking content and in-depth analysis on topics that shape our world.',
        keywords: 'blog, magazine, news, articles, stories, content',
        heroTitle: 'Discover Stories That Inspire',
        heroSubtitle: 'In-depth journalism and perspectives on the issues that matter',
        primaryCTA: 'Read Latest Articles',
        secondaryCTA: 'Subscribe Now',
        imageSeed: 'magazine-content',
        aboutContent: 'Insight Magazine is dedicated to providing high-quality journalism and thought-provoking content. Our team of experienced writers and contributors brings you in-depth analysis, compelling stories, and diverse perspectives on the topics shaping our world.',
        features: [
          { title: 'Quality Journalism', description: 'Well-researched, accurate, and balanced reporting' },
          { title: 'Diverse Perspectives', description: 'Multiple viewpoints and expert opinions' },
          { title: 'In-Depth Analysis', description: 'Comprehensive coverage of complex issues' },
          { title: 'Community Focus', description: 'Stories that matter to our local and global community' }
        ],
        servicesTitle: 'Featured Sections',
        services: [
          { title: 'Politics', description: 'Analysis and updates on political developments', price: 'Free', icon: '🏛️' },
          { title: 'Technology', description: 'Latest tech news and innovation insights', price: 'Free', icon: '💻' },
          { title: 'Culture', description: 'Arts, entertainment, and cultural commentary', price: 'Free', icon: '🎭' },
          { title: 'Business', description: 'Market trends and economic analysis', price: 'Free', icon: '💼' }
        ],
        contactDescription: 'Have a story tip or want to contribute? We\'d love to hear from you.',
        address: '321 Media Plaza, Press District, City, State 12345',
        phone: '(555) 456-7890',
        email: 'editor@insightmagazine.com',
        hours: 'Monday-Friday: 8:00 AM - 6:00 PM<br>Weekend: 10:00 AM - 4:00 PM',
        footerDescription: 'Insight Magazine - Journalism that informs and inspires.',
        primaryColor: '#C0392B',
        secondaryColor: '#E74C3C',
        accentColor: '#F39C12',
        textColor: '#2C3E50',
        textLight: '#7F8C8D',
        bgColor: '#FFFFFF',
        bgLight: '#F8F9FA',
        fontFamily: 'Merriweather:wght@300;400;700&family=Lato:wght@300;400;700&display=swap'
      }
    }

    if (lowerPrompt.includes('real estate') || lowerPrompt.includes('property') || lowerPrompt.includes('housing')) {
      return {
        websiteType: 'real-estate',
        brandName: 'Premier Properties',
        title: 'Premier Properties - Your Dream Home Awaits',
        description: 'Expert real estate services helping you find the perfect property for your needs.',
        keywords: 'real estate, property, housing, homes, apartments, realty',
        heroTitle: 'Find Your Perfect Home',
        heroSubtitle: 'Professional real estate services tailored to your needs',
        primaryCTA: 'View Properties',
        secondaryCTA: 'Free Consultation',
        imageSeed: 'luxury-real-estate',
        aboutContent: 'Premier Properties has been connecting families with their dream homes for over 15 years. Our team of experienced real estate professionals is committed to providing exceptional service and finding the perfect property match for each client.',
        features: [
          { title: 'Expert Agents', description: 'Licensed professionals with deep market knowledge' },
          { title: 'Extensive Listings', description: 'Wide range of properties in prime locations' },
          { title: 'Market Analysis', description: 'Comprehensive market insights and pricing strategies' },
          { title: 'Full Service', description: 'From search to closing, we handle everything' }
        ],
        servicesTitle: 'Property Types',
        services: [
          { title: 'Luxury Homes', description: 'High-end properties with premium amenities', price: 'From $1M+', icon: '🏰' },
          { title: 'Family Homes', description: 'Perfect properties for growing families', price: 'From $300K', icon: '🏡' },
          { title: 'Condos', description: 'Modern condominiums in urban locations', price: 'From $200K', icon: '🏢' },
          { title: 'Investment Properties', description: 'Properties with strong rental potential', price: 'Varies', icon: '📊' }
        ],
        contactDescription: 'Ready to find your dream property? Contact us for a personalized consultation.',
        address: '555 Real Estate Blvd, Business District, City, State 12345',
        phone: '(555) 567-8901',
        email: 'info@premierproperties.com',
        hours: 'Monday-Friday: 9:00 AM - 8:00 PM<br>Saturday-Sunday: 10:00 AM - 6:00 PM',
        footerDescription: 'Premier Properties - Making dreams of home ownership a reality.',
        primaryColor: '#8E44AD',
        secondaryColor: '#9B59B6',
        accentColor: '#3498DB',
        textColor: '#2C3E50',
        textLight: '#7F8C8D',
        bgColor: '#FFFFFF',
        bgLight: '#F8F9FA',
        fontFamily: 'Playfair+Display:wght@400;700&family=Raleway:wght@300;400;600&display=swap'
      }
    }

    if (lowerPrompt.includes('fitness') || lowerPrompt.includes('gym') || lowerPrompt.includes('health')) {
      return {
        websiteType: 'fitness-health',
        brandName: 'FitLife Center',
        title: 'FitLife Center - Transform Your Health',
        description: 'Comprehensive fitness and wellness programs designed to help you achieve your health goals.',
        keywords: 'fitness, gym, health, wellness, exercise, training',
        heroTitle: 'Transform Your Body, Transform Your Life',
        heroSubtitle: 'Professional fitness training and wellness programs for all levels',
        primaryCTA: 'Start Your Journey',
        secondaryCTA: 'Free Trial',
        imageSeed: 'fitness-center',
        aboutContent: 'FitLife Center is more than just a gym - it\'s a comprehensive wellness destination. Our certified trainers and state-of-the-art facilities provide everything you need to achieve your fitness goals and maintain a healthy lifestyle.',
        features: [
          { title: 'Expert Trainers', description: 'Certified professionals with diverse expertise' },
          { title: 'Modern Equipment', description: 'Latest fitness technology and facilities' },
          { title: 'Personalized Plans', description: 'Custom programs tailored to your goals' },
          { title: 'Community Support', description: 'Motivating environment with like-minded members' }
        ],
        servicesTitle: 'Our Programs',
        services: [
          { title: 'Personal Training', description: 'One-on-one coaching with certified trainers', price: 'From $75/session', icon: '💪' },
          { title: 'Group Classes', description: 'Energetic group fitness sessions', price: 'From $25/class', icon: '👥' },
          { title: 'Nutrition Coaching', description: 'Personalized nutrition plans and guidance', price: 'From $100/session', icon: '🥗' },
          { title: 'Wellness Programs', description: 'Holistic health and wellness services', price: 'From $50/session', icon: '🧘' }
        ],
        contactDescription: 'Ready to start your fitness journey? Contact us for a free consultation and facility tour.',
        address: '888 Fitness Way, Health District, City, State 12345',
        phone: '(555) 678-9012',
        email: 'info@fitlifecenter.com',
        hours: 'Monday-Friday: 5:00 AM - 10:00 PM<br>Saturday-Sunday: 6:00 AM - 8:00 PM',
        footerDescription: 'FitLife Center - Your partner in health and wellness.',
        primaryColor: '#E74C3C',
        secondaryColor: '#C0392B',
        accentColor: '#F39C12',
        textColor: '#2C3E50',
        textLight: '#7F8C8D',
        bgColor: '#FFFFFF',
        bgLight: '#F8F9FA',
        fontFamily: 'Oswald:wght@400;600;700&family=Roboto:wght@300;400;500&display=swap'
      }
    }

    if (lowerPrompt.includes('education') || lowerPrompt.includes('school') || lowerPrompt.includes('learning')) {
      return {
        websiteType: 'education',
        brandName: 'Excellence Academy',
        title: 'Excellence Academy - Empowering Through Education',
        description: 'Providing quality education and learning opportunities for students of all ages.',
        keywords: 'education, school, learning, academy, courses, training',
        heroTitle: 'Unlock Your Potential',
        heroSubtitle: 'Quality education and personalized learning experiences',
        primaryCTA: 'Explore Programs',
        secondaryCTA: 'Apply Now',
        imageSeed: 'education-campus',
        aboutContent: 'Excellence Academy is dedicated to providing high-quality education that prepares students for success in their chosen fields. Our experienced faculty and comprehensive curriculum ensure that every student receives the knowledge and skills needed to excel.',
        features: [
          { title: 'Expert Faculty', description: 'Experienced educators with real-world expertise' },
          { title: 'Modern Curriculum', description: 'Up-to-date programs aligned with industry needs' },
          { title: 'Small Classes', description: 'Personalized attention and interactive learning' },
          { title: 'Career Support', description: 'Job placement assistance and career guidance' }
        ],
        servicesTitle: 'Academic Programs',
        services: [
          { title: 'Business Studies', description: 'Comprehensive business and management courses', price: 'From $5,000/term', icon: '💼' },
          { title: 'Technology', description: 'Cutting-edge IT and computer science programs', price: 'From $6,000/term', icon: '💻' },
          { title: 'Arts & Design', description: 'Creative programs for artistic development', price: 'From $4,500/term', icon: '🎨' },
          { title: 'Languages', description: 'Comprehensive language and communication courses', price: 'From $3,000/term', icon: '🌍' }
        ],
        contactDescription: 'Interested in joining our academic community? Contact our admissions office for more information.',
        address: '999 Education Lane, Academic District, City, State 12345',
        phone: '(555) 789-0123',
        email: 'admissions@excellenceacademy.com',
        hours: 'Monday-Friday: 8:00 AM - 6:00 PM<br>Saturday: 9:00 AM - 2:00 PM',
        footerDescription: 'Excellence Academy - Shaping tomorrow\'s leaders today.',
        primaryColor: '#2980B9',
        secondaryColor: '#3498DB',
        accentColor: '#1ABC9C',
        textColor: '#2C3E50',
        textLight: '#7F8C8D',
        bgColor: '#FFFFFF',
        bgLight: '#F8F9FA',
        fontFamily: 'Source+Sans+Pro:wght@300;400;600;700&family=Roboto:wght@300;400;500&display=swap'
      }
    }

    if (lowerPrompt.includes('travel') || lowerPrompt.includes('tourism') || lowerPrompt.includes('vacation')) {
      return {
        websiteType: 'travel-tourism',
        brandName: 'Wanderlust Travels',
        title: 'Wanderlust Travels - Discover the World',
        description: 'Expert travel planning and tour services to help you explore the world\'s most amazing destinations.',
        keywords: 'travel, tourism, vacation, tours, destinations, adventures',
        heroTitle: 'Explore the World with Confidence',
        heroSubtitle: 'Expertly crafted travel experiences to amazing destinations',
        primaryCTA: 'Book Your Trip',
        secondaryCTA: 'View Destinations',
        imageSeed: 'travel-destination',
        aboutContent: 'Wanderlust Travels is your trusted partner in discovering the world. With years of experience and a passion for travel, we create unforgettable experiences that combine adventure, culture, and relaxation in perfect harmony.',
        features: [
          { title: 'Expert Planners', description: 'Experienced travel consultants with global knowledge' },
          { title: 'Best Value', description: 'Competitive prices without compromising quality' },
          { title: '24/7 Support', description: 'Travel assistance whenever you need it' },
          { title: 'Custom Itineraries', description: 'Personalized trips tailored to your preferences' }
        ],
        servicesTitle: 'Travel Services',
        services: [
          { title: 'International Tours', description: 'Guided tours to international destinations', price: 'From $1,500', icon: '✈️' },
          { title: 'Domestic Getaways', description: 'Local and regional travel experiences', price: 'From $500', icon: '🚗' },
          { title: 'Adventure Travel', description: 'Thrilling outdoor and adventure experiences', price: 'From $800', icon: '🏔️' },
          { title: 'Luxury Travel', description: 'Premium travel experiences and accommodations', price: 'From $3,000', icon: '⭐' }
        ],
        contactDescription: 'Ready to plan your next adventure? Let us help you create the perfect travel experience.',
        address: '222 Travel Plaza, Tourism District, City, State 12345',
        phone: '(555) 890-1234',
        email: 'info@wanderlusttravels.com',
        hours: 'Monday-Friday: 9:00 AM - 7:00 PM<br>Saturday: 10:00 AM - 4:00 PM',
        footerDescription: 'Wanderlust Travels - Your journey begins here.',
        primaryColor: '#16A085',
        secondaryColor: '#1ABC9C',
        accentColor: '#F39C12',
        textColor: '#2C3E50',
        textLight: '#7F8C8D',
        bgColor: '#FFFFFF',
        bgLight: '#F8F9FA',
        fontFamily: 'Nunito:wght@300;400;600;700&family=Open+Sans:wght@300;400;600&display=swap'
      }
    }
    
    // Default business configuration
    return {
      websiteType: 'business',
      brandName: 'Professional Services',
      title: 'Professional Services - Excellence in Every Aspect',
      description: 'Providing top-quality professional services tailored to meet your specific needs.',
      keywords: 'professional, services, business, quality, expertise',
      heroTitle: 'Excellence in Professional Services',
      heroSubtitle: 'Dedicated to delivering outstanding results for our clients',
      primaryCTA: 'Our Services',
      secondaryCTA: 'Contact Us',
      imageSeed: 'professional-business',
      aboutContent: 'We are committed to providing exceptional professional services that exceed expectations and drive success for our clients.',
      features: [
        { title: 'Expert Team', description: 'Highly skilled professionals with years of experience' },
        { title: 'Quality Assurance', description: 'Rigorous quality control processes ensure excellence' },
        { title: 'Client Focus', description: 'Tailored solutions to meet specific client needs' },
        { title: 'Innovation', description: 'Cutting-edge approaches and methodologies' }
      ],
      servicesTitle: 'Our Services',
      services: [
        { title: 'Consulting', description: 'Expert advice and strategic guidance', price: 'Contact Us', icon: '💼' },
        { title: 'Implementation', description: 'Professional execution of projects', price: 'Custom Quote', icon: '🔧' },
        { title: 'Support', description: 'Ongoing maintenance and assistance', price: 'From $99/mo', icon: '🛟' },
        { title: 'Training', description: 'Comprehensive training programs', price: 'Contact Us', icon: '📚' }
      ],
      contactDescription: 'Ready to elevate your business? Contact us today for a consultation.',
      address: '123 Business Street, Commercial District, City, State 12345',
      phone: '(555) 987-6543',
      email: 'info@professionalservices.com',
      hours: 'Monday-Friday: 9:00 AM - 6:00 PM<br>Saturday: 10:00 AM - 4:00 PM',
      footerDescription: 'Professional Services - Your partner in success.',
      primaryColor: '#2C3E50',
      secondaryColor: '#34495E',
      accentColor: '#3498DB',
      textColor: '#333333',
      textLight: '#666666',
      bgColor: '#FFFFFF',
      bgLight: '#F8F9FA',
      fontFamily: 'Montserrat:wght@300;400;600;700&family=Open+Sans:wght@300;400;600&display=swap'
    }
  }
}

// Initialize the webpage generator
const webpageGenerator = new WebpageGenerator()

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { prompt, type, context } = body
    
    if (!prompt) {
      return NextResponse.json({
        success: false,
        error: 'Prompt is required'
      }, { status: 400 })
    }

    console.log(`[AI-Prompt API] 🚀 Processing prompt: "${prompt}"`)

    try {
      // Try to generate with OpenRouter API first
      const result = await webpageGenerator.generateWebpage(prompt)

      console.log('[AI-Prompt API] ✅ Webpage generation completed successfully')
      console.log(`[AI-Prompt API] 📁 Created ${result.files.length} files: ${result.files.map(f => f.name).join(', ')}`)

      return NextResponse.json({
        success: true,
        files: result.files,
        explanation: result.explanation
      })

    } catch (aiError) {
      console.error('[AI-Prompt API] ❌ AI generation failed:', aiError)
      
      // Always provide professional fallback
      const fallbackResult = webpageGenerator.createFallbackWebpage(prompt)
      
      return NextResponse.json({
        success: true,
        files: fallbackResult.files,
        explanation: fallbackResult.explanation + ' (Using professional fallback template)'
      })
    }

  } catch (error) {
    console.error('[AI-Prompt API] ❌ Unexpected error:', error)
    
    // Even in unexpected errors, provide fallback
    try {
      const body = await request.json()
      const prompt = body.prompt || 'website'
      const fallbackResult = webpageGenerator.createFallbackWebpage(prompt)
      
      return NextResponse.json({
        success: true,
        files: fallbackResult.files,
        explanation: fallbackResult.explanation + ' (Emergency fallback)'
      })
    } catch {
      // Ultimate fallback if even parsing fails
      return NextResponse.json({
        success: true,
        files: webpageGenerator.createFallbackWebpage('website').files,
        explanation: 'Ultimate fallback webpage created'
      })
    }
  }
}