'use client'

import { useState, useEffect, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from '@/components/ui/resizable'
import { 
  Play, 
  Square, 
  Save, 
  FolderOpen, 
  FileText, 
  Settings, 
  Bot, 
  CheckCircle, 
  AlertCircle,
  Code,
  Terminal,
  ListTodo,
  Sparkles,
  Plus,
  Send,
  Eye,
  Loader2,
  Maximize,
  Minimize
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface File {
  id: string
  name: string
  content: string
  language: string
  lastModified: Date
}

interface Task {
  id: string
  title: string
  description: string
  status: 'pending' | 'in_progress' | 'completed' | 'error'
  priority: 'high' | 'medium' | 'low'
  createdAt: Date
}

interface ConsoleOutput {
  id: string
  type: 'log' | 'error' | 'success' | 'info'
  message: string
  timestamp: Date
}

interface PromptResponse {
  success: boolean
  html?: string
  css?: string
  javascript?: string
  explanation?: string
  error?: string
  files?: {
    name: string
    content: string
    language: string
  }[]
}

export default function AIDeIDE() {
  const [files, setFiles] = useState<File[]>([
    {
      id: '1',
      name: 'index.html',
      content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Generated Webpage</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div id="app">
        <h1>Welcome to AI-IDE</h1>
        <p>Enter a prompt below to generate a complete webpage</p>
    </div>
    <script src="script.js"></script>
</body>
</html>`,
      language: 'html',
      lastModified: new Date()
    },
    {
      id: '2',
      name: 'styles.css',
      content: `/* AI-Generated Styles */
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
    background-color: #f5f5f5;
}

#app {
    max-width: 800px;
    margin: 0 auto;
    background: white;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

h1 {
    color: #333;
    text-align: center;
}

p {
    color: #666;
    text-align: center;
    font-size: 18px;
}`,
      language: 'css',
      lastModified: new Date()
    },
    {
      id: '3',
      name: 'script.js',
      content: `// AI-Generated JavaScript
console.log('AI-IDE Initialized');

document.addEventListener('DOMContentLoaded', function() {
    console.log('Page loaded successfully');
    
    // Add any interactive functionality here
    const app = document.getElementById('app');
    if (app) {
        app.addEventListener('click', function(e) {
            console.log('App clicked');
        });
    }
});`,
      language: 'javascript',
      lastModified: new Date()
    }
  ])
  
  const [activeFile, setActiveFile] = useState<string>('1')
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: '1',
      title: 'Initialize AI-IDE system',
      description: 'Set up the development environment and initialize all components',
      status: 'completed',
      priority: 'high',
      createdAt: new Date()
    },
    {
      id: '2',
      title: 'Configure AI processing engine',
      description: 'Set up the AI backend for prompt processing and code generation',
      status: 'completed',
      priority: 'high',
      createdAt: new Date()
    },
    {
      id: '3',
      title: 'Ready for user prompts',
      description: 'System is ready to process any user prompt and generate complete webpages',
      status: 'pending',
      priority: 'medium',
      createdAt: new Date()
    }
  ])
  
  const [consoleOutput, setConsoleOutput] = useState<ConsoleOutput[]>([
    {
      id: '1',
      type: 'info',
      message: 'AI-IDE Clone System Initialized Successfully',
      timestamp: new Date()
    },
    {
      id: '2',
      type: 'success',
      message: 'AI Processing Engine Ready - Enter any prompt to generate complete webpage',
      timestamp: new Date()
    },
    {
      id: '3',
      type: 'info',
      message: 'System supports: HTML, CSS, JavaScript generation with real-time preview',
      timestamp: new Date()
    }
  ])

  const [isRunning, setIsRunning] = useState(false)
  const [aiMode, setAiMode] = useState<'assist' | 'auto' | 'learn'>('auto')
  const [prompt, setPrompt] = useState('')
  const [showPreview, setShowPreview] = useState(false)
  const [previewContent, setPreviewContent] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const { toast } = useToast()

  const currentFile = files.find(f => f.id === activeFile)

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen)
  }

  const updateFileContent = (fileId: string, content: string) => {
    setFiles(files.map(file => 
      file.id === fileId 
        ? { ...file, content, lastModified: new Date() }
        : file
    ))
  }

  const addConsoleOutput = (type: ConsoleOutput['type'], message: string) => {
    const newOutput: ConsoleOutput = {
      id: Date.now().toString(),
      type,
      message,
      timestamp: new Date()
    }
    setConsoleOutput(prev => [...prev, newOutput])
  }

  const runCode = async () => {
    if (!currentFile) return
    
    setIsRunning(true)
    addConsoleOutput('info', `Running ${currentFile.name}...`)
    
    try {
      // Simulate code execution
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      if (currentFile.language === 'javascript') {
        addConsoleOutput('success', 'JavaScript code executed successfully')
        addConsoleOutput('log', 'AI-IDE system operational')
      } else if (currentFile.language === 'html') {
        addConsoleOutput('success', 'HTML page rendered successfully')
        updatePreview()
      } else {
        addConsoleOutput('success', `${currentFile.name} processed successfully`)
      }
      
      toast({
        title: "Code Executed",
        description: `${currentFile.name} ran successfully`,
      })
    } catch (error) {
      addConsoleOutput('error', `Error: ${error}`)
      toast({
        title: "Execution Failed",
        description: "There was an error running your code",
        variant: "destructive"
      })
    } finally {
      setIsRunning(false)
    }
  }

  const updatePreview = () => {
    const htmlFile = files.find(f => f.language === 'html')
    const cssFile = files.find(f => f.language === 'css')
    const jsFile = files.find(f => f.language === 'javascript')
    
    if (htmlFile) {
      let preview = htmlFile.content
      
      // Inject CSS if exists
      if (cssFile) {
        preview = preview.replace(
          '</head>',
          `<style>${cssFile.content}</style></head>`
        )
      }
      
      // Inject JavaScript if exists
      if (jsFile) {
        preview = preview.replace(
          '</body>',
          `<script>${jsFile.content}</script></body>`
        )
      }
      
      setPreviewContent(preview)
    }
  }

  const generateFromPrompt = async () => {
    if (!prompt.trim()) {
      addConsoleOutput('error', 'Please enter a prompt to generate webpage')
      return
    }
    
    setIsGenerating(true)
    addConsoleOutput('info', `Processing prompt: "${prompt}"`)
    addConsoleOutput('info', 'AI analyzing prompt and generating complete webpage...')
    
    try {
      const response = await fetch('/api/ai-prompt', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: prompt,
          type: 'complete-webpage'
        })
      })
      
      const data: PromptResponse = await response.json()
      
      if (data.success && data.files) {
        // Clear existing files and add new ones
        const newFiles: File[] = []
        
        data.files.forEach((fileData, index) => {
          newFiles.push({
            id: (index + 1).toString(),
            name: fileData.name,
            content: fileData.content,
            language: fileData.language,
            lastModified: new Date()
          })
        })
        
        setFiles(newFiles)
        setActiveFile('1') // Select first file (usually HTML)
        
        // Add console outputs
        addConsoleOutput('success', `✅ Complete webpage generated successfully!`)
        addConsoleOutput('info', `📁 Generated ${data.files.length} files:`)
        
        data.files.forEach(file => {
          addConsoleOutput('info', `   - ${file.name} (${file.language})`)
        })
        
        if (data.explanation) {
          addConsoleOutput('success', `🤖 AI Explanation: ${data.explanation}`)
        }
        
        // Update preview
        setTimeout(() => {
          updatePreview()
          setShowPreview(true)
        }, 500)
        
        // Add completion task
        const completionTask: Task = {
          id: Date.now().toString(),
          title: `Generated: ${prompt.substring(0, 50)}${prompt.length > 50 ? '...' : ''}`,
          description: `Complete webpage generated from prompt: "${prompt}"`,
          status: 'completed',
          priority: 'high',
          createdAt: new Date()
        }
        
        setTasks(prev => [...prev, completionTask])
        
        toast({
          title: "Webpage Generated Successfully",
          description: `Created ${data.files.length} files from your prompt`,
        })
        
      } else {
        addConsoleOutput('error', `❌ Generation failed: ${data.error || 'Unknown error'}`)
        toast({
          title: "Generation Failed",
          description: data.error || "Failed to generate webpage",
          variant: "destructive"
        })
      }
    } catch (error) {
      addConsoleOutput('error', `❌ Failed to connect to AI services: ${error}`)
      toast({
        title: "Connection Error",
        description: "Failed to connect to AI generation service",
        variant: "destructive"
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const createNewFile = () => {
    const newFile: File = {
      id: Date.now().toString(),
      name: `new-file-${files.length + 1}.html`,
      content: '<!-- New file created by AI-IDE -->\n',
      language: 'html',
      lastModified: new Date()
    }
    setFiles([...files, newFile])
    setActiveFile(newFile.id)
    addConsoleOutput('info', `Created ${newFile.name}`)
  }

  const updateTaskStatus = (taskId: string, status: Task['status']) => {
    setTasks(tasks.map(task => 
      task.id === taskId ? { ...task, status } : task
    ))
  }

  const getStatusColor = (status: Task['status']) => {
    switch (status) {
      case 'completed': return 'bg-green-500'
      case 'in_progress': return 'bg-blue-500'
      case 'error': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  const getPriorityColor = (priority: Task['priority']) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800'
      case 'medium': return 'bg-yellow-100 text-yellow-800'
      case 'low': return 'bg-green-100 text-green-800'
    }
  }

  useEffect(() => {
    updatePreview()
  }, [files])

  return (
    <div className="h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <Bot className="h-6 w-6 text-primary" />
            <h1 className="text-xl font-bold">AI-IDE Clone - Complete Webpage Generator</h1>
          </div>
          
          <div className="flex items-center gap-2">
            <Badge variant={aiMode === 'auto' ? 'default' : 'secondary'}>
              {aiMode === 'assist' ? 'AI Assist' : aiMode === 'auto' ? 'AI Auto' : 'AI Learn'}
            </Badge>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => setAiMode(aiMode === 'assist' ? 'auto' : aiMode === 'auto' ? 'learn' : 'assist')}
            >
              <Sparkles className="h-4 w-4 mr-2" />
              Switch Mode
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <ResizablePanelGroup direction="horizontal">
        {/* File Explorer */}
        <ResizablePanel defaultSize={15} minSize={15}>
          <Card className="h-full rounded-none border-0">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <FolderOpen className="h-4 w-4" />
                File Explorer
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[calc(100vh-120px)]">
                <div className="p-2 space-y-1">
                  {files.map((file) => (
                    <div
                      key={file.id}
                      className={`p-2 rounded cursor-pointer hover:bg-accent text-sm flex items-center gap-2 ${
                        activeFile === file.id ? 'bg-accent' : ''
                      }`}
                      onClick={() => setActiveFile(file.id)}
                    >
                      <FileText className="h-4 w-4" />
                      <span className="truncate">{file.name}</span>
                      <Badge variant="outline" className="text-xs ml-auto">
                        {file.language}
                      </Badge>
                    </div>
                  ))}
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start mt-2"
                    onClick={createNewFile}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    New File
                  </Button>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </ResizablePanel>

        <ResizableHandle withHandle />

        {/* Code Editor */}
        <ResizablePanel defaultSize={45}>
          <div className="h-full flex flex-col">
            {/* Editor Header */}
            <div className="border-b bg-card p-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Code className="h-4 w-4" />
                <span className="font-medium">{currentFile?.name}</span>
                <Badge variant="outline">{currentFile?.language}</Badge>
              </div>
              
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowPreview(!showPreview)}
                >
                  <Eye className="h-4 w-4 mr-2" />
                  {showPreview ? 'Hide Preview' : 'Show Preview'}
                </Button>
                
                <Button
                  variant="default"
                  size="sm"
                  onClick={runCode}
                  disabled={isRunning}
                >
                  {isRunning ? (
                    <>
                      <Square className="h-4 w-4 mr-2" />
                      Stop
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4 mr-2" />
                      Run
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Editor Content */}
            <div className="flex-1 p-4">
              <Textarea
                value={currentFile?.content || ''}
                onChange={(e) => updateFileContent(currentFile.id, e.target.value)}
                className="h-full font-mono text-sm resize-none border-0 focus:ring-0"
                placeholder="Start coding..."
              />
            </div>
          </div>
        </ResizablePanel>

        <ResizableHandle withHandle />

        {/* Right Panel */}
        <ResizablePanel defaultSize={40}>
          <Tabs defaultValue="prompt" className="h-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="prompt" className="text-xs">
                <Send className="h-4 w-4 mr-2" />
                Prompt
              </TabsTrigger>
              <TabsTrigger value="preview" className="text-xs">
                <Eye className="h-4 w-4 mr-2" />
                Preview
              </TabsTrigger>
              <TabsTrigger value="console" className="text-xs">
                <Terminal className="h-4 w-4 mr-2" />
                Console
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="prompt" className="m-0">
              <Card className="h-full rounded-none border-0">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm">AI Prompt Generator</CardTitle>
                  <p className="text-xs text-muted-foreground">
                    Enter any prompt to generate a complete webpage
                  </p>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="p-4 space-y-4 h-full flex flex-col">
                    <div className="flex-1">
                      <Textarea
                        placeholder="Enter your prompt here... (e.g., 'Create me a complete todo list webpage')"
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        className="h-full min-h-[200px] resize-none"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Button
                        onClick={generateFromPrompt}
                        disabled={isGenerating || !prompt.trim()}
                        className="w-full"
                      >
                        {isGenerating ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Generating...
                          </>
                        ) : (
                          <>
                            <Sparkles className="h-4 w-4 mr-2" />
                            Generate Complete Webpage
                          </>
                        )}
                      </Button>
                      
                      <div className="text-xs text-muted-foreground text-center">
                        🤖 AI will generate HTML, CSS, and JavaScript files
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="preview" className="m-0">
              <Card className="h-full rounded-none border-0">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center justify-between">
                    <span>Live Preview</span>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={updatePreview}
                        className="text-xs"
                      >
                        Refresh
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={toggleFullscreen}
                        className="text-xs"
                      >
                        {isFullscreen ? (
                          <>
                            <Minimize className="h-3 w-3 mr-1" />
                            Exit Fullscreen
                          </>
                        ) : (
                          <>
                            <Maximize className="h-3 w-3 mr-1" />
                            Fullscreen
                          </>
                        )}
                      </Button>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="h-full">
                    {previewContent ? (
                      <>
                        <iframe
                          srcDoc={previewContent}
                          className={`w-full h-full border-0 ${isFullscreen ? 'hidden' : 'block'}`}
                          title="Webpage Preview"
                          sandbox="allow-scripts allow-same-origin"
                        />
                        
                        {/* Fullscreen Modal */}
                        {isFullscreen && (
                          <div className="fixed inset-0 z-50 bg-black bg-opacity-90 flex items-center justify-center">
                            <div className="relative w-full h-full">
                              <Button
                                variant="secondary"
                                size="sm"
                                onClick={toggleFullscreen}
                                className="absolute top-4 right-4 z-10"
                              >
                                <Minimize className="h-4 w-4 mr-2" />
                                Exit Fullscreen
                              </Button>
                              <iframe
                                srcDoc={previewContent}
                                className="w-full h-full border-0"
                                title="Fullscreen Webpage Preview"
                                sandbox="allow-scripts allow-same-origin"
                              />
                            </div>
                          </div>
                        )}
                      </>
                    ) : (
                      <div className="flex items-center justify-center h-full text-muted-foreground">
                        <div className="text-center">
                          <Eye className="h-12 w-12 mx-auto mb-4 opacity-50" />
                          <p>Generate a webpage to see preview</p>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="console" className="m-0">
              <Card className="h-full rounded-none border-0">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center justify-between">
                    <span>Console Output</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setConsoleOutput([])}
                      className="text-xs"
                    >
                      Clear
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <ScrollArea className="h-[calc(100vh-180px)]">
                    <div className="p-3 space-y-2 font-mono text-xs">
                      {consoleOutput.map((output) => (
                        <div key={output.id} className="flex items-start gap-2">
                          {output.type === 'error' && <AlertCircle className="h-3 w-3 text-red-500 mt-0.5" />}
                          {output.type === 'success' && <CheckCircle className="h-3 w-3 text-green-500 mt-0.5" />}
                          {output.type === 'info' && <div className="w-3 h-3 bg-blue-500 rounded-full mt-0.5" />}
                          {output.type === 'log' && <div className="w-3 h-3 bg-gray-400 rounded-full mt-0.5" />}
                          <span className={`${
                            output.type === 'error' ? 'text-red-500' :
                            output.type === 'success' ? 'text-green-500' :
                            output.type === 'info' ? 'text-blue-500' :
                            'text-foreground'
                          }`}>
                            {output.message}
                          </span>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </ResizablePanel>
      </ResizablePanelGroup>
    </div>
  )
}