import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

interface CodeGenerationRequest {
  prompt: string
  language: string
  context?: string
  type: 'generate' | 'improve' | 'refactor' | 'complete'
  currentCode?: string
}

interface CodeGenerationResponse {
  success: boolean
  generatedCode?: string
  explanation?: string
  improvements?: string[]
  error?: string
}

export async function POST(request: NextRequest) {
  try {
    const body: CodeGenerationRequest = await request.json()
    const { prompt, language, context, type, currentCode } = body
    
    if (!prompt || !language) {
      return NextResponse.json({
        success: false,
        error: 'Prompt and language are required'
      }, { status: 400 })
    }

    const zai = await ZAI.create()
    
    let systemPrompt = ''
    let userPrompt = ''

    switch (type) {
      case 'generate':
        systemPrompt = `You are an expert ${language} developer. Generate clean, efficient, and well-documented code based on the user's request. Follow best practices and include appropriate error handling.`
        userPrompt = `Generate ${language} code for: ${prompt}${context ? `\n\nContext: ${context}` : ''}`
        break
        
      case 'improve':
        systemPrompt = `You are an expert ${language} developer specializing in code optimization and improvement. Analyze the provided code and suggest improvements for better performance, readability, and maintainability.`
        userPrompt = `Improve this ${language} code:\n\n${currentCode}\n\nImprovements needed: ${prompt}`
        break
        
      case 'refactor':
        systemPrompt = `You are an expert ${language} developer specializing in code refactoring. Refactor the provided code to improve its structure, efficiency, and maintainability while preserving its functionality.`
        userPrompt = `Refactor this ${language} code:\n\n${currentCode}\n\nRefactoring goals: ${prompt}`
        break
        
      case 'complete':
        systemPrompt = `You are an expert ${language} developer. Complete the partial code by providing the most logical and efficient implementation based on the context and requirements.`
        userPrompt = `Complete this ${language} code:\n\n${currentCode}\n\nComplete the code to: ${prompt}`
        break
        
      default:
        return NextResponse.json({
          success: false,
          error: 'Invalid generation type'
        }, { status: 400 })
    }

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: systemPrompt
        },
        {
          role: 'user',
          content: userPrompt
        }
      ],
      temperature: 0.7,
      max_tokens: 2000
    })

    const generatedContent = completion.choices[0]?.message?.content
    
    if (!generatedContent) {
      return NextResponse.json({
        success: false,
        error: 'Failed to generate code'
      }, { status: 500 })
    }

    // Parse the response to extract code and explanation
    const { code, explanation, improvements } = parseGeneratedContent(generatedContent, type)

    return NextResponse.json({
      success: true,
      generatedCode: code,
      explanation,
      improvements
    })

  } catch (error) {
    console.error('Code generation error:', error)
    return NextResponse.json({
      success: false,
      error: 'Failed to generate code'
    }, { status: 500 })
  }
}

function parseGeneratedContent(content: string, type: string): {
  code: string
  explanation: string
  improvements: string[]
} {
  let code = ''
  let explanation = ''
  const improvements: string[] = []

  // Extract code blocks (marked with ``` or similar)
  const codeBlockRegex = /```(?:\w+)?\n([\s\S]*?)```/g
  const codeBlocks = content.match(codeBlockRegex)
  
  if (codeBlocks && codeBlocks.length > 0) {
    code = codeBlocks[0].replace(/```(?:\w+)?\n?/g, '').replace(/```$/, '').trim()
  } else {
    // If no code blocks, try to extract code from the content
    const lines = content.split('\n')
    const codeLines: string[] = []
    let inCode = false
    
    for (const line of lines) {
      if (line.includes('```')) {
        inCode = !inCode
        continue
      }
      if (inCode || line.match(/^\s*(function|const|let|var|class|import|export|if|for|while|switch|try|catch)\s/)) {
        codeLines.push(line)
      }
    }
    
    if (codeLines.length > 0) {
      code = codeLines.join('\n')
    } else {
      // If no code detected, use the entire content as code
      code = content
    }
  }

  // Extract explanation (content before or after code blocks)
  const withoutCodeBlocks = content.replace(codeBlockRegex, '')
  explanation = withoutCodeBlocks.trim()

  // Extract improvements (for improve/refactor types)
  if (type === 'improve' || type === 'refactor') {
    const improvementRegex = /(?:improvement|enhancement|optimization|fix)[:\s]*([^\n]+)/gi
    const improvementMatches = content.match(improvementRegex)
    
    if (improvementMatches) {
      improvements.push(...improvementMatches.map(match => 
        match.replace(/(?:improvement|enhancement|optimization|fix)[:\s]*/i, '').trim()
      ))
    }
  }

  return { code, explanation, improvements }
}

// Code templates for common patterns
export async function GET() {
  return NextResponse.json({
    message: 'AI Code Generation API is running',
    endpoints: {
      generate: 'POST /api/ai-code - Generate/Improve/Refactor code',
      health: 'GET /api/ai-code - Health check'
    },
    templates: {
      'react-component': 'Generate React component with props and state',
      'api-endpoint': 'Create REST API endpoint with error handling',
      'database-model': 'Generate database model with validation',
      'auth-middleware': 'Create authentication middleware',
      'utility-function': 'Generate utility function with documentation',
      'test-suite': 'Create comprehensive test suite'
    }
  })
}