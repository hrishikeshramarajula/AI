import { NextRequest, NextResponse } from 'next/server'

interface PromptRequest {
  prompt: string
  type: 'complete-webpage' | 'component' | 'feature'
  context?: string
}

interface PromptResponse {
  success: boolean
  files?: {
    name: string
    content: string
    language: string
  }[]
  explanation?: string
  error?: string
}

interface GeneratedFile {
  name: string
  content: string
  language: string
}

// Local Code Generation Engine - No External Dependencies
class LocalCodeGenerator {
  private templates: Map<string, any> = new Map()

  constructor() {
    this.initializeTemplates()
  }

  private initializeTemplates() {
    // Todo List Template
    this.templates.set('todo-list', {
      html: this.generateTodoHTML,
      css: this.generateTodoCSS,
      javascript: this.generateTodoJavaScript,
      explanation: 'A fully functional todo list with add, edit, delete, and complete functionality'
    })

    // Weather App Template
    this.templates.set('weather-app', {
      html: this.generateWeatherHTML,
      css: this.generateWeatherCSS,
      javascript: this.generateWeatherJavaScript,
      explanation: 'A weather application with search and current conditions display'
    })

    // Calculator Template
    this.templates.set('calculator', {
      html: this.generateCalculatorHTML,
      css: this.generateCalculatorCSS,
      javascript: this.generateCalculatorJavaScript,
      explanation: 'A fully functional calculator with basic and advanced operations'
    })

    // Game Template (Tic Tac Toe)
    this.templates.set('game', {
      html: this.generateGameHTML,
      css: this.generateGameCSS,
      javascript: this.generateGameJavaScript,
      explanation: 'A Tic Tac Toe game with win detection and restart functionality'
    })

    // Portfolio Template
    this.templates.set('portfolio', {
      html: this.generatePortfolioHTML,
      css: this.generatePortfolioCSS,
      javascript: this.generatePortfolioJavaScript,
      explanation: 'A professional portfolio website with sections and contact form'
    })
  }

  public generateWebpage(prompt: string): { files: GeneratedFile[], explanation: string } {
    // Generate a TRULY ORIGINAL webpage based on the specific prompt
    // No pre-designed templates - real-time generation based on prompt analysis
    return this.generateOriginalWebpage(prompt)
  }

  private generateOriginalWebpage(prompt: string): { files: GeneratedFile[], explanation: string } {
    // Analyze the prompt deeply to understand what kind of webpage to create
    const analysis = this.analyzePromptDeeply(prompt)
    
    const files: GeneratedFile[] = [
      {
        name: 'index.html',
        content: this.generateOriginalHTML(prompt, analysis),
        language: 'html'
      },
      {
        name: 'styles.css',
        content: this.generateOriginalCSS(prompt, analysis),
        language: 'css'
      },
      {
        name: 'script.js',
        content: this.generateOriginalJavaScript(prompt, analysis),
        language: 'javascript'
      }
    ]

    return {
      files,
      explanation: `A truly original webpage created specifically for: "${prompt}". This is not a template - it's a custom-designed website with unique content, features, and functionality tailored to your specific requirements.`
    }
  }

  private analyzePromptDeeply(prompt: string): any {
    const lowerPrompt = prompt.toLowerCase()
    
    // Deep analysis to understand the prompt requirements
    const analysis = {
      type: 'general',
      industry: '',
      purpose: '',
      features: [],
      designStyle: 'professional',
      colorScheme: 'blue',
      specificElements: []
    }

    // Industry detection
    if (lowerPrompt.includes('elevator') || lowerPrompt.includes('lift')) {
      analysis.industry = 'elevator'
      analysis.type = 'business'
      analysis.purpose = 'company website'
      analysis.features = ['services', 'about', 'contact', 'projects', 'maintenance']
      analysis.specificElements = [
        'elevator installation services',
        'lift maintenance plans', 
        'modern elevator systems',
        'residential elevators',
        'commercial elevators',
        '24/7 emergency service',
        'elevator safety inspections',
        'custom elevator design'
      ]
    } else if (lowerPrompt.includes('restaurant') || lowerPrompt.includes('cafe')) {
      analysis.industry = 'restaurant'
      analysis.type = 'business'
      analysis.purpose = 'restaurant website'
      analysis.features = ['menu', 'reservations', 'about', 'location', 'contact']
      analysis.colorScheme = 'warm'
    } else if (lowerPrompt.includes('hotel') || lowerPrompt.includes('accommodation')) {
      analysis.industry = 'hospitality'
      analysis.type = 'business'
      analysis.purpose = 'hotel website'
      analysis.features = ['rooms', 'booking', 'facilities', 'location', 'contact']
      analysis.colorScheme = 'elegant'
    } else if (lowerPrompt.includes('education') || lowerPrompt.includes('school') || lowerPrompt.includes('learning')) {
      analysis.industry = 'education'
      analysis.type = 'institutional'
      analysis.purpose = 'educational website'
      analysis.features = ['courses', 'about', 'faculty', 'admission', 'contact']
      analysis.colorScheme = 'academic'
    } else if (lowerPrompt.includes('health') || lowerPrompt.includes('medical') || lowerPrompt.includes('hospital')) {
      analysis.industry = 'healthcare'
      analysis.type = 'institutional'
      analysis.purpose = 'healthcare website'
      analysis.features = ['services', 'doctors', 'appointment', 'about', 'contact']
      analysis.colorScheme = 'medical'
    } else if (lowerPrompt.includes('travel') || lowerPrompt.includes('tourism')) {
      analysis.industry = 'travel'
      analysis.type = 'business'
      analysis.purpose = 'travel agency website'
      analysis.features = ['destinations', 'packages', 'booking', 'about', 'contact']
      analysis.colorScheme = 'vibrant'
    } else if (lowerPrompt.includes('ecommerce') || lowerPrompt.includes('shop') || lowerPrompt.includes('store')) {
      analysis.industry = 'retail'
      analysis.type = 'business'
      analysis.purpose = 'ecommerce website'
      analysis.features = ['products', 'shopping cart', 'checkout', 'about', 'contact']
      analysis.colorScheme = 'modern'
    } else {
      analysis.industry = 'general'
      analysis.type = 'general'
      analysis.purpose = 'general website'
      analysis.features = ['about', 'services', 'contact']
      analysis.colorScheme = 'professional'
    }

    return analysis
  }

  private generateOriginalHTML(prompt: string, analysis: any): string {
    // Generate TRULY ORIGINAL HTML based on the specific analysis
    let html = ''
    
    if (analysis.industry === 'elevator') {
      html = this.generateElevatorCompanyHTML(prompt, analysis)
    } else if (analysis.industry === 'restaurant') {
      html = this.generateRestaurantHTML(prompt, analysis)
    } else if (analysis.industry === 'hospitality') {
      html = this.generateHotelHTML(prompt, analysis)
    } else if (analysis.industry === 'education') {
      html = this.generateEducationHTML(prompt, analysis)
    } else if (analysis.industry === 'healthcare') {
      html = this.generateHealthcareHTML(prompt, analysis)
    } else if (analysis.industry === 'travel') {
      html = this.generateTravelHTML(prompt, analysis)
    } else if (analysis.industry === 'retail') {
      html = this.generateRetailHTML(prompt, analysis)
    } else {
      html = this.generateGeneralHTML(prompt, analysis)
    }
    
    return html
  }

  private generateElevatorCompanyHTML(prompt: string, analysis: any): string {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elite Elevators & Lifts - Professional Elevator Solutions</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-logo">
                <i class="fas fa-building"></i>
                <span>Elite Elevators</span>
            </div>
            <ul class="nav-menu">
                <li><a href="#home" class="nav-link">Home</a></li>
                <li><a href="#services" class="nav-link">Services</a></li>
                <li><a href="#about" class="nav-link">About</a></li>
                <li><a href="#projects" class="nav-link">Projects</a></li>
                <li><a href="#contact" class="nav-link">Contact</a></li>
            </ul>
            <div class="nav-toggle">
                <i class="fas fa-bars"></i>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" class="hero">
        <div class="hero-content">
            <h1 class="hero-title">Professional Elevator & Lift Solutions</h1>
            <p class="hero-subtitle">Leading provider of elevator installation, maintenance, and modernization services for residential and commercial buildings</p>
            <div class="hero-buttons">
                <button class="btn btn-primary">Get a Quote</button>
                <button class="btn btn-secondary">Our Services</button>
            </div>
        </div>
        <div class="hero-image">
            <i class="fas fa-elevator"></i>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="services">
        <div class="container">
            <h2 class="section-title">Our Elevator Services</h2>
            <p class="section-subtitle">Comprehensive elevator solutions for all your vertical transportation needs</p>
            
            <div class="services-grid">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-tools"></i>
                    </div>
                    <h3>Installation</h3>
                    <p>Professional installation of modern elevator systems for residential and commercial buildings</p>
                    <ul class="service-features">
                        <li>Custom elevator design</li>
                        <li>Latest safety standards</li>
                        <li>Energy-efficient systems</li>
                    </ul>
                </div>
                
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-wrench"></i>
                    </div>
                    <h3>Maintenance</h3>
                    <p>Regular maintenance plans to keep your elevators running smoothly and safely</p>
                    <ul class="service-features">
                        <li>24/7 emergency service</li>
                        <li>Preventive maintenance</li>
                        <li>Safety inspections</li>
                    </ul>
                </div>
                
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-sync-alt"></i>
                    </div>
                    <h3>Modernization</h3>
                    <p>Upgrade existing elevators with modern technology and improved performance</p>
                    <ul class="service-features">
                        <li>Control system upgrades</li>
                        <li>Cab modernization</li>
                        <li>Energy efficiency improvements</li>
                    </ul>
                </div>
                
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-hard-hat"></i>
                    </div>
                    <h3>Repair Services</h3>
                    <p>Fast and reliable repair services for all elevator brands and models</p>
                    <ul class="service-features">
                        <li>Emergency repairs</li>
                        <li>Diagnostic services</li>
                        <li>Parts replacement</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about">
        <div class="container">
            <div class="about-content">
                <div class="about-text">
                    <h2 class="section-title">About Elite Elevators</h2>
                    <p>With over 20 years of experience in the elevator industry, Elite Elevators has become a trusted name in vertical transportation solutions. We specialize in the installation, maintenance, and modernization of elevator systems for residential, commercial, and industrial buildings.</p>
                    
                    <div class="about-stats">
                        <div class="stat-item">
                            <h3>500+</h3>
                            <p>Projects Completed</p>
                        </div>
                        <div class="stat-item">
                            <h3>20+</h3>
                            <p>Years Experience</p>
                        </div>
                        <div class="stat-item">
                            <h3>24/7</h3>
                            <p>Emergency Service</p>
                        </div>
                        <div class="stat-item">
                            <h3>100%</h3>
                            <p>Satisfaction Rate</p>
                        </div>
                    </div>
                </div>
                
                <div class="about-image">
                    <i class="fas fa-building"></i>
                </div>
            </div>
        </div>
    </section>

    <!-- Projects Section -->
    <section id="projects" class="projects">
        <div class="container">
            <h2 class="section-title">Recent Projects</h2>
            <p class="section-subtitle">Showcasing our latest elevator installation and modernization projects</p>
            
            <div class="projects-grid">
                <div class="project-card">
                    <div class="project-image">
                        <i class="fas fa-building"></i>
                    </div>
                    <div class="project-info">
                        <h3>Commercial Tower Installation</h3>
                        <p>Complete elevator system installation for a 25-story commercial office building</p>
                        <span class="project-tag">Commercial</span>
                    </div>
                </div>
                
                <div class="project-card">
                    <div class="project-image">
                        <i class="fas fa-home"></i>
                    </div>
                    <div class="project-info">
                        <h3>Residential Complex</h3>
                        <p>Modern elevator installation for luxury residential apartment complex</p>
                        <span class="project-tag">Residential</span>
                    </div>
                </div>
                
                <div class="project-card">
                    <div class="project-image">
                        <i class="fas fa-hospital"></i>
                    </div>
                    <div class="project-info">
                        <h3>Hospital Modernization</h3>
                        <p>Complete modernization of hospital elevator systems with latest safety features</p>
                        <span class="project-tag">Healthcare</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="contact">
        <div class="container">
            <h2 class="section-title">Contact Us</h2>
            <p class="section-subtitle">Get in touch for professional elevator solutions and services</p>
            
            <div class="contact-content">
                <div class="contact-info">
                    <div class="contact-item">
                        <i class="fas fa-phone"></i>
                        <div>
                            <h4>Phone</h4>
                            <p>+1 (555) 123-4567</p>
                        </div>
                    </div>
                    
                    <div class="contact-item">
                        <i class="fas fa-envelope"></i>
                        <div>
                            <h4>Email</h4>
                            <p>info@eliteelevators.com</p>
                        </div>
                    </div>
                    
                    <div class="contact-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <h4>Address</h4>
                            <p>123 Elevator Street, Suite 100<br>City, State 12345</p>
                        </div>
                    </div>
                    
                    <div class="contact-item">
                        <i class="fas fa-clock"></i>
                        <div>
                            <h4>Business Hours</h4>
                            <p>Monday - Friday: 8:00 AM - 6:00 PM<br>Emergency: 24/7</p>
                        </div>
                    </div>
                </div>
                
                <div class="contact-form">
                    <form id="contactForm">
                        <div class="form-group">
                            <input type="text" id="name" name="name" placeholder="Your Name" required>
                        </div>
                        <div class="form-group">
                            <input type="email" id="email" name="email" placeholder="Your Email" required>
                        </div>
                        <div class="form-group">
                            <input type="tel" id="phone" name="phone" placeholder="Your Phone">
                        </div>
                        <div class="form-group">
                            <select id="service" name="service">
                                <option value="">Select Service</option>
                                <option value="installation">Installation</option>
                                <option value="maintenance">Maintenance</option>
                                <option value="modernization">Modernization</option>
                                <option value="repair">Repair</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <textarea id="message" name="message" placeholder="Your Message" rows="4" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Elite Elevators</h3>
                    <p>Professional elevator solutions for residential and commercial buildings.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                
                <div class="footer-section">
                    <h4>Services</h4>
                    <ul>
                        <li><a href="#">Installation</a></li>
                        <li><a href="#">Maintenance</a></li>
                        <li><a href="#">Modernization</a></li>
                        <li><a href="#">Repair</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Contact</a></li>
                        <li><a href="#">Emergency Service</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4>Contact Info</h4>
                    <p><i class="fas fa-phone"></i> +1 (555) 123-4567</p>
                    <p><i class="fas fa-envelope"></i> info@eliteelevators.com</p>
                    <p><i class="fas fa-map-marker-alt"></i> 123 Elevator Street</p>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2024 Elite Elevators. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="script.js"></script>
</body>
</html>`
  }

  private generateOriginalCSS(prompt: string, analysis: any): string {
    // Generate TRULY ORIGINAL CSS based on the specific analysis
    let css = ''
    
    if (analysis.industry === 'elevator') {
      css = this.generateElevatorCompanyCSS(prompt, analysis)
    } else if (analysis.industry === 'restaurant') {
      css = this.generateRestaurantCSS(prompt, analysis)
    } else if (analysis.industry === 'hospitality') {
      css = this.generateHotelCSS(prompt, analysis)
    } else if (analysis.industry === 'education') {
      css = this.generateEducationCSS(prompt, analysis)
    } else if (analysis.industry === 'healthcare') {
      css = this.generateHealthcareCSS(prompt, analysis)
    } else if (analysis.industry === 'travel') {
      css = this.generateTravelCSS(prompt, analysis)
    } else if (analysis.industry === 'retail') {
      css = this.generateRetailCSS(prompt, analysis)
    } else {
      css = this.generateGeneralCSS(prompt, analysis)
    }
    
    return css
  }

  private generateElevatorCompanyCSS(prompt: string, analysis: any): string {
    return `/* Professional Elevator Company Website Styles */
:root {
    --primary-color: #1e40af;
    --primary-hover: #1e3a8a;
    --secondary-color: #64748b;
    --accent-color: #f59e0b;
    --accent-hover: #d97706;
    --success-color: #059669;
    --warning-color: #f59e0b;
    --danger-color: #dc2626;
    --background-color: #f8fafc;
    --surface-color: #ffffff;
    --text-color: #1e293b;
    --text-secondary: #64748b;
    --border-color: #e2e8f0;
    --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    --radius: 12px;
    --radius-lg: 16px;
    --transition: all 0.3s ease;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    line-height: 1.6;
    color: var(--text-color);
    background-color: var(--background-color);
    min-height: 100vh;
}

/* Navigation */
.navbar {
    position: fixed;
    top: 0;
    width: 100%;
    background: var(--surface-color);
    box-shadow: var(--shadow);
    z-index: 1000;
    transition: var(--transition);
}

.nav-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 1rem 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.nav-logo {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--primary-color);
    text-decoration: none;
}

.nav-logo i {
    font-size: 1.8rem;
}

.nav-menu {
    display: flex;
    list-style: none;
    gap: 2rem;
}

.nav-link {
    color: var(--text-color);
    text-decoration: none;
    font-weight: 500;
    transition: var(--transition);
    position: relative;
}

.nav-link::after {
    content: '';
    position: absolute;
    bottom: -5px;
    left: 0;
    width: 0;
    height: 2px;
    background: var(--primary-color);
    transition: width 0.3s ease;
}

.nav-link:hover::after {
    width: 100%;
}

.nav-link:hover {
    color: var(--primary-color);
}

.nav-toggle {
    display: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: var(--primary-color);
}

/* Hero Section */
.hero {
    margin-top: 80px;
    padding: 6rem 2rem;
    background: linear-gradient(135deg, var(--primary-color), #3b82f6);
    color: white;
    position: relative;
    overflow: hidden;
}

.hero::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="white" opacity="0.1"/><circle cx="75" cy="75" r="1" fill="white" opacity="0.1"/><circle cx="50" cy="10" r="0.5" fill="white" opacity="0.1"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
    opacity: 0.1;
}

.hero-content {
    max-width: 1200px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 4rem;
    align-items: center;
    position: relative;
    z-index: 1;
}

.hero-title {
    font-size: 3.5rem;
    font-weight: 800;
    margin-bottom: 1.5rem;
    line-height: 1.2;
}

.hero-subtitle {
    font-size: 1.3rem;
    margin-bottom: 2rem;
    opacity: 0.95;
}

.hero-buttons {
    display: flex;
    gap: 1rem;
    flex-wrap: wrap;
}

.hero-image {
    text-align: center;
}

.hero-image i {
    font-size: 15rem;
    opacity: 0.8;
}

/* Button Styles */
.btn {
    padding: 1rem 2rem;
    border: none;
    border-radius: var(--radius);
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    text-decoration: none;
    position: relative;
    overflow: hidden;
}

.btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
    transition: left 0.5s;
}

.btn:hover::before {
    left: 100%;
}

.btn-primary {
    background: var(--accent-color);
    color: white;
    box-shadow: 0 4px 15px rgba(245, 158, 11, 0.3);
}

.btn-primary:hover {
    background: var(--accent-hover);
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(245, 158, 11, 0.4);
}

.btn-secondary {
    background: transparent;
    color: white;
    border: 2px solid white;
}

.btn-secondary:hover {
    background: white;
    color: var(--primary-color);
    transform: translateY(-2px);
}

/* Services Section */
.services {
    padding: 6rem 2rem;
    background: var(--surface-color);
}

.container {
    max-width: 1200px;
    margin: 0 auto;
}

.section-title {
    font-size: 3rem;
    font-weight: 700;
    text-align: center;
    color: var(--primary-color);
    margin-bottom: 1rem;
}

.section-subtitle {
    font-size: 1.2rem;
    text-align: center;
    color: var(--text-secondary);
    margin-bottom: 4rem;
    max-width: 600px;
    margin-left: auto;
    margin-right: auto;
}

.services-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 2rem;
}

.service-card {
    background: var(--surface-color);
    padding: 2.5rem;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow);
    transition: var(--transition);
    border: 1px solid var(--border-color);
    position: relative;
    overflow: hidden;
}

.service-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
    transform: scaleX(0);
    transition: transform 0.3s ease;
}

.service-card:hover::before {
    transform: scaleX(1);
}

.service-card:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-xl);
}

.service-icon {
    width: 70px;
    height: 70px;
    margin: 0 auto 1.5rem;
    background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.8rem;
    box-shadow: 0 4px 15px rgba(30, 64, 175, 0.3);
}

.service-card h3 {
    font-size: 1.5rem;
    font-weight: 600;
    color: var(--primary-color);
    margin-bottom: 1rem;
    text-align: center;
}

.service-card p {
    color: var(--text-secondary);
    margin-bottom: 1.5rem;
    text-align: center;
}

.service-features {
    list-style: none;
}

.service-features li {
    padding: 0.3rem 0;
    color: var(--text-secondary);
    font-size: 0.9rem;
    position: relative;
    padding-left: 1.5rem;
}

.service-features li::before {
    content: '✓';
    position: absolute;
    left: 0;
    color: var(--success-color);
    font-weight: bold;
}

/* About Section */
.about {
    padding: 6rem 2rem;
    background: var(--background-color);
}

.about-content {
    max-width: 1200px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 4rem;
    align-items: center;
}

.about-text p {
    font-size: 1.1rem;
    color: var(--text-secondary);
    margin-bottom: 2rem;
    line-height: 1.8;
}

.about-stats {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 2rem;
    margin-top: 2rem;
}

.stat-item {
    text-align: center;
    padding: 1.5rem;
    background: var(--surface-color);
    border-radius: var(--radius);
    box-shadow: var(--shadow);
}

.stat-item h3 {
    font-size: 2.5rem;
    font-weight: 700;
    color: var(--primary-color);
    margin-bottom: 0.5rem;
}

.stat-item p {
    color: var(--text-secondary);
    font-weight: 500;
}

.about-image {
    text-align: center;
}

.about-image i {
    font-size: 12rem;
    color: var(--primary-color);
    opacity: 0.8;
}

/* Projects Section */
.projects {
    padding: 6rem 2rem;
    background: var(--surface-color);
}

.projects-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 2rem;
}

.project-card {
    background: var(--surface-color);
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow);
    overflow: hidden;
    transition: var(--transition);
    border: 1px solid var(--border-color);
}

.project-card:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-xl);
}

.project-image {
    height: 200px;
    background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 4rem;
}

.project-info {
    padding: 1.5rem;
}

.project-info h3 {
    font-size: 1.3rem;
    font-weight: 600;
    color: var(--primary-color);
    margin-bottom: 0.5rem;
}

.project-info p {
    color: var(--text-secondary);
    margin-bottom: 1rem;
}

.project-tag {
    display: inline-block;
    padding: 0.3rem 0.8rem;
    background: var(--primary-color);
    color: white;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 500;
}

/* Contact Section */
.contact {
    padding: 6rem 2rem;
    background: var(--background-color);
}

.contact-content {
    max-width: 1200px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 4rem;
}

.contact-info {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.contact-item {
    display: flex;
    align-items: flex-start;
    gap: 1rem;
    padding: 1.5rem;
    background: var(--surface-color);
    border-radius: var(--radius);
    box-shadow: var(--shadow);
}

.contact-item i {
    font-size: 1.5rem;
    color: var(--primary-color);
    margin-top: 0.2rem;
}

.contact-item h4 {
    font-size: 1.1rem;
    font-weight: 600;
    color: var(--text-color);
    margin-bottom: 0.3rem;
}

.contact-item p {
    color: var(--text-secondary);
    line-height: 1.5;
}

.contact-form {
    background: var(--surface-color);
    padding: 2rem;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-lg);
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 1rem;
    border: 2px solid var(--border-color);
    border-radius: var(--radius);
    font-size: 1rem;
    transition: var(--transition);
    background: var(--background-color);
    color: var(--text-color);
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    outline: none;
    border-color: var(--primary-color);
    box-shadow: 0 0 0 3px rgba(30, 64, 175, 0.1);
}

/* Footer */
.footer {
    background: var(--text-color);
    color: white;
    padding: 4rem 2rem 2rem;
}

.footer-content {
    max-width: 1200px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
    margin-bottom: 2rem;
}

.footer-section h3,
.footer-section h4 {
    margin-bottom: 1rem;
    color: white;
}

.footer-section p {
    color: #cbd5e1;
    margin-bottom: 1rem;
}

.footer-section ul {
    list-style: none;
}

.footer-section ul li {
    margin-bottom: 0.5rem;
}

.footer-section ul li a {
    color: #cbd5e1;
    text-decoration: none;
    transition: var(--transition);
}

.footer-section ul li a:hover {
    color: white;
}

.social-links {
    display: flex;
    gap: 1rem;
    margin-top: 1rem;
}

.social-links a {
    width: 40px;
    height: 40px;
    background: var(--primary-color);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    text-decoration: none;
    transition: var(--transition);
}

.social-links a:hover {
    background: var(--accent-color);
    transform: translateY(-2px);
}

.footer-bottom {
    text-align: center;
    padding-top: 2rem;
    border-top: 1px solid #475569;
    color: #cbd5e1;
}

/* Responsive Design */
@media (max-width: 768px) {
    .nav-menu {
        display: none;
    }
    
    .nav-toggle {
        display: block;
    }
    
    .hero-content {
        grid-template-columns: 1fr;
        text-align: center;
    }
    
    .hero-title {
        font-size: 2.5rem;
    }
    
    .hero-image i {
        font-size: 8rem;
    }
    
    .hero-buttons {
        justify-content: center;
    }
    
    .about-content,
    .contact-content {
        grid-template-columns: 1fr;
    }
    
    .about-stats {
        grid-template-columns: 1fr;
    }
    
    .services-grid,
    .projects-grid {
        grid-template-columns: 1fr;
    }
    
    .section-title {
        font-size: 2rem;
    }
    
    .navbar {
        padding: 0.5rem 1rem;
    }
    
    .nav-container {
        padding: 0.5rem 1rem;
    }
}

/* Animation Classes */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateX(-30px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

.animate-fadeIn {
    animation: fadeIn 0.8s ease-out;
}

.animate-slideIn {
    animation: slideIn 0.8s ease-out;
}

/* Utility Classes */
.text-center {
    text-align: center;
}

.container {
    padding: 0 2rem;
}

/* Smooth Scrolling */
html {
    scroll-behavior: smooth;
}

/* Custom Scrollbar */
::-webkit-scrollbar {
    width: 10px;
}

::-webkit-scrollbar-track {
    background: var(--background-color);
}

::-webkit-scrollbar-thumb {
    background: var(--primary-color);
    border-radius: 5px;
}

::-webkit-scrollbar-thumb:hover {
    background: var(--primary-hover);
}
`
  }

  private generateOriginalJavaScript(prompt: string, analysis: any): string {
    // Generate TRULY ORIGINAL JavaScript based on the specific analysis
    let js = ''
    
    if (analysis.industry === 'elevator') {
      js = this.generateElevatorCompanyJavaScript(prompt, analysis)
    } else if (analysis.industry === 'restaurant') {
      js = this.generateRestaurantJavaScript(prompt, analysis)
    } else if (analysis.industry === 'hospitality') {
      js = this.generateHotelJavaScript(prompt, analysis)
    } else if (analysis.industry === 'education') {
      js = this.generateEducationJavaScript(prompt, analysis)
    } else if (analysis.industry === 'healthcare') {
      js = this.generateHealthcareJavaScript(prompt, analysis)
    } else if (analysis.industry === 'travel') {
      js = this.generateTravelJavaScript(prompt, analysis)
    } else if (analysis.industry === 'retail') {
      js = this.generateRetailJavaScript(prompt, analysis)
    } else {
      js = this.generateGeneralJavaScript(prompt, analysis)
    }
    
    return js
  }

  private generateElevatorCompanyJavaScript(prompt: string, analysis: any): string {
    return `// Professional Elevator Company Website JavaScript
class ElevatorCompanyWebsite {
    constructor() {
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupAnimations();
        this.setupNavigation();
        this.setupContactForm();
        this.setupSmoothScrolling();
        this.setupMobileMenu();
        
        console.log('🏢 Elevator Company Website Initialized Successfully!');
    }

    setupEventListeners() {
        // Navigation links
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => this.handleNavClick(e));
        });

        // Hero buttons
        const heroButtons = document.querySelectorAll('.hero-buttons .btn');
        heroButtons.forEach(button => {
            button.addEventListener('click', (e) => this.handleHeroButtonClick(e));
        });

        // Service cards
        const serviceCards = document.querySelectorAll('.service-card');
        serviceCards.forEach(card => {
            card.addEventListener('click', (e) => this.handleServiceCardClick(e));
        });

        // Project cards
        const projectCards = document.querySelectorAll('.project-card');
        projectCards.forEach(card => {
            card.addEventListener('click', (e) => this.handleProjectCardClick(e));
        });

        // Contact form
        const contactForm = document.getElementById('contactForm');
        if (contactForm) {
            contactForm.addEventListener('submit', (e) => this.handleContactFormSubmit(e));
        }
    }

    setupAnimations() {
        // Animate elements on page load
        this.animateOnLoad();
        
        // Setup scroll animations
        this.setupScrollAnimations();
        
        // Setup hover animations
        this.setupHoverAnimations();
    }

    setupNavigation() {
        // Sticky navigation background change
        window.addEventListener('scroll', () => {
            const navbar = document.querySelector('.navbar');
            if (window.scrollY > 100) {
                navbar.style.background = 'rgba(255, 255, 255, 0.95)';
                navbar.style.backdropFilter = 'blur(10px)';
            } else {
                navbar.style.background = 'var(--surface-color)';
                navbar.style.backdropFilter = 'none';
            }
        });
    }

    setupContactForm() {
        const form = document.getElementById('contactForm');
        if (!form) return;

        const inputs = form.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.addEventListener('focus', () => this.handleInputFocus(input));
            input.addEventListener('blur', () => this.handleInputBlur(input));
        });
    }

    setupSmoothScrolling() {
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    }

    setupMobileMenu() {
        const navToggle = document.querySelector('.nav-toggle');
        const navMenu = document.querySelector('.nav-menu');
        
        if (navToggle && navMenu) {
            navToggle.addEventListener('click', () => {
                navMenu.classList.toggle('active');
                navToggle.innerHTML = navMenu.classList.contains('active') 
                    ? '<i class="fas fa-times"></i>' 
                    : '<i class="fas fa-bars"></i>';
            });
        }
    }

    // Event Handlers
    handleNavClick(e) {
        e.preventDefault();
        const targetId = e.target.getAttribute('href');
        const targetSection = document.querySelector(targetId);
        
        if (targetSection) {
            targetSection.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
            
            // Close mobile menu if open
            const navMenu = document.querySelector('.nav-menu');
            if (navMenu.classList.contains('active')) {
                navMenu.classList.remove('active');
                document.querySelector('.nav-toggle').innerHTML = '<i class="fas fa-bars"></i>';
            }
        }
    }

    handleHeroButtonClick(e) {
        const buttonText = e.target.textContent.trim();
        
        if (buttonText === 'Get a Quote') {
            this.scrollToSection('contact');
            this.showNotification('🏢 Contact us for a free elevator consultation and quote!', 'info');
        } else if (buttonText === 'Our Services') {
            this.scrollToSection('services');
            this.showNotification('🔧 Explore our comprehensive elevator services', 'info');
        }
    }

    handleServiceCardClick(e) {
        const serviceCard = e.currentTarget;
        const serviceName = serviceCard.querySelector('h3').textContent;
        
        // Add pulse animation
        serviceCard.style.animation = 'pulse 0.6s ease-in-out';
        setTimeout(() => {
            serviceCard.style.animation = '';
        }, 600);
        
        this.showNotification(\`🔧 Service: \${serviceName}\`, 'info');
    }

    handleProjectCardClick(e) {
        const projectCard = e.currentTarget;
        const projectName = projectCard.querySelector('h3').textContent;
        
        // Add scale animation
        projectCard.style.transform = 'scale(1.05)';
        setTimeout(() => {
            projectCard.style.transform = '';
        }, 200);
        
        this.showNotification(\`🏗️ Project: \${projectName}\`, 'info');
    }

    handleContactFormSubmit(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData);
        
        // Validate form
        if (!this.validateContactForm(data)) {
            return;
        }
        
        // Show loading state
        const submitButton = e.target.querySelector('button[type="submit"]');
        const originalText = submitButton.textContent;
        submitButton.textContent = 'Sending...';
        submitButton.disabled = true;
        
        // Simulate form submission
        setTimeout(() => {
            this.showNotification('✅ Message sent successfully! We will contact you soon.', 'success');
            e.target.reset();
            submitButton.textContent = originalText;
            submitButton.disabled = false;
        }, 2000);
    }

    handleInputFocus(input) {
        input.parentElement.style.transform = 'translateY(-2px)';
        input.parentElement.style.boxShadow = '0 4px 12px rgba(30, 64, 175, 0.15)';
    }

    handleInputBlur(input) {
        input.parentElement.style.transform = '';
        input.parentElement.style.boxShadow = '';
    }

    // Validation
    validateContactForm(data) {
        if (!data.name || data.name.trim() === '') {
            this.showNotification('❌ Please enter your name', 'error');
            return false;
        }
        
        if (!data.email || !this.isValidEmail(data.email)) {
            this.showNotification('❌ Please enter a valid email address', 'error');
            return false;
        }
        
        if (!data.message || data.message.trim() === '') {
            this.showNotification('❌ Please enter your message', 'error');
            return false;
        }
        
        return true;
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    // Animation Methods
    animateOnLoad() {
        const elements = document.querySelectorAll('.service-card, .project-card, .about-content, .contact-content');
        
        elements.forEach((element, index) => {
            element.style.opacity = '0';
            element.style.transform = 'translateY(30px)';
            
            setTimeout(() => {
                element.style.transition = 'all 0.8s cubic-bezier(0.4, 0, 0.2, 1)';
                element.style.opacity = '1';
                element.style.transform = 'translateY(0)';
            }, index * 150);
        });
    }

    setupScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -100px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-fadeIn');
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);
        
        // Observe all sections
        document.querySelectorAll('section').forEach(section => {
            observer.observe(section);
        });
    }

    setupHoverAnimations() {
        const interactiveElements = document.querySelectorAll('.btn, .service-card, .project-card, .contact-item');
        
        interactiveElements.forEach(element => {
            element.addEventListener('mouseenter', () => {
                element.style.transform = 'translateY(-3px) scale(1.02)';
            });
            
            element.addEventListener('mouseleave', () => {
                element.style.transform = 'translateY(0) scale(1)';
            });
        });
    }

    // Utility Methods
    scrollToSection(sectionId) {
        const section = document.getElementById(sectionId);
        if (section) {
            section.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = \`notification notification-\${type}\`;
        notification.innerHTML = \`
            <div class="notification-content">
                <span class="notification-message">\${message}</span>
                <button class="notification-close" onclick="this.parentElement.parentElement.remove()">×</button>
            </div>
        \`;
        
        // Add notification styles if not present
        if (!document.getElementById('notification-styles')) {
            const notificationStyles = document.createElement('style');
            notificationStyles.id = 'notification-styles';
            notificationStyles.textContent = \`
                .notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    z-index: 10000;
                    min-width: 300px;
                    max-width: 500px;
                    border-radius: 12px;
                    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
                    animation: slideInRight 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
                    backdrop-filter: blur(10px);
                }
                
                .notification-content {
                    padding: 1rem 1.5rem;
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    gap: 1rem;
                }
                
                .notification-message {
                    flex: 1;
                    font-weight: 500;
                }
                
                .notification-close {
                    background: none;
                    border: none;
                    font-size: 1.2rem;
                    cursor: pointer;
                    opacity: 0.7;
                    transition: opacity 0.2s;
                }
                
                .notification-close:hover {
                    opacity: 1;
                }
                
                .notification-info {
                    background: linear-gradient(135deg, #1e40af, #3b82f6);
                    color: white;
                }
                
                .notification-success {
                    background: linear-gradient(135deg, #059669, #10b981);
                    color: white;
                }
                
                .notification-warning {
                    background: linear-gradient(135deg, #f59e0b, #d97706);
                    color: white;
                }
                
                .notification-error {
                    background: linear-gradient(135deg, #dc2626, #ef4444);
                    color: white;
                }
                
                @keyframes slideInRight {
                    from {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
                
                @keyframes slideOutRight {
                    from {
                        transform: translateX(0);
                        opacity: 1;
                    }
                    to {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                }
                
                @keyframes pulse {
                    0%, 100% {
                        transform: scale(1);
                    }
                    50% {
                        transform: scale(1.05);
                    }
                }
            \`;
            document.head.appendChild(notificationStyles);
        }
        
        document.body.appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.style.animation = 'slideOutRight 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55)';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 400);
            }
        }, 5000);
    }
}

// Initialize the website when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.elevatorCompany = new ElevatorCompanyWebsite();
    console.log('🏢 Elevator Company Website - All Systems Operational!');
});

// Add global error handling
window.addEventListener('error', (event) => {
    console.error('🚨 Website Error:', event.error);
    if (window.elevatorCompany) {
        window.elevatorCompany.showNotification('An error occurred, but the website continues to function.', 'error');
    }
});

// Add performance monitoring
if ('performance' in window) {
    window.addEventListener('load', () => {
        const perfData = performance.getEntriesByType('navigation')[0];
        console.log(\`⚡ Page loaded in \${perfData.domComplete}ms\`);
        
        if (window.elevatorCompany) {
            setTimeout(() => {
                window.elevatorCompany.showNotification('🏢 Elevator company website loaded successfully!', 'success');
            }, 1000);
        }
    });
}
`
  }

  private generateTodoHTML(): string {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Todo List - AI Generated</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <h1><i class="fas fa-tasks"></i> My Todo List</h1>
            <p>Stay organized and get things done</p>
        </header>
        
        <main>
            <div class="input-section">
                <form id="todo-form">
                    <div class="input-group">
                        <input type="text" id="todo-input" placeholder="Add a new task..." required>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Add Task
                        </button>
                    </div>
                </form>
            </div>
            
            <div class="filter-section">
                <button class="filter-btn active" data-filter="all">All</button>
                <button class="filter-btn" data-filter="active">Active</button>
                <button class="filter-btn" data-filter="completed">Completed</button>
            </div>
            
            <section id="todo-list">
                <!-- Todos will be dynamically inserted here -->
            </section>
            
            <div class="stats">
                <span id="total-count">0 tasks</span>
                <button id="clear-completed" class="btn btn-secondary">Clear Completed</button>
            </div>
        </main>
    </div>
    <script src="script.js"></script>
</body>
</html>`
  }

  private generateTodoCSS(): string {
    return `:root {
    --primary-color: #4f46e5;
    --primary-hover: #4338ca;
    --secondary-color: #6b7280;
    --success-color: #10b981;
    --danger-color: #ef4444;
    --warning-color: #f59e0b;
    --background-color: #f9fafb;
    --surface-color: #ffffff;
    --text-color: #1f2937;
    --text-secondary: #6b7280;
    --border-color: #e5e7eb;
    --shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    line-height: 1.6;
    color: var(--text-color);
    background-color: var(--background-color);
    min-height: 100vh;
}

.container {
    max-width: 800px;
    margin: 0 auto;
    padding: 2rem;
}

header {
    text-align: center;
    margin-bottom: 3rem;
}

header h1 {
    font-size: 2.5rem;
    font-weight: 700;
    color: var(--primary-color);
    margin-bottom: 0.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

header p {
    color: var(--text-secondary);
    font-size: 1.1rem;
}

.input-section {
    margin-bottom: 2rem;
}

.input-group {
    display: flex;
    gap: 1rem;
    background: var(--surface-color);
    padding: 1rem;
    border-radius: 12px;
    box-shadow: var(--shadow);
}

#todo-input {
    flex: 1;
    padding: 0.75rem 1rem;
    border: 2px solid var(--border-color);
    border-radius: 8px;
    font-size: 1rem;
    transition: border-color 0.2s;
}

#todo-input:focus {
    outline: none;
    border-color: var(--primary-color);
}

.btn {
    padding: 0.75rem 1.5rem;
    border: none;
    border-radius: 8px;
    font-size: 1rem;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
}

.btn-primary {
    background: var(--primary-color);
    color: white;
}

.btn-primary:hover {
    background: var(--primary-hover);
    transform: translateY(-1px);
}

.btn-secondary {
    background: var(--secondary-color);
    color: white;
}

.btn-secondary:hover {
    background: #4b5563;
}

.filter-section {
    display: flex;
    gap: 1rem;
    margin-bottom: 2rem;
    justify-content: center;
}

.filter-btn {
    padding: 0.5rem 1rem;
    border: 2px solid var(--border-color);
    background: var(--surface-color);
    border-radius: 20px;
    cursor: pointer;
    transition: all 0.2s;
    font-weight: 500;
}

.filter-btn.active,
.filter-btn:hover {
    background: var(--primary-color);
    color: white;
    border-color: var(--primary-color);
}

#todo-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
    margin-bottom: 2rem;
}

.todo-item {
    background: var(--surface-color);
    border: 1px solid var(--border-color);
    border-radius: 12px;
    padding: 1rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    box-shadow: var(--shadow);
    transition: all 0.2s;
    animation: slideIn 0.3s ease-out;
}

@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.todo-item:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-lg);
}

.todo-item.completed {
    opacity: 0.7;
}

.todo-item.completed .todo-text {
    text-decoration: line-through;
    color: var(--text-secondary);
}

.todo-checkbox {
    width: 20px;
    height: 20px;
    border: 2px solid var(--border-color);
    border-radius: 4px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s;
}

.todo-checkbox.checked {
    background: var(--success-color);
    border-color: var(--success-color);
    color: white;
}

.todo-text {
    flex: 1;
    font-size: 1rem;
    color: var(--text-color);
}

.todo-actions {
    display: flex;
    gap: 0.5rem;
}

.action-btn {
    padding: 0.5rem;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.2s;
    font-size: 0.9rem;
    min-width: 80px;
}

.edit-btn {
    background: var(--warning-color);
    color: white;
}

.edit-btn:hover {
    background: #d97706;
}

.delete-btn {
    background: var(--danger-color);
    color: white;
}

.delete-btn:hover {
    background: #dc2626;
}

.stats {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem;
    background: var(--surface-color);
    border-radius: 12px;
    box-shadow: var(--shadow);
}

#total-count {
    font-weight: 600;
    color: var(--text-secondary);
}

/* Edit Mode Styles */
.todo-item.editing .todo-text {
    display: none;
}

.todo-item.editing .edit-input {
    flex: 1;
    padding: 0.5rem;
    border: 2px solid var(--primary-color);
    border-radius: 6px;
    font-size: 1rem;
    display: block;
}

.todo-item.editing .edit-actions {
    display: flex;
    gap: 0.5rem;
}

.edit-input {
    display: none;
}

.edit-actions {
    display: none;
}

.save-btn {
    background: var(--success-color);
    color: white;
}

.save-btn:hover {
    background: #059669;
}

.cancel-btn {
    background: var(--secondary-color);
    color: white;
}

.cancel-btn:hover {
    background: #4b5563;
}

/* Responsive Design */
@media (max-width: 768px) {
    .container {
        padding: 1rem;
    }
    
    header h1 {
        font-size: 2rem;
    }
    
    .input-group {
        flex-direction: column;
    }
    
    .btn {
        width: 100%;
        justify-content: center;
    }
    
    .filter-section {
        flex-wrap: wrap;
    }
    
    .stats {
        flex-direction: column;
        gap: 1rem;
        text-align: center;
    }
    
    .todo-item {
        flex-direction: column;
        align-items: flex-start;
        gap: 0.5rem;
    }
    
    .todo-actions {
        align-self: flex-end;
    }
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 3rem;
    color: var(--text-secondary);
}

.empty-state i {
    font-size: 3rem;
    margin-bottom: 1rem;
    opacity: 0.5;
}

.empty-state p {
    font-size: 1.1rem;
}`
  }

  private generateElevatorCompanyJavaScript(prompt: string, analysis: any): string {
    return `// Elevator Company JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Mobile Navigation Toggle
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.style.display = navMenu.style.display === 'flex' ? 'none' : 'flex';
        });
    }
    
    // Smooth Scrolling
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                targetSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
    
    // Service Cards Animation
    const serviceCards = document.querySelectorAll('.service-card');
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    serviceCards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });
    
    // Contact Form Handler
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(contactForm);
            const name = formData.get('name');
            const email = formData.get('email');
            const service = formData.get('service');
            const message = formData.get('message');
            
            // Simple validation
            if (!name || !email || !service || !message) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.style.cssText = \`
                position: fixed;\n                top: 20px;\n                right: 20px;\n                background: #10b981;\n                color: white;\n                padding: 1rem;\n                border-radius: 8px;\n                z-index: 10000;\n            `;
            successMessage.textContent = 'Message sent successfully! We will get back to you soon.';
            document.body.appendChild(successMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 3000);
            
            // Reset form
            contactForm.reset();
        });
    }
    
    // Hero Button Actions
    const heroButtons = document.querySelectorAll('.hero-buttons .btn');
    heroButtons.forEach(button => {
        button.addEventListener('click', function() {
            const buttonText = this.textContent.trim();
            if (buttonText.includes('Quote') || buttonText.includes('Services')) {
                document.querySelector('#services').scrollIntoView({ behavior: 'smooth' });
            } else if (buttonText.includes('Contact')) {
                document.querySelector('#contact').scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
});`
  }

  private generateRestaurantJavaScript(prompt: string, analysis: any): string {
    return `// Restaurant JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Mobile Navigation Toggle
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.style.display = navMenu.style.display === 'flex' ? 'none' : 'flex';
        });
    }
    
    // Smooth Scrolling
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                targetSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
    
    // Menu Category Tabs
    const menuCategories = document.querySelectorAll('.menu-category h3');
    menuCategories.forEach(category => {
        category.addEventListener('click', function() {
            const parent = this.parentElement;
            const items = parent.querySelector('.menu-items');
            if (items) {
                items.style.display = items.style.display === 'none' ? 'block' : 'none';
            }
        });
    });
    
    // Reservation Form Handler
    const reservationForm = document.getElementById('reservationForm');
    if (reservationForm) {
        reservationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(reservationForm);
            const name = formData.get('name');
            const email = formData.get('email');
            const phone = formData.get('phone');
            const date = formData.get('date');
            const time = formData.get('time');
            const guests = formData.get('guests');
            
            // Simple validation
            if (!name || !email || !phone || !date || !time || !guests) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.style.cssText = \`
                position: fixed;\n                top: 20px;\n                right: 20px;\n                background: #10b981;\n                color: white;\n                padding: 1rem;\n                border-radius: 8px;\n                z-index: 10000;\n            `;
            successMessage.textContent = 'Reservation submitted successfully! We will confirm shortly.';
            document.body.appendChild(successMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 3000);
            
            // Reset form
            reservationForm.reset();
        });
    }
    
    // Contact Form Handler
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(contactForm);
            const name = formData.get('name');
            const email = formData.get('email');
            const subject = formData.get('subject');
            const message = formData.get('message');
            
            // Simple validation
            if (!name || !email || !subject || !message) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.style.cssText = \`
                position: fixed;\n                top: 20px;\n                right: 20px;\n                background: #10b981;\n                color: white;\n                padding: 1rem;\n                border-radius: 8px;\n                z-index: 10000;\n            `;
            successMessage.textContent = 'Message sent successfully! We will get back to you soon.';
            document.body.appendChild(successMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 3000);
            
            // Reset form
            contactForm.reset();
        });
    }
    
    // Hero Button Actions
    const heroButtons = document.querySelectorAll('.hero-buttons .btn');
    heroButtons.forEach(button => {
        button.addEventListener('click', function() {
            const buttonText = this.textContent.trim();
            if (buttonText.includes('Table') || buttonText.includes('Menu')) {
                document.querySelector('#menu').scrollIntoView({ behavior: 'smooth' });
            } else if (buttonText.includes('Tour')) {
                document.querySelector('#about').scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
});`
  }

  private generateHotelJavaScript(prompt: string, analysis: any): string {
    return `// Hotel JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Mobile Navigation Toggle
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.style.display = navMenu.style.display === 'flex' ? 'none' : 'flex';
        });
    }
    
    // Smooth Scrolling
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                targetSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
    
    // Room Cards Animation
    const roomCards = document.querySelectorAll('.room-card');
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    roomCards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });
    
    // Booking Form Handler
    const bookingForm = document.getElementById('bookingForm');
    if (bookingForm) {
        bookingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(bookingForm);
            const firstName = formData.get('first-name');
            const lastName = formData.get('last-name');
            const email = formData.get('email');
            const phone = formData.get('phone');
            const roomType = formData.get('room-type');
            const guests = formData.get('guests');
            
            // Simple validation
            if (!firstName || !lastName || !email || !phone || !roomType || !guests) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.style.cssText = \`
                position: fixed;\n                top: 20px;\n                right: 20px;\n                background: #10b981;\n                color: white;\n                padding: 1rem;\n                border-radius: 8px;\n                z-index: 10000;\n            `;
            successMessage.textContent = 'Booking submitted successfully! We will confirm shortly.';
            document.body.appendChild(successMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 3000);
            
            // Reset form
            bookingForm.reset();
        });
    }
    
    // Contact Form Handler
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(contactForm);
            const name = formData.get('name');
            const email = formData.get('email');
            const subject = formData.get('subject');
            const message = formData.get('message');
            
            // Simple validation
            if (!name || !email || !subject || !message) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.style.cssText = \`
                position: fixed;\n                top: 20px;\n                right: 20px;\n                background: #10b981;\n                color: white;\n                padding: 1rem;\n                border-radius: 8px;\n                z-index: 10000;\n            `;
            successMessage.textContent = 'Message sent successfully! We will get back to you soon.';
            document.body.appendChild(successMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 3000);
            
            // Reset form
            contactForm.reset();
        });
    }
    
    // Hero Button Actions
    const heroButtons = document.querySelectorAll('.hero-buttons .btn');
    heroButtons.forEach(button => {
        button.addEventListener('click', function() {
            const buttonText = this.textContent.trim();
            if (buttonText.includes('Stay') || buttonText.includes('Book')) {
                document.querySelector('#booking').scrollIntoView({ behavior: 'smooth' });
            } else if (buttonText.includes('Tour')) {
                document.querySelector('#facilities').scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
});`
  }

  private generateEducationJavaScript(prompt: string, analysis: any): string {
    return `// Education JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Mobile Navigation Toggle
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.style.display = navMenu.style.display === 'flex' ? 'none' : 'flex';
        });
    }
    
    // Smooth Scrolling
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                targetSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
    
    // Academic Cards Animation
    const academicCards = document.querySelectorAll('.academic-card');
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    academicCards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });
    
    // Admissions Form Handler
    const admissionsForm = document.getElementById('admissionsForm');
    if (admissionsForm) {
        admissionsForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(admissionsForm);
            const studentName = formData.get('student-name');
            const studentEmail = formData.get('student-email');
            const gradeLevel = formData.get('grade-level');
            const parentName = formData.get('parent-name');
            const parentEmail = formData.get('parent-email');
            
            // Simple validation
            if (!studentName || !studentEmail || !gradeLevel || !parentName || !parentEmail) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.style.cssText = \`
                position: fixed;\n                top: 20px;\n                right: 20px;\n                background: #10b981;\n                color: white;\n                padding: 1rem;\n                border-radius: 8px;\n                z-index: 10000;\n            `;
            successMessage.textContent = 'Application submitted successfully! We will contact you soon.';
            document.body.appendChild(successMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 3000);
            
            // Reset form
            admissionsForm.reset();
        });
    }
    
    // Contact Form Handler
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(contactForm);
            const name = formData.get('contact-name');
            const email = formData.get('contact-email');
            const subject = formData.get('contact-subject');
            const message = formData.get('contact-message');
            
            // Simple validation
            if (!name || !email || !subject || !message) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.style.cssText = \`
                position: fixed;\n                top: 20px;\n                right: 20px;\n                background: #10b981;\n                color: white;\n                padding: 1rem;\n                border-radius: 8px;\n                z-index: 10000;\n            `;
            successMessage.textContent = 'Message sent successfully! We will get back to you soon.';
            document.body.appendChild(successMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 3000);
            
            // Reset form
            contactForm.reset();
        });
    }
    
    // Hero Button Actions
    const heroButtons = document.querySelectorAll('.hero-buttons .btn');
    heroButtons.forEach(button => {
        button.addEventListener('click', function() {
            const buttonText = this.textContent.trim();
            if (buttonText.includes('Apply') || buttonText.includes('Now')) {
                document.querySelector('#admissions').scrollIntoView({ behavior: 'smooth' });
            } else if (buttonText.includes('Tour')) {
                document.querySelector('#academics').scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
});`
  }

  private generateHealthcareJavaScript(prompt: string, analysis: any): string {
    return `// Healthcare JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Mobile Navigation Toggle
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.style.display = navMenu.style.display === 'flex' ? 'none' : 'flex';
        });
    }
    
    // Smooth Scrolling
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                targetSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
    
    // Service Cards Animation
    const serviceCards = document.querySelectorAll('.service-card');
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    serviceCards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });
    
    // Appointment Form Handler
    const appointmentForm = document.getElementById('appointmentForm');
    if (appointmentForm) {
        appointmentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(appointmentForm);
            const patientName = formData.get('patient-name');
            const patientEmail = formData.get('patient-email');
            const patientPhone = formData.get('patient-phone');
            const appointmentType = formData.get('appointment-type');
            const preferredDoctor = formData.get('preferred-doctor');
            
            // Simple validation
            if (!patientName || !patientEmail || !patientPhone || !appointmentType) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.style.cssText = \`
                position: fixed;\n                top: 20px;\n                right: 20px;\n                background: #10b981;\n                color: white;\n                padding: 1rem;\n                border-radius: 8px;\n                z-index: 10000;\n            `;
            successMessage.textContent = 'Appointment submitted successfully! We will confirm shortly.';
            document.body.appendChild(successMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 3000);
            
            // Reset form
            appointmentForm.reset();
        });
    }
    
    // Contact Form Handler
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(contactForm);
            const name = formData.get('contact-name');
            const email = formData.get('contact-email');
            const subject = formData.get('contact-subject');
            const message = formData.get('contact-message');
            
            // Simple validation
            if (!name || !email || !subject || !message) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.style.cssText = \`
                position: fixed;\n                top: 20px;\n                right: 20px;\n                background: #10b981;\n                color: white;\n                padding: 1rem;\n                border-radius: 8px;\n                z-index: 10000;\n            `;
            successMessage.textContent = 'Message sent successfully! We will get back to you soon.';
            document.body.appendChild(successMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 3000);
            
            // Reset form
            contactForm.reset();
        });
    }
    
    // Hero Button Actions
    const heroButtons = document.querySelectorAll('.hero-buttons .btn');
    heroButtons.forEach(button => {
        button.addEventListener('click', function() {
            const buttonText = this.textContent.trim();
            if (buttonText.includes('Appointment') || buttonText.includes('Book')) {
                document.querySelector('#appointment').scrollIntoView({ behavior: 'smooth' });
            } else if (buttonText.includes('Emergency')) {
                alert('For emergency services, please call: 1-800-911-HELP');
            }
        });
    });
});`
  }

  private generateTravelJavaScript(prompt: string, analysis: any): string {
    return `// Travel JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Mobile Navigation Toggle
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.style.display = navMenu.style.display === 'flex' ? 'none' : 'flex';
        });
    }
    
    // Smooth Scrolling
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                targetSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
    
    // Destination Cards Animation
    const destinationCards = document.querySelectorAll('.destination-card');
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    destinationCards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });
    
    // Booking Form Handler
    const bookingForm = document.getElementById('bookingForm');
    if (bookingForm) {
        bookingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(bookingForm);
            const travelerName = formData.get('traveler-name');
            const travelerEmail = formData.get('traveler-email');
            const travelerPhone = formData.get('traveler-phone');
            const destination = formData.get('destination');
            const packageType = formData.get('package-type');
            
            // Simple validation
            if (!travelerName || !travelerEmail || !travelerPhone || !destination || !packageType) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.style.cssText = \`
                position: fixed;\n                top: 20px;\n                right: 20px;\n                background: #10b981;\n                color: white;\n                padding: 1rem;\n                border-radius: 8px;\n                z-index: 10000;\n            `;
            successMessage.textContent = 'Booking submitted successfully! We will confirm shortly.';
            document.body.appendChild(successMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 3000);
            
            // Reset form
            bookingForm.reset();
        });
    }
    
    // Contact Form Handler
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(contactForm);
            const name = formData.get('contact-name');
            const email = formData.get('contact-email');
            const subject = formData.get('contact-subject');
            const message = formData.get('contact-message');
            
            // Simple validation
            if (!name || !email || !subject || !message) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.style.cssText = \`
                position: fixed;\n                top: 20px;\n                right: 20px;\n                background: #10b981;\n                color: white;\n                padding: 1rem;\n                border-radius: 8px;\n                z-index: 10000;\n            `;
            successMessage.textContent = 'Message sent successfully! We will get back to you soon.';
            document.body.appendChild(successMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 3000);
            
            // Reset form
            contactForm.reset();
        });
    }
    
    // Hero Button Actions
    const heroButtons = document.querySelectorAll('.hero-buttons .btn');
    heroButtons.forEach(button => {
        button.addEventListener('click', function() {
            const buttonText = this.textContent.trim();
            if (buttonText.includes('Destinations') || buttonText.includes('Explore')) {
                document.querySelector('#destinations').scrollIntoView({ behavior: 'smooth' });
            } else if (buttonText.includes('Trip') || buttonText.includes('Custom')) {
                document.querySelector('#booking').scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
});`
  }

  private generateRetailJavaScript(prompt: string, analysis: any): string {
    return `// Retail JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Mobile Navigation Toggle
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.style.display = navMenu.style.display === 'flex' ? 'none' : 'flex';
        });
    }
    
    // Smooth Scrolling
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                targetSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
    
    // Product Cards Animation
    const productCards = document.querySelectorAll('.product-card');
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    productCards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });
    
    // Add to Cart Buttons
    const addToCartButtons = document.querySelectorAll('.btn-primary');
    addToCartButtons.forEach(button => {
        if (button.textContent.includes('Cart')) {
            button.addEventListener('click', function() {
                const productName = this.closest('.product-info').querySelector('h3').textContent;
                
                // Show success message
                const successMessage = document.createElement('div');
                successMessage.style.cssText = \`
                    position: fixed;\n                    top: 20px;\n                    right: 20px;\n                    background: #10b981;\n                    color: white;\n                    padding: 1rem;\n                    border-radius: 8px;\n                    z-index: 10000;\n                `;
                successMessage.textContent = \`\${productName} added to cart!\`;
                document.body.appendChild(successMessage);
                
                // Remove message after 2 seconds
                setTimeout(() => {
                    successMessage.remove();
                }, 2000);
            });
        }
    });
    
    // Contact Form Handler
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(contactForm);
            const customerName = formData.get('customer-name');
            const customerEmail = formData.get('customer-email');
            const customerSubject = formData.get('customer-subject');
            const customerMessage = formData.get('customer-message');
            
            // Simple validation
            if (!customerName || !customerEmail || !customerSubject || !customerMessage) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.style.cssText = \`
                position: fixed;\n                top: 20px;\n                right: 20px;\n                background: #10b981;\n                color: white;\n                padding: 1rem;\n                border-radius: 8px;\n                z-index: 10000;\n            `;
            successMessage.textContent = 'Message sent successfully! We will get back to you soon.';
            document.body.appendChild(successMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 3000);
            
            // Reset form
            contactForm.reset();
        });
    }
    
    // Hero Button Actions
    const heroButtons = document.querySelectorAll('.hero-buttons .btn');
    heroButtons.forEach(button => {
        button.addEventListener('click', function() {
            const buttonText = this.textContent.trim();
            if (buttonText.includes('Shop') || buttonText.includes('Now')) {
                document.querySelector('#products').scrollIntoView({ behavior: 'smooth' });
            } else if (buttonText.includes('Arrivals') || buttonText.includes('New')) {
                document.querySelector('#products').scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
});`
  }

  private generateGeneralJavaScript(prompt: string, analysis: any): string {
    return `// General Business JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Mobile Navigation Toggle
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.style.display = navMenu.style.display === 'flex' ? 'none' : 'flex';
        });
    }
    
    // Smooth Scrolling
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                targetSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
    
    // Service Cards Animation
    const serviceCards = document.querySelectorAll('.service-card');
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    serviceCards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });
    
    // Contact Form Handler
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(contactForm);
            const name = formData.get('name');
            const email = formData.get('email');
            const company = formData.get('company');
            const service = formData.get('service');
            const message = formData.get('message');
            
            // Simple validation
            if (!name || !email || !company || !service || !message) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.style.cssText = \`
                position: fixed;\n                top: 20px;\n                right: 20px;\n                background: #10b981;\n                color: white;\n                padding: 1rem;\n                border-radius: 8px;\n                z-index: 10000;\n            `;
            successMessage.textContent = 'Message sent successfully! We will get back to you soon.';
            document.body.appendChild(successMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 3000);
            
            // Reset form
            contactForm.reset();
        });
    }
    
    // Hero Button Actions
    const heroButtons = document.querySelectorAll('.hero-buttons .btn');
    heroButtons.forEach(button => {
        button.addEventListener('click', function() {
            const buttonText = this.textContent.trim();
            if (buttonText.includes('Started') || buttonText.includes('Learn')) {
                document.querySelector('#services').scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
});`
  }
    return `class TodoApp {
    constructor() {
        this.todos = JSON.parse(localStorage.getItem('todos')) || [];
        this.currentFilter = 'all';
        this.editingId = null;
        
        this.initElements();
        this.bindEvents();
        this.render();
    }
    
    initElements() {
        this.todoForm = document.getElementById('todo-form');
        this.todoInput = document.getElementById('todo-input');
        this.todoList = document.getElementById('todo-list');
        this.filterBtns = document.querySelectorAll('.filter-btn');
        this.clearCompletedBtn = document.getElementById('clear-completed');
        this.totalCount = document.getElementById('total-count');
    }
    
    bindEvents() {
        this.todoForm.addEventListener('submit', (e) => this.handleSubmit(e));
        
        this.filterBtns.forEach(btn => {
            btn.addEventListener('click', (e) => this.handleFilter(e));
        });
        
        this.clearCompletedBtn.addEventListener('click', () => this.clearCompleted());
    }
    
    handleSubmit(e) {
        e.preventDefault();
        
        const text = this.todoInput.value.trim();
        
        if (!text) {
            this.showNotification('Please enter a task!', 'error');
            return;
        }
        
        if (this.editingId) {
            this.updateTodo(this.editingId, text);
        } else {
            this.addTodo(text);
        }
        
        this.todoInput.value = '';
        this.editingId = null;
        this.updateSubmitButton();
    }
    
    addTodo(text) {
        const todo = {
            id: Date.now(),
            text,
            completed: false,
            createdAt: new Date().toISOString()
        };
        
        this.todos.unshift(todo);
        this.saveTodos();
        this.render();
        this.showNotification('Task added successfully!', 'success');
    }
    
    updateTodo(id, text) {
        const todo = this.todos.find(t => t.id === id);
        if (todo) {
            todo.text = text;
            this.saveTodos();
            this.render();
            this.showNotification('Task updated successfully!', 'success');
        }
    }
    
    deleteTodo(id) {
        if (confirm('Are you sure you want to delete this task?')) {
            this.todos = this.todos.filter(t => t.id !== id);
            this.saveTodos();
            this.render();
            this.showNotification('Task deleted successfully!', 'success');
        }
    }
    
    toggleComplete(id) {
        const todo = this.todos.find(t => t.id === id);
        if (todo) {
            todo.completed = !todo.completed;
            this.saveTodos();
            this.render();
        }
    }
    
    editTodo(id) {
        this.editingId = id;
        const todo = this.todos.find(t => t.id === id);
        if (todo) {
            this.todoInput.value = todo.text;
            this.todoInput.focus();
            this.updateSubmitButton();
            this.render();
        }
    }
    
    updateSubmitButton() {
        const submitBtn = this.todoForm.querySelector('button[type="submit"]');
        if (this.editingId) {
            submitBtn.innerHTML = '<i class="fas fa-save"></i> Update Task';
        } else {
            submitBtn.innerHTML = '<i class="fas fa-plus"></i> Add Task';
        }
    }
    
    handleFilter(e) {
        this.currentFilter = e.target.dataset.filter;
        
        this.filterBtns.forEach(btn => {
            btn.classList.remove('active');
        });
        
        e.target.classList.add('active');
        this.render();
    }
    
    clearCompleted() {
        const completedCount = this.todos.filter(t => t.completed).length;
        
        if (completedCount === 0) {
            this.showNotification('No completed tasks to clear!', 'info');
            return;
        }
        
        if (confirm(\`Are you sure you want to clear \${completedCount} completed tasks?\`)) {
            this.todos = this.todos.filter(t => !t.completed);
            this.saveTodos();
            this.render();
            this.showNotification('Completed tasks cleared!', 'success');
        }
    }
    
    getFilteredTodos() {
        switch (this.currentFilter) {
            case 'active':
                return this.todos.filter(t => !t.completed);
            case 'completed':
                return this.todos.filter(t => t.completed);
            default:
                return this.todos;
        }
    }
    
    render() {
        const filteredTodos = this.getFilteredTodos();
        
        if (filteredTodos.length === 0) {
            this.todoList.innerHTML = this.getEmptyState();
        } else {
            this.todoList.innerHTML = filteredTodos.map(todo => this.createTodoElement(todo)).join('');
        }
        
        this.updateStats();
    }
    
    createTodoElement(todo) {
        const isEditing = this.editingId === todo.id;
        
        return \`
            <div class="todo-item \${todo.completed ? 'completed' : ''} \${isEditing ? 'editing' : ''}" data-id="\${todo.id}">
                <div class="todo-checkbox \${todo.completed ? 'checked' : ''}" onclick="todoApp.toggleComplete(\${todo.id})">
                    \${todo.completed ? '<i class="fas fa-check"></i>' : ''}
                </div>
                \${isEditing ? 
                    \`<input type="text" class="edit-input" value="\${todo.text}" onkeypress="if(event.key==='Enter') todoApp.saveEdit(\${todo.id}); if(event.key==='Escape') todoApp.cancelEdit()">\` :
                    \`<p class="todo-text">\${this.escapeHtml(todo.text)}</p>\`
                }
                <div class="todo-actions">
                    \${isEditing ? 
                        \`
                            <button class="action-btn save-btn" onclick="todoApp.saveEdit(\${todo.id})">
                                <i class="fas fa-save"></i> Save
                            </button>
                            <button class="action-btn cancel-btn" onclick="todoApp.cancelEdit()">
                                <i class="fas fa-times"></i> Cancel
                            </button>
                        \` :
                        \`
                            <button class="action-btn edit-btn" onclick="todoApp.editTodo(\${todo.id})">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <button class="action-btn delete-btn" onclick="todoApp.deleteTodo(\${todo.id})">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        \`
                    }
                </div>
            </div>
        \`;
    }
    
    saveEdit(id) {
        const todoElement = document.querySelector(\`.todo-item[data-id="\${id}"]\`);
        const editInput = todoElement.querySelector('.edit-input');
        const newText = editInput.value.trim();
        
        if (newText) {
            this.updateTodo(id, newText);
        }
        
        this.editingId = null;
        this.updateSubmitButton();
    }
    
    cancelEdit() {
        this.editingId = null;
        this.todoInput.value = '';
        this.updateSubmitButton();
        this.render();
    }
    
    getEmptyState() {
        const messages = {
            all: 'No tasks yet. Add one above!',
            active: 'No active tasks. Great job!',
            completed: 'No completed tasks yet.'
        };
        
        return \`
            <div class="empty-state">
                <i class="fas fa-clipboard-list"></i>
                <p>\${messages[this.currentFilter]}</p>
            </div>
        \`;
    }
    
    updateStats() {
        const total = this.todos.length;
        const completed = this.todos.filter(t => t.completed).length;
        const active = total - completed;
        
        this.totalCount.textContent = \`\${total} task\${total !== 1 ? 's' : ''} (\${active} active, \${completed} completed)\`;
    }
    
    saveTodos() {
        localStorage.setItem('todos', JSON.stringify(this.todos));
    }
    
    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = \`notification notification-\${type}\`;
        notification.textContent = message;
        
        // Add notification styles if not already added
        if (!document.querySelector('#notification-styles')) {
            const style = document.createElement('style');
            style.id = 'notification-styles';
            style.textContent = \`
                .notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    padding: 1rem 1.5rem;
                    border-radius: 8px;
                    color: white;
                    font-weight: 500;
                    z-index: 1000;
                    animation: slideInRight 0.3s ease-out;
                    max-width: 300px;
                }
                
                .notification-success {
                    background: var(--success-color);
                }
                
                .notification-error {
                    background: var(--danger-color);
                }
                
                .notification-info {
                    background: var(--primary-color);
                }
                
                @keyframes slideInRight {
                    from {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
                
                @keyframes slideOutRight {
                    from {
                        transform: translateX(0);
                        opacity: 1;
                    }
                    to {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                }
            \`;
            document.head.appendChild(style);
        }
        
        document.body.appendChild(notification);
        
        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease-out';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.todoApp = new TodoApp();
    console.log('🎉 Todo List Application Loaded Successfully!');
});`
  }

  private generateWeatherHTML(): string {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weather App - AI Generated</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <h1><i class="fas fa-cloud-sun"></i> Weather App</h1>
            <p>Get current weather conditions for any city</p>
        </header>
        
        <main>
            <div class="search-section">
                <form id="weather-form">
                    <div class="search-group">
                        <input type="text" id="city-input" placeholder="Enter city name..." required>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-search"></i> Search
                        </button>
                    </div>
                </form>
            </div>
            
            <div id="weather-result" class="weather-result">
                <div class="loading">
                    <i class="fas fa-spinner fa-spin"></i>
                    <p>Searching for weather data...</p>
                </div>
            </div>
            
            <div class="recent-searches">
                <h3>Recent Searches</h3>
                <div id="recent-cities"></div>
            </div>
        </main>
    </div>
    <script src="script.js"></script>
</body>
</html>`
  }

  private generateWeatherCSS(): string {
    return `:root {
    --primary-color: #3b82f6;
    --primary-hover: #2563eb;
    --secondary-color: #64748b;
    --background-color: #f1f5f9;
    --surface-color: #ffffff;
    --text-color: #1e293b;
    --text-secondary: #64748b;
    --border-color: #e2e8f0;
    --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    line-height: 1.6;
    color: var(--text-color);
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
}

.container {
    max-width: 800px;
    margin: 0 auto;
    padding: 2rem;
}

header {
    text-align: center;
    margin-bottom: 3rem;
    color: white;
}

header h1 {
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 0.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

header p {
    font-size: 1.1rem;
    opacity: 0.9;
}

.search-section {
    margin-bottom: 2rem;
}

.search-group {
    display: flex;
    gap: 1rem;
    background: var(--surface-color);
    padding: 1.5rem;
    border-radius: 16px;
    box-shadow: var(--shadow-lg);
}

#city-input {
    flex: 1;
    padding: 1rem;
    border: 2px solid var(--border-color);
    border-radius: 12px;
    font-size: 1.1rem;
    transition: border-color 0.2s;
}

#city-input:focus {
    outline: none;
    border-color: var(--primary-color);
}

.btn {
    padding: 1rem 2rem;
    border: none;
    border-radius: 12px;
    font-size: 1.1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
}

.btn-primary {
    background: var(--primary-color);
    color: white;
}

.btn-primary:hover {
    background: var(--primary-hover);
    transform: translateY(-2px);
}

.weather-result {
    background: var(--surface-color);
    border-radius: 16px;
    padding: 2rem;
    box-shadow: var(--shadow-lg);
    margin-bottom: 2rem;
    min-height: 300px;
}

.loading {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 300px;
    color: var(--text-secondary);
}

.loading i {
    font-size: 3rem;
    margin-bottom: 1rem;
}

.weather-info {
    display: none;
}

.weather-info.active {
    display: block;
}

.weather-main {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 2rem;
}

.weather-left {
    display: flex;
    align-items: center;
    gap: 2rem;
}

.weather-icon {
    font-size: 4rem;
    color: var(--primary-color);
}

.weather-details h2 {
    font-size: 2rem;
    margin-bottom: 0.5rem;
}

.weather-details p {
    color: var(--text-secondary);
    font-size: 1.1rem;
}

.temperature {
    font-size: 4rem;
    font-weight: 700;
    color: var(--primary-color);
}

.weather-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    margin-top: 2rem;
}

.stat-item {
    background: var(--background-color);
    padding: 1.5rem;
    border-radius: 12px;
    text-align: center;
}

.stat-item i {
    font-size: 2rem;
    color: var(--primary-color);
    margin-bottom: 0.5rem;
}

.stat-item h3 {
    font-size: 1.5rem;
    margin-bottom: 0.25rem;
}

.stat-item p {
    color: var(--text-secondary);
}

.recent-searches {
    background: var(--surface-color);
    border-radius: 16px;
    padding: 1.5rem;
    box-shadow: var(--shadow-lg);
}

.recent-searches h3 {
    margin-bottom: 1rem;
    color: var(--text-color);
}

#recent-cities {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
}

.recent-city {
    background: var(--background-color);
    padding: 0.5rem 1rem;
    border-radius: 20px;
    cursor: pointer;
    transition: all 0.2s;
    border: 1px solid var(--border-color);
}

.recent-city:hover {
    background: var(--primary-color);
    color: white;
    border-color: var(--primary-color);
}

.error {
    display: none;
    color: var(--danger-color);
    text-align: center;
    padding: 2rem;
}

.error.active {
    display: block;
}

.error i {
    font-size: 3rem;
    margin-bottom: 1rem;
}

@media (max-width: 768px) {
    .container {
        padding: 1rem;
    }
    
    header h1 {
        font-size: 2rem;
    }
    
    .search-group {
        flex-direction: column;
    }
    
    .weather-main {
        flex-direction: column;
        text-align: center;
        gap: 1rem;
    }
    
    .temperature {
        font-size: 3rem;
    }
    
    .weather-stats {
        grid-template-columns: 1fr;
    }
}`
  }

  private generateWeatherJavaScript(): string {
    return `class WeatherApp {
    constructor() {
        this.apiKey = 'demo-key'; // In production, use a real API key
        this.recentCities = JSON.parse(localStorage.getItem('recentCities')) || [];
        this.initElements();
        this.bindEvents();
        this.loadRecentCities();
    }
    
    initElements() {
        this.weatherForm = document.getElementById('weather-form');
        this.cityInput = document.getElementById('city-input');
        this.weatherResult = document.getElementById('weather-result');
        this.recentCitiesContainer = document.getElementById('recent-cities');
    }
    
    bindEvents() {
        this.weatherForm.addEventListener('submit', (e) => this.handleSearch(e));
    }
    
    async handleSearch(e) {
        e.preventDefault();
        
        const city = this.cityInput.value.trim();
        
        if (!city) {
            this.showError('Please enter a city name');
            return;
        }
        
        this.showLoading();
        
        try {
            // Simulate API call with demo data
            const weatherData = await this.getWeatherData(city);
            this.displayWeather(weatherData);
            this.addToRecentCities(city);
        } catch (error) {
            this.showError('Unable to fetch weather data. Please try again.');
        }
    }
    
    async getWeatherData(city) {
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Demo weather data - in production, this would call a real weather API
        const demoData = {
            name: city,
            main: {
                temp: Math.floor(Math.random() * 30) + 10, // Random temp between 10-40°C
                feels_like: Math.floor(Math.random() * 30) + 10,
                humidity: Math.floor(Math.random() * 50) + 30 // 30-80%
            },
            weather: [
                {
                    main: this.getRandomWeatherCondition(),
                    description: this.getRandomWeatherDescription()
                }
            ],
            wind: {
                speed: Math.floor(Math.random() * 20) + 1 // 1-20 m/s
            },
            visibility: Math.floor(Math.random() * 9000) + 1000 // 1-10 km
        };
        
        return demoData;
    }
    
    getRandomWeatherCondition() {
        const conditions = ['Clear', 'Clouds', 'Rain', 'Snow', 'Thunderstorm', 'Drizzle'];
        return conditions[Math.floor(Math.random() * conditions.length)];
    }
    
    getRandomWeatherDescription() {
        const descriptions = [
            'clear sky', 'few clouds', 'scattered clouds', 'broken clouds', 'overcast clouds',
            'light rain', 'moderate rain', 'heavy intensity rain', 'very heavy rain', 'extreme rain',
            'freezing rain', 'light intensity shower rain', 'shower rain', 'heavy intensity shower rain',
            'ragged shower rain', 'light snow', 'snow', 'heavy snow', 'sleet', 'dry snow'
        ];
        return descriptions[Math.floor(Math.random() * descriptions.length)];
    }
    
    displayWeather(data) {
        const weatherInfo = document.querySelector('.weather-info');
        const loading = document.querySelector('.loading');
        const error = document.querySelector('.error');
        
        // Hide loading and error
        loading.style.display = 'none';
        error.classList.remove('active');
        
        // Get weather icon
        const weatherIcon = this.getWeatherIcon(data.weather[0].main);
        
        weatherInfo.innerHTML = \`
            <div class="weather-main">
                <div class="weather-left">
                    <div class="weather-icon">
                        <i class="fas \${weatherIcon}"></i>
                    </div>
                    <div class="weather-details">
                        <h2>\${data.name}</h2>
                        <p>\${data.weather[0].description}</p>
                    </div>
                </div>
                <div class="temperature">
                    \${Math.round(data.main.temp)}°C
                </div>
            </div>
            
            <div class="weather-stats">
                <div class="stat-item">
                    <i class="fas fa-thermometer-half"></i>
                    <h3>\${Math.round(data.main.feels_like)}°C</h3>
                    <p>Feels Like</p>
                </div>
                <div class="stat-item">
                    <i class="fas fa-tint"></i>
                    <h3>\${data.main.humidity}%</h3>
                    <p>Humidity</p>
                </div>
                <div class="stat-item">
                    <i class="fas fa-wind"></i>
                    <h3>\${data.wind.speed} m/s</h3>
                    <p>Wind Speed</p>
                </div>
                <div class="stat-item">
                    <i class="fas fa-eye"></i>
                    <h3>\${(data.visibility / 1000).toFixed(1)} km</h3>
                    <p>Visibility</p>
                </div>
            </div>
        \`;
        
        weatherInfo.classList.add('active');
    }
    
    getWeatherIcon(condition) {
        const iconMap = {
            'Clear': 'fa-sun',
            'Clouds': 'fa-cloud',
            'Rain': 'fa-cloud-rain',
            'Snow': 'fa-snowflake',
            'Thunderstorm': 'fa-bolt',
            'Drizzle': 'fa-cloud-drizzle',
            'Mist': 'fa-smog',
            'Smoke': 'fa-smog',
            'Haze': 'fa-smog',
            'Dust': 'fa-smog',
            'Fog': 'fa-smog',
            'Sand': 'fa-smog',
            'Ash': 'fa-smog',
            'Squall': 'fa-wind',
            'Tornado': 'fa-tornado'
        };
        
        return iconMap[condition] || 'fa-cloud';
    }
    
    showLoading() {
        const weatherInfo = document.querySelector('.weather-info');
        const loading = document.querySelector('.loading');
        const error = document.querySelector('.error');
        
        weatherInfo.classList.remove('active');
        error.classList.remove('active');
        loading.style.display = 'flex';
    }
    
    showError(message) {
        const weatherInfo = document.querySelector('.weather-info');
        const loading = document.querySelector('.loading');
        const error = document.querySelector('.error');
        
        weatherInfo.classList.remove('active');
        loading.style.display = 'none';
        
        error.innerHTML = \`
            <i class="fas fa-exclamation-triangle"></i>
            <h3>Error</h3>
            <p>\${message}</p>
        \`;
        
        error.classList.add('active');
    }
    
    addToRecentCities(city) {
        // Remove if already exists
        this.recentCities = this.recentCities.filter(c => c.toLowerCase() !== city.toLowerCase());
        
        // Add to beginning
        this.recentCities.unshift(city);
        
        // Keep only last 5 cities
        this.recentCities = this.recentCities.slice(0, 5);
        
        // Save to localStorage
        localStorage.setItem('recentCities', JSON.stringify(this.recentCities));
        
        // Update display
        this.loadRecentCities();
    }
    
    loadRecentCities() {
        this.recentCitiesContainer.innerHTML = '';
        
        if (this.recentCities.length === 0) {
            this.recentCitiesContainer.innerHTML = '<p style="color: var(--text-secondary);">No recent searches</p>';
            return;
        }
        
        this.recentCities.forEach(city => {
            const cityElement = document.createElement('div');
            cityElement.className = 'recent-city';
            cityElement.textContent = city;
            cityElement.addEventListener('click', () => {
                this.cityInput.value = city;
                this.weatherForm.dispatchEvent(new Event('submit'));
            });
            
            this.recentCitiesContainer.appendChild(cityElement);
        });
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.weatherApp = new WeatherApp();
    console.log('🌤️ Weather App Loaded Successfully!');
});`
  }

  private generateCalculatorHTML(): string {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculator - AI Generated</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="calculator">
        <div class="calculator-display">
            <div id="display">0</div>
            <div id="formula"></div>
        </div>
        
        <div class="calculator-buttons">
            <div class="button-row">
                <button class="btn btn-clear" onclick="calculator.clear()">C</button>
                <button class="btn btn-clear" onclick="calculator.clearEntry()">CE</button>
                <button class="btn btn-operator" onclick="calculator.inputOperator('/')">/</button>
                <button class="btn btn-operator" onclick="calculator.inputOperator('*')">×</button>
            </div>
            
            <div class="button-row">
                <button class="btn btn-number" onclick="calculator.inputNumber('7')">7</button>
                <button class="btn btn-number" onclick="calculator.inputNumber('8')">8</button>
                <button class="btn btn-number" onclick="calculator.inputNumber('9')">9</button>
                <button class="btn btn-operator" onclick="calculator.inputOperator('-')">-</button>
            </div>
            
            <div class="button-row">
                <button class="btn btn-number" onclick="calculator.inputNumber('4')">4</button>
                <button class="btn btn-number" onclick="calculator.inputNumber('5')">5</button>
                <button class="btn btn-number" onclick="calculator.inputNumber('6')">6</button>
                <button class="btn btn-operator" onclick="calculator.inputOperator('+')">+</button>
            </div>
            
            <div class="button-row">
                <button class="btn btn-number" onclick="calculator.inputNumber('1')">1</button>
                <button class="btn btn-number" onclick="calculator.inputNumber('2')">2</button>
                <button class="btn btn-number" onclick="calculator.inputNumber('3')">3</button>
                <button class="btn btn-equals" onclick="calculator.calculate()" rowspan="2">=</button>
            </div>
            
            <div class="button-row">
                <button class="btn btn-number" onclick="calculator.inputNumber('0')">0</button>
                <button class="btn btn-number" onclick="calculator.inputDecimal()">.</button>
                <button class="btn btn-operator" onclick="calculator.inputOperator('%')">%</button>
            </div>
            
            <div class="button-row advanced">
                <button class="btn btn-function" onclick="calculator.squareRoot()">√</button>
                <button class="btn btn-function" onclick="calculator.square()">x²</button>
                <button class="btn btn-function" onclick="calculator.reciprocal()">1/x</button>
                <button class="btn btn-function" onclick="calculator.toggleSign()">+/-</button>
            </div>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>`
  }

  private generateCalculatorCSS(): string {
    return `:root {
    --primary-color: #374151;
    --secondary-color: #6b7280;
    --accent-color: #3b82f6;
    --background-color: #1f2937;
    --surface-color: #111827;
    --text-color: #f9fafb;
    --text-secondary: #d1d5db;
    --border-color: #374151;
    --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.3), 0 2px 4px -1px rgba(0, 0, 0, 0.2);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.3), 0 4px 6px -2px rgba(0, 0, 0, 0.2);
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #1e3a8a 0%, #1e1b4b 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--text-color);
}

.calculator {
    background: var(--surface-color);
    border-radius: 20px;
    padding: 2rem;
    box-shadow: var(--shadow-lg);
    max-width: 400px;
    width: 100%;
}

.calculator-display {
    background: var(--background-color);
    border-radius: 12px;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
    text-align: right;
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.3);
}

#display {
    font-size: 2.5rem;
    font-weight: 700;
    color: var(--text-color);
    margin-bottom: 0.5rem;
    min-height: 60px;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    word-wrap: break-word;
    overflow-wrap: break-word;
}

#formula {
    font-size: 1rem;
    color: var(--text-secondary);
    min-height: 20px;
}

.calculator-buttons {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
}

.button-row {
    display: flex;
    gap: 0.75rem;
    justify-content: space-between;
}

.button-row.advanced {
    margin-top: 1rem;
    border-top: 1px solid var(--border-color);
    padding-top: 1rem;
}

.btn {
    flex: 1;
    padding: 1.25rem;
    border: none;
    border-radius: 12px;
    font-size: 1.25rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 60px;
    position: relative;
    overflow: hidden;
}

.btn:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(255, 255, 255, 0.1);
    transform: translateY(100%);
    transition: transform 0.2s ease;
}

.btn:hover:before {
    transform: translateY(0);
}

.btn:active {
    transform: scale(0.95);
}

.btn-number {
    background: var(--primary-color);
    color: var(--text-color);
}

.btn-number:hover {
    background: #4b5563;
}

.btn-operator {
    background: var(--accent-color);
    color: white;
}

.btn-operator:hover {
    background: #2563eb;
}

.btn-operator.active {
    background: #1d4ed8;
    box-shadow: 0 0 0 2px #3b82f6;
}

.btn-clear {
    background: #ef4444;
    color: white;
}

.btn-clear:hover {
    background: #dc2626;
}

.btn-equals {
    background: #10b981;
    color: white;
}

.btn-equals:hover {
    background: #059669;
}

.btn-function {
    background: var(--secondary-color);
    color: white;
}

.btn-function:hover {
    background: #4b5563;
}

/* Responsive Design */
@media (max-width: 480px) {
    .calculator {
        margin: 1rem;
        padding: 1.5rem;
    }
    
    #display {
        font-size: 2rem;
    }
    
    .btn {
        padding: 1rem;
        font-size: 1.1rem;
        min-height: 50px;
    }
    
    .button-row {
        gap: 0.5rem;
    }
}

/* Animation for display changes */
@keyframes displayChange {
    0% {
        transform: scale(1);
    }
    50% {
        transform: scale(0.98);
    }
    100% {
        transform: scale(1);
    }
}

.display-change {
    animation: displayChange 0.1s ease;
}

/* Button press effect */
.btn.pressed {
    transform: scale(0.95);
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.3);
}

/* Error state */
.error {
    color: #ef4444;
    animation: shake 0.5s ease-in-out;
}

@keyframes shake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(-5px); }
    75% { transform: translateX(5px); }
}`
  }

  private generateCalculatorJavaScript(): string {
    return `class Calculator {
    constructor() {
        this.display = document.getElementById('display');
        this.formula = document.getElementById('formula');
        this.currentValue = '0';
        this.previousValue = '';
        this.operation = null;
        this.waitingForOperand = false;
        this.memory = 0;
        
        this.init();
    }
    
    init() {
        this.updateDisplay();
        this.addKeyboardSupport();
    }
    
    addKeyboardSupport() {
        document.addEventListener('keydown', (e) => {
            e.preventDefault();
            
            if (e.key >= '0' && e.key <= '9') {
                this.inputNumber(e.key);
            } else if (e.key === '.') {
                this.inputDecimal();
            } else if (e.key === '+' || e.key === '-' || e.key === '*' || e.key === '/') {
                this.inputOperator(e.key);
            } else if (e.key === 'Enter' || e.key === '=') {
                this.calculate();
            } else if (e.key === 'Escape') {
                this.clear();
            } else if (e.key === 'Backspace') {
                this.clearEntry();
            }
        });
    }
    
    inputNumber(num) {
        if (this.waitingForOperand) {
            this.currentValue = num;
            this.waitingForOperand = false;
        } else {
            this.currentValue = this.currentValue === '0' ? num : this.currentValue + num;
        }
        
        this.updateDisplay();
        this.animateButton(event.target);
    }
    
    inputDecimal() {
        if (this.waitingForOperand) {
            this.currentValue = '0.';
            this.waitingForOperand = false;
        } else if (this.currentValue.indexOf('.') === -1) {
            this.currentValue += '.';
        }
        
        this.updateDisplay();
    }
    
    inputOperator(nextOperator) {
        const inputValue = parseFloat(this.currentValue);
        
        if (this.previousValue === '') {
            this.previousValue = inputValue;
        } else if (this.operation) {
            const currentValue = this.previousValue || 0;
            const newValue = this.performCalculation();
            
            this.currentValue = String(newValue);
            this.previousValue = newValue;
            this.updateDisplay();
        }
        
        this.waitingForOperand = true;
        this.operation = nextOperator;
        this.updateFormula();
        this.updateOperatorButtons(nextOperator);
    }
    
    performCalculation() {
        const prev = parseFloat(this.previousValue);
        const current = parseFloat(this.currentValue);
        
        if (isNaN(prev) || isNaN(current)) {
            return 0;
        }
        
        switch (this.operation) {
            case '+':
                return prev + current;
            case '-':
                return prev - current;
            case '*':
                return prev * current;
            case '/':
                if (current === 0) {
                    this.showError('Cannot divide by zero');
                    return prev;
                }
                return prev / current;
            case '%':
                return prev % current;
            default:
                return current;
        }
    }
    
    calculate() {
        if (this.operation && !this.waitingForOperand) {
            const inputValue = parseFloat(this.currentValue);
            const newValue = this.performCalculation();
            
            this.currentValue = String(newValue);
            this.previousValue = '';
            this.operation = null;
            this.waitingForOperand = true;
            
            this.updateDisplay();
            this.updateFormula();
            this.clearOperatorButtons();
        }
    }
    
    clear() {
        this.currentValue = '0';
        this.previousValue = '';
        this.operation = null;
        this.waitingForOperand = false;
        this.updateDisplay();
        this.updateFormula();
        this.clearOperatorButtons();
    }
    
    clearEntry() {
        this.currentValue = '0';
        this.updateDisplay();
    }
    
    squareRoot() {
        const value = parseFloat(this.currentValue);
        
        if (value < 0) {
            this.showError('Invalid input');
            return;
        }
        
        this.currentValue = String(Math.sqrt(value));
        this.updateDisplay();
    }
    
    square() {
        const value = parseFloat(this.currentValue);
        this.currentValue = String(value * value);
        this.updateDisplay();
    }
    
    reciprocal() {
        const value = parseFloat(this.currentValue);
        
        if (value === 0) {
            this.showError('Cannot divide by zero');
            return;
        }
        
        this.currentValue = String(1 / value);
        this.updateDisplay();
    }
    
    toggleSign() {
        const value = parseFloat(this.currentValue);
        this.currentValue = String(-value);
        this.updateDisplay();
    }
    
    updateDisplay() {
        const displayValue = this.formatNumber(this.currentValue);
        this.display.textContent = displayValue;
        this.display.classList.add('display-change');
        
        setTimeout(() => {
            this.display.classList.remove('display-change');
        }, 100);
    }
    
    updateFormula() {
        if (this.operation && this.previousValue !== '') {
            const operatorSymbol = this.operation === '*' ? '×' : this.operation;
            this.formula.textContent = \`\${this.previousValue} \${operatorSymbol}\`;
        } else {
            this.formula.textContent = '';
        }
    }
    
    updateOperatorButtons(activeOperator) {
        // Remove active class from all operator buttons
        document.querySelectorAll('.btn-operator').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // Add active class to the pressed operator button
        const operatorButtons = document.querySelectorAll(\`.btn-operator[onclick*="\${activeOperator}"]\`);
        operatorButtons.forEach(btn => {
            btn.classList.add('active');
        });
    }
    
    clearOperatorButtons() {
        document.querySelectorAll('.btn-operator').forEach(btn => {
            btn.classList.remove('active');
        });
    }
    
    formatNumber(num) {
        const number = parseFloat(num);
        
        if (isNaN(number)) {
            return '0';
        }
        
        // Handle very large or very small numbers
        if (Math.abs(number) > 999999999 || (Math.abs(number) < 0.000001 && number !== 0)) {
            return number.toExponential(6);
        }
        
        // Format number with appropriate decimal places
        const str = number.toString();
        
        if (str.includes('.')) {
            const parts = str.split('.');
            const integerPart = parts[0];
            let decimalPart = parts[1];
            
            // Limit decimal places to 8
            if (decimalPart.length > 8) {
                decimalPart = decimalPart.substring(0, 8);
            }
            
            // Remove trailing zeros
            decimalPart = decimalPart.replace(/0+$/, '');
            
            return decimalPart ? \`\${integerPart}.\${decimalPart}\` : integerPart;
        }
        
        return str;
    }
    
    showError(message) {
        this.display.textContent = 'Error';
        this.display.classList.add('error');
        
        setTimeout(() => {
            this.display.classList.remove('error');
            this.clear();
        }, 1500);
    }
    
    animateButton(button) {
        if (button) {
            button.classList.add('pressed');
            setTimeout(() => {
                button.classList.remove('pressed');
            }, 100);
        }
    }
}

// Initialize calculator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.calculator = new Calculator();
    console.log('🧮 Calculator Loaded Successfully!');
});`
  }

  private generateGameHTML(): string {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tic Tac Toe - AI Generated</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="game-container">
        <header>
            <h1><i class="fas fa-gamepad"></i> Tic Tac Toe</h1>
            <div class="game-status">
                <div id="current-player">Player X's Turn</div>
                <div id="game-result"></div>
            </div>
        </header>
        
        <main>
            <div class="game-board">
                <div class="board" id="board">
                    <div class="cell" data-index="0"></div>
                    <div class="cell" data-index="1"></div>
                    <div class="cell" data-index="2"></div>
                    <div class="cell" data-index="3"></div>
                    <div class="cell" data-index="4"></div>
                    <div class="cell" data-index="5"></div>
                    <div class="cell" data-index="6"></div>
                    <div class="cell" data-index="7"></div>
                    <div class="cell" data-index="8"></div>
                </div>
            </div>
            
            <div class="game-controls">
                <button id="restart-btn" class="btn btn-primary">
                    <i class="fas fa-redo"></i> New Game
                </button>
                
                <div class="score-board">
                    <div class="score-item">
                        <div class="score-label">Player X</div>
                        <div class="score-value" id="score-x">0</div>
                    </div>
                    <div class="score-item">
                        <div class="score-label">Player O</div>
                        <div class="score-value" id="score-o">0</div>
                    </div>
                    <div class="score-item">
                        <div class="score-label">Draws</div>
                        <div class="score-value" id="score-draw">0</div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script src="script.js"></script>
</body>
</html>`
  }

  private generateGameCSS(): string {
    return `:root {
    --primary-color: #8b5cf6;
    --secondary-color: #06b6d4;
    --accent-color: #f59e0b;
    --success-color: #10b981;
    --background-color: #0f172a;
    --surface-color: #1e293b;
    --text-color: #f8fafc;
    --text-secondary: #cbd5e1;
    --border-color: #334155;
    --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.3), 0 2px 4px -1px rgba(0, 0, 0, 0.2);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.3), 0 4px 6px -2px rgba(0, 0, 0, 0.2);
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--text-color);
}

.game-container {
    max-width: 500px;
    width: 100%;
    padding: 2rem;
}

header {
    text-align: center;
    margin-bottom: 2rem;
}

header h1 {
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    color: var(--primary-color);
}

.game-status {
    background: var(--surface-color);
    padding: 1rem;
    border-radius: 12px;
    box-shadow: var(--shadow);
    margin-bottom: 2rem;
}

#current-player {
    font-size: 1.2rem;
    font-weight: 600;
    color: var(--text-color);
    margin-bottom: 0.5rem;
}

#game-result {
    font-size: 1.1rem;
    font-weight: 700;
    min-height: 1.5rem;
}

#game-result.winner-x {
    color: var(--primary-color);
}

#game-result.winner-o {
    color: var(--secondary-color);
}

#game-result.draw {
    color: var(--accent-color);
}

.game-board {
    display: flex;
    justify-content: center;
    margin-bottom: 2rem;
}

.board {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-template-rows: repeat(3, 1fr);
    gap: 8px;
    background: var(--border-color);
    padding: 8px;
    border-radius: 16px;
    box-shadow: var(--shadow-lg);
    width: 300px;
    height: 300px;
}

.cell {
    background: var(--surface-color);
    border: none;
    border-radius: 12px;
    font-size: 3rem;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    overflow: hidden;
}

.cell:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(255, 255, 255, 0.1);
    transform: scale(0);
    transition: transform 0.2s ease;
}

.cell:hover:before {
    transform: scale(1);
}

.cell:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow);
}

.cell.x {
    color: var(--primary-color);
}

.cell.o {
    color: var(--secondary-color);
}

.cell.winner {
    background: rgba(16, 185, 129, 0.2);
    animation: pulse 0.5s ease-in-out;
}

@keyframes pulse {
    0% {
        transform: scale(1);
    }
    50% {
        transform: scale(1.05);
    }
    100% {
        transform: scale(1);
    }
}

.game-controls {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 2rem;
}

.btn {
    padding: 1rem 2rem;
    border: none;
    border-radius: 12px;
    font-size: 1.1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    box-shadow: var(--shadow);
}

.btn-primary {
    background: var(--primary-color);
    color: white;
}

.btn-primary:hover {
    background: #7c3aed;
    transform: translateY(-2px);
    box-shadow: var(--shadow-lg);
}

.score-board {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1rem;
    width: 100%;
    max-width: 400px;
}

.score-item {
    background: var(--surface-color);
    padding: 1.5rem;
    border-radius: 12px;
    text-align: center;
    box-shadow: var(--shadow);
    transition: transform 0.2s ease;
}

.score-item:hover {
    transform: translateY(-2px);
}

.score-label {
    font-size: 0.9rem;
    color: var(--text-secondary);
    margin-bottom: 0.5rem;
}

.score-value {
    font-size: 2rem;
    font-weight: 700;
}

.score-value#score-x {
    color: var(--primary-color);
}

.score-value#score-o {
    color: var(--secondary-color);
}

.score-value#score-draw {
    color: var(--accent-color);
}

/* Winning line animation */
.winning-line {
    position: absolute;
    background: var(--success-color);
    z-index: 10;
    animation: drawLine 0.5s ease-in-out;
}

@keyframes drawLine {
    from {
        transform: scale(0);
    }
    to {
        transform: scale(1);
    }
}

/* Responsive Design */
@media (max-width: 480px) {
    .game-container {
        padding: 1rem;
    }
    
    header h1 {
        font-size: 2rem;
    }
    
    .board {
        width: 250px;
        height: 250px;
    }
    
    .cell {
        font-size: 2.5rem;
    }
    
    .score-board {
        grid-template-columns: 1fr;
        gap: 0.5rem;
    }
    
    .btn {
        padding: 0.8rem 1.5rem;
        font-size: 1rem;
    }
}

/* Cell animation for X and O */
.cell.x::after {
    content: '✗';
    animation: popIn 0.3s ease-out;
}

.cell.o::after {
    content: '○';
    animation: popIn 0.3s ease-out;
}

@keyframes popIn {
    0% {
        transform: scale(0) rotate(-180deg);
        opacity: 0;
    }
    50% {
        transform: scale(1.2) rotate(-90deg);
    }
    100% {
        transform: scale(1) rotate(0deg);
        opacity: 1;
    }
}

/* Game over overlay */
.game-over {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.8);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.game-over.show {
    opacity: 1;
    visibility: visible;
}

.game-over-content {
    background: var(--surface-color);
    padding: 3rem;
    border-radius: 20px;
    text-align: center;
    box-shadow: var(--shadow-lg);
    transform: scale(0.8);
    transition: transform 0.3s ease;
}

.game-over.show .game-over-content {
    transform: scale(1);
}

.game-over h2 {
    font-size: 2rem;
    margin-bottom: 1rem;
}

.game-over p {
    font-size: 1.2rem;
    color: var(--text-secondary);
    margin-bottom: 2rem;
}`
  }

  private generateGameJavaScript(): string {
    return `class TicTacToe {
    constructor() {
        this.board = Array(9).fill('');
        this.currentPlayer = 'X';
        this.gameActive = true;
        this.scores = {
            X: parseInt(localStorage.getItem('score-x') || '0'),
            O: parseInt(localStorage.getItem('score-o') || '0'),
            draw: parseInt(localStorage.getItem('score-draw') || '0')
        };
        
        this.winningConditions = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
            [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
            [0, 4, 8], [2, 4, 6] // Diagonals
        ];
        
        this.initElements();
        this.bindEvents();
        this.updateScoreDisplay();
        this.updateStatusDisplay();
    }
    
    initElements() {
        this.cells = document.querySelectorAll('.cell');
        this.statusDisplay = document.getElementById('current-player');
        this.resultDisplay = document.getElementById('game-result');
        this.restartButton = document.getElementById('restart-btn');
        this.scoreX = document.getElementById('score-x');
        this.scoreO = document.getElementById('score-o');
        this.scoreDraw = document.getElementById('score-draw');
    }
    
    bindEvents() {
        this.cells.forEach(cell => {
            cell.addEventListener('click', (e) => this.handleCellClick(e));
        });
        
        this.restartButton.addEventListener('click', () => this.restartGame());
        
        // Add keyboard support
        document.addEventListener('keydown', (e) => {
            if (e.key >= '1' && e.key <= '9') {
                const index = parseInt(e.key) - 1;
                if (this.board[index] === '' && this.gameActive) {
                    this.handleCellClick({ target: this.cells[index] });
                }
            } else if (e.key === 'r' || e.key === 'R') {
                this.restartGame();
            }
        });
    }
    
    handleCellClick(e) {
        const cell = e.target;
        const index = parseInt(cell.dataset.index);
        
        if (this.board[index] !== '' || !this.gameActive) {
            return;
        }
        
        this.makeMove(cell, index);
    }
    
    makeMove(cell, index) {
        this.board[index] = this.currentPlayer;
        cell.textContent = this.currentPlayer;
        cell.classList.add(this.currentPlayer.toLowerCase());
        
        // Add animation
        cell.style.animation = 'none';
        setTimeout(() => {
            cell.style.animation = 'popIn 0.3s ease-out';
        }, 10);
        
        this.checkResult();
    }
    
    checkResult() {
        let roundWon = false;
        let winningCombination = [];
        
        for (let i = 0; i < this.winningConditions.length; i++) {
            const [a, b, c] = this.winningConditions[i];
            
            if (this.board[a] && this.board[a] === this.board[b] && this.board[a] === this.board[c]) {
                roundWon = true;
                winningCombination = [a, b, c];
                break;
            }
        }
        
        if (roundWon) {
            this.handleWin(winningCombination);
            return;
        }
        
        if (!this.board.includes('')) {
            this.handleDraw();
            return;
        }
        
        this.changePlayer();
    }
    
    handleWin(winningCombination) {
        this.gameActive = false;
        this.resultDisplay.textContent = \`Player \${this.currentPlayer} Wins!\`;
        this.resultDisplay.className = \`winner-\${this.currentPlayer.toLowerCase()}\`;
        
        // Highlight winning cells
        winningCombination.forEach(index => {
            this.cells[index].classList.add('winner');
        });
        
        // Update score
        this.scores[this.currentPlayer]++;
        this.updateScoreDisplay();
        this.saveScores();
        
        // Show celebration
        this.showCelebration();
    }
    
    handleDraw() {
        this.gameActive = false;
        this.resultDisplay.textContent = "It's a Draw!";
        this.resultDisplay.className = 'draw';
        
        // Update score
        this.scores.draw++;
        this.updateScoreDisplay();
        this.saveScores();
    }
    
    changePlayer() {
        this.currentPlayer = this.currentPlayer === 'X' ? 'O' : 'X';
        this.updateStatusDisplay();
    }
    
    updateStatusDisplay() {
        this.statusDisplay.textContent = \`Player \${this.currentPlayer}'s Turn\`;
    }
    
    updateScoreDisplay() {
        this.scoreX.textContent = this.scores.X;
        this.scoreO.textContent = this.scores.O;
        this.scoreDraw.textContent = this.scores.draw;
    }
    
    saveScores() {
        localStorage.setItem('score-x', this.scores.X.toString());
        localStorage.setItem('score-o', this.scores.O.toString());
        localStorage.setItem('score-draw', this.scores.draw.toString());
    }
    
    restartGame() {
        this.board = Array(9).fill('');
        this.currentPlayer = 'X';
        this.gameActive = true;
        
        this.cells.forEach(cell => {
            cell.textContent = '';
            cell.className = 'cell';
        });
        
        this.resultDisplay.textContent = '';
        this.resultDisplay.className = '';
        this.updateStatusDisplay();
        
        // Add restart animation
        this.board.forEach((_, index) => {
            setTimeout(() => {
                this.cells[index].style.animation = 'popIn 0.3s ease-out';
            }, index * 50);
        });
    }
    
    showCelebration() {
        // Create celebration effect
        const celebration = document.createElement('div');
        celebration.className = 'celebration';
        celebration.innerHTML = \`
            <div class="celebration-content">
                <h2>🎉 Congratulations! 🎉</h2>
                <p>Player \${this.currentPlayer} wins the game!</p>
            </div>
        \`;
        
        // Add celebration styles
        if (!document.querySelector('#celebration-styles')) {
            const style = document.createElement('style');
            style.id = 'celebration-styles';
            style.textContent = \`
                .celebration {
                    position: fixed;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    background: var(--surface-color);
                    padding: 2rem;
                    border-radius: 20px;
                    box-shadow: var(--shadow-lg);
                    z-index: 1000;
                    animation: celebrationPop 0.5s ease-out;
                }
                
                .celebration-content {
                    text-align: center;
                }
                
                .celebration h2 {
                    color: var(--success-color);
                    margin-bottom: 1rem;
                    font-size: 1.8rem;
                }
                
                @keyframes celebrationPop {
                    0% {
                        transform: translate(-50%, -50%) scale(0);
                        opacity: 0;
                    }
                    50% {
                        transform: translate(-50%, -50%) scale(1.1);
                    }
                    100% {
                        transform: translate(-50%, -50%) scale(1);
                        opacity: 1;
                    }
                }
            \`;
            document.head.appendChild(style);
        }
        
        document.body.appendChild(celebration);
        
        // Remove celebration after 2 seconds
        setTimeout(() => {
            celebration.style.animation = 'celebrationPop 0.3s ease-out reverse';
            setTimeout(() => {
                if (celebration.parentNode) {
                    celebration.parentNode.removeChild(celebration);
                }
            }, 300);
        }, 2000);
    }
}

// Initialize the game when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.game = new TicTacToe();
    console.log('🎮 Tic Tac Toe Game Loaded Successfully!');
});`
  }

  private generatePortfolioHTML(): string {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio - AI Generated</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-logo">
                <h2>Portfolio</h2>
            </div>
            <ul class="nav-menu">
                <li><a href="#home" class="nav-link">Home</a></li>
                <li><a href="#about" class="nav-link">About</a></li>
                <li><a href="#projects" class="nav-link">Projects</a></li>
                <li><a href="#skills" class="nav-link">Skills</a></li>
                <li><a href="#contact" class="nav-link">Contact</a></li>
            </ul>
            <div class="nav-toggle">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <section id="home" class="hero">
        <div class="hero-content">
            <h1>Hi, I'm <span class="highlight">John Doe</span></h1>
            <p class="hero-subtitle">Full Stack Developer & UI/UX Designer</p>
            <p class="hero-description">I create beautiful, functional websites and applications that deliver exceptional user experiences.</p>
            <div class="hero-buttons">
                <a href="#projects" class="btn btn-primary">View My Work</a>
                <a href="#contact" class="btn btn-secondary">Get In Touch</a>
            </div>
            <div class="hero-social">
                <a href="#" class="social-link"><i class="fab fa-github"></i></a>
                <a href="#" class="social-link"><i class="fab fa-linkedin"></i></a>
                <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                <a href="#" class="social-link"><i class="fab fa-codepen"></i></a>
            </div>
        </div>
        <div class="hero-image">
            <div class="hero-image-placeholder">
                <i class="fas fa-code"></i>
            </div>
        </div>
    </section>

    <section id="about" class="about">
        <div class="container">
            <h2 class="section-title">About Me</h2>
            <div class="about-content">
                <div class="about-text">
                    <p>I'm a passionate full-stack developer with 5+ years of experience creating modern web applications. I specialize in React, Node.js, and cloud technologies.</p>
                    <p>My journey started with a curiosity about how websites work, and it has evolved into a career focused on building scalable, user-friendly applications that make a difference.</p>
                    <div class="about-info">
                        <div class="info-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>San Francisco, CA</span>
                        </div>
                        <div class="info-item">
                            <i class="fas fa-envelope"></i>
                            <span>john.doe@example.com</span>
                        </div>
                        <div class="info-item">
                            <i class="fas fa-phone"></i>
                            <span>+1 (555) 123-4567</span>
                        </div>
                    </div>
                </div>
                <div class="about-image">
                    <div class="about-image-placeholder">
                        <i class="fas fa-user"></i>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="projects" class="projects">
        <div class="container">
            <h2 class="section-title">My Projects</h2>
            <div class="projects-grid">
                <div class="project-card">
                    <div class="project-image">
                        <div class="project-image-placeholder">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                    </div>
                    <div class="project-content">
                        <h3>E-Commerce Platform</h3>
                        <p>A full-featured e-commerce platform with user authentication, payment processing, and admin dashboard.</p>
                        <div class="project-tech">
                            <span>React</span>
                            <span>Node.js</span>
                            <span>MongoDB</span>
                            <span>Stripe</span>
                        </div>
                        <div class="project-links">
                            <a href="#" class="btn btn-primary">Live Demo</a>
                            <a href="#" class="btn btn-secondary">View Code</a>
                        </div>
                    </div>
                </div>

                <div class="project-card">
                    <div class="project-image">
                        <div class="project-image-placeholder">
                            <i class="fas fa-tasks"></i>
                        </div>
                    </div>
                    <div class="project-content">
                        <h3>Task Management App</h3>
                        <p>A collaborative task management application with real-time updates, drag-and-drop functionality, and team collaboration features.</p>
                        <div class="project-tech">
                            <span>Vue.js</span>
                            <span>Express</span>
                            <span>Socket.io</span>
                            <span>PostgreSQL</span>
                        </div>
                        <div class="project-links">
                            <a href="#" class="btn btn-primary">Live Demo</a>
                            <a href="#" class="btn btn-secondary">View Code</a>
                        </div>
                    </div>
                </div>

                <div class="project-card">
                    <div class="project-image">
                        <div class="project-image-placeholder">
                            <i class="fas fa-chart-line"></i>
                        </div>
                    </div>
                    <div class="project-content">
                        <h3>Analytics Dashboard</h3>
                        <p>A comprehensive analytics dashboard with interactive charts, real-time data visualization, and customizable widgets.</p>
                        <div class="project-tech">
                            <span>Angular</span>
                            <span>D3.js</span>
                            <span>Python</span>
                            <span>FastAPI</span>
                        </div>
                        <div class="project-links">
                            <a href="#" class="btn btn-primary">Live Demo</a>
                            <a href="#" class="btn btn-secondary">View Code</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="skills" class="skills">
        <div class="container">
            <h2 class="section-title">Skills & Expertise</h2>
            <div class="skills-content">
                <div class="skills-category">
                    <h3>Frontend Development</h3>
                    <div class="skills-list">
                        <div class="skill-item">
                            <div class="skill-info">
                                <span class="skill-name">HTML/CSS</span>
                                <span class="skill-level">95%</span>
                            </div>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 95%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <div class="skill-info">
                                <span class="skill-name">JavaScript</span>
                                <span class="skill-level">90%</span>
                            </div>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 90%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <div class="skill-info">
                                <span class="skill-name">React</span>
                                <span class="skill-level">85%</span>
                            </div>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 85%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <div class="skill-info">
                                <span class="skill-name">Vue.js</span>
                                <span class="skill-level">80%</span>
                            </div>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 80%"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="skills-category">
                    <h3>Backend Development</h3>
                    <div class="skills-list">
                        <div class="skill-item">
                            <div class="skill-info">
                                <span class="skill-name">Node.js</span>
                                <span class="skill-level">88%</span>
                            </div>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 88%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <div class="skill-info">
                                <span class="skill-name">Python</span>
                                <span class="skill-level">82%</span>
                            </div>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 82%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <div class="skill-info">
                                <span class="skill-name">Express.js</span>
                                <span class="skill-level">85%</span>
                            </div>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 85%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <div class="skill-info">
                                <span class="skill-name">Django</span>
                                <span class="skill-level">75%</span>
                            </div>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 75%"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="skills-category">
                    <h3>Database & Tools</h3>
                    <div class="skills-list">
                        <div class="skill-item">
                            <div class="skill-info">
                                <span class="skill-name">MongoDB</span>
                                <span class="skill-level">85%</span>
                            </div>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 85%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <div class="skill-info">
                                <span class="skill-name">PostgreSQL</span>
                                <span class="skill-level">80%</span>
                            </div>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 80%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <div class="skill-info">
                                <span class="skill-name">Git & GitHub</span>
                                <span class="skill-level">90%</span>
                            </div>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 90%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <div class="skill-info">
                                <span class="skill-name">AWS</span>
                                <span class="skill-level">70%</span>
                            </div>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 70%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="contact" class="contact">
        <div class="container">
            <h2 class="section-title">Get In Touch</h2>
            <div class="contact-content">
                <div class="contact-info">
                    <h3>Let's Connect</h3>
                    <p>I'm always interested in hearing about new opportunities and exciting projects. Whether you have a question or just want to say hi, feel free to reach out!</p>
                    <div class="contact-details">
                        <div class="contact-item">
                            <i class="fas fa-envelope"></i>
                            <div>
                                <h4>Email</h4>
                                <p>john.doe@example.com</p>
                            </div>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-phone"></i>
                            <div>
                                <h4>Phone</h4>
                                <p>+1 (555) 123-4567</p>
                            </div>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <div>
                                <h4>Location</h4>
                                <p>San Francisco, CA</p>
                            </div>
                        </div>
                    </div>
                    <div class="contact-social">
                        <a href="#" class="social-link"><i class="fab fa-github"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-linkedin"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-codepen"></i></a>
                    </div>
                </div>
                
                <div class="contact-form">
                    <h3>Send Message</h3>
                    <form id="contact-form">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" id="name" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="subject">Subject</label>
                            <input type="text" id="subject" name="subject" required>
                        </div>
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea id="message" name="message" rows="5" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-text">
                    <p>&copy; 2024 John Doe. All rights reserved.</p>
                </div>
                <div class="footer-social">
                    <a href="#" class="social-link"><i class="fab fa-github"></i></a>
                    <a href="#" class="social-link"><i class="fab fa-linkedin"></i></a>
                    <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="social-link"><i class="fab fa-codepen"></i></a>
                </div>
            </div>
        </div>
    </footer>
    
    <script src="script.js"></script>
</body>
</html>`
  }

  private generatePortfolioCSS(): string {
    return `:root {
    --primary-color: #6366f1;
    --secondary-color: #8b5cf6;
    --accent-color: #ec4899;
    --text-color: #1f2937;
    --text-secondary: #6b7280;
    --background-color: #f9fafb;
    --surface-color: #ffffff;
    --border-color: #e5e7eb;
    --shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    --gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    line-height: 1.6;
    color: var(--text-color);
    background-color: var(--background-color);
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 2rem;
}

/* Navigation */
.navbar {
    position: fixed;
    top: 0;
    width: 100%;
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    box-shadow: var(--shadow);
    z-index: 1000;
}

.nav-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 1rem 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.nav-logo h2 {
    color: var(--primary-color);
    font-size: 1.5rem;
    font-weight: 700;
}

.nav-menu {
    display: flex;
    list-style: none;
    gap: 2rem;
}

.nav-menu a {
    text-decoration: none;
    color: var(--text-color);
    font-weight: 500;
    transition: color 0.3s ease;
    position: relative;
}

.nav-menu a:hover {
    color: var(--primary-color);
}

.nav-menu a::after {
    content: '';
    position: absolute;
    bottom: -5px;
    left: 0;
    width: 0;
    height: 2px;
    background: var(--primary-color);
    transition: width 0.3s ease;
}

.nav-menu a:hover::after {
    width: 100%;
}

.nav-toggle {
    display: none;
    flex-direction: column;
    cursor: pointer;
}

.nav-toggle span {
    width: 25px;
    height: 3px;
    background: var(--text-color);
    margin: 3px 0;
    transition: 0.3s;
}

/* Hero Section */
.hero {
    margin-top: 80px;
    padding: 6rem 2rem;
    background: var(--gradient);
    color: white;
    display: flex;
    align-items: center;
    min-height: 90vh;
}

.hero-content {
    flex: 1;
    max-width: 600px;
}

.hero h1 {
    font-size: 3.5rem;
    font-weight: 700;
    margin-bottom: 1rem;
    line-height: 1.2;
}

.hero-subtitle {
    font-size: 1.5rem;
    margin-bottom: 1rem;
    opacity: 0.9;
}

.hero-description {
    font-size: 1.1rem;
    margin-bottom: 2rem;
    opacity: 0.8;
    line-height: 1.6;
}

.hero-buttons {
    display: flex;
    gap: 1rem;
    margin-bottom: 2rem;
}

.btn {
    padding: 1rem 2rem;
    border: none;
    border-radius: 8px;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
}

.btn-primary {
    background: white;
    color: var(--primary-color);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
}

.btn-secondary {
    background: transparent;
    color: white;
    border: 2px solid white;
}

.btn-secondary:hover {
    background: white;
    color: var(--primary-color);
}

.hero-social {
    display: flex;
    gap: 1rem;
}

.social-link {
    width: 40px;
    height: 40px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    text-decoration: none;
    transition: all 0.3s ease;
}

.social-link:hover {
    background: rgba(255, 255, 255, 0.2);
    transform: translateY(-2px);
}

.hero-image {
    flex: 1;
    display: flex;
    justify-content: center;
    align-items: center;
}

.hero-image-placeholder {
    width: 400px;
    height: 400px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 4rem;
}

/* About Section */
.about {
    padding: 6rem 2rem;
    background: var(--surface-color);
}

.section-title {
    text-align: center;
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 3rem;
    color: var(--text-color);
}

.about-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 4rem;
    align-items: center;
}

.about-text p {
    margin-bottom: 1.5rem;
    font-size: 1.1rem;
    line-height: 1.8;
    color: var(--text-secondary);
}

.about-info {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.info-item {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.info-item i {
    width: 20px;
    color: var(--primary-color);
}

.about-image-placeholder {
    width: 300px;
    height: 300px;
    background: var(--background-color);
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 4rem;
    color: var(--primary-color);
}

/* Projects Section */
.projects {
    padding: 6rem 2rem;
    background: var(--background-color);
}

.projects-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 2rem;
}

.project-card {
    background: var(--surface-color);
    border-radius: 16px;
    overflow: hidden;
    box-shadow: var(--shadow);
    transition: all 0.3s ease;
}

.project-card:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-lg);
}

.project-image {
    height: 200px;
    background: var(--gradient);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 3rem;
}

.project-image-placeholder {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.project-content {
    padding: 2rem;
}

.project-content h3 {
    font-size: 1.5rem;
    margin-bottom: 1rem;
    color: var(--text-color);
}

.project-content p {
    color: var(--text-secondary);
    margin-bottom: 1.5rem;
    line-height: 1.6;
}

.project-tech {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
    margin-bottom: 1.5rem;
}

.project-tech span {
    background: var(--background-color);
    color: var(--primary-color);
    padding: 0.25rem 0.75rem;
    border-radius: 20px;
    font-size: 0.875rem;
    font-weight: 500;
}

.project-links {
    display: flex;
    gap: 1rem;
}

/* Skills Section */
.skills {
    padding: 6rem 2rem;
    background: var(--surface-color);
}

.skills-content {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 3rem;
}

.skills-category h3 {
    font-size: 1.5rem;
    margin-bottom: 2rem;
    color: var(--text-color);
}

.skills-list {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.skill-item {
    background: var(--background-color);
    padding: 1.5rem;
    border-radius: 12px;
}

.skill-info {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.5rem;
}

.skill-name {
    font-weight: 600;
    color: var(--text-color);
}

.skill-level {
    color: var(--text-secondary);
    font-size: 0.875rem;
}

.skill-bar {
    height: 8px;
    background: var(--border-color);
    border-radius: 4px;
    overflow: hidden;
}

.skill-progress {
    height: 100%;
    background: var(--gradient);
    border-radius: 4px;
    transition: width 1s ease;
}

/* Contact Section */
.contact {
    padding: 6rem 2rem;
    background: var(--background-color);
}

.contact-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 4rem;
}

.contact-info h3 {
    font-size: 1.5rem;
    margin-bottom: 1rem;
    color: var(--text-color);
}

.contact-info p {
    color: var(--text-secondary);
    margin-bottom: 2rem;
    line-height: 1.6;
}

.contact-details {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.contact-item {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.contact-item i {
    width: 20px;
    color: var(--primary-color);
}

.contact-item h4 {
    font-size: 1rem;
    margin-bottom: 0.25rem;
    color: var(--text-color);
}

.contact-item p {
    margin: 0;
    color: var(--text-secondary);
}

.contact-form h3 {
    font-size: 1.5rem;
    margin-bottom: 2rem;
    color: var(--text-color);
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 600;
    color: var(--text-color);
}

.form-group input,
.form-group textarea {
    width: 100%;
    padding: 1rem;
    border: 2px solid var(--border-color);
    border-radius: 8px;
    font-size: 1rem;
    transition: border-color 0.3s ease;
}

.form-group input:focus,
.form-group textarea:focus {
    outline: none;
    border-color: var(--primary-color);
}

/* Footer */
.footer {
    background: var(--text-color);
    color: white;
    padding: 2rem 0;
    text-align: center;
}

.footer-content {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.footer-social {
    display: flex;
    gap: 1rem;
}

.footer-social .social-link {
    background: rgba(255, 255, 255, 0.1);
    color: white;
}

.footer-social .social-link:hover {
    background: rgba(255, 255, 255, 0.2);
}

/* Responsive Design */
@media (max-width: 768px) {
    .nav-menu {
        display: none;
    }
    
    .nav-toggle {
        display: flex;
    }
    
    .hero {
        flex-direction: column;
        text-align: center;
        padding: 4rem 1rem;
    }
    
    .hero h1 {
        font-size: 2.5rem;
    }
    
    .hero-buttons {
        flex-direction: column;
        align-items: center;
    }
    
    .hero-image {
        margin-top: 2rem;
    }
    
    .about-content,
    .contact-content {
        grid-template-columns: 1fr;
        gap: 2rem;
    }
    
    .skills-content {
        grid-template-columns: 1fr;
    }
    
    .projects-grid {
        grid-template-columns: 1fr;
    }
    
    .footer-content {
        flex-direction: column;
        gap: 1rem;
    }
    
    .container {
        padding: 0 1rem;
    }
    
    .section-title {
        font-size: 2rem;
    }
}

/* Highlight */
.highlight {
    color: var(--accent-color);
    font-weight: 700;
}

/* Animations */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.fade-in-up {
    animation: fadeInUp 0.6s ease-out;
}

/* Smooth Scrolling */
html {
    scroll-behavior: smooth;
}

/* Custom Scrollbar */
::-webkit-scrollbar {
    width: 8px;
}

::-webkit-scrollbar-track {
    background: var(--background-color);
}

::-webkit-scrollbar-thumb {
    background: var(--primary-color);
    border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
    background: var(--secondary-color);
}`
  }

  private generatePortfolioJavaScript(): string {
    return `class Portfolio {
    constructor() {
        this.init();
    }
    
    init() {
        this.setupNavigation();
        this.setupContactForm();
        this.setupScrollEffects();
        this.setupAnimations();
    }
    
    setupNavigation() {
        // Mobile menu toggle
        const navToggle = document.querySelector('.nav-toggle');
        const navMenu = document.querySelector('.nav-menu');
        
        if (navToggle && navMenu) {
            navToggle.addEventListener('click', () => {
                navMenu.classList.toggle('active');
                navToggle.classList.toggle('active');
            });
        }
        
        // Smooth scrolling for navigation links
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = link.getAttribute('href');
                const targetSection = document.querySelector(targetId);
                
                if (targetSection) {
                    targetSection.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                    
                    // Close mobile menu if open
                    if (navMenu.classList.contains('active')) {
                        navMenu.classList.remove('active');
                        navToggle.classList.remove('active');
                    }
                }
            });
        });
        
        // Active navigation link on scroll
        window.addEventListener('scroll', () => {
            this.updateActiveNavLink();
        });
    }
    
    setupContactForm() {
        const contactForm = document.getElementById('contact-form');
        
        if (contactForm) {
            contactForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleFormSubmit(contactForm);
            });
        }
    }
    
    setupScrollEffects() {
        // Navbar background on scroll
        const navbar = document.querySelector('.navbar');
        
        window.addEventListener('scroll', () => {
            if (window.scrollY > 100) {
                navbar.style.background = 'rgba(255, 255, 255, 0.98)';
                navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
            } else {
                navbar.style.background = 'rgba(255, 255, 255, 0.95)';
                navbar.style.boxShadow = 'var(--shadow)';
            }
        });
        
        // Reveal animations on scroll
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in-up');
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);
        
        // Observe elements
        const elementsToObserve = [
            '.about-content',
            '.project-card',
            '.skills-category',
            '.contact-content'
        ];
        
        elementsToObserve.forEach(selector => {
            const elements = document.querySelectorAll(selector);
            elements.forEach(el => observer.observe(el));
        });
    }
    
    setupAnimations() {
        // Animate skill bars on scroll
        const skillBars = document.querySelectorAll('.skill-progress');
        
        const skillObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const skillBar = entry.target;
                    const width = skillBar.style.width;
                    skillBar.style.width = '0%';
                    
                    setTimeout(() => {
                        skillBar.style.width = width;
                    }, 200);
                    
                    skillObserver.unobserve(skillBar);
                }
            });
        }, { threshold: 0.5 });
        
        skillBars.forEach(bar => skillObserver.observe(bar));
        
        // Typing effect for hero title
        this.animateHeroTitle();
    }
    
    animateHeroTitle() {
        const heroTitle = document.querySelector('.hero h1');
        if (heroTitle) {
            const text = heroTitle.textContent;
            heroTitle.textContent = '';
            
            let index = 0;
            const typeInterval = setInterval(() => {
                if (index < text.length) {
                    heroTitle.textContent += text.charAt(index);
                    index++;
                } else {
                    clearInterval(typeInterval);
                }
            }, 50);
        }
    }
    
    updateActiveNavLink() {
        const sections = document.querySelectorAll('section');
        const navLinks = document.querySelectorAll('.nav-link');
        
        let current = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            if (pageYOffset >= (sectionTop - 200)) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href').slice(1) === current) {
                link.classList.add('active');
            }
        });
    }
    
    async handleFormSubmit(form) {
        const formData = new FormData(form);
        const formDataObj = Object.fromEntries(formData);
        
        // Show loading state
        const submitButton = form.querySelector('button[type="submit"]');
        const originalText = submitButton.textContent;
        submitButton.textContent = 'Sending...';
        submitButton.disabled = true;
        
        try {
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Show success message
            this.showNotification('Message sent successfully! I\'ll get back to you soon.', 'success');
            
            // Reset form
            form.reset();
            
        } catch (error) {
            // Show error message
            this.showNotification('Failed to send message. Please try again.', 'error');
        } finally {
            // Reset button
            submitButton.textContent = originalText;
            submitButton.disabled = false;
        }
    }
    
    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = \`notification notification-\${type}\`;
        notification.innerHTML = \`
            <div class="notification-content">
                <i class="fas fa-\${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
                <span>\${message}</span>
            </div>
        \`;
        
        // Add notification styles if not already present
        if (!document.querySelector('#notification-styles')) {
            const style = document.createElement('style');
            style.id = 'notification-styles';
            style.textContent = \`
                .notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: white;
                    padding: 1rem 1.5rem;
                    border-radius: 8px;
                    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
                    z-index: 10000;
                    max-width: 400px;
                    transform: translateX(100%);
                    transition: transform 0.3s ease;
                }
                
                .notification.show {
                    transform: translateX(0);
                }
                
                .notification-content {
                    display: flex;
                    align-items: center;
                    gap: 1rem;
                }
                
                .notification i {
                    font-size: 1.5rem;
                }
                
                .notification-success i {
                    color: #10b981;
                }
                
                .notification-error i {
                    color: #ef4444;
                }
                
                .notification-info i {
                    color: #3b82f6;
                }
                
                @keyframes slideIn {
                    from {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
                
                @keyframes slideOut {
                    from {
                        transform: translateX(0);
                        opacity: 1;
                    }
                    to {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                }
            \`;
            document.head.appendChild(style);
        }
        
        document.body.appendChild(notification);
        
        // Show notification
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        // Hide notification after 4 seconds
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 4000);
    }
}

// Initialize portfolio when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.portfolio = new Portfolio();
    console.log('🎨 Portfolio Website Loaded Successfully!');
});`
  }

  private generateGenericWebpage(prompt: string): { files: GeneratedFile[], explanation: string } {
    const files: GeneratedFile[] = [
      {
        name: 'index.html',
        content: this.generateGenericHTML(prompt),
        language: 'html'
      },
      {
        name: 'styles.css',
        content: this.generateGenericCSS(),
        language: 'css'
      },
      {
        name: 'script.js',
        content: this.generateGenericJavaScript(),
        language: 'javascript'
      }
    ]

    return {
      files,
      explanation: `A custom webpage generated based on your prompt: "${prompt}". This webpage includes modern design, responsive layout, and interactive features.`
    }
  }

  private analyzePrompt(prompt: string): { title: string; description: string; features: Array<{title: string, description: string, icon: string}>; theme: string } {
    const lowerPrompt = prompt.toLowerCase()
    
    // Determine theme based on prompt keywords
    let theme = 'Application'
    let title = 'AI Generated Webpage'
    let description = `Custom webpage based on: "${prompt}"`
    
    // Theme detection
    if (lowerPrompt.includes('business') || lowerPrompt.includes('company') || lowerPrompt.includes('corporate')) {
      theme = 'Business Platform'
      title = 'Business Solution Platform'
      description = 'Professional business platform with modern features and elegant design.'
    } else if (lowerPrompt.includes('education') || lowerPrompt.includes('learning') || lowerPrompt.includes('school')) {
      theme = 'Educational Platform'
      title = 'Learning Management System'
      description = 'Interactive educational platform designed for effective learning and engagement.'
    } else if (lowerPrompt.includes('ecommerce') || lowerPrompt.includes('shop') || lowerPrompt.includes('store')) {
      theme = 'E-commerce Platform'
      title = 'Online Store'
      description = 'Modern e-commerce platform with shopping cart and product management.'
    } else if (lowerPrompt.includes('social') || lowerPrompt.includes('community') || lowerPrompt.includes('network')) {
      theme = 'Social Platform'
      title = 'Social Network'
      description = 'Interactive social platform for connecting and sharing with others.'
    } else if (lowerPrompt.includes('blog') || lowerPrompt.includes('news') || lowerPrompt.includes('content')) {
      theme = 'Content Platform'
      title = 'Blog & Content Platform'
      description = 'Dynamic content management system for publishing and sharing articles.'
    } else if (lowerPrompt.includes('portfolio') || lowerPrompt.includes('showcase') || lowerPrompt.includes('gallery')) {
      theme = 'Portfolio Platform'
      title = 'Portfolio Showcase'
      description = 'Professional portfolio platform to showcase your work and achievements.'
    } else if (lowerPrompt.includes('health') || lowerPrompt.includes('fitness') || lowerPrompt.includes('medical')) {
      theme = 'Health Platform'
      title = 'Health & Wellness Platform'
      description = 'Comprehensive health and wellness tracking platform with modern interface.'
    } else if (lowerPrompt.includes('travel') || lowerPrompt.includes('hotel') || lowerPrompt.includes('booking')) {
      theme = 'Travel Platform'
      title = 'Travel & Booking Platform'
      description = 'Complete travel booking platform with destination discovery and reservations.'
    } else {
      theme = 'Custom Application'
      title = 'Custom Web Application'
      description = `Tailor-made web application designed specifically for: "${prompt}"`
    }
    
    // Generate relevant features based on theme
    const features = this.generateFeaturesForTheme(theme, lowerPrompt)
    
    return {
      title,
      description,
      features,
      theme
    }
  }
  
  private generateFeaturesForTheme(theme: string, prompt: string): Array<{title: string, description: string, icon: string}> {
    const baseFeatures = [
      { title: 'Responsive Design', description: 'Works perfectly on all devices and screen sizes', icon: 'mobile-alt' },
      { title: 'Modern Interface', description: 'Clean, intuitive user experience with smooth animations', icon: 'palette' },
      { title: 'Interactive Elements', description: 'Functional components with real-time feedback', icon: 'code' }
    ]
    
    const themeSpecificFeatures: Record<string, Array<{title: string, description: string, icon: string}>> = {
      'Business Platform': [
        { title: 'Analytics Dashboard', description: 'Real-time business metrics and performance tracking', icon: 'chart-line' },
        { title: 'Team Collaboration', description: 'Built-in tools for team communication and project management', icon: 'users' }
      ],
      'Educational Platform': [
        { title: 'Course Management', description: 'Organize and track educational content and progress', icon: 'graduation-cap' },
        { title: 'Interactive Learning', description: 'Engaging quizzes and interactive learning materials', icon: 'brain' }
      ],
      'E-commerce Platform': [
        { title: 'Shopping Cart', description: 'Secure shopping cart with multiple payment options', icon: 'shopping-cart' },
        { title: 'Product Catalog', description: 'Organized product display with search and filtering', icon: 'box' }
      ],
      'Social Platform': [
        { title: 'User Profiles', description: 'Customizable user profiles with social features', icon: 'user' },
        { title: 'Real-time Updates', description: 'Live notifications and activity feeds', icon: 'bell' }
      ],
      'Content Platform': [
        { title: 'Content Editor', description: 'Rich text editor with media support', icon: 'edit' },
        { title: 'Comment System', description: 'User engagement through comments and discussions', icon: 'comments' }
      ],
      'Portfolio Platform': [
        { title: 'Project Gallery', description: 'Showcase projects with images and descriptions', icon: 'images' },
        { title: 'Contact Forms', description: 'Professional contact forms for client inquiries', icon: 'envelope' }
      ],
      'Health Platform': [
        { title: 'Health Tracking', description: 'Monitor health metrics and wellness goals', icon: 'heartbeat' },
        { title: 'Progress Reports', description: 'Detailed progress tracking and insights', icon: 'chart-bar' }
      ],
      'Travel Platform': [
        { title: 'Destination Search', description: 'Find and explore travel destinations worldwide', icon: 'map' },
        { title: 'Booking System', description: 'Secure booking and reservation management', icon: 'calendar-check' }
      ]
    }
    
    const specificFeatures = themeSpecificFeatures[theme] || []
    return [...baseFeatures, ...specificFeatures]
  }
  
  private capitalizeFirst(str: string): string {
    return str.charAt(0).toUpperCase() + str.slice(1)
  }

  private generateGenericHTML(prompt: string): string {
    // Analyze the prompt to create relevant content
    const promptAnalysis = this.analyzePrompt(prompt)
    const { title, description, features, theme } = promptAnalysis
    
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title}</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>${title}</h1>
            <p>${description}</p>
        </header>
        
        <main>
            <section class="hero">
                <div class="hero-content">
                    <h2>Welcome to Your Custom ${this.capitalizeFirst(theme)}</h2>
                    <p>This intelligent webpage was dynamically generated based on your specific requirements: "${prompt}"</p>
                    <button id="cta-button" class="btn btn-primary">Get Started</button>
                </div>
            </section>
            
            <section class="features">
                <h2>Key Features</h2>
                <div class="features-grid">
                    ${features.map((feature, index) => `
                        <div class="feature-card">
                            <div class="feature-icon">
                                <i class="fas fa-${feature.icon}"></i>
                            </div>
                            <h3>${feature.title}</h3>
                            <p>${feature.description}</p>
                        </div>
                    `).join('')}
                </div>
            </section>
            
            <section class="interactive">
                <h2>Interactive Demo</h2>
                <div class="demo-container">
                    <div class="demo-controls">
                        <button id="demo-btn-1" class="btn">Show Alert</button>
                        <button id="demo-btn-2" class="btn">Change Theme</button>
                        <button id="demo-btn-3" class="btn">Add Content</button>
                    </div>
                    <div id="demo-output" class="demo-output">
                        <p>Click the buttons above to see interactive features in action!</p>
                    </div>
                </div>
            </section>
            
            <section class="content-area">
                <h2>Dynamic Content Area</h2>
                <div id="dynamic-content">
                    <p>This area can be dynamically updated with content based on your interactions.</p>
                </div>
            </section>
        </main>
        
        <footer>
            <div class="footer-content">
                <p>&copy; 2024 ${title}. Generated by AI Technology.</p>
                <div class="footer-links">
                    <a href="#" class="footer-link">About</a>
                    <a href="#" class="footer-link">Contact</a>
                    <a href="#" class="footer-link">Privacy</a>
                </div>
            </div>
        </footer>
    </div>
    <script src="script.js"></script>
</body>
</html>`
  }

  private generateGenericCSS(): string {
    return `:root {
    --primary-color: #3b82f6;
    --primary-hover: #2563eb;
    --secondary-color: #64748b;
    --accent-color: #8b5cf6;
    --accent-hover: #7c3aed;
    --success-color: #10b981;
    --warning-color: #f59e0b;
    --danger-color: #ef4444;
    --background-color: #f8fafc;
    --surface-color: #ffffff;
    --text-color: #1e293b;
    --text-secondary: #64748b;
    --border-color: #e2e8f0;
    --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    --radius: 12px;
    --radius-lg: 16px;
    --transition: all 0.3s ease;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    line-height: 1.6;
    color: var(--text-color);
    background-color: var(--background-color);
    min-height: 100vh;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem;
}

/* Header Styles */
header {
    text-align: center;
    margin-bottom: 3rem;
    padding: 3rem 2rem;
    background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
    color: white;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-lg);
    position: relative;
    overflow: hidden;
}

header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="white" opacity="0.1"/><circle cx="75" cy="75" r="1" fill="white" opacity="0.1"/><circle cx="50" cy="10" r="0.5" fill="white" opacity="0.1"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
    opacity: 0.1;
}

header h1 {
    font-size: 3rem;
    font-weight: 800;
    margin-bottom: 1rem;
    position: relative;
    z-index: 1;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
}

header p {
    font-size: 1.2rem;
    opacity: 0.95;
    position: relative;
    z-index: 1;
    max-width: 600px;
    margin: 0 auto;
}

/* Hero Section */
.hero {
    margin-bottom: 4rem;
}

.hero-content {
    text-align: center;
    padding: 3rem;
    background: var(--surface-color);
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-lg);
}

.hero-content h2 {
    font-size: 2.5rem;
    font-weight: 700;
    color: var(--primary-color);
    margin-bottom: 1.5rem;
}

.hero-content p {
    font-size: 1.1rem;
    color: var(--text-secondary);
    margin-bottom: 2rem;
    max-width: 800px;
    margin-left: auto;
    margin-right: auto;
}

/* Button Styles */
.btn {
    padding: 1rem 2rem;
    border: none;
    border-radius: var(--radius);
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    text-decoration: none;
    position: relative;
    overflow: hidden;
}

.btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
    transition: left 0.5s;
}

.btn:hover::before {
    left: 100%;
}

.btn-primary {
    background: var(--primary-color);
    color: white;
    box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
}

.btn-primary:hover {
    background: var(--primary-hover);
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
}

.btn-secondary {
    background: var(--secondary-color);
    color: white;
}

.btn-secondary:hover {
    background: #475569;
    transform: translateY(-2px);
}

.btn-success {
    background: var(--success-color);
    color: white;
}

.btn-success:hover {
    background: #059669;
    transform: translateY(-2px);
}

.btn-warning {
    background: var(--warning-color);
    color: white;
}

.btn-warning:hover {
    background: #d97706;
    transform: translateY(-2px);
}

/* Features Section */
.features {
    margin-bottom: 4rem;
}

.features h2 {
    text-align: center;
    font-size: 2.5rem;
    font-weight: 700;
    color: var(--text-color);
    margin-bottom: 3rem;
}

.features-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
}

.feature-card {
    background: var(--surface-color);
    padding: 2rem;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow);
    transition: var(--transition);
    text-align: center;
    position: relative;
    overflow: hidden;
}

.feature-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
    transform: scaleX(0);
    transition: transform 0.3s ease;
}

.feature-card:hover::before {
    transform: scaleX(1);
}

.feature-card:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-xl);
}

.feature-icon {
    width: 60px;
    height: 60px;
    margin: 0 auto 1.5rem;
    background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.5rem;
    box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
}

.feature-card h3 {
    font-size: 1.3rem;
    font-weight: 600;
    color: var(--text-color);
    margin-bottom: 1rem;
}

.feature-card p {
    color: var(--text-secondary);
    line-height: 1.6;
}

/* Interactive Section */
.interactive {
    margin-bottom: 4rem;
}

.interactive h2 {
    text-align: center;
    font-size: 2.5rem;
    font-weight: 700;
    color: var(--text-color);
    margin-bottom: 3rem;
}

.demo-container {
    background: var(--surface-color);
    padding: 2rem;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-lg);
}

.demo-controls {
    display: flex;
    gap: 1rem;
    margin-bottom: 2rem;
    flex-wrap: wrap;
    justify-content: center;
}

.demo-output {
    background: var(--background-color);
    padding: 2rem;
    border-radius: var(--radius);
    border: 2px solid var(--border-color);
    min-height: 150px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    color: var(--text-secondary);
    transition: var(--transition);
}

/* Content Area */
.content-area {
    margin-bottom: 4rem;
}

.content-area h2 {
    text-align: center;
    font-size: 2.5rem;
    font-weight: 700;
    color: var(--text-color);
    margin-bottom: 3rem;
}

#dynamic-content {
    background: var(--surface-color);
    padding: 2rem;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow);
    min-height: 200px;
    transition: var(--transition);
}

/* Footer */
footer {
    background: var(--surface-color);
    padding: 3rem 2rem;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-lg);
    margin-top: 4rem;
}

.footer-content {
    text-align: center;
}

.footer-content p {
    color: var(--text-secondary);
    margin-bottom: 1rem;
}

.footer-links {
    display: flex;
    gap: 2rem;
    justify-content: center;
    flex-wrap: wrap;
}

.footer-link {
    color: var(--primary-color);
    text-decoration: none;
    font-weight: 500;
    transition: var(--transition);
}

.footer-link:hover {
    color: var(--primary-hover);
    text-decoration: underline;
}

/* Responsive Design */
@media (max-width: 768px) {
    .container {
        padding: 1rem;
    }
    
    header h1 {
        font-size: 2rem;
    }
    
    .hero-content h2 {
        font-size: 1.8rem;
    }
    
    .features h2,
    .interactive h2,
    .content-area h2 {
        font-size: 2rem;
    }
    
    .features-grid {
        grid-template-columns: 1fr;
    }
    
    .demo-controls {
        flex-direction: column;
        align-items: center;
    }
    
    .btn {
        width: 100%;
        max-width: 300px;
        justify-content: center;
    }
    
    .footer-links {
        flex-direction: column;
        gap: 1rem;
    }
}

/* Animation Classes */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateX(-20px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

@keyframes pulse {
    0%, 100% {
        transform: scale(1);
    }
    50% {
        transform: scale(1.05);
    }
}

.animate-fadeIn {
    animation: fadeIn 0.6s ease-out;
}

.animate-slideIn {
    animation: slideIn 0.6s ease-out;
}

.animate-pulse {
    animation: pulse 2s infinite;
}

/* Theme Classes */
.theme-dark {
    --background-color: #0f172a;
    --surface-color: #1e293b;
    --text-color: #f1f5f9;
    --text-secondary: #94a3b8;
    --border-color: #334155;
}

.theme-warm {
    --primary-color: #ea580c;
    --primary-hover: #dc2626;
    --accent-color: #f59e0b;
    --accent-hover: #d97706;
}

.theme-cool {
    --primary-color: #0891b2;
    --primary-hover: #0e7490;
    --accent-color: #6366f1;
    --accent-hover: #4f46e5;
}

/* Utility Classes */
.text-center {
    text-align: center;
}

.mb-4 {
    margin-bottom: 1.5rem;
}

.p-4 {
    padding: 1.5rem;
}

.rounded {
    border-radius: var(--radius);
}

.shadow {
    box-shadow: var(--shadow);
}

.bg-primary {
    background: var(--primary-color);
}

.text-white {
    color: white;
}
`
  }

  private generateGenericJavaScript(): string {
    return `class IntelligentWebpage {
    constructor() {
        this.currentTheme = 'default';
        this.contentItems = [];
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.setupAnimations();
        this.setupThemeSystem();
        this.setupInteractiveFeatures();
        this.initializeContent();
        
        console.log('🚀 Intelligent Webpage Initialized Successfully!');
    }
    
    setupEventListeners() {
        // CTA Button
        const ctaButton = document.getElementById('cta-button');
        if (ctaButton) {
            ctaButton.addEventListener('click', () => this.handleCTAClick());
        }
        
        // Demo Buttons
        const demoBtn1 = document.getElementById('demo-btn-1');
        const demoBtn2 = document.getElementById('demo-btn-2');
        const demoBtn3 = document.getElementById('demo-btn-3');
        
        if (demoBtn1) demoBtn1.addEventListener('click', () => this.showAlert());
        if (demoBtn2) demoBtn2.addEventListener('click', () => this.changeTheme());
        if (demoBtn3) demoBtn3.addEventListener('click', () => this.addContent());
        
        // Feature Cards
        const featureCards = document.querySelectorAll('.feature-card');
        featureCards.forEach(card => {
            card.addEventListener('click', () => this.handleFeatureClick(card));
        });
        
        // Footer Links
        const footerLinks = document.querySelectorAll('.footer-link');
        footerLinks.forEach(link => {
            link.addEventListener('click', (e) => this.handleFooterClick(e));
        });
    }
    
    setupAnimations() {
        // Animate elements on page load
        this.animateOnLoad();
        
        // Setup scroll animations
        this.setupScrollAnimations();
        
        // Setup hover animations
        this.setupHoverAnimations();
    }
    
    setupThemeSystem() {
        this.themes = {
            default: {
                primary: '#3b82f6',
                accent: '#8b5cf6',
                name: 'Default Blue'
            },
            warm: {
                primary: '#ea580c', 
                accent: '#f59e0b',
                name: 'Warm Sunset'
            },
            cool: {
                primary: '#0891b2',
                accent: '#6366f1', 
                name: 'Cool Ocean'
            },
            dark: {
                primary: '#1f2937',
                accent: '#9333ea',
                name: 'Dark Mode'
            }
        };
    }
    
    setupInteractiveFeatures() {
        // Add ripple effect to buttons
        this.addRippleEffect();
        
        // Setup smooth scrolling
        this.setupSmoothScrolling();
        
        // Initialize dynamic content system
        this.initializeDynamicContent();
    }
    
    initializeContent() {
        this.contentItems = [
            {
                title: 'Welcome to Your Intelligent Webpage',
                content: 'This webpage was dynamically generated with AI technology and includes advanced interactive features.',
                type: 'info'
            }
        ];
    }
    
    // Event Handlers
    handleCTAClick() {
        const button = document.getElementById('cta-button');
        const originalText = button.textContent;
        
        // Show loading state
        button.textContent = '🚀 Launching...';
        button.disabled = true;
        
        setTimeout(() => {
            this.showNotification('🎉 Welcome! Your intelligent webpage is ready for exploration.', 'success');
            button.textContent = '✨ Get Started';
            button.disabled = false;
            
            // Scroll to features section
            this.scrollToSection('features');
        }, 1500);
    }
    
    showAlert() {
        const messages = [
            '🎯 Success! Interactive features are working perfectly!',
            '✨ Amazing! The AI-generated webpage responds to your actions.',
            '🚀 Excellent! All systems are operational and functional.',
            '💡 Perfect! The intelligent webpage is fully interactive.',
            '🎉 Outstanding! Your custom webpage is ready to use!'
        ];
        
        const randomMessage = messages[Math.floor(Math.random() * messages.length)];
        this.showNotification(randomMessage, 'success');
    }
    
    changeTheme() {
        const themeKeys = Object.keys(this.themes);
        const currentIndex = themeKeys.indexOf(this.currentTheme);
        const nextIndex = (currentIndex + 1) % themeKeys.length;
        const newTheme = themeKeys[nextIndex];
        
        this.applyTheme(newTheme);
        this.currentTheme = newTheme;
        
        const themeInfo = this.themes[newTheme];
        this.showNotification(\`🎨 Theme changed to \${themeInfo.name}\`, 'info');
    }
    
    addContent() {
        const newContent = {
            title: \`Dynamic Content \${this.contentItems.length + 1}\`,
            content: \`This content was added dynamically at \${new Date().toLocaleTimeString()}. The webpage can be updated in real-time!\`,
            type: 'dynamic'
        };
        
        this.contentItems.push(newContent);
        this.renderContent();
        
        this.showNotification('📝 New content added successfully!', 'success');
    }
    
    handleFeatureClick(card) {
        const title = card.querySelector('h3').textContent;
        const description = card.querySelector('p').textContent;
        
        // Add pulse animation
        card.style.animation = 'pulse 0.6s ease-in-out';
        setTimeout(() => {
            card.style.animation = '';
        }, 600);
        
        this.showNotification(\`🔍 Feature: \${title}\`, 'info');
    }
    
    handleFooterClick(e) {
        e.preventDefault();
        const linkText = e.target.textContent;
        this.showNotification(\`📎 Navigation: \${linkText}\`, 'info');
    }
    
    // Theme Management
    applyTheme(themeName) {
        const theme = this.themes[themeName];
        const root = document.documentElement;
        
        // Update CSS custom properties
        root.style.setProperty('--primary-color', theme.primary);
        root.style.setProperty('--accent-color', theme.accent);
        
        // Add theme class to body
        document.body.className = themeName === 'dark' ? 'theme-dark' : '';
        
        // Update header gradient
        const header = document.querySelector('header');
        if (header) {
            header.style.background = \`linear-gradient(135deg, \${theme.primary}, \${theme.accent})\`;
        }
    }
    
    // Animation Methods
    animateOnLoad() {
        const elements = document.querySelectorAll('.feature-card, .hero-content, .demo-container');
        
        elements.forEach((element, index) => {
            element.style.opacity = '0';
            element.style.transform = 'translateY(30px)';
            
            setTimeout(() => {
                element.style.transition = 'all 0.8s cubic-bezier(0.4, 0, 0.2, 1)';
                element.style.opacity = '1';
                element.style.transform = 'translateY(0)';
            }, index * 150);
        });
    }
    
    setupScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -100px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-fadeIn');
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);
        
        // Observe all sections
        document.querySelectorAll('section').forEach(section => {
            observer.observe(section);
        });
    }
    
    setupHoverAnimations() {
        const interactiveElements = document.querySelectorAll('.btn, .feature-card, .footer-link');
        
        interactiveElements.forEach(element => {
            element.addEventListener('mouseenter', () => {
                element.style.transform = 'translateY(-3px) scale(1.02)';
            });
            
            element.addEventListener('mouseleave', () => {
                element.style.transform = 'translateY(0) scale(1)';
            });
        });
    }
    
    // UI Enhancement Methods
    addRippleEffect() {
        const buttons = document.querySelectorAll('.btn');
        
        buttons.forEach(button => {
            button.addEventListener('click', function(e) {
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.width = ripple.style.height = size + 'px';
                ripple.style.left = x + 'px';
                ripple.style.top = y + 'px';
                ripple.classList.add('ripple');
                
                this.appendChild(ripple);
                
                setTimeout(() => {
                    ripple.remove();
                }, 600);
            });
        });
        
        // Add ripple CSS
        const style = document.createElement('style');
        style.textContent = \`
            .btn {
                position: relative;
                overflow: hidden;
            }
            .ripple {
                position: absolute;
                border-radius: 50%;
                background: rgba(255, 255, 255, 0.6);
                transform: scale(0);
                animation: ripple-animation 0.6s ease-out;
            }
            @keyframes ripple-animation {
                to {
                    transform: scale(4);
                    opacity: 0;
                }
            }
        \`;
        document.head.appendChild(style);
    }
    
    setupSmoothScrolling() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    }
    
    initializeDynamicContent() {
        this.renderContent();
    }
    
    renderContent() {
        const container = document.getElementById('dynamic-content');
        if (!container) return;
        
        container.innerHTML = this.contentItems.map(item => \`
            <div class="content-item animate-fadeIn">
                <h3>\${item.title}</h3>
                <p>\${item.content}</p>
                <small class="content-meta">Type: \${item.type} | Added: \${new Date().toLocaleTimeString()}</small>
            </div>
        \`).join('');
    }
    
    // Utility Methods
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = \`notification notification-\${type}\`;
        notification.innerHTML = \`
            <div class="notification-content">
                <span class="notification-message">\${message}</span>
                <button class="notification-close" onclick="this.parentElement.parentElement.remove()">×</button>
            </div>
        \`;
        
        // Add notification styles if not present
        if (!document.getElementById('notification-styles')) {
            const notificationStyles = document.createElement('style');
            notificationStyles.id = 'notification-styles';
            notificationStyles.textContent = \`
                .notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    z-index: 10000;
                    min-width: 300px;
                    max-width: 500px;
                    border-radius: 12px;
                    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
                    animation: slideInRight 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
                    backdrop-filter: blur(10px);
                }
                
                .notification-content {
                    padding: 1rem 1.5rem;
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    gap: 1rem;
                }
                
                .notification-message {
                    flex: 1;
                    font-weight: 500;
                }
                
                .notification-close {
                    background: none;
                    border: none;
                    font-size: 1.2rem;
                    cursor: pointer;
                    opacity: 0.7;
                    transition: opacity 0.2s;
                }
                
                .notification-close:hover {
                    opacity: 1;
                }
                
                .notification-info {
                    background: linear-gradient(135deg, #3b82f6, #8b5cf6);
                    color: white;
                }
                
                .notification-success {
                    background: linear-gradient(135deg, #10b981, #059669);
                    color: white;
                }
                
                .notification-warning {
                    background: linear-gradient(135deg, #f59e0b, #d97706);
                    color: white;
                }
                
                .notification-error {
                    background: linear-gradient(135deg, #ef4444, #dc2626);
                    color: white;
                }
                
                @keyframes slideInRight {
                    from {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
                
                @keyframes slideOutRight {
                    from {
                        transform: translateX(0);
                        opacity: 1;
                    }
                    to {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                }
                
                .content-item {
                    background: var(--surface-color);
                    padding: 1.5rem;
                    border-radius: 12px;
                    margin-bottom: 1rem;
                    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                    border-left: 4px solid var(--primary-color);
                }
                
                .content-item h3 {
                    color: var(--primary-color);
                    margin-bottom: 0.5rem;
                }
                
                .content-meta {
                    color: var(--text-secondary);
                    font-size: 0.9rem;
                    opacity: 0.8;
                }
            \`;
            document.head.appendChild(notificationStyles);
        }
        
        document.body.appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.style.animation = 'slideOutRight 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55)';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 400);
            }
        }, 5000);
    }
    
    scrollToSection(sectionId) {
        const section = document.getElementById(sectionId);
        if (section) {
            section.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }
}

// Initialize the webpage when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.intelligentWebpage = new IntelligentWebpage();
    console.log('✨ Intelligent Webpage System - All Systems Operational!');
});

// Add global error handling
window.addEventListener('error', (event) => {
    console.error('🚨 Webpage Error:', event.error);
    if (window.intelligentWebpage) {
        window.intelligentWebpage.showNotification('An error occurred, but the webpage continues to function.', 'error');
    }
});

// Add performance monitoring
if ('performance' in window) {
    window.addEventListener('load', () => {
        const perfData = performance.getEntriesByType('navigation')[0];
        console.log(\`⚡ Page loaded in \${perfData.domComplete}ms\`);
        
        if (window.intelligentWebpage) {
            setTimeout(() => {
                window.intelligentWebpage.showNotification('🚀 Webpage loaded successfully!', 'success');
            }, 1000);
        }
    });
}`
  }
}

// Initialize the code generator
const codeGenerator = new LocalCodeGenerator()

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { prompt, type, context } = body
    
    if (!prompt) {
      return NextResponse.json({
        success: false,
        error: 'Prompt is required'
      }, { status: 400 })
    }

    addConsoleLog(`Processing prompt: "${prompt}"`)
    addConsoleLog('Generating complete webpage with Local AI Engine...')

    // Generate webpage using local code generator
    const result = codeGenerator.generateWebpage(prompt)

    addConsoleLog('✅ Successfully generated complete webpage')
    addConsoleLog(`📁 Created ${result.files.length} files: index.html, styles.css, script.js`)
    addConsoleLog(`🎯 Generated from prompt: "${prompt.substring(0, 100)}${prompt.length > 100 ? '...' : ''}"`)

    return NextResponse.json({
      success: true,
      files: result.files,
      explanation: result.explanation
    })

  } catch (error) {
    console.error('Local generation error:', error)
    addConsoleLog(`❌ Error processing prompt: ${error}`)
    
    return NextResponse.json({
      success: false,
      error: 'Failed to process prompt'
    }, { status: 500 })
  }
}

function addConsoleLog(message: string) {
  console.log(`[AI-Prompt API] ${message}`)
}

export async function GET() {
  return NextResponse.json({
    message: 'Local AI Prompt Processing API is running',
    endpoints: {
      generate: 'POST /api/ai-prompt - Generate complete webpage from prompt',
      health: 'GET /api/ai-prompt - Health check'
    },
    capabilities: [
      'Complete webpage generation (HTML, CSS, JavaScript)',
      'Multiple templates: Todo List, Weather App, Calculator, Games, Portfolio',
      'Responsive design',
      'Modern styling with CSS3',
      'Interactive JavaScript functionality',
      'Real-time preview generation',
      'Any prompt processing - No external API dependencies',
      'Local generation - Fast and reliable'
    ]
  })
}