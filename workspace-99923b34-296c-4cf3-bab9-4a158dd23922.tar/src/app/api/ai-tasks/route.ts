import { NextRequest, NextResponse } from 'next/server'

interface TaskAnalysis {
  id: string
  title: string
  description: string
  priority: 'high' | 'medium' | 'low'
  estimatedTime: number
  category: 'frontend' | 'backend' | 'testing' | 'optimization' | 'bugfix'
}

interface CodeAnalysis {
  complexity: number
  issues: string[]
  suggestions: string[]
  improvements: string[]
}

export async function POST(request: NextRequest) {
  try {
    const { code, language, currentTasks } = await request.json()
    
    // AI-powered code analysis
    const analysis: CodeAnalysis = {
      complexity: analyzeComplexity(code),
      issues: detectIssues(code, language),
      suggestions: generateSuggestions(code, language),
      improvements: generateImprovements(code, language)
    }
    
    // Generate tasks based on analysis
    const newTasks: TaskAnalysis[] = generateTasksFromAnalysis(analysis, currentTasks)
    
    return NextResponse.json({
      success: true,
      analysis,
      tasks: newTasks,
      message: 'AI analysis completed successfully'
    })
    
  } catch (error) {
    console.error('AI analysis error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to analyze code' },
      { status: 500 }
    )
  }
}

function analyzeComplexity(code: string): number {
  // Simple complexity analysis based on various factors
  const lines = code.split('\n').length
  const functions = (code.match(/function\s+\w+/g) || []).length
  const loops = (code.match(/(for|while)\s*\(/g) || []).length
  const conditionals = (code.match(/(if|else|switch)\s*\(/g) || []).length
  
  const complexity = (lines * 0.1) + (functions * 2) + (loops * 3) + (conditionals * 1.5)
  return Math.min(Math.max(complexity, 1), 10)
}

function detectIssues(code: string, language: string): string[] {
  const issues: string[] = []
  
  // Common issues detection
  if (language === 'javascript') {
    // Check for console.log statements
    if (code.includes('console.log')) {
      issues.push('Remove debug console.log statements')
    }
    
    // Check for var usage
    if (code.includes('var ')) {
      issues.push('Use const/let instead of var')
    }
    
    // Check for missing semicolons (basic check)
    const lines = code.split('\n')
    lines.forEach((line, index) => {
      const trimmed = line.trim()
      if (trimmed && !trimmed.endsWith(';') && !trimmed.endsWith('{') && !trimmed.endsWith('}') && 
          !trimmed.startsWith('//') && !trimmed.startsWith('/*') && !trimmed.includes('return')) {
        issues.push(`Missing semicolon on line ${index + 1}`)
      }
    })
  }
  
  // Check for very long lines
  const longLines = code.split('\n').filter(line => line.length > 100)
  if (longLines.length > 0) {
    issues.push(`${longLines.length} lines exceed 100 characters`)
  }
  
  // Check for deeply nested code
  const maxIndentation = Math.max(...code.split('\n').map(line => 
    line.match(/^\s*/)?.[0]?.length || 0
  ))
  if (maxIndentation > 8) {
    issues.push('Code is deeply nested, consider refactoring')
  }
  
  return issues
}

function generateSuggestions(code: string, language: string): string[] {
  const suggestions: string[] = []
  
  if (language === 'javascript') {
    // Suggest modern JavaScript features
    if (code.includes('function ') && !code.includes('=>')) {
      suggestions.push('Consider using arrow functions for better readability')
    }
    
    if (code.includes('var ')) {
      suggestions.push('Use const and let for variable declarations')
    }
    
    if (code.includes('.then(') && !code.includes('async')) {
      suggestions.push('Consider using async/await instead of promises')
    }
    
    // Suggest error handling
    if (!code.includes('try') && !code.includes('catch')) {
      suggestions.push('Add error handling with try-catch blocks')
    }
    
    // Suggest code organization
    if (code.length > 500 && !code.includes('export')) {
      suggestions.push('Consider splitting code into smaller modules')
    }
  }
  
  // General suggestions
  if (code.length > 1000) {
    suggestions.push('Consider adding comments for complex logic')
  }
  
  return suggestions
}

function generateImprovements(code: string, language: string): string[] {
  const improvements: string[] = []
  
  if (language === 'javascript') {
    // Performance improvements
    if (code.includes('for (let i = 0; i <')) {
      improvements.push('Consider using array methods like map/filter/reduce for better performance')
    }
    
    // Security improvements
    if (code.includes('innerHTML') || code.includes('eval(')) {
      improvements.push('Avoid using innerHTML or eval() for security reasons')
    }
    
    // Readability improvements
    if (code.includes('===') && code.includes('!==')) {
      improvements.push('Good use of strict equality operators')
    } else {
      improvements.push('Use strict equality operators (===, !==) for type safety')
    }
  }
  
  return improvements
}

function generateTasksFromAnalysis(analysis: CodeAnalysis, currentTasks: any[]): TaskAnalysis[] {
  const tasks: TaskAnalysis[] = []
  
  // Generate tasks based on issues
  analysis.issues.forEach((issue, index) => {
    tasks.push({
      id: `issue-${Date.now()}-${index}`,
      title: `Fix: ${issue}`,
      description: `Address the identified issue: ${issue}`,
      priority: analysis.complexity > 7 ? 'high' : 'medium',
      estimatedTime: analysis.complexity > 7 ? 30 : 15,
      category: 'bugfix'
    })
  })
  
  // Generate tasks based on suggestions
  analysis.suggestions.forEach((suggestion, index) => {
    tasks.push({
      id: `suggestion-${Date.now()}-${index}`,
      title: `Improve: ${suggestion}`,
      description: `Implement the suggested improvement: ${suggestion}`,
      priority: 'medium',
      estimatedTime: 20,
      category: 'optimization'
    })
  })
  
  // Generate tasks based on improvements
  analysis.improvements.forEach((improvement, index) => {
    tasks.push({
      id: `improvement-${Date.now()}-${index}`,
      title: `Enhance: ${improvement}`,
      description: `Apply the enhancement: ${improvement}`,
      priority: 'low',
      estimatedTime: 25,
      category: 'optimization'
    })
  })
  
  // Add complexity-based tasks
  if (analysis.complexity > 8) {
    tasks.push({
      id: `complexity-${Date.now()}`,
      title: 'Reduce code complexity',
      description: 'The code has high complexity. Consider refactoring into smaller functions.',
      priority: 'high',
      estimatedTime: 45,
      category: 'optimization'
    })
  }
  
  // Filter out tasks that already exist
  const existingTaskTitles = currentTasks.map((task: any) => task.title)
  return tasks.filter(task => !existingTaskTitles.includes(task.title))
}

export async function GET() {
  return NextResponse.json({
    message: 'AI Task Management API is running',
    endpoints: {
      analysis: 'POST /api/ai-tasks - Analyze code and generate tasks',
      health: 'GET /api/ai-tasks - Health check'
    }
  })
}