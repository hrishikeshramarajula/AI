import { NextRequest, NextResponse } from 'next/server';
import { EnhancedFullstackGenerator } from '@/lib/enhancedFullstackGenerator';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { prompt, context = {} } = body;

    if (!prompt) {
      return NextResponse.json(
        { error: 'Prompt is required' },
        { status: 400 }
      );
    }

    console.log('🚀 Enhanced Fullstack Generation for:', prompt);

    // Generate the complete fullstack project with enhanced AI analysis
    const result = await EnhancedFullstackGenerator.generateFromSinglePrompt(prompt, context);

    // Return comprehensive response with project details and preview info
    return NextResponse.json({
      success: true,
      project: result.project,
      preview: {
        url: result.previewUrl,
        instructions: `Open ${result.previewUrl} to see your application running`,
        estimatedTime: result.estimatedTime
      },
      setup: {
        commands: result.setupCommands,
        instructions: result.project.setupInstructions
      },
      summary: {
        name: result.project.structure.name,
        description: result.project.structure.description,
        files: result.project.files.length,
        features: result.features,
        framework: result.project.structure.framework,
        database: result.project.structure.database,
        estimatedTime: result.estimatedTime
      },
      message: `🎉 Successfully generated complete ${result.project.structure.name}!\\n\\nWhat was created:\\n• ${result.project.files.length} files including frontend, backend, and database\\n• Features: ${result.features.join(', ')}\\n• Framework: ${result.project.structure.framework} with ${result.project.structure.database}\\n• Ready to run in ${result.estimatedTime}\\n\\nNext steps:\\n1. Run the setup commands below\\n2. Open the preview URL\\n3. Start using your new application!`
    });

  } catch (error) {
    console.error('Enhanced fullstack generation error:', error);
    
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to generate enhanced fullstack project',
        message: 'I encountered an error while generating your complete fullstack application. Please try again with a clearer description.',
        suggestions: [
          'Try describing your project in simpler terms',
          'Focus on the main features you need (e.g., "todo list with database")',
          'Specify the type of application (e.g., blog, e-commerce, dashboard)',
          'Mention any specific requirements like authentication or real-time features'
        ],
        fallback: {
          simpleProject: {
            name: 'Simple Web App',
            description: 'A basic web application with CRUD operations',
            features: ['responsive', 'database', 'api'],
            setupTime: '2-3 minutes'
          }
        }
      },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    message: 'Enhanced Fullstack Generator API',
    capabilities: [
      '🤖 AI-powered analysis of natural language requests',
      '🏗️ Complete frontend + backend generation from single text prompt',
      '🗄️ Automatic database schema and API creation',
      '🎨 Modern UI components with responsive design',
      '⚡ Real-time preview and live development',
      '📊 Project structure and file generation',
      '🔧 Setup instructions and deployment guidance'
    ],
    examples: [
      {
        prompt: 'Create a todo list application with database',
        features: ['CRUD operations', 'SQLite database', 'React frontend', 'Modern UI']
      },
      {
        prompt: 'Build a blog CMS with user authentication',
        features: ['Post management', 'User auth', 'Comments', 'Admin panel']
      },
      {
        prompt: 'Make an e-commerce platform with shopping cart',
        features: ['Product catalog', 'Shopping cart', 'User accounts', 'Checkout']
      },
      {
        prompt: 'Create a real-time chat application',
        features: ['WebSocket support', 'User rooms', 'Message history', 'Online status']
      },
      {
        prompt: 'Build an admin dashboard with charts',
        features: ['Data visualization', 'User management', 'Analytics', 'Reports']
      }
    ],
    features: [
      '🧠 Intelligent prompt analysis',
      '📝 Automatic code generation',
      '🗄️ Database schema creation',
      '🔌 API endpoint generation',
      '🎨 Frontend component creation',
      '⚙️ Configuration file setup',
      '📚 Documentation generation',
      '🚀 One-click deployment setup'
    ]
  });
}