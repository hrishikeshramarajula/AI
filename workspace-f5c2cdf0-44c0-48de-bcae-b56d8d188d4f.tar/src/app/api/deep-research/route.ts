import { NextRequest, NextResponse } from 'next/server';
import { getZAIInstance, safeZAIChatCompletion } from '@/lib/zaiHelper';
import { ContentFormatter } from '@/lib/contentFormatter';
import { IndiaResearchHelper } from '@/lib/indiaResearchHelper';

export async function POST(request: NextRequest) {
  const startTime = Date.now();
  let message: string;
  
  try {
    console.log('🔬 Deep Research API: Processing real-time research request...');
    
    const body = await request.json();
    message = body?.message || '';
    const { 
      config = {},
      model = 'claude-3-5-sonnet' // Use Claude Sonnet for better research
    } = body;

    if (!message || !message.trim()) {
      return NextResponse.json({
        error: 'Research query is required',
        success: false
      }, { status: 400 });
    }

    console.log('🔬 Deep Research Query:', message.substring(0, 100) + (message.length > 100 ? '...' : ''));

    // Generate real-time research using AI with enhanced retry logic
    console.log('🚀 Deep Research: Starting AI-powered research...');
    const researchResponse = await generateRealResearchContent(message, config, model);
    
    console.log('✅ Real-time research completed successfully');
    console.log(`📝 Generated content length: ${researchResponse.length} characters`);

    // Create research output with real content
    const researchOutput = {
      success: true,
      query: message,
      response: researchResponse,
      _metadata: {
        processingTime: Date.now() - startTime,
        model: model,
        timestamp: new Date().toISOString(),
        researchMode: 'real-time-ai',
        processingMethod: 'ai-generated',
        researchStages: ['AI Content Generation']
      }
    };

    console.log('✅ Deep Research API: Real-time processing completed successfully');
    console.log(`📊 Research metadata:`, {
      processingTime: researchOutput._metadata.processingTime,
      researchDepth: 'real-ai',
      researchStages: researchOutput._metadata.researchStages
    });

    return NextResponse.json(researchOutput);

  } catch (error) {
    console.error('❌ Deep Research API Error:', error);
    
    const processingTime = Date.now() - startTime;
    
    // Try to get AI-generated content even on error, don't fall back to predefined data
    let fallbackContent = '';
    try {
      console.log('🔄 Attempting to generate AI fallback content...');
      const zai = await getZAIInstance();
      const fallbackPrompt = `Generate a comprehensive research report on: ${query}. Focus on providing factual, current information. Keep it detailed but concise.`;
      
      const fallbackCompletion = await zai.chat.completions.create({
        messages: [
          {
            role: "system",
            content: "You are a helpful research assistant providing accurate information."
          },
          {
            role: "user",
            content: fallbackPrompt
          }
        ],
        model: "llama-4-maverick-free",
        temperature: 0.5,
        max_tokens: 3000
      });
      
      fallbackContent = fallbackCompletion.choices[0]?.message?.content || `Research on ${query}: Unable to generate comprehensive content due to technical issues.`;
    } catch (fallbackError) {
      console.error('❌ AI fallback also failed:', fallbackError.message);
      // Last resort - minimal helpful response
      fallbackContent = `Research Analysis: ${query}

This research query encountered technical difficulties during processing. The system is designed to provide comprehensive, up-to-date information through AI-powered research. Please try again or check your internet connection.

For immediate assistance with information about "${query}", consider:
- Searching recent news sources
- Checking official websites
- Consulting reliable databases and publications

The research system will be back online shortly to provide detailed analysis.`;
    }
    
    return NextResponse.json({
      success: true,
      query: body?.message || 'Unknown query',
      response: fallbackContent,
      _metadata: {
        processingTime,
        error: true,
        errorMessage: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString(),
        researchMode: 'ai-fallback-research',
        processingMethod: 'ai-generated-fallback'
      }
    }, { status: 200 }); // Always return 200 to prevent frontend errors
  }
}

// Generate comprehensive fallback content when AI research fails
function generateComprehensiveFallbackContent(query: string): string {
  // This function is kept for emergencies but should rarely be used
  return `Research Analysis: ${query}

This research query encountered technical difficulties during processing. The system is designed to provide comprehensive, up-to-date information through AI-powered research.

Please try again or check your internet connection. For immediate assistance with information about "${query}", consider:
- Searching recent news sources
- Checking official websites  
- Consulting reliable databases and publications

The research system will be back online shortly to provide detailed analysis.`;
}

// Generate real research content using AI with comprehensive retry logic
async function generateRealResearchContent(query: string, config: any, model: string): Promise<string> {
  const maxRetries = 5;
  const retryDelay = 3000; // 3 seconds between retries
  
  // Priority list of models for deep research
  const researchModels = [
    'claude-3-5-sonnet',      // Best for research
    'claude-3-opus',         // High quality alternative
    'gpt-4o',                // Powerful research model
    'gemini-2-5-pro-free',   // Free research model
    'llama-4-maverick-free', // Free alternative
  ];
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      console.log(`🧠 Research attempt ${attempt}/${maxRetries} using model: ${model}`);
      
      // Use the provided model or fall back to research models
      const currentModel = researchModels.includes(model) ? model : researchModels[0];
      
      const zai = await getZAIInstance();
      
      // Check if this is an India-related research query
      const cleanQuery = query.trim().toLowerCase();
      let researchPrompt: string;
      
      if (cleanQuery.includes('india') || cleanQuery.includes('bharat')) {
        // Use enhanced India research with real-time data
        console.log('🇮🇳 Using enhanced India research with real-time data');
        researchPrompt = createEnhancedIndiaResearchPrompt(query, config);
      } else {
        // Use enhanced research prompt for real-time data
        researchPrompt = createEnhancedResearchPrompt(query, config);
      }
      
      // Make AI call with extended timeout for deep research
      const completion = await Promise.race([
        safeZAIChatCompletion([
          {
            role: "system",
            content: "You are an expert research analyst providing comprehensive, accurate, and in-depth analysis on any topic. You provide specific facts, detailed analysis, and expert-level insights. Focus on factual, verifiable information and include current, up-to-date data."
          },
          {
            role: "user",
            content: researchPrompt
          }
        ], {
          model: currentModel,
          temperature: 0.3, // Lower temperature for more accurate research
          max_tokens: 12000 // Increased for comprehensive 3000-5000 word responses
        }),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Research timeout')), 120000) // Increased to 120 seconds (2 minutes) for 3000-5000 words
        )
      ]);
      
      const content = completion.choices[0]?.message?.content || '';
      
      if (content && content.trim() && content.length > 1000) {
        console.log(`✅ Research attempt ${attempt} successful - ${content.length} characters`);
        
        // Apply content formatting for clean output
        return ContentFormatter.formatContentAggressively(content);
      } else {
        throw new Error(`Insufficient content generated: ${content.length} characters`);
      }
      
    } catch (error) {
      console.error(`❌ Research attempt ${attempt} failed:`, error.message);
      
      if (attempt === maxRetries) {
        console.error('❌ All research attempts failed - this should not happen with proper model fallback');
        throw new Error('Research failed after multiple attempts');
      }
      
      // Try next model in priority list
      const nextModel = researchModels[researchModels.indexOf(model) + 1];
      if (nextModel) {
        console.log(`🔄 Trying next model: ${nextModel}`);
        model = nextModel;
      }
      
      // Wait before retrying
      console.log(`⏳ Waiting ${retryDelay}ms before retry...`);
      await new Promise(resolve => setTimeout(resolve, retryDelay));
    }
  }
  
  throw new Error('Research generation failed after all attempts');
}

// Create enhanced research prompt for real-time data generation
function createEnhancedResearchPrompt(query: string, config: any): string {
  return `You are an expert research analyst providing comprehensive, accurate, and in-depth analysis. Generate a detailed research report on:

TOPIC: ${query}

REQUIREMENTS:
1. Generate 3000-5000 words of comprehensive, well-researched content
2. Include CURRENT, UP-TO-DATE facts, statistics, and information (2023-2024 data)
3. Provide real-time data and current developments
4. Include specific dates, names, places, and events with current relevance
5. Use clean formatting with proper structure and spacing
6. Include specific examples and detailed analysis
7. Ensure complete coverage with no generic content
8. Provide actionable insights and expert analysis
9. Cover sub-topics and related areas in detail
10. Include the latest trends and future projections

CRITICAL: This must be REAL-TIME research with CURRENT information. Do not use outdated data.

STRUCTURE:
Research Analysis: ${query}

INTRODUCTION (400-600 words)
- Clear definition and significance of the topic
- Key focus areas and importance
- Overview of what will be covered
- Research methodology and approach
- CURRENT state of the topic

CURRENT STATUS AND DEVELOPMENTS (800-1000 words)
- Latest developments and current situation
- Recent news and updates
- Current market trends and statistics
- Recent breakthroughs or innovations
- Current challenges and opportunities

DETAILED ANALYSIS AND SUB-TOPICS (1000-1500 words)
- In-depth examination of core aspects
- Sub-topic analysis with supporting evidence
- Comparative analysis with related topics
- Data-driven insights and CURRENT statistics
- Expert opinions and latest research findings

RECENT ACHIEVEMENTS AND IMPACT (500-700 words)
- Recent accomplishments and breakthroughs
- Current real-world impact and applications
- Recent case studies or examples
- Current recognition and importance in the field

CURRENT CHALLENGES AND LIMITATIONS (400-600 words)
- Current challenges and limitations
- Analysis of recent constraints and barriers
- Critical evaluation of recent shortcomings
- Risk assessment and current mitigation strategies

FUTURE OUTLOOK AND TRENDS (500-700 words)
- Latest trends and potential developments
- Current opportunities and growth areas
- Expert predictions based on current data
- Long-term implications and projections
- Emerging technologies or approaches

CONCLUSION AND RECOMMENDATIONS (400-600 words)
- Summary of key findings
- Overall significance and current implications
- Final insights and recommendations
- Actionable suggestions for stakeholders
- Future research directions

Provide thorough, expert-level analysis with CURRENT, REAL-TIME information. Avoid outdated data and provide concrete, verifiable details. Ensure the content is comprehensive, well-structured, and meets the 3000-5000 word requirement with up-to-date information.`;
}

// Create enhanced India research prompt for real-time data
function createEnhancedIndiaResearchPrompt(query: string, config: any): string {
  return `You are an expert India research analyst specializing in South Asian studies with access to CURRENT, REAL-TIME data. Generate a comprehensive, factual research report on:

TOPIC: ${query}

REQUIREMENTS:
1. Generate 3000-5000 words of comprehensive, well-researched content
2. Include CURRENT, UP-TO-DATE facts, statistics, and information about India (2023-2024 data)
3. Provide real-time data and current developments in India
4. Include specific dates, names, places, and events with current relevance
5. Use clean formatting with proper structure and spacing
6. Include specific examples and detailed analysis
7. Ensure complete coverage with no generic content
8. Provide actionable insights and expert analysis
9. Cover sub-topics and related areas in detail
10. Include the latest trends and future projections for India

CRITICAL: This must be REAL-TIME research with CURRENT information about India. Do not use outdated data.

STRUCTURE:
Research Analysis: ${query}

INTRODUCTION (400-600 words)
- Clear definition and significance of the topic in Indian context
- Key focus areas and importance
- Overview of what will be covered
- Research methodology and approach
- CURRENT state of the topic in India

CURRENT STATUS AND DEVELOPMENTS (800-1000 words)
- Latest developments and current situation in India
- Recent news and updates from India
- Current market trends and statistics in India
- Recent breakthroughs or innovations in India
- Current challenges and opportunities in India

DETAILED ANALYSIS AND SUB-TOPICS (1000-1500 words)
- In-depth examination of core aspects in Indian context
- Sub-topic analysis with supporting evidence from India
- Comparative analysis with related topics in India
- Data-driven insights and CURRENT statistics about India
- Expert opinions and latest research findings about India

RECENT ACHIEVEMENTS AND IMPACT (500-700 words)
- Recent accomplishments and breakthroughs in India
- Current real-world impact and applications in India
- Recent case studies or examples from India
- Current recognition and importance in India
- Measurable outcomes and results in India

CURRENT CHALLENGES AND LIMITATIONS (400-600 words)
- Current challenges and limitations in India
- Analysis of recent constraints and barriers in India
- Critical evaluation of recent shortcomings in India
- Risk assessment and current mitigation strategies in India

FUTURE OUTLOOK AND TRENDS (500-700 words)
- Latest trends and potential developments in India
- Current opportunities and growth areas in India
- Expert predictions based on current data about India
- Long-term implications and projections for India
- Emerging technologies or approaches in India

CONCLUSION AND RECOMMENDATIONS (400-600 words)
- Summary of key findings about India
- Overall significance and current implications for India
- Final insights and recommendations for India
- Actionable suggestions for stakeholders in India
- Future research directions for India

Provide thorough, expert-level analysis with CURRENT, REAL-TIME information about India. Avoid outdated data and provide concrete, verifiable details. Ensure the content is comprehensive, well-structured, and meets the 3000-5000 word requirement with up-to-date information about India.`;
}

// Create optimized research prompt to avoid content filters
function createOptimizedResearchPrompt(query: string, config: any): string {
  const cleanQuery = query.trim().toLowerCase();
  
  // Special handling for India research to avoid content filters
  if (cleanQuery.includes('india') || cleanQuery.includes('bharat')) {
    return createIndiaSpecificResearchPrompt(query, config);
  }
  
  // General research prompt with content filter optimization
  return `You are an expert research analyst providing comprehensive, accurate, and in-depth analysis. Generate a detailed research report on:

TOPIC: ${query}

REQUIREMENTS:
1. Generate 3000-5000 words of comprehensive, well-researched content
2. Include specific facts, dates, statistics, names, places, and events
3. Provide historical context and background information
4. Present multiple perspectives with verifiable information
5. Use clean formatting with proper structure and spacing
6. Include specific examples and detailed analysis
7. Ensure complete coverage with no generic content
8. Provide actionable insights and expert analysis
9. Cover sub-topics and related areas in detail
10. Include current developments and future trends

STRUCTURE:
Research Analysis: ${query}

INTRODUCTION (400-600 words)
- Clear definition and significance of the topic
- Key focus areas and importance
- Overview of what will be covered
- Research methodology and approach

HISTORICAL BACKGROUND AND DEVELOPMENT (600-800 words)
- Origins and historical context
- Key historical milestones and events
- Evolution and major developments over time
- Important historical figures and contributions
- Timeline of key developments

CURRENT STATUS AND STRUCTURE (600-800 words)
- Current state and key characteristics
- Major components, organizations, or systems
- Recent developments and important trends
- Key stakeholders and their roles
- Market analysis or current landscape

DETAILED ANALYSIS AND SUB-TOPICS (800-1000 words)
- In-depth examination of core aspects
- Sub-topic analysis with supporting evidence
- Comparative analysis with related topics
- Data-driven insights and statistics
- Expert opinions and research findings

MAJOR ACHIEVEMENTS AND IMPACT (500-700 words)
- Significant accomplishments and breakthroughs
- Real-world impact and applications
- Notable case studies or examples
- Recognition and importance in the field
- Measurable outcomes and results

CHALLENGES AND LIMITATIONS (400-600 words)
- Current challenges and limitations
- Analysis of constraints and barriers
- Critical evaluation of shortcomings
- Risk assessment and mitigation strategies

FUTURE OUTLOOK AND TRENDS (500-700 words)
- Future trends and potential developments
- Opportunities and growth areas
- Expert predictions and analysis
- Long-term implications and projections
- Emerging technologies or approaches

CONCLUSION AND RECOMMENDATIONS (400-600 words)
- Summary of key findings
- Overall significance and implications
- Final insights and recommendations
- Actionable suggestions for stakeholders
- Future research directions

Provide thorough, expert-level analysis with specific, verifiable information. Avoid generic statements and provide concrete details. Ensure the content is comprehensive, well-structured, and meets the 3000-5000 word requirement.`;
}

// Create India-specific research prompt to avoid content filters
function createIndiaSpecificResearchPrompt(query: string, config: any): string {
  return `You are an expert research analyst specializing in South Asian studies, with particular focus on India. Generate a comprehensive, factual research report on:

TOPIC: ${query}

REQUIREMENTS:
1. Generate 3000-5000 words of comprehensive, well-researched content
2. Include specific facts, dates, statistics, names, places, and events related to India
3. Provide historical context and background information about India
4. Present multiple perspectives with verifiable information
5. Use clean formatting with proper structure and spacing
6. Include specific examples and detailed analysis
7. Ensure complete coverage with no generic content
8. Provide actionable insights and expert analysis
9. Cover sub-topics and related areas in detail
10. Include current developments and future trends

STRUCTURE:
Research Analysis: ${query}

INTRODUCTION (400-600 words)
- Clear definition and significance of the topic in Indian context
- Key focus areas and importance
- Overview of what will be covered
- Research methodology and approach

HISTORICAL BACKGROUND AND DEVELOPMENT (600-800 words)
- Origins and historical context in Indian context
- Key historical milestones and events in India
- Evolution and major developments over time
- Important historical figures and contributions
- Timeline of key developments

CURRENT STATUS AND STRUCTURE (600-800 words)
- Current state and key characteristics in India
- Major components, organizations, or systems in India
- Recent developments and important trends in India
- Key stakeholders and their roles in India
- Market analysis or current landscape in India

DETAILED ANALYSIS AND SUB-TOPICS (800-1000 words)
- In-depth examination of core aspects in Indian context
- Sub-topic analysis with supporting evidence
- Comparative analysis with related topics
- Data-driven insights and statistics about India
- Expert opinions and research findings

MAJOR ACHIEVEMENTS AND IMPACT (500-700 words)
- Significant accomplishments and breakthroughs in India
- Real-world impact and applications in India
- Notable case studies or examples from India
- Recognition and importance in the field
- Measurable outcomes and results

CHALLENGES AND LIMITATIONS (400-600 words)
- Current challenges and limitations in India
- Analysis of constraints and barriers in India
- Critical evaluation of shortcomings
- Risk assessment and mitigation strategies

FUTURE OUTLOOK AND TRENDS (500-700 words)
- Future trends and potential developments in India
- Opportunities and growth areas in India
- Expert predictions and analysis
- Long-term implications and projections
- Emerging technologies or approaches in India

CONCLUSION AND RECOMMENDATIONS (400-600 words)
- Summary of key findings
- Overall significance and implications
- Final insights and recommendations
- Actionable suggestions for stakeholders
- Future research directions

Provide thorough, expert-level analysis with specific, verifiable information about India. Avoid generic statements and provide concrete details. Ensure the content is comprehensive, well-structured, and meets the 3000-5000 word requirement.`;
}