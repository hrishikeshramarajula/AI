// ====== 7. MAIN INTELLIGENT CHATBOT CLASS ======
import { Preprocessor, Token } from './preprocessor';
import { ContextManager, ConversationExchange, ContextSummary } from './contextManager';
import { IntentRecognizer, IntentResult } from './intentRecognizer';
import { KnowledgeRetriever, SearchResult, KnowledgeItem } from './knowledgeRetriever';
import { ResponseGenerator, GeneratedResponse } from './responseGenerator';
import { PostProcessor, ProcessingOptions, ProcessedResponse } from './postProcessor';
import { safeZAIChatCompletion } from '../zaiHelper';

export interface ChatBotConfig {
  maxHistory?: number;
  maxContextTokens?: number;
  enableSafetyChecks?: boolean;
  enableDisclaimers?: boolean;
  responseStyle?: 'formal' | 'casual' | 'technical' | 'friendly';
  enableEmojis?: boolean;
  maxLength?: number;
  enableCaching?: boolean;
}

export interface ChatBotResponse {
  response: string;
  confidence: number;
  intent: string;
  processingTime: number;
  metadata: {
    preprocessing: {
      tokens: Token[];
      entities: Array<{ text: string; type: string; confidence: number }>;
      cleanedText: string;
    };
    context: {
      summary: ContextSummary;
      isFollowUp: boolean;
      relevantContext: string;
    };
    intent: IntentResult;
    knowledge: SearchResult;
    generation: GeneratedResponse;
    postProcessing: ProcessedResponse;
  };
  suggestions: string[];
  followUpQuestions: string[];
}

export class IntelligentChatBot {
  private preprocessor = Preprocessor;
  private contextManager: ContextManager;
  private intentRecognizer = IntentRecognizer;
  private knowledgeRetriever = KnowledgeRetriever;
  private responseGenerator = ResponseGenerator;
  private postProcessor = PostProcessor;

  private config: Required<ChatBotConfig>;
  private processingStats = {
    totalMessages: 0,
    averageProcessingTime: 0,
    cacheHits: 0,
    cacheMisses: 0
  };

  constructor(config: ChatBotConfig = {}) {
    this.config = {
      maxHistory: config.maxHistory || 10,
      maxContextTokens: config.maxContextTokens || 4000,
      enableSafetyChecks: config.enableSafetyChecks !== false,
      enableDisclaimers: config.enableDisclaimers !== false,
      responseStyle: config.responseStyle || 'friendly',
      enableEmojis: config.enableEmojis !== false,
      maxLength: config.maxLength || 5000,
      enableCaching: config.enableCaching !== false
    };

    this.contextManager = new ContextManager(
      this.config.maxHistory,
      this.config.maxContextTokens
    );
  }

  /**
   * Main processing pipeline - orchestrates all components
   */
  async processMessage(userInput: string): Promise<ChatBotResponse> {
    const startTime = Date.now();
    this.processingStats.totalMessages++;

    console.log('🤖 Processing message with Intelligent ChatBot:', userInput);

    try {
      // ====== STEP 1: PREPROCESSING ======
      const preprocessingResult = this.preprocessor.process(userInput);
      console.log('📝 Preprocessing completed:', {
        tokens: preprocessingResult.tokens.length,
        entities: preprocessingResult.entities.length,
        cleanedText: preprocessingResult.cleanedText
      });

      // ====== STEP 2: CONTEXT ANALYSIS ======
      const isFollowUp = this.contextManager.isFollowUpQuestion(userInput);
      const relevantContext = this.contextManager.getRelevantContext(userInput);
      const contextSummary = this.contextManager.getContextSummary();
      
      console.log('📚 Context analysis:', {
        isFollowUp,
        contextLength: relevantContext.length,
        recentTopics: contextSummary.recentTopics,
        conversationFlow: contextSummary.conversationFlow
      });

      // ====== STEP 3: INTENT RECOGNITION ======
      const intentResult = this.intentRecognizer.classify(
        preprocessingResult.cleanedText,
        preprocessingResult.tokens,
        preprocessingResult.entities
      );
      
      console.log('🎯 Intent recognized:', {
        intent: intentResult.intent,
        confidence: intentResult.confidence,
        action: intentResult.action,
        parameters: intentResult.parameters
      });

      // ====== STEP 4: REAL AI RESPONSE GENERATION ======
      let generatedResponse: GeneratedResponse;
      let knowledgeResult: SearchResult;
      
      try {
        console.log('🤖 Calling real AI for response generation...');
        
        // Prepare conversation context for AI
        const conversationHistory = this.contextManager.getRecentExchanges(10);
        const messages = [
          {
            role: 'system' as const,
            content: `You are an intelligent AI assistant with expertise in technology, science, and various academic fields. 
            Provide comprehensive, well-structured, and accurate responses to user queries.
            
            CRITICAL REQUIREMENT - ALWAYS PROVIDE REAL-TIME, CURRENT INFORMATION:
            - Always provide CURRENT, UP-TO-DATE information (2023-2024 data)
            - Never provide generic or placeholder content
            - Include specific details, facts, and current insights
            - For products, companies, or topics, provide current status, specifications, and relevant details
            - Include pricing, features, or current developments where applicable
            - Use real information, not outdated or generic responses
            
            CRITICAL FORMATTING REQUIREMENTS - ABSOLUTELY NO SYMBOLS:
            1. NEVER use markdown symbols like #, ##, ###, **, *, __, _, ~, ==, or [text](url)
            2. NEVER use special characters like ►, ▼, ▶, ▷, ▸, ▹, ▻, ▽, ●, ○, ■, □, ▪, ▫, ★, ☆, ✦, ✧, ✩, ✪, ←, ↑, →, ↓, ↔, ↕, ♠, ♣, ♥, ♦, ©, ®, ™
            3. Use clean, professional formatting with proper spacing
            4. Structure content with clear headings using ONLY capitalization and line breaks (like: HEADING TITLE or Important Topic:)
            5. Use bullet points (•) for lists with proper spacing
            6. Add blank lines between paragraphs and sections for readability
            7. Use proper capitalization for emphasis instead of symbols
            8. Ensure proper spacing after punctuation marks
            9. Structure content with clear visual hierarchy and adequate white space
            10. Keep paragraphs concise and well-spaced
            11. NEVER use code blocks with backticks (\`\`)
            12. NEVER use inline code with single backticks (\`)
            13. NEVER use horizontal rules (--- or ***)
            
            CONTENT STRUCTURE GUIDELINES:
            - Always provide factual, up-to-date information and cite sources when relevant
            - For technical topics, provide both conceptual understanding and practical applications
            - Use clear, readable formatting with adequate spacing between sections
            - Write in English only with proper grammar and spelling
            - Make responses visually appealing and easy to read without special symbols
            - Include relevant examples and practical applications
            - Use proper sentence structure and paragraph breaks
            - Structure longer responses with clear sections separated by blank lines
            - Use appropriate spacing around bullet points and numbered lists
            - End points properly with periods and ensure complete sentences
            - Emphasize current data and real-time information over historical content
            - Provide recent developments, current status, and up-to-date facts
            
            EXAMPLE OF PROPER FORMATTING:
            
            MAIN TOPIC
            
            This is the introduction paragraph with proper spacing and no symbols. It provides context and overview.
            
            Key Subtopic:
            Here we discuss the important aspects in detail. Each paragraph should be well-structured and concise.
            
            Important Points:
            • First point with proper bullet formatting
            • Second point with consistent spacing
            • Third point to complete the list
            
            Another Section:
            Continue with well-formatted content that flows naturally and is easy to read.`
          }
        ];
        
        // Add conversation history for context
        conversationHistory.forEach(exchange => {
          messages.push({
            role: 'user' as const,
            content: exchange.user
          });
          messages.push({
            role: 'assistant' as const,
            content: exchange.bot
          });
        });
        
        // Add current user message
        messages.push({
          role: 'user' as const,
          content: userInput
        });
        
        // Call real AI
        const aiResponse = await safeZAIChatCompletion(messages, {
          model: 'gpt-4o',
          temperature: 0.7,
          max_tokens: 2000
        });
        
        const aiContent = aiResponse.choices[0]?.message?.content || '';
        
        console.log('✅ Real AI response generated successfully');
        console.log('📝 AI response length:', aiContent.length, 'characters');
        
        // Create a mock knowledge result for compatibility
        knowledgeResult = {
          items: [{
            id: 'ai-generated',
            title: `AI Response: ${intentResult.intent}`,
            content: aiContent,
            category: 'ai-generated',
            tags: [intentResult.intent],
            relevance: 0.95,
            source: 'ai' as const,
            timestamp: new Date(),
            confidence: 0.95
          }],
          query: preprocessingResult.cleanedText,
          totalFound: 1,
          searchTime: Date.now() - startTime,
          sources: ['AI-generated response']
        };
        
        // Create generated response
        generatedResponse = {
          content: aiContent,
          confidence: 0.95,
          intent: intentResult.intent,
          sources: ['AI-generated'],
          suggestions: this.generateSuggestions(intentResult),
          followUpQuestions: this.generateFollowUpQuestions(intentResult)
        };
        
      } catch (error) {
        console.error('❌ Real AI generation failed, falling back to knowledge base:', error);
        
        // Fallback to knowledge base if AI fails
        knowledgeResult = await this.knowledgeRetriever.retrieve(
          preprocessingResult.cleanedText,
          relevantContext
        );
        
        generatedResponse = this.responseGenerator.generate(
          intentResult,
          relevantContext,
          knowledgeResult,
          contextSummary.userPreferences
        );
      }
      
      console.log('💬 Response generated:', {
        contentLength: generatedResponse.content.length,
        confidence: generatedResponse.confidence,
        intent: generatedResponse.intent,
        sources: generatedResponse.sources,
        usingRealAI: generatedResponse.sources.includes('AI-generated')
      });

      // ====== STEP 6: POST-PROCESSING ======
      const processingOptions: ProcessingOptions = {
        addFormatting: true,
        addSafetyChecks: this.config.enableSafetyChecks,
        addDisclaimers: this.config.enableDisclaimers,
        maxLength: this.config.maxLength,
        style: this.config.responseStyle,
        includeSources: true,
        addEmojis: this.config.enableEmojis,
        structureResponse: true
      };

      const processedResponse = this.postProcessor.formatResponse(
        generatedResponse.content,
        processingOptions
      );
      
      console.log('✨ Post-processing completed:', {
        finalLength: processedResponse.content.length,
        formattingApplied: processedResponse.formattingApplied,
        safetyChecks: processedResponse.safetyChecks,
        disclaimers: processedResponse.disclaimers
      });

      // ====== STEP 7: FINAL CLEANUP ======
      const finalResponse = this.postProcessor.cleanFinalResponse(processedResponse);

      // ====== STEP 8: UPDATE CONTEXT ======
      this.contextManager.addExchange(
        userInput,
        finalResponse,
        preprocessingResult.tokens,
        preprocessingResult.entities,
        intentResult.intent
      );

      const processingTime = Date.now() - startTime;
      this.updateProcessingStats(processingTime);

      // ====== STEP 9: COMPOSE FINAL RESPONSE ======
      const chatBotResponse: ChatBotResponse = {
        response: finalResponse,
        confidence: generatedResponse.confidence,
        intent: intentResult.intent,
        processingTime,
        metadata: {
          preprocessing: preprocessingResult,
          context: {
            summary: contextSummary,
            isFollowUp,
            relevantContext
          },
          intent: intentResult,
          knowledge: knowledgeResult,
          generation: generatedResponse,
          postProcessing: processedResponse
        },
        suggestions: generatedResponse.suggestions || [],
        followUpQuestions: generatedResponse.followUpQuestions || []
      };

      console.log('✅ Intelligent ChatBot processing completed:', {
        processingTime,
        confidence: chatBotResponse.confidence,
        intent: chatBotResponse.intent
      });

      return chatBotResponse;

    } catch (error) {
      console.error('❌ Error in Intelligent ChatBot processing:', error);
      
      // Try to provide a helpful response even if there's an error
      const errorResponse: ChatBotResponse = {
        response: this.generateHelpfulErrorResponse(userInput, error),
        confidence: 0.7,
        intent: 'helpful_response',
        processingTime: Date.now() - startTime,
        metadata: {
          preprocessing: {
            tokens: [],
            entities: [],
            cleanedText: userInput
          },
          context: {
            summary: this.contextManager.getContextSummary(),
            isFollowUp: false,
            relevantContext: ''
          },
          intent: {
            intent: 'helpful_response',
            confidence: 0.7,
            entities: [],
            action: 'provide_helpful_info'
          },
          knowledge: {
            items: [],
            query: userInput,
            totalFound: 0,
            searchTime: 0,
            sources: []
          },
          generation: {
            content: '',
            confidence: 0.7,
            intent: 'helpful_response',
            sources: []
          },
          postProcessing: {
            content: '',
            warnings: ['processing_error'],
            formattingApplied: [],
            safetyChecks: [],
            disclaimers: [],
            sources: [],
            metadata: {
              wordCount: 0,
              readingTime: 0,
              complexityScore: 0,
              sentimentScore: 0
            }
          }
        },
        suggestions: ['Try asking about related topics', 'Check if the question is clear'],
        followUpQuestions: ['Can I help you with something else?']
      };

      return errorResponse;
    }
  }

  /**
   * Generate a helpful error response based on the user's input
   */
  private generateHelpfulErrorResponse(userInput: string, error: any): string {
    const lowerInput = userInput.toLowerCase();
    
    // Try to provide relevant information based on the input
    if (lowerInput.includes('ibm') && lowerInput.includes('qiskit')) {
      return `# **IBM Qiskit: Quantum Computing Framework**

## **What is IBM Qiskit?**

IBM Qiskit is an open-source quantum computing software development framework developed by IBM. It provides comprehensive tools for creating, simulating, and running quantum circuits on both real quantum computers and simulators.

## **Key Features:**

**🔧 Core Components**
- **Qiskit Terra**: For composing quantum programs and circuits
- **Qiskit Aer**: High-performance quantum simulators
- **Qiskit Ignis**: Quantum error correction and noise modeling
- **Qiskit Aqua**: Building quantum algorithms and applications

**🎯 Key Capabilities**
- Create and manipulate quantum circuits
- Run programs on IBM Quantum real processors
- Access cloud-based quantum computing services
- Comprehensive documentation and learning resources
- Active community support

## **Who Uses Qiskit?**

- **Researchers**: Exploring quantum algorithms and applications
- **Developers**: Building quantum software solutions
- **Students**: Learning quantum computing concepts
- **Organizations**: Experimenting with quantum technology

## **Getting Started**

Qiskit is designed to be accessible and provides extensive tutorials, documentation, and examples to help users get started with quantum computing development.

---

Would you like me to elaborate on any specific aspect of IBM Qiskit, such as how to get started or specific use cases?`;
    }
    
    if (lowerInput.includes('quantum') || lowerInput.includes('qubit')) {
      return `# **Quantum Computing: A Revolutionary Approach**

## **What is Quantum Computing?**

Quantum computing represents a fundamental paradigm shift in computational technology. Unlike traditional computers that use classical bits (which can only be either 0 or 1), quantum computers leverage the principles of quantum mechanics to process information in entirely new ways.

## **Core Concepts**

At the heart of quantum computing lie several fundamental principles:

### **Key Properties:**

**🔄 Superposition**
- Qubits can exist in multiple states simultaneously
- Enables parallel processing of vast amounts of information
- Fundamental to quantum computing power

**🔗 Entanglement**
- Creates powerful correlations between quantum bits
- Changes to one qubit instantly affect its entangled partners
- Enables complex computational relationships

## **Practical Applications**

Quantum computing promises to transform numerous fields:

**🔐 Cryptography & Security**
- Breaking current encryption methods
- Creating quantum-resistant cryptographic systems
- Enhancing secure communication protocols

**💊 Drug Discovery & Medicine**
- Simulating molecular interactions at quantum level
- Accelerating pharmaceutical development
- Personalized medicine through complex modeling

---

Would you like me to dive deeper into any specific aspect of quantum computing?`;
    }
    
    if (lowerInput.includes('ai') || lowerInput.includes('artificial intelligence')) {
      return `# **Artificial Intelligence: Transforming Technology**

## **What is Artificial Intelligence?**

Artificial Intelligence (AI) refers to the simulation of human intelligence in machines that are programmed to think like humans and mimic their actions. AI systems can exhibit traits associated with human minds such as learning, problem-solving, and decision-making.

## **Key Areas of AI**

**🧠 Machine Learning**
- Systems that learn from data without explicit programming
- Includes supervised, unsupervised, and reinforcement learning
- Powers recommendation systems, fraud detection, and more

**🗣️ Natural Language Processing**
- Enables computers to understand human language
- Powers chatbots, translation services, and text analysis
- Includes sentiment analysis and language generation

**👁️ Computer Vision**
- Allows machines to interpret and understand visual information
- Powers facial recognition, object detection, and medical imaging
- Used in autonomous vehicles and quality control systems

## **Applications Across Industries**

**🏥 Healthcare**: Disease diagnosis, drug discovery, personalized treatment
**💰 Finance**: Fraud detection, algorithmic trading, risk assessment
**🏭 Manufacturing**: Predictive maintenance, quality control, automation
**🚗 Transportation**: Autonomous vehicles, traffic optimization, route planning

---

Would you like me to explore any specific area of artificial intelligence in more detail?`;
    }
    
    // Generic helpful response for other topics
    return `# **Information About Your Query**

I'd be happy to help you with information about "${userInput}". While I encountered a technical issue in my processing, I can still provide you with some useful insights.

## **What I Can Help You With**

**🔍 Research & Information**
- Explanations of complex topics
- Step-by-step guides and tutorials
- Comparisons and analysis
- Best practices and recommendations

**💡 Problem Solving**
- Troubleshooting common issues
- Suggesting approaches to challenges
- Providing alternative solutions
- Offering practical advice

## **Getting the Most Accurate Information**

For the most current and detailed information about your specific topic, I recommend:

1. **Being specific** about what aspect you'd like to explore
2. **Asking follow-up questions** to dive deeper into areas of interest
3. **Providing context** about your specific needs or use case

## **Next Steps**

Could you please clarify what specific aspect of "${userInput}" you're most interested in learning about? This will help me provide you with the most relevant and helpful information.

---

I'm here to help and want to ensure you get the information you need. What would you like to focus on?`;
  }

  /**
   * Handle ambiguous intents by asking for clarification
   */
  async handleAmbiguousIntent(userInput: string, ambiguousIntents: Array<{ intent: string; confidence: number }>): Promise<ChatBotResponse> {
    const clarificationQuestions = this.intentRecognizer.suggestClarification(ambiguousIntents);
    
    const clarificationResponse = `I notice your request could be interpreted in multiple ways. To help me better assist you, could you clarify what you're looking for?

${clarificationQuestions.map((q, i) => `${i + 1}. ${q}`).join('\n')}

Alternatively, you can rephrase your question to be more specific.`;

    return {
      response: clarificationResponse,
      confidence: 0.6,
      intent: 'clarification',
      processingTime: 0,
      metadata: {
        preprocessing: {
          tokens: [],
          entities: [],
          cleanedText: userInput
        },
        context: {
          summary: this.contextManager.getContextSummary(),
          isFollowUp: false,
          relevantContext: ''
        },
        intent: {
          intent: 'clarification',
          confidence: 0.6,
          entities: [],
          action: 'request_clarification'
        },
        knowledge: {
          items: [],
          query: userInput,
          totalFound: 0,
          searchTime: 0,
          sources: []
        },
        generation: {
          content: clarificationResponse,
          confidence: 0.6,
          intent: 'clarification',
          sources: []
        },
        postProcessing: {
          content: clarificationResponse,
          warnings: ['ambiguous_intent'],
          formattingApplied: [],
          safetyChecks: [],
          disclaimers: [],
          sources: [],
          metadata: {
            wordCount: clarificationResponse.split(' ').length,
            readingTime: Math.ceil(clarificationResponse.split(' ').length / 200),
            complexityScore: 0.5,
            sentimentScore: 0
          }
        }
      },
      suggestions: clarificationQuestions,
      followUpQuestions: ['Which option best describes what you need?']
    };
  }

  /**
   * Get conversation history
   */
  getConversationHistory(): ConversationExchange[] {
    return this.contextManager.getRecentExchanges(10);
  }

  /**
   * Get context summary
   */
  getContextSummary(): ContextSummary {
    return this.contextManager.getContextSummary();
  }

  /**
   * Clear conversation history
   */
  clearConversation(): void {
    this.contextManager.clearHistory();
    console.log('🗑️ Conversation history cleared');
  }

  /**
   * Add custom knowledge to the knowledge base
   */
  addCustomKnowledge(title: string, content: string, category: string, tags: string[]): string {
    return this.knowledgeRetriever.addKnowledgeItem({
      title,
      content,
      category,
      tags,
      relevance: 0.8,
      source: 'user',
      confidence: 0.9
    });
  }

  /**
   * Get processing statistics
   */
  getProcessingStats() {
    return {
      ...this.processingStats,
      cacheHitRate: this.processingStats.cacheHits / Math.max(this.processingStats.cacheHits + this.processingStats.cacheMisses, 1),
      contextStats: {
        historySize: this.contextManager.getRecentExchanges().length,
        topics: Array.from(this.getContextSummary().recentTopics),
        conversationFlow: this.getContextSummary().conversationFlow
      }
    };
  }

  /**
   * Update processing statistics
   */
  private updateProcessingStats(processingTime: number): void {
    const totalMessages = this.processingStats.totalMessages;
    this.processingStats.averageProcessingTime = 
      (this.processingStats.averageProcessingTime * (totalMessages - 1) + processingTime) / totalMessages;
  }

  /**
   * Get available intents
   */
  getAvailableIntents(): string[] {
    return this.intentRecognizer.getAvailableIntents();
  }

  /**
   * Get knowledge categories
   */
  getKnowledgeCategories(): string[] {
    return this.knowledgeRetriever.getCategories();
  }

  /**
   * Check if bot can handle specific intent
   */
  canHandleIntent(intent: string): boolean {
    return this.getAvailableIntents().includes(intent);
  }

  /**
   * Get bot capabilities
   */
  getCapabilities(): {
    intents: string[];
    knowledgeCategories: string[];
    features: string[];
    config: Required<ChatBotConfig>;
  } {
    return {
      intents: this.getAvailableIntents(),
      knowledgeCategories: this.getKnowledgeCategories(),
      features: [
        'intelligent_preprocessing',
        'context_awareness',
        'intent_recognition',
        'knowledge_retrieval',
        'response_generation',
        'safety_checks',
        'formatting',
        'conversation_history'
      ],
      config: this.config
    };
  }

  /**
   * Health check
   */
  healthCheck(): {
    status: 'healthy' | 'degraded' | 'unhealthy';
    components: {
      preprocessing: 'ok' | 'error';
      context: 'ok' | 'error';
      intent: 'ok' | 'error';
      knowledge: 'ok' | 'error';
      generation: 'ok' | 'error';
      postProcessing: 'ok' | 'error';
    };
    stats: typeof this.processingStats;
  } {
    const components = {
      preprocessing: 'ok' as const,
      context: 'ok' as const,
      intent: 'ok' as const,
      knowledge: 'ok' as const,
      generation: 'ok' as const,
      postProcessing: 'ok' as const
    };

    // Basic health checks
    try {
      this.preprocessor.process('test');
    } catch {
      components.preprocessing = 'error';
    }

    try {
      this.contextManager.getContextSummary();
    } catch {
      components.context = 'error';
    }

    try {
      this.intentRecognizer.classify('test');
    } catch {
      components.intent = 'error';
    }

    try {
      this.knowledgeRetriever.getCategories();
    } catch {
      components.knowledge = 'error';
    }

    const errorCount = Object.values(components).filter(status => status === 'error').length;
    let status: 'healthy' | 'degraded' | 'unhealthy' = 'healthy';
    
    if (errorCount >= 3) status = 'unhealthy';
    else if (errorCount > 0) status = 'degraded';

    return {
      status,
      components,
      stats: this.processingStats
    };
  }

  /**
   * Generate suggestions based on intent
   */
  private generateSuggestions(intentResult: IntentResult): string[] {
    const suggestions: string[] = [];
    
    switch (intentResult.intent) {
      case 'explanation':
        suggestions.push('Ask for more details about specific aspects');
        suggestions.push('Request examples or practical applications');
        break;
      case 'comparison':
        suggestions.push('Ask about specific differences');
        suggestions.push('Get recommendations for your use case');
        break;
      case 'instruction':
        suggestions.push('Ask for clarification on specific steps');
        suggestions.push('Request troubleshooting tips');
        break;
      case 'analysis':
        suggestions.push('Ask about specific aspects of the analysis');
        suggestions.push('Request recommendations based on findings');
        break;
      default:
        suggestions.push('Explore related topics');
        suggestions.push('Ask for practical examples');
    }
    
    return suggestions.slice(0, 2);
  }

  /**
   * Generate follow-up questions based on intent
   */
  private generateFollowUpQuestions(intentResult: IntentResult): string[] {
    const questions: string[] = [];
    
    switch (intentResult.intent) {
      case 'explanation':
        questions.push('Would you like me to explain any part in more detail?');
        questions.push('Do you have any specific questions about this topic?');
        break;
      case 'comparison':
        questions.push('Which aspect would you like me to focus on?');
        questions.push('Do you have a specific use case in mind?');
        break;
      case 'instruction':
        questions.push('Which step would you like me to clarify?');
        questions.push('Do you need help with any specific part?');
        break;
      default:
        questions.push('Is there anything else you\'d like to know?');
        questions.push('How else can I help you?');
    }
    
    return questions.slice(0, 2);
  }
}