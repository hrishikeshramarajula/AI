'use client';

import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
}

interface State {
  hasError: boolean;
  error?: Error;
  errorInfo?: ErrorInfo;
  errorId?: string;
}

export class ErrorBoundary extends Component<Props, State> {
  private errorCount = 0;
  private readonly maxErrors = 5;

  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    // Update state so the next render shows the fallback UI
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Log the error to an error tracking service
    console.error('ErrorBoundary caught an error:', error, errorInfo);
    
    // Increment error count
    this.errorCount++;
    
    // Generate unique error ID
    const errorId = `error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    // Update state with error info
    this.setState({ error, errorInfo, errorId });
    
    // Call custom error handler if provided
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    }
    
    // Log error with ID for debugging
    console.error(`[${errorId}] Error caught by boundary:`, {
      error: error.message,
      stack: error.stack,
      componentStack: errorInfo.componentStack,
      errorCount: this.errorCount
    });
    
    // If too many errors, show fatal error UI
    if (this.errorCount >= this.maxErrors) {
      console.error(`[${errorId}] Too many errors detected, showing fatal error UI`);
      this.setState({ 
        hasError: true, 
        error: new Error('Too many errors detected. The application may be experiencing issues.'),
        errorId 
      });
    }
  }

  handleRetry = () => {
    this.errorCount = 0;
    this.setState({ hasError: false, error: undefined, errorInfo: undefined, errorId: undefined });
  };

  handleGoHome = () => {
    // Reset error state and navigate to home
    this.errorCount = 0;
    this.setState({ hasError: false, error: undefined, errorInfo: undefined, errorId: undefined });
    window.location.href = '/';
  };

  render() {
    if (this.state.hasError) {
      // If custom fallback is provided, use it
      if (this.props.fallback) {
        return this.props.fallback;
      }

      // Default error UI
      return (
        <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-red-50 to-orange-50 dark:from-red-950/20 dark:to-orange-950/20">
          <Card className="w-full max-w-lg border-red-200 dark:border-red-800 shadow-lg">
            <CardHeader className="text-center">
              <div className="mx-auto w-12 h-12 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mb-4">
                <AlertTriangle className="w-6 h-6 text-red-600 dark:text-red-400" />
              </div>
              <CardTitle className="text-xl font-bold text-red-800 dark:text-red-200">
                Oops! Something went wrong
              </CardTitle>
              <CardDescription className="text-red-600 dark:text-red-300">
                We're sorry, but an unexpected error occurred while loading this component.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Error details for development */}
              {process.env.NODE_ENV === 'development' && this.state.error && (
                <div className="bg-red-50 dark:bg-red-900/20 p-3 rounded-lg text-xs font-mono text-red-700 dark:text-red-300 overflow-auto max-h-32">
                  <div className="font-bold mb-1">Error: {this.state.error.message}</div>
                  {this.state.error.stack && (
                    <div className="mt-1">
                      <div className="font-bold">Stack:</div>
                      <div className="whitespace-pre-wrap break-words">
                        {this.state.error.stack}
                      </div>
                    </div>
                  )}
                  {this.state.errorId && (
                    <div className="mt-1 text-xs">
                      <div className="font-bold">Error ID:</div>
                      <code className="bg-red-200 dark:bg-red-800 px-1 rounded">
                        {this.state.errorId}
                      </code>
                    </div>
                  )}
                </div>
              )}
              
              {/* User-friendly message */}
              <div className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                <p>
                  {this.state.error?.message?.includes('Too many errors') 
                    ? 'The application is experiencing multiple issues. Please try again later or refresh the page.'
                    : 'This might be a temporary issue. Please try the following:'
                  }
                </p>
                <ul className="list-disc list-inside space-y-1 text-xs">
                  <li>Refresh the page to try again</li>
                  <li>Clear your browser cache and cookies</li>
                  <li>Check your internet connection</li>
                  <li>Try using a different browser</li>
                </ul>
              </div>

              {/* Action buttons */}
              <div className="flex gap-2 pt-4">
                <Button 
                  onClick={this.handleRetry}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                  variant="default"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Try Again
                </Button>
                <Button 
                  onClick={this.handleGoHome}
                  variant="outline"
                  className="flex-1 border-gray-300 hover:bg-gray-50"
                >
                  <Home className="w-4 h-4 mr-2" />
                  Go Home
                </Button>
              </div>

              {/* Support message */}
              <div className="text-xs text-center text-gray-500 dark:text-gray-400 pt-4 border-t">
                <p>
                  If the problem persists, please contact support with the error ID: 
                  <span className="font-mono bg-gray-100 dark:bg-gray-800 px-1 rounded ml-1">
                    {this.state.errorId || 'unknown'}
                  </span>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}

// Hook for functional components to use error boundary
export function useErrorHandler() {
  return (error: Error, errorInfo: ErrorInfo) => {
    console.error('Error caught by useErrorHandler:', error, errorInfo);
    // You could integrate with error tracking services here
  };
}

// Higher-order component for class components
export function withErrorBoundary<P extends object>(
  Component: React.ComponentType<P>,
  errorFallback?: ReactNode
) {
  return function WrappedComponent(props: P) {
    return (
      <ErrorBoundary fallback={errorFallback}>
        <Component {...props} />
      </ErrorBoundary>
    );
  };
}