import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

interface SuggestionRequest {
  code: string
  context?: string
  language?: string
  cursorPosition?: {
    line: number
    column: number
  }
  type: 'autocomplete' | 'refactor' | 'debug' | 'optimize' | 'explain'
}

interface SuggestionResponse {
  success: boolean
  suggestions?: Array<{
    type: 'completion' | 'improvement' | 'fix' | 'explanation'
    text: string
    code?: string
    confidence: number
    position?: {
      start: { line: number; column: number }
      end: { line: number; column: number }
    }
    description: string
  }>
  explanation?: string
  error?: string
}

export async function POST(request: NextRequest) {
  try {
    const body: SuggestionRequest = await request.json()
    const { code, context = '', language = 'javascript', cursorPosition, type } = body

    if (!code || !type) {
      return NextResponse.json({
        success: false,
        error: 'Code and type are required'
      }, { status: 400 })
    }

    console.log(`💡 AI Suggestion Request: ${type} for ${language}`)

    let zai: ZAI | null = null

    try {
      zai = await ZAI.create()
    } catch (error) {
      console.error('❌ Failed to initialize ZAI:', error)
      return NextResponse.json({
        success: false,
        error: 'Failed to initialize AI service'
      }, { status: 500 })
    }

    try {
      let response: SuggestionResponse

      switch (type) {
        case 'autocomplete':
          response = await generateAutocomplete(zai, code, context, language, cursorPosition)
          break
        case 'refactor':
          response = await generateRefactorSuggestions(zai, code, context, language)
          break
        case 'debug':
          response = await generateDebugSuggestions(zai, code, context, language)
          break
        case 'optimize':
          response = await generateOptimizationSuggestions(zai, code, context, language)
          break
        case 'explain':
          response = await generateExplanation(zai, code, context, language)
          break
        default:
          return NextResponse.json({
            success: false,
            error: `Unsupported suggestion type: ${type}`
          }, { status: 400 })
      }

      return NextResponse.json(response)

    } catch (error) {
      console.error('❌ Suggestion Generation Error:', error)
      return NextResponse.json({
        success: false,
        error: 'Failed to generate suggestions'
      }, { status: 500 })
    }

  } catch (error) {
    console.error('❌ Request Processing Error:', error)
    return NextResponse.json({
      success: false,
      error: 'Internal server error'
    }, { status: 500 })
  }
}

async function generateAutocomplete(
  zai: ZAI, 
  code: string, 
  context: string, 
  language: string,
  cursorPosition?: { line: number; column: number }
): Promise<SuggestionResponse> {
  const systemPrompt = `You are an expert code completion assistant. Analyze the provided code and generate intelligent autocomplete suggestions.

Requirements:
1. Provide contextually relevant completions
2. Follow the language's best practices and syntax
3. Include function signatures, variable names, and common patterns
4. Consider the code structure and surrounding context
5. Provide multiple options with different approaches

Language: ${language}
Cursor Position: ${cursorPosition ? `Line ${cursorPosition.line}, Column ${cursorPosition.column}` : 'End of code'}

Respond with a JSON object containing:
{
  "suggestions": [
    {
      "type": "completion",
      "text": "suggested completion text",
      "code": "complete code snippet if applicable",
      "confidence": 0.9,
      "description": "Brief description of what this completion does"
    }
  ],
  "explanation": "Summary of completion suggestions"
}`

  try {
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Code:\n${code}\n\nContext:\n${context}` }
      ],
      temperature: 0.3,
      max_tokens: 1000,
      top_p: 0.8
    })

    const content = completion.choices[0]?.message?.content || ''
    
    try {
      const parsed = JSON.parse(content)
      return {
        success: true,
        suggestions: parsed.suggestions || [],
        explanation: parsed.explanation || 'Autocomplete suggestions generated'
      }
    } catch (parseError) {
      // Fallback suggestions
      return {
        success: true,
        suggestions: [
          {
            type: 'completion',
            text: '// Complete the code based on context',
            confidence: 0.7,
            description: 'Basic code completion'
          }
        ],
        explanation: 'Basic autocomplete provided'
      }
    }
  } catch (error) {
    return {
      success: false,
      error: 'Failed to generate autocomplete suggestions'
    }
  }
}

async function generateRefactorSuggestions(
  zai: ZAI, 
  code: string, 
  context: string, 
  language: string
): Promise<SuggestionResponse> {
  const systemPrompt = `You are an expert code refactoring assistant. Analyze the provided code and suggest improvements for better structure, readability, and maintainability.

Focus on:
1. Code organization and structure
2. Naming conventions and clarity
3. Function and variable organization
4. Design patterns implementation
5. Code duplication elimination
6. Best practices adherence

Language: ${language}

Respond with a JSON object containing:
{
  "suggestions": [
    {
      "type": "improvement",
      "text": "description of the refactoring suggestion",
      "code": "refactored code example",
      "confidence": 0.8,
      "description": "Detailed explanation of the improvement"
    }
  ],
  "explanation": "Summary of refactoring suggestions"
}`

  try {
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Code:\n${code}\n\nContext:\n${context}` }
      ],
      temperature: 0.4,
      max_tokens: 2000,
      top_p: 0.8
    })

    const content = completion.choices[0]?.message?.content || ''
    
    try {
      const parsed = JSON.parse(content)
      return {
        success: true,
        suggestions: parsed.suggestions || [],
        explanation: parsed.explanation || 'Refactoring suggestions generated'
      }
    } catch (parseError) {
      return {
        success: true,
        suggestions: [
          {
            type: 'improvement',
            text: 'Consider refactoring for better readability',
            confidence: 0.6,
            description: 'General refactoring suggestion'
          }
        ],
        explanation: 'Basic refactoring suggestions provided'
      }
    }
  } catch (error) {
    return {
      success: false,
      error: 'Failed to generate refactoring suggestions'
    }
  }
}

async function generateDebugSuggestions(
  zai: ZAI, 
  code: string, 
  context: string, 
  language: string
): Promise<SuggestionResponse> {
  const systemPrompt = `You are an expert debugging assistant. Analyze the provided code and identify potential bugs, errors, or issues.

Look for:
1. Syntax errors and typos
2. Logical errors and edge cases
3. Runtime errors and exceptions
4. Performance bottlenecks
5. Security vulnerabilities
6. Memory leaks and resource management issues

Language: ${language}

Respond with a JSON object containing:
{
  "suggestions": [
    {
      "type": "fix",
      "text": "description of the issue and fix",
      "code": "fixed code example",
      "confidence": 0.9,
      "position": {
        "start": { "line": 10, "column": 5 },
        "end": { "line": 10, "column": 15 }
      },
      "description": "Detailed explanation of the issue and solution"
    }
  ],
  "explanation": "Summary of debugging analysis"
}`

  try {
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Code:\n${code}\n\nContext:\n${context}` }
      ],
      temperature: 0.2,
      max_tokens: 2000,
      top_p: 0.7
    })

    const content = completion.choices[0]?.message?.content || ''
    
    try {
      const parsed = JSON.parse(content)
      return {
        success: true,
        suggestions: parsed.suggestions || [],
        explanation: parsed.explanation || 'Debugging analysis completed'
      }
    } catch (parseError) {
      return {
        success: true,
        suggestions: [
          {
            type: 'fix',
            text: 'Review code for potential issues',
            confidence: 0.5,
            description: 'General debugging suggestion'
          }
        ],
        explanation: 'Basic debugging analysis provided'
      }
    }
  } catch (error) {
    return {
      success: false,
      error: 'Failed to generate debugging suggestions'
    }
  }
}

async function generateOptimizationSuggestions(
  zai: ZAI, 
  code: string, 
  context: string, 
  language: string
): Promise<SuggestionResponse> {
  const systemPrompt = `You are an expert code optimization assistant. Analyze the provided code and suggest performance improvements.

Focus on:
1. Algorithm efficiency and complexity
2. Memory usage and garbage collection
3. CPU performance and bottlenecks
4. Network requests and data processing
5. Caching strategies
6. Concurrency and parallelization opportunities

Language: ${language}

Respond with a JSON object containing:
{
  "suggestions": [
    {
      "type": "improvement",
      "text": "description of the optimization",
      "code": "optimized code example",
      "confidence": 0.8,
      "description": "Explanation of performance benefits"
    }
  ],
  "explanation": "Summary of optimization suggestions"
}`

  try {
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Code:\n${code}\n\nContext:\n${context}` }
      ],
      temperature: 0.3,
      max_tokens: 2000,
      top_p: 0.8
    })

    const content = completion.choices[0]?.message?.content || ''
    
    try {
      const parsed = JSON.parse(content)
      return {
        success: true,
        suggestions: parsed.suggestions || [],
        explanation: parsed.explanation || 'Optimization suggestions generated'
      }
    } catch (parseError) {
      return {
        success: true,
        suggestions: [
          {
            type: 'improvement',
            text: 'Consider optimizing for better performance',
            confidence: 0.6,
            description: 'General optimization suggestion'
          }
        ],
        explanation: 'Basic optimization suggestions provided'
      }
    }
  } catch (error) {
    return {
      success: false,
      error: 'Failed to generate optimization suggestions'
    }
  }
}

async function generateExplanation(
  zai: ZAI, 
  code: string, 
  context: string, 
  language: string
): Promise<SuggestionResponse> {
  const systemPrompt = `You are an expert code explanation assistant. Analyze the provided code and provide clear, detailed explanations of what it does and how it works.

Provide explanations for:
1. Overall purpose and functionality
2. Key algorithms and logic flow
3. Important functions and their roles
4. Data structures and their usage
5. Design patterns and architectural decisions
6. Potential use cases and applications

Language: ${language}

Respond with a JSON object containing:
{
  "suggestions": [
    {
      "type": "explanation",
      "text": "detailed explanation of the code",
      "confidence": 0.9,
      "description": "Summary of what this code does"
    }
  ],
  "explanation": "Comprehensive code explanation"
}`

  try {
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Code:\n${code}\n\nContext:\n${context}` }
      ],
      temperature: 0.2,
      max_tokens: 3000,
      top_p: 0.7
    })

    const content = completion.choices[0]?.message?.content || ''
    
    try {
      const parsed = JSON.parse(content)
      return {
        success: true,
        suggestions: parsed.suggestions || [],
        explanation: parsed.explanation || 'Code explanation generated'
      }
    } catch (parseError) {
      return {
        success: true,
        suggestions: [
          {
            type: 'explanation',
            text: 'This code appears to implement functionality based on the context provided.',
            confidence: 0.7,
            description: 'Basic code explanation'
          }
        ],
        explanation: 'Basic code explanation provided'
      }
    }
  } catch (error) {
    return {
      success: false,
      error: 'Failed to generate code explanation'
    }
  }
}